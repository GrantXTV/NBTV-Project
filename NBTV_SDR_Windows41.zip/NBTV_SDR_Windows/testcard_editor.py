"""Test card editor for the NBTV OFDM Lab - brought over from ExSDR (Grant Taylor VE3XTV).

A test card (PM5544, Colourful, Dish, IDTV, TestF, Bars, ATV, ATV basic, the lab's own) or any picture of
yours, with two lines of text on it (font, size, colour, bold, black box), placed by dragging.  Set + Save
writes it to Pictures/NBTV Lab and makes it the lab's Picture source.

The cards are in the "testcards" folder next to this file; put your own in Pictures/NBTV Lab test cards
(any of PNG, GIF, JPEG, BMP, WebP, TIFF, PPM).  Text needs Pillow (python3-pil) for real fonts; without it
a built-in dot font is used."""
import os
import glob
import json
import time
import subprocess
import numpy as np
import tkinter as tk
from tkinter import ttk
try:
    from tkinter import filedialog
except ImportError:
    filedialog = None
try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    Image = ImageDraw = ImageFont = None


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def pictures_dir():
    """The user's Pictures folder (XDG on Linux, ~/Pictures elsewhere)."""
    home = os.path.expanduser("~")
    try:
        cfgp = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config"), "user-dirs.dirs")
        with open(cfgp) as f:
            for line in f:
                if line.startswith("XDG_PICTURES_DIR"):
                    v = line.split("=", 1)[1].strip().strip('"').replace("$HOME", home)
                    if os.path.isdir(v):
                        return v
    except OSError:
        pass
    d = os.path.join(home, "Pictures")
    return d if os.path.isdir(d) else home


# The test cards: (button, file name without extension), in the "testcards" folder next to this file or in
# Pictures/NBTV Lab test cards.  "NBTV Lab" is the lab's own test card, drawn by the program.
TESTCARDS = (("PM5544", "PM5544"), ("Colourful", "COLFUL"), ("Dish", "DISH"), ("IDTV", "IDCARD"),
             ("TestF", "TestF"), ("TestX", "TestX"), ("Bars", "Bars"), ("ATV", "ATV"), ("ATVBasic", "ATVB"),
             ("NBTV Lab", None))
CARDS_169 = ("TestX",)                            # (5.60) cards drawn 16:9 (squeezed into a 4:3 frame): Fit starts on Scale
TC_EXTS = (".gif", ".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff", ".ppm")
TC_WORK_W = 862                                   # big pictures are worked on at this width
IMG_TYPES = [("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.ppm *.pgm *.webp *.tif *.tiff"), ("All files", "*")]


def testcard_dirs():
    return [os.path.join(os.path.dirname(os.path.abspath(__file__)), "testcards"),
            os.path.join(pictures_dir(), "NBTV Lab test cards")]


def testcard_path(stem):
    """The file for a test card button, or None."""
    if not stem:
        return None
    for d in testcard_dirs():
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for n in sorted(names):
            b, e = os.path.splitext(n)
            if b.lower() == stem.lower() and e.lower() in TC_EXTS:
                return os.path.join(d, n)
    return None


_FONTS = None


class Host:
    """What the editor needs from the window that opens it (ExSDR's names, the lab's look).
    app: the lab's window - cfg, root, log(), and use_picture(path, img) / builtin_card(w, h)."""

    def __init__(self, app, colours, fonts):
        self.lab = app
        self.root, self.cfg, self.log = app.root, app.cfg, app.log
        self.ui = app.cfg.setdefault("tc", {})          # (the editor's settings, kept with the lab's)
        (self.BG, self.CARD, self.FG, self.MUTED, self.ACC, self.FIELD, self.BORDER, self.DISPLAY) = colours
        self.SEL, self.HOVER = "#2d5f91", "#3d4651"
        self.F, self.F_SMALL, self.F_HEAD = fonts
        self.IMG_TYPES = IMG_TYPES
        self.tc_editor = None

    def use_picture(self, path, img):
        self.lab.tc_use_picture(path, img)

    def builtin_card(self, w, h):
        return self.lab.tc_builtin_card(w, h)

    @staticmethod
    def _bg(widget):
        try:
            return widget["bg"]
        except Exception:
            return "#262b31"

    def frame(self, parent):
        return tk.Frame(parent, bg=self._bg(parent))

    def group(self, parent, title):
        f = tk.Frame(parent, bg=self.CARD, highlightthickness=1, highlightbackground=self.BORDER)
        if title:
            tk.Label(f, text=title, bg=self.CARD, fg=self.ACC, font=self.F_HEAD).pack(anchor="w", padx=6, pady=(3, 1))
        return f

    def lbl(self, parent, text, muted=False, **kw):
        return tk.Label(parent, text=text, bg=self._bg(parent), fg=self.MUTED if muted else self.FG,
                        font=kw.pop("font", self.F), **kw)

    def btn(self, parent, text, cmd, **kw):
        return tk.Button(parent, text=text, command=cmd, bg="#323942", fg=self.FG, activebackground=self.HOVER,
                         activeforeground=self.FG, relief=tk.FLAT, font=self.F, padx=6, pady=1,
                         highlightthickness=0, **kw)

    def toggle(self, parent, text, variable, value=None, cmd=None, width=None, color=None):
        """Flat push button that stays pressed (radio button when value is given)."""
        common = dict(text=text, variable=variable, command=cmd, indicatoron=False, width=width,
                      bg="#323942", fg=self.FG, selectcolor=color or self.SEL, activebackground=self.HOVER,
                      activeforeground=self.FG, relief=tk.FLAT, bd=0, offrelief=tk.FLAT, highlightthickness=0,
                      font=self.F, padx=6, pady=2, cursor="hand2")
        if value is None:
            return tk.Checkbutton(parent, **common)
        return tk.Radiobutton(parent, value=value, **common)


def open_editor(host):
    """Open the editor (or bring the open one forward)."""
    ed = host.tc_editor
    if ed is not None:
        try:
            ed.win.deiconify()
            ed.win.lift()
            return ed
        except Exception:
            host.tc_editor = None
    host.tc_editor = TestCardEditor(host, "nbtv")
    return host.tc_editor


WFID_FONT = {
    "A": "01110 10001 10001 11111 10001 10001 10001", "B": "11110 10001 10001 11110 10001 10001 11110",
    "C": "01110 10001 10000 10000 10000 10001 01110", "D": "11100 10010 10001 10001 10001 10010 11100",
    "E": "11111 10000 10000 11110 10000 10000 11111", "F": "11111 10000 10000 11110 10000 10000 10000",
    "G": "01110 10001 10000 10111 10001 10001 01111", "H": "10001 10001 10001 11111 10001 10001 10001",
    "I": "01110 00100 00100 00100 00100 00100 01110", "J": "00111 00010 00010 00010 00010 10010 01100",
    "K": "10001 10010 10100 11000 10100 10010 10001", "L": "10000 10000 10000 10000 10000 10000 11111",
    "M": "10001 11011 10101 10101 10001 10001 10001", "N": "10001 10001 11001 10101 10011 10001 10001",
    "O": "01110 10001 10001 10001 10001 10001 01110", "P": "11110 10001 10001 11110 10000 10000 10000",
    "Q": "01110 10001 10001 10001 10101 10010 01101", "R": "11110 10001 10001 11110 10100 10010 10001",
    "S": "01111 10000 10000 01110 00001 00001 11110", "T": "11111 00100 00100 00100 00100 00100 00100",
    "U": "10001 10001 10001 10001 10001 10001 01110", "V": "10001 10001 10001 10001 10001 01010 00100",
    "W": "10001 10001 10001 10101 10101 10101 01010", "X": "10001 10001 01010 00100 01010 10001 10001",
    "Y": "10001 10001 10001 01010 00100 00100 00100", "Z": "11111 00001 00010 00100 01000 10000 11111",
    "0": "01110 10001 10011 10101 11001 10001 01110", "1": "00100 01100 00100 00100 00100 00100 01110",
    "2": "01110 10001 00001 00010 00100 01000 11111", "3": "11111 00010 00100 00010 00001 10001 01110",
    "4": "00010 00110 01010 10010 11111 00010 00010", "5": "11111 10000 11110 00001 00001 10001 01110",
    "6": "00110 01000 10000 11110 10001 10001 01110", "7": "11111 00001 00010 00100 01000 01000 01000",
    "8": "01110 10001 10001 01110 10001 10001 01110", "9": "01110 10001 10001 01111 00001 00010 01100",
    "/": "00001 00010 00010 00100 01000 01000 10000", "-": "00000 00000 00000 11111 00000 00000 00000",
    ".": "00000 00000 00000 00000 00000 01100 01100", " ": "00000 00000 00000 00000 00000 00000 00000",
}


def fit_image(img, w, h):
    """Scale an RGB array to w x h, filling the frame (centre crop), area-averaged."""
    H, W = img.shape[:2]
    s = max(w / float(W), h / float(H))
    cw, ch = min(W, int(round(w / s))), min(H, int(round(h / s)))
    x0, y0 = (W - cw) // 2, (H - ch) // 2
    crop = img[y0:y0 + ch, x0:x0 + cw].astype(np.float64)
    # area average with cumulative sums (works for up- and down-scaling)
    def axis_resample(a, n, ax):
        m = a.shape[ax]
        edges = np.linspace(0, m, n + 1)
        cs = np.concatenate([np.zeros_like(np.take(a, [0], axis=ax)), np.cumsum(a, axis=ax)], axis=ax)
        idx = np.arange(m + 1)
        lo = edges[:-1]
        hi = np.maximum(edges[1:], lo + 1e-6)
        def at(x):
            i = np.clip(np.floor(x).astype(int), 0, m - 1)
            fr = (x - i).reshape([-1 if k == ax else 1 for k in range(a.ndim)])
            return np.take(cs, i, axis=ax) + fr * (np.take(cs, i + 1, axis=ax) - np.take(cs, i, axis=ax))
        shape = [-1 if k == ax else 1 for k in range(a.ndim)]
        return (at(hi) - at(lo)) / (hi - lo).reshape(shape)
    out = axis_resample(axis_resample(crop, h, 0), w, 1)
    return np.clip(out, 0, 255).astype(np.uint8)


def parse_ppm(data):
    """Binary PPM (P6) / PGM (P5) bytes -> RGB array."""
    toks, i = [], 0
    while len(toks) < 4:
        while data[i:i + 1].isspace():
            i += 1
        if data[i:i + 1] == b"#":
            while data[i:i + 1] not in (b"\n", b""):
                i += 1
            continue
        j = i
        while not data[j:j + 1].isspace():
            j += 1
        toks.append(data[i:j])
        i = j
    i += 1
    kind, w, h, mx = toks[0], int(toks[1]), int(toks[2]), int(toks[3])
    ch = 3 if kind == b"P6" else 1
    dt = np.uint8 if mx < 256 else ">u2"
    a = np.frombuffer(data, dtype=dt, count=w * h * ch, offset=i).reshape(h, w, ch).astype(np.float64)
    a = np.clip(a * 255.0 / mx, 0, 255).astype(np.uint8)
    return np.repeat(a, 3, axis=2) if ch == 1 else a


def read_image(path):
    """Any picture file -> RGB array (Pillow if installed, else Tk: PNG, GIF, PPM, PGM)."""
    if Image is not None:
        with Image.open(path) as im:
            return np.asarray(im.convert("RGB")).copy()
    if path.lower().endswith((".ppm", ".pgm", ".pnm")):
        with open(path, "rb") as f:
            return parse_ppm(f.read())
    ph = tk.PhotoImage(file=path)
    import tempfile
    fd, tmp = tempfile.mkstemp(suffix=".ppm")
    os.close(fd)
    try:
        ph.write(tmp, format="ppm")
        with open(tmp, "rb") as f:
            return parse_ppm(f.read())
    finally:
        os.unlink(tmp)


def save_image(img, path):
    if Image is not None:
        Image.fromarray(np.ascontiguousarray(img)).save(path)
        return
    ppm = b"P6 %d %d 255\n" % (img.shape[1], img.shape[0]) + np.ascontiguousarray(img).tobytes()
    if path.lower().endswith(".ppm"):
        with open(path, "wb") as f:
            f.write(ppm)
        return
    tk.PhotoImage(data=ppm, format="PPM").write(path, format="png")



def list_fonts():
    """{family: {style: font file}} of the fonts Pillow can draw with ({} without Pillow)."""
    global _FONTS
    if _FONTS is not None:
        return _FONTS
    fonts = {}
    if ImageFont is None:
        _FONTS = fonts
        return fonts
    try:                                          # Linux: fontconfig knows them all
        out = subprocess.run(["fc-list", "--format", "%{family[0]}|%{style[0]}|%{file}\n"],
                             capture_output=True, text=True, timeout=10).stdout
        for line in out.splitlines():
            p = line.split("|")
            if len(p) == 3 and p[2].lower().endswith((".ttf", ".otf", ".ttc")):
                fonts.setdefault(p[0].strip(), {}).setdefault(p[1].strip() or "Regular", p[2])
    except Exception:
        pass
    if not fonts:                                 # Windows / macOS / no fc-list: look in the font folders
        dirs = [os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Fonts"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
                "/Library/Fonts", "/System/Library/Fonts", os.path.expanduser("~/Library/Fonts"),
                "/usr/share/fonts", os.path.expanduser("~/.fonts")]
        for d in dirs:
            for path in glob.glob(os.path.join(d, "**", "*.*"), recursive=True)[:1500]:
                if not path.lower().endswith((".ttf", ".otf", ".ttc")):
                    continue
                try:
                    fam, sty = ImageFont.truetype(path, 12).getname()
                except Exception:
                    continue
                fonts.setdefault(fam, {}).setdefault(sty or "Regular", path)
    _FONTS = fonts
    return fonts


def font_file(family, bold):
    """Font file for a family, the bold style when asked (and there is one).  -> (path, real bold)"""
    styles = list_fonts().get(family) or {}
    if not styles:
        return None, False
    def pick(words, avoid=("italic", "oblique")):
        for s, p in styles.items():
            sl = s.lower()
            if all(w in sl for w in words) and not any(a in sl for a in avoid):
                return p
        return None
    exact = {s.lower(): p for s, p in styles.items()}
    odd = ("italic", "oblique", "semi", "demi", "extra", "ultra", "condensed", "narrow", "light", "thin",
           "black", "medium", "heavy")
    if bold:
        p = exact.get("bold") or pick(("bold",), odd) or pick(("bold",))
        if p:
            return p, True
    p = next((exact[k] for k in ("regular", "book", "normal", "roman", "medium") if k in exact), None) or \
        pick(("regular",), odd) or pick(("book",), odd) or pick((), odd) or pick(())
    return (p or list(styles.values())[0]), False


def _dots_text(img, text, cx, y, size, colour):
    """Without Pillow: the waterfall ID 5 x 7 dot font, scaled (capitals and digits only)."""
    d = max(1, int(round(size / 7.0)))
    chars = [c for c in text.upper() if c in WFID_FONT or c == " "]
    w = len(chars) * 6 * d
    x = int(cx - w / 2)
    H, W = img.shape[:2]
    for c in chars:
        if c != " ":
            for r, row in enumerate(WFID_FONT[c].split()):
                for k, b in enumerate(row):
                    if b == "1":
                        y0, x0 = y + r * d, x + k * d
                        img[max(0, y0):max(0, min(H, y0 + d)), max(0, x0):max(0, min(W, x0 + d))] = colour
        x += 6 * d
    return img


def testcard_draw(base, texts, family, size, colour, bold=True, box=False, boxes=None):
    """(The old two-line call, kept: texts [(text, centre x, top y)] at one size.)"""
    return draw_lines(base, [(t, x, y, size) for t, x, y in texts], family, colour, bold,
                      "Box" if box else "Plain", 100, boxes)


# ---------------------------------------------------------------- live text (5.58)
FIELDS = (("callsign", "your callsign"), ("title", "the title"), ("grid", "grid square"), ("freq", "frequency"),
          ("mode", "encoder mode"), ("date", "date (UTC)"), ("time", "local time, with seconds"),
          ("utc", "UTC time, with seconds"))


def field_values(cfg, mode=""):
    """The live fields' values now, from the program's settings."""
    utc, loc = time.gmtime(), time.localtime()
    f = cfg.get("hw_freq")
    return dict(callsign=(cfg.get("callsign", "") or "").strip().upper() or "NBTV",
                title=(cfg.get("title", "") or "").strip(), grid=(cfg.get("grid", "") or "").strip().upper(),
                freq=("%.3f MHz" % float(f)) if f else "", mode=mode or "",
                date=time.strftime("%Y-%m-%d", utc), time=time.strftime("%H:%M:%S", loc),
                utc=time.strftime("%H:%M:%S UTC", utc))


def fill_fields(text, values):
    """{callsign}, {time} ... in a text, filled in (any case); anything else left as it is."""
    out = text
    for k, v in values.items():
        for form in ("{%s}" % k, "{%s}" % k.upper(), "{%s}" % k.capitalize()):
            out = out.replace(form, v)
    return out


def has_fields(texts):
    return any(("{%s}" % k) in t.lower() for t in texts for k, _ in FIELDS)


CONTRAST_AIM = 7.0                                # (5.60) Auto contrast's aim: 7:1, as WCAG's AAA for text


def _lin(c):
    c = np.asarray(c, np.float64) / 255.0
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def luminance(rgb):
    """WCAG relative luminance of sRGB colour(s) (... x 3)."""
    l = _lin(rgb)
    return l[..., 0] * 0.2126 + l[..., 1] * 0.7152 + l[..., 2] * 0.0722


def contrast_ratio(a, b):
    la, lb = luminance(a), luminance(b)
    return (np.maximum(la, lb) + 0.05) / (np.minimum(la, lb) + 0.05)


def auto_panel(colour):
    """Auto background colour: black or white, whichever stands further from the text."""
    return (0, 0, 0) if contrast_ratio(colour, (0, 0, 0)) >= contrast_ratio(colour, (255, 255, 255)) else (255, 255, 255)


def auto_contrast(region, colour, panel, aim=CONTRAST_AIM):
    """(5.60) The least strength k (0-1) of the background over this piece of the card for the text to reach the
    aim's contrast ratio - judged at the background's worst 10 % (a busy card is not let off by its average).
    -> (k, the ratio reached).  If even a solid background falls short, k = 1 and what it reaches."""
    px = np.asarray(region, np.float64).reshape(-1, 3)
    if len(px) > 4000:
        px = px[:: len(px) // 4000 + 1]
    if not len(px):
        return 1.0, float(contrast_ratio(colour, panel))
    pan = np.asarray(panel, np.float64)

    def worst(k):
        return float(np.percentile(contrast_ratio(np.asarray(colour, np.float64)[None, :], px * (1 - k) + pan * k), 10))

    if worst(0.0) >= aim:
        return 0.0, worst(0.0)
    if worst(1.0) < aim:
        return 1.0, worst(1.0)
    lo, hi = 0.0, 1.0
    for _ in range(14):
        mid = (lo + hi) / 2
        if worst(mid) >= aim:
            hi = mid
        else:
            lo = mid
    return hi, worst(hi)


def draw_lines(base, lines, family, colour, bold=True, style="Plain", alpha=100, boxes=None, bg=None, contrast=None,
               bg_colour="auto", ratios=None):
    """(5.58) The test card with text on it.  lines: [(text, centre x, top y, size)].
    style: the letters - Plain, Outline (a dark edge round them: reads at 120x96 without covering the card) or
    Shadow (a dark copy behind, down and right).  (5.59) bg: a background panel behind each line, the card cut
    out behind the text; contrast (0-100 %): how far the panel goes from the card - to black behind light text,
    to white behind dark text, so the text always stands out more.  (5.58's style "Box", with alpha as its
    opacity, is the background on at that contrast.)
    boxes (a list) gets the (x0, y0, x1, y1) of each text, None for an empty one."""
    if style == "Box":
        style, bg, contrast = "Plain", True, alpha if contrast is None else contrast
    bg = bool(bg)
    # (5.60) the background's colour: Auto (black or white, the further from the text) or one chosen; its
    # contrast: a strength (0-100 %) or "auto" (the least that reaches CONTRAST_AIM, line by line)
    panel = auto_panel(colour) if (bg_colour in (None, "auto", "Auto")) else tuple(int(v) for v in bg_colour)
    auto_k = isinstance(contrast, str) and contrast.lower() == "auto"
    k = 1.0 if auto_k else clamp(100.0 if contrast is None else float(contrast), 0.0, 100.0) / 100.0
    if ratios is not None:
        del ratios[:]
    img = np.ascontiguousarray(base[..., :3]).copy()
    if boxes is not None:
        del boxes[:]
    path, real_bold = font_file(family, bold)
    if ImageDraw is None or path is None:
        for t, x, y, size in lines:
            d = max(1, int(round(size / 7.0)))
            w = len(t) * 6 * d
            if boxes is not None:
                boxes.append((x - w / 2.0, y, x + w / 2.0, y + 7 * d) if t.strip() else None)
            if t.strip():
                if bg:
                    sl = (slice(max(0, y - d), y + 8 * d), slice(max(0, int(x - w / 2 - d)), int(x + w / 2 + d)))
                    kk, cr = auto_contrast(img[sl], colour, panel) if auto_k else (k, None)
                    img[sl] = (img[sl] * (1 - kk) + np.array(panel) * kk).astype(np.uint8)
                    if ratios is not None:
                        ratios.append((kk, cr))
                if style in ("Outline", "Shadow"):
                    offs = ((d, d),) if style == "Shadow" else ((-d, 0), (d, 0), (0, -d), (0, d))
                    for ox, oy in offs:
                        _dots_text(img, t, x + ox, y + oy, size, (0, 0, 0))
                _dots_text(img, t, x, y, size, colour)
        return img
    im = Image.fromarray(img).convert("RGBA")
    over = Image.new("RGBA", im.size, (0, 0, 0, 0))
    dr = ImageDraw.Draw(over)
    for t, x, y, size in lines:
        if not t.strip():
            if boxes is not None:
                boxes.append(None)
            continue
        try:
            font = ImageFont.truetype(path, max(4, int(size)))
        except Exception:
            font = ImageFont.load_default()
        sw = 0 if real_bold or not bold else max(1, int(size / 30))       # no bold face: thicken it
        l, tp, r, b = dr.textbbox((0, 0), t, font=font, stroke_width=sw)
        x0 = x - (r - l) / 2.0 - l
        if boxes is not None:
            boxes.append((x0 + l, y + tp, x0 + r, y + b))
        fill = tuple(colour) + (255,)
        if bg:
            pad = max(2, int(size / 8))
            rx0, ry0, rx1, ry1 = [int(round(v)) for v in (x0 + l - pad, y + tp - pad, x0 + r + pad, y + b + pad)]
            if auto_k:
                H_, W_ = img.shape[:2]
                kk, cr = auto_contrast(img[max(0, ry0):max(0, min(H_, ry1)), max(0, rx0):max(0, min(W_, rx1))],
                                       colour, panel)
            else:
                kk, cr = k, None
            if ratios is not None:
                if cr is None:                            # (the ratio it reaches, for the editor to show)
                    H_, W_ = img.shape[:2]
                    reg = img[max(0, ry0):max(0, min(H_, ry1)), max(0, rx0):max(0, min(W_, rx1))].reshape(-1, 3)
                    if len(reg):
                        reg = reg.astype(np.float64) * (1 - kk) + np.asarray(panel, np.float64) * kk
                        cr = float(np.percentile(contrast_ratio(np.asarray(colour, np.float64)[None, :], reg), 10))
                ratios.append((kk, cr))
            dr.rectangle((rx0, ry0, rx1, ry1), fill=panel + (int(round(kk * 255)),))
        if style == "Shadow":
            o = max(2, int(round(size / 14.0)))
            dr.text((x0 + o, y + o), t, font=font, fill=(0, 0, 0, 255), stroke_width=sw, stroke_fill=(0, 0, 0, 255))
        if style == "Outline":
            ow = max(2, int(round(size / 12.0))) + sw
            dr.text((x0, y), t, font=font, fill=fill, stroke_width=ow, stroke_fill=(0, 0, 0, 255))
        dr.text((x0, y), t, font=font, fill=fill, stroke_width=sw, stroke_fill=fill)
    im = Image.alpha_composite(im, over).convert("RGB")
    return np.asarray(im).copy()


# ---------------------------------------------------------------- NBTV test patterns (5.58)
# Frequencies in cycles across the picture's width (or down its height): 120 wide carries up to 60, 180 wide
# up to 90, the 240x192 detail up to 120; 96 lines up to 48 down the height, 192 up to 96.
PATTERNS = ("Multiburst", "Wedges", "Grey steps", "Bars 75%", "Bars 100%", "PLUGE", "Zone plate")
LIMITS_W = ((60, "120"), (90, "180"), (120, "240"))
LIMITS_H = ((48, "96"), (96, "192"))


def _label(img, items):
    """Small labels [(text, x, y)] in white on black, on a pattern."""
    if ImageDraw is None:
        return img
    im = Image.fromarray(img)
    dr = ImageDraw.Draw(im)
    path, _ = font_file("DejaVu Sans", True)
    try:
        font = ImageFont.truetype(path, 17) if path else ImageFont.load_default()
    except Exception:
        font = ImageFont.load_default()
    for t, x, y in items:
        l, tp, r, b = dr.textbbox((0, 0), t, font=font)
        dr.rectangle((x - 2 + l, y - 1 + tp, x + r + 2, y + b + 1), fill=(0, 0, 0))
        dr.text((x, y), t, font=font, fill=(255, 255, 255))
    return np.asarray(im).copy()


def make_pattern(name, W=864, H=648):
    """An NBTV test pattern, W x H (4:3), as RGB.  Bursts and wedges are marked at the formats' limits."""
    X = (np.arange(W) + 0.5) / W
    Y = (np.arange(H) + 0.5) / H
    img = np.zeros((H, W, 3), np.float32)
    lab = []
    if name == "Multiburst":
        # top: bursts across (cycles a width), bottom: bursts down (cycles a height); grey 50 % between
        img[:] = 128
        fr = (15, 30, 45, 60, 75, 90, 105, 120)
        n = len(fr)
        for k, f in enumerate(fr):
            x0, x1 = int(W * k / n), int(W * (k + 1) / n)
            img[int(H * 0.12):int(H * 0.47), x0 + 3:x1 - 3] = (128 + 100 * np.cos(2 * np.pi * f * X[x0 + 3:x1 - 3]))[None, :, None]
            mark = {60: " =120w", 90: " =180w", 120: " =240w"}.get(f, "")
            lab.append(("%d%s" % (f, mark), x0 + 6, int(H * 0.04)))
        fv = (12, 24, 36, 48, 60, 72, 84, 96)
        for k, f in enumerate(fv):
            x0, x1 = int(W * k / n), int(W * (k + 1) / n)
            img[int(H * 0.55):int(H * 0.90), x0 + 3:x1 - 3] = (128 + 100 * np.cos(2 * np.pi * f * Y[int(H * 0.55):int(H * 0.90)]))[:, None, None]
            mark = {48: " =96", 96: " =192"}.get(f, "")
            lab.append(("%d%s" % (f, mark), x0 + 6, int(H * 0.915)))
        lab.append(("cycles across (picture width) - marked: the widths that carry them", 8, int(H * 0.49)))
    elif name == "Wedges":
        # a wedge across: lines whose frequency rises from 10 to 150 cycles a width, left to right in each row
        img[:] = 0
        top, bot = int(H * 0.08), int(H * 0.46)
        f = 10 + 140 * X                                      # cycles a width, at each x
        ph = np.cumsum(f) / W                                 # (the phase: a chirp)
        img[top:bot] = (128 + 120 * np.cos(2 * np.pi * ph))[None, :, None]
        # and down (in the lower half): 6 to 110 cycles a height, top to bottom
        l0, l1 = int(W * 0.16), int(W * 0.96)
        y0 = int(H * 0.52)
        fy = np.zeros(H)
        fy[y0:] = 6 + 104 * (np.arange(H - y0) / float(H - y0))
        phy = np.cumsum(fy) / H
        img[y0:, l0:l1] = (128 + 120 * np.cos(2 * np.pi * phy[y0:]))[:, None, None]
        for c, t in LIMITS_W:
            x = int(W * (c - 10) / 140.0)
            img[bot:bot + 14, x - 1:x + 2] = 255
            lab.append((t + " wide", x - 20, bot + 16))
        for c, t in LIMITS_H:
            y = y0 + int((H - y0) * (c - 6) / 104.0)
            img[y - 1:y + 2, l0 - 16:l0 - 2] = 255
            lab.append((t + " lines", 4, y - 24))
        lab.append(("10 to 150 cycles across", 8, int(H * 0.005)))
    elif name == "Grey steps":
        n = 11
        for k in range(n):
            x0, x1 = int(W * k / n), int(W * (k + 1) / n)
            img[:int(H * 0.6), x0:x1] = round(255 * k / (n - 1))
            lab.append(("%d%%" % (10 * k), x0 + 4, int(H * 0.62)))
        img[int(H * 0.7):, :] = (255 * X)[None, :, None]       # and a smooth ramp below
    elif name in ("Bars 75%", "Bars 100%"):
        v = 191 if name == "Bars 75%" else 255
        cols = [(255, 255, 255), (v, v, 0), (0, v, v), (0, v, 0), (v, 0, v), (v, 0, 0), (0, 0, v), (0, 0, 0)]
        for k, c in enumerate(cols):
            img[:int(H * 0.75), int(W * k / 8):int(W * (k + 1) / 8)] = c
        n = 8
        for k in range(n):                                    # below: a grey scale to compare against
            img[int(H * 0.75):, int(W * k / n):int(W * (k + 1) / n)] = round(255 * k / (n - 1))
    elif name == "PLUGE":
        # black level: bars just above black (1, 2, 4, 8 %) on black, with white and 50 % grey for reference -
        # set brightness and contrast so 2 % just shows and the black stays black
        img[:] = 0
        for k, lv in enumerate((1, 2, 4, 8)):
            x0 = int(W * (0.10 + 0.16 * k))
            img[int(H * 0.15):int(H * 0.85), x0:x0 + int(W * 0.10)] = 2.55 * lv
            lab.append(("%d%%" % lv, x0 + 10, int(H * 0.87)))
        img[int(H * 0.15):int(H * 0.40), int(W * 0.80):int(W * 0.94)] = 255
        img[int(H * 0.45):int(H * 0.60), int(W * 0.80):int(W * 0.94)] = 128
        lab.append(("black level: 2 % should just show, the black stay black", 8, int(H * 0.03)))
    elif name == "Zone plate":
        # circles whose frequency rises from the centre: 0 there, 120 cycles a width at the left and right edges
        xx = (X - 0.5)[None, :]
        yy = ((Y - 0.5) * H / W)[:, None]
        r2 = xx * xx + yy * yy
        img[:] = (128 + 120 * np.cos(np.pi * 240.0 * r2))[..., None]   # (local frequency 240 r: 120 at r = 0.5)
        lab.append(("0 at the centre, 120 cycles across at the sides", 8, int(H * 0.005)))
    img = np.clip(img, 0, 255).astype(np.uint8)
    return _label(img, lab)


# ---------------------------------------------------------------- a saved card, for the source to redraw
class LiveCard:
    """(5.58) A card saved with live fields: Set + Save writes the card without text (-base.png) and the text's
    layout (.json) beside the picture; the lab's and NBTV SDR's Picture source redraw the text from them with the
    fields' values now (the clock ticks), and send that."""

    def __init__(self, path):
        stem = os.path.splitext(path)[0]
        with open(stem + ".json") as f:
            self.lay = json.load(f)
        self.base = read_image(os.path.join(os.path.dirname(path), self.lay["base"]))
        self.last = None

    @staticmethod
    def find(path):
        """The live card for a saved picture, or None (no layout beside it, or no fields in its text)."""
        try:
            stem = os.path.splitext(path)[0]
            if not os.path.isfile(stem + ".json"):
                return None
            lc = LiveCard(path)
            return lc if has_fields([ln[0] for ln in lc.lay["lines"]]) else None
        except Exception:
            return None

    def picture(self, values):
        """-> the card with its fields filled in now, or None if the text is as last time."""
        L = self.lay
        texts = [fill_fields(t, values) for t, _, _, _ in L["lines"]]
        if texts == self.last:
            return None
        self.last = texts
        h, w = self.base.shape[:2]
        lines = [(t, int(round(fx * w)), int(round(fy * h)), sz) for t, (_, fx, fy, sz) in zip(texts, L["lines"])]
        return draw_lines(self.base, lines, L["font"], tuple(L["colour"]), L.get("bold", True), L.get("style", "Plain"),
                          L.get("alpha", 100), bg=L.get("bg"), contrast=L.get("contrast"),
                          bg_colour=L.get("bg_colour", "auto"))


class TestCardEditor:
    """Test card editor (from ExSDR): a test card, an NBTV test pattern or your own picture, with up to four lines
    of text on it (live fields too), saved to Pictures/NBTV Lab and used as the picture source, ready to send.
    5.58: four lines each with its own size, Outline / Shadow / Box (with opacity), live fields ({callsign},
    {time}...), the NBTV test patterns, and a preview as sent - at the format's size, or through the codec."""
    SWATCHES = ("#ffffff", "#000000", "#ffff00", "#00ffff", "#00ff00", "#ff00ff", "#ff0000", "#0000ff",
                "#ff8000", "#808080", "#c0c0c0", "#800000", "#008000", "#000080", "#804000", "#ff80c0")
    NL = 4                                                # text lines
    LINE_NAMES = ("Line 1", "Line 2", "Line 3", "Line 4")
    STYLES = ("Plain", "Outline", "Shadow")
    RATIOS = ("4:3", "16:9")
    VIEWS = ("Edit", "As sent", "After codec")

    def __init__(self, app, target):
        self.app, self.target = app, target
        a, ui = app, app.ui
        self.win = w = tk.Toplevel(app.root)
        w.title("Test Card Editor")
        w.configure(bg=a.BG)
        w.geometry("1180x820")
        w.protocol("WM_DELETE_WINDOW", self.close)
        self.base = None                                  # the card without text (RGB array)
        self.card = ui.get("tc_card", "PM5544")
        self.img = None
        self.pending = None
        self.dh = None                                    # (the codec preview's decoder)
        call = (app.cfg.get("callsign", "") or "").strip().upper()
        # the lines: [text, x (fraction of the width, centre), y (fraction of the height, top), size]
        lines = ui.get("tc_lines")
        if not (isinstance(lines, list) and len(lines) == self.NL):
            sz = int(ui.get("tc_size", 38))                # (from the two-line editor's settings)
            lines = [[ui.get("tc_upper", call or "NBTV"), ui.get("tc_ux", 0.5), ui.get("tc_uy", 0.084), sz],
                     [ui.get("tc_lower", "Test TX"), ui.get("tc_lx", 0.5), ui.get("tc_ly", 0.775), sz],
                     ["", 0.5, 0.45, sz], ["", 0.5, 0.88, max(8, sz * 2 // 3)]]
        self.lines = [list(x) for x in lines]
        self.sel = 0
        # ---- top: test cards and patterns, the lines' text
        top = a.frame(w)
        top.configure(bg=a.BG)
        top.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(6, 2))
        right_t = a.frame(top)
        right_t.pack(side=tk.RIGHT, padx=(8, 0))
        hdr = a.frame(right_t)
        hdr.grid(row=0, column=0, columnspan=4, sticky="we")
        a.lbl(hdr, "Text  (size each line)", muted=True, font=a.F_SMALL).pack(side=tk.LEFT)
        self.v_field = tk.StringVar(value="Insert field...")
        fc = ttk.Combobox(hdr, textvariable=self.v_field, state="readonly", width=24,
                          values=["{%s}  %s" % (k, d) for k, d in FIELDS])
        fc.pack(side=tk.RIGHT)
        fc.bind("<<ComboboxSelected>>", lambda e: self.insert_field())
        self.v_sel = tk.IntVar(value=0)
        self.v_text, self.v_lsize, self.entries_t = [], [], []
        for r in range(self.NL):
            a.toggle(right_t, self.LINE_NAMES[r], self.v_sel, value=r, cmd=self.select_line, width=6).grid(
                row=r + 1, column=0, sticky="w", pady=1)
            v = tk.StringVar(value=self.lines[r][0])
            v.trace_add("write", lambda *_, r=r: self.text_changed(r))
            e = tk.Entry(right_t, textvariable=v, width=30, bg=a.FIELD, fg=a.FG, insertbackground=a.FG,
                         relief=tk.FLAT, highlightthickness=1, highlightbackground=a.BORDER)
            e.grid(row=r + 1, column=1, pady=1, padx=(3, 3))
            e.bind("<FocusIn>", lambda ev, r=r: (self.v_sel.set(r), self.select_line()))
            vs = tk.IntVar(value=int(self.lines[r][3]))
            sp = tk.Spinbox(right_t, from_=8, to=300, width=4, textvariable=vs, command=lambda r=r: self.size_changed(r),
                            bg=a.FIELD, fg=a.FG, buttonbackground=a.CARD, relief=tk.FLAT, highlightthickness=1,
                            highlightbackground=a.BORDER)
            sp.grid(row=r + 1, column=2)
            sp.bind("<KeyRelease>", lambda ev, r=r: self.size_changed(r))
            self.v_text.append(v)
            self.v_lsize.append(vs)
            self.entries_t.append(e)
        left_t = a.frame(top)
        left_t.pack(side=tk.LEFT, fill=tk.X, expand=True)
        cards = a.frame(left_t)
        cards.pack(fill=tk.X)
        self.v_card = tk.StringVar(value=self.card)
        self.card_btns = {}
        for name, stem in TESTCARDS:
            b = a.toggle(cards, name, self.v_card, value=name, cmd=lambda n=name: self.load_card(n), width=8)
            b.pack(side=tk.LEFT, padx=1)
            self.card_btns[name] = b
            if stem and testcard_path(stem) is None:
                b.config(state=tk.DISABLED)               # file not there
        pats = a.frame(left_t)
        pats.pack(fill=tk.X, pady=(3, 0))
        a.lbl(pats, "NBTV patterns", muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(0, 4))
        for name in PATTERNS:
            b = a.toggle(pats, name, self.v_card, value="P:" + name, cmd=lambda n=name: self.load_pattern(n))
            b.pack(side=tk.LEFT, padx=1)
        pos = a.group(left_t, "")
        pos.pack(fill=tk.X, pady=(4, 0))
        self.pos_title = a.lbl(pos, "Line 1", font=a.F_SMALL)
        self.pos_title.pack(side=tk.LEFT, padx=(6, 6))
        self.scales = []
        for j, ax in enumerate(("X", "Y")):
            a.lbl(pos, ax, muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(6 if j else 0, 2))
            v = tk.DoubleVar(value=0)
            sc = ttk.Scale(pos, from_=0, to=100, orient=tk.HORIZONTAL, length=130, variable=v,
                           command=lambda _x, j=j: self.slid(j))
            sc.pack(side=tk.LEFT)
            vl = tk.Label(pos, text="", width=4, bg=a._bg(pos), fg=a.FG, font=a.F_SMALL)
            vl.pack(side=tk.LEFT)
            self.scales.append((sc, v, vl))
        for t, fy in (("Top", 0.06), ("Middle", 0.45), ("Bottom", 0.84)):
            a.btn(pos, t, lambda fy=fy: self.quick(fy=fy)).pack(side=tk.LEFT, padx=1)
        a.btn(pos, "Centre", lambda: self.quick(fx=0.5)).pack(side=tk.LEFT, padx=(4, 1))
        # ---- right column: colour, font, style, save, your own pictures
        side = a.group(w, "")
        side.pack(side=tk.RIGHT, fill=tk.Y, padx=(2, 6), pady=(2, 6))
        # (5.59) the picture's shape: the card cut to it while you design (the patterns drawn at it); on Set + Save
        # the program's aspect is set to it, so the card goes out as designed
        rr = a.frame(side)
        rr.pack(fill=tk.X, pady=(0, 6))
        a.lbl(rr, "Picture ratio", muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(0, 6))
        r0 = app.cfg.get("aspect", "4:3")
        self.v_ratio = tk.StringVar(value=r0 if r0 in self.RATIOS else "4:3")
        for nm in self.RATIOS:
            a.toggle(rr, nm, self.v_ratio, value=nm, cmd=self.ratio_changed, width=5).pack(side=tk.LEFT, padx=1)
        # (5.61) how a picture of another shape is made to fit: Crop (the middle, cut to the ratio) or Scale (the
        # whole of it, resized to the ratio) - kept for each card (TestX, drawn 16:9, starts on Scale)
        fr = a.frame(side)
        fr.pack(fill=tk.X, pady=(0, 6))
        a.lbl(fr, "Fit", muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(0, 6))
        self.v_fit = tk.StringVar(value="Crop")
        self.fit_btns = []
        for nm in ("Crop", "Scale"):
            b = a.toggle(fr, nm, self.v_fit, value=nm, cmd=self.fit_changed, width=5)
            b.pack(side=tk.LEFT, padx=1)
            self.fit_btns.append(b)
        self.fit_lbl = a.lbl(fr, "", muted=True, font=a.F_SMALL)
        self.fit_lbl.pack(side=tk.LEFT, padx=(6, 0))
        a.lbl(side, "Text colour", muted=True, font=a.F_SMALL).pack(anchor="w")
        sw = a.frame(side)
        sw.pack(anchor="w", pady=(2, 2))
        for k, c in enumerate(self.SWATCHES):
            b = tk.Label(sw, bg=c, width=3, height=1, relief=tk.FLAT, highlightthickness=1,
                         highlightbackground=a.BORDER, cursor="hand2")
            b.grid(row=k // 8, column=k % 8, padx=1, pady=1)
            b.bind("<Button-1>", lambda e, c=c: self.set_colour(c))
        cr = a.frame(side)
        cr.pack(fill=tk.X, pady=(2, 6))
        self.colour = ui.get("tc_colour", "#ffffff")
        self.col_show = tk.Label(cr, bg=self.colour, width=6, highlightthickness=1, highlightbackground=a.BORDER)
        self.col_show.pack(side=tk.LEFT)
        a.btn(cr, "More...", self.pick_colour).pack(side=tk.LEFT, padx=4)
        a.lbl(side, "Font", muted=True, font=a.F_SMALL).pack(anchor="w")
        fams = sorted(list_fonts(), key=str.lower) or ["Built-in dots"]
        want = ui.get("tc_font")
        if want not in fams:
            want = next((f for f in ("DejaVu Sans", "Arial", "Liberation Sans", "FreeSans", "Helvetica")
                         if f in fams), fams[0])
        self.v_font = tk.StringVar(value=want)
        fcb = ttk.Combobox(side, textvariable=self.v_font, values=fams, width=24, state="readonly")
        fcb.pack(fill=tk.X)
        fcb.bind("<<ComboboxSelected>>", lambda e: self.redraw_soon())
        ob = a.frame(side)
        ob.pack(fill=tk.X, pady=(4, 0))
        self.v_bold = tk.IntVar(value=int(ui.get("tc_bold", 1)))
        a.toggle(ob, "Bold", self.v_bold, cmd=self.redraw_soon).pack(side=tk.LEFT)
        a.lbl(side, "Letters  (Outline reads best at 120x96)", muted=True, font=a.F_SMALL).pack(anchor="w", pady=(6, 0))
        st = a.frame(side)
        st.pack(fill=tk.X)
        st0 = ui.get("tc_style", "Box" if int(ui.get("tc_box", 0)) else "Plain")
        bg0 = int(ui.get("tc_bg", 1 if st0 == "Box" else 0))      # (5.58's Box: the background, on)
        self.v_style = tk.StringVar(value=st0 if st0 in self.STYLES else "Plain")
        for nm in self.STYLES:
            a.toggle(st, nm, self.v_style, value=nm, cmd=self.redraw_soon).pack(side=tk.LEFT, padx=(0, 1))
        # (5.59) a background behind the text: the card cut out behind each line, on or off, and how far it goes
        # from the card (dark behind light text, light behind dark text)
        al = a.frame(side)
        al.pack(fill=tk.X, pady=(6, 0))
        self.v_bg = tk.IntVar(value=bg0)
        a.toggle(al, "Background", self.v_bg, cmd=self.redraw_soon).pack(side=tk.LEFT)
        # (5.60) its colour: Auto (black or white, whichever stands further from the text) or one chosen
        bc = a.frame(side)
        bc.pack(fill=tk.X, pady=(2, 0))
        a.lbl(bc, "Colour", muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(0, 4))
        self.bg_colour = ui.get("tc_bg_colour", "auto")
        self.v_bgauto = tk.IntVar(value=1 if self.bg_colour == "auto" else 0)
        a.toggle(bc, "Auto", self.v_bgauto, cmd=self.bg_auto_changed).pack(side=tk.LEFT)
        for c in ("#000000", "#ffffff", "#808080", "#000080", "#ffff00", "#800000"):
            b = tk.Label(bc, bg=c, width=2, height=1, relief=tk.FLAT, highlightthickness=1,
                         highlightbackground=a.BORDER, cursor="hand2")
            b.pack(side=tk.LEFT, padx=1)
            b.bind("<Button-1>", lambda e, c=c: self.set_bg_colour(c))
        a.btn(bc, "More...", self.pick_bg_colour).pack(side=tk.LEFT, padx=(3, 0))
        self.bg_show = tk.Label(bc, width=2, highlightthickness=1, highlightbackground=a.BORDER)
        self.bg_show.pack(side=tk.LEFT, padx=(4, 0))
        # its contrast: a strength, or Auto - the least that gives the text a 7:1 contrast ratio over the card
        cl = a.frame(side)
        cl.pack(fill=tk.X, pady=(2, 0))
        a.lbl(cl, "Contrast", muted=True, font=a.F_SMALL).pack(side=tk.LEFT)
        self.v_cauto = tk.IntVar(value=int(ui.get("tc_contrast_auto", 0)))
        a.toggle(cl, "Auto", self.v_cauto, cmd=self.redraw_soon).pack(side=tk.LEFT, padx=(4, 0))
        self.v_alpha = tk.DoubleVar(value=float(ui.get("tc_contrast", ui.get("tc_alpha", 70))))
        self.alpha_sc = ttk.Scale(cl, from_=0, to=100, orient=tk.HORIZONTAL, variable=self.v_alpha,
                                  command=lambda _x: self.alpha_moved())
        self.alpha_sc.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        self.alpha_lbl = tk.Label(cl, text="%d%%" % self.v_alpha.get(), width=5, bg=a._bg(cl), fg=a.FG, font=a.F_SMALL)
        self.alpha_lbl.pack(side=tk.LEFT)
        self.ratio_lbl = tk.Label(side, text="", bg=a._bg(side), fg=a.MUTED, font=a.F_SMALL, anchor="w")
        self.ratio_lbl.pack(fill=tk.X)
        self.show_bg_colour()
        a.btn(side, "Set + Save", self.save).pack(fill=tk.X, pady=(10, 2))
        a.btn(side, "User file", self.user_file).pack(fill=tk.X, pady=(2, 4))
        self.dir = ui.get("tc_dir") or pictures_dir()
        self.dir_lbl = tk.Label(side, text="", bg=a._bg(side), fg=a.MUTED, font=a.F_SMALL, anchor="w",
                                width=30)
        self.dir_lbl.pack(fill=tk.X)
        lf = a.frame(side)
        lf.pack(fill=tk.BOTH, expand=True)
        self.files = tk.Listbox(lf, bg=a.FIELD, fg=a.FG, selectbackground=a.SEL, relief=tk.FLAT,
                                highlightthickness=1, highlightbackground=a.BORDER, activestyle="none",
                                exportselection=False, width=30)
        sb = ttk.Scrollbar(lf, orient=tk.VERTICAL, command=self.files.yview)
        self.files.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.files.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.files.bind("<Double-Button-1>", lambda e: self.user_file())
        self.files.bind("<Return>", lambda e: self.user_file())
        a.lbl(side, "Double-click a folder to open it,\na picture to use it.", muted=True,
              font=a.F_SMALL).pack(anchor="w", pady=(2, 0))
        # ---- under the picture: the view (edit, or as it will be sent)
        vb = a.frame(w)
        vb.configure(bg=a.BG)
        vb.pack(side=tk.BOTTOM, fill=tk.X, padx=6, pady=(0, 6))
        a.lbl(vb, "View", muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(0, 4))
        self.v_view = tk.StringVar(value="Edit")
        for nm in self.VIEWS:
            a.toggle(vb, nm, self.v_view, value=nm, cmd=self.redraw_soon).pack(side=tk.LEFT, padx=1)
        a.lbl(vb, "C/N", muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(10, 2))
        self.v_cn = tk.DoubleVar(value=float(ui.get("tc_cn", 12)))
        ttk.Scale(vb, from_=0, to=30, orient=tk.HORIZONTAL, length=140, variable=self.v_cn,
                  command=lambda _x: self.cn_moved()).pack(side=tk.LEFT)
        self.cn_lbl = tk.Label(vb, text="%.0f dB" % self.v_cn.get(), width=6, bg=a.BG, fg=a.FG, font=a.F_SMALL)
        self.cn_lbl.pack(side=tk.LEFT)
        self.view_lbl = tk.Label(vb, text="", bg=a.BG, fg=a.MUTED, font=a.F_SMALL, anchor="w")
        self.view_lbl.pack(side=tk.LEFT, padx=8, fill=tk.X, expand=True)
        # ---- the picture
        self.cv = tk.Canvas(w, bg=a.DISPLAY, highlightthickness=1, highlightbackground=a.BORDER)
        self.cv.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(6, 2), pady=(2, 6))
        self.cv.bind("<Configure>", lambda e: self.show())
        self.boxes = []
        self.drag = None
        self.cv.bind("<Button-1>", self.press)          # on a text: drag it; elsewhere: the chosen line goes there
        self.cv.bind("<B1-Motion>", self.motion)
        self.cv.bind("<ButtonRelease-1>", self.release)
        self.cv.bind("<Motion>", self.hover)
        self.status = tk.Label(w, text="", bg=a.BG, fg=a.MUTED, font=a.F_SMALL)
        self.fill_files()
        self.tick()                                        # (live fields: the clock)
        last = ui.get("tc_userfile")
        if self.card == "User file" and last and os.path.isfile(last):
            self.load_file(last)
        elif str(self.card).startswith("P:") and self.card[2:] in PATTERNS:
            self.load_pattern(self.card[2:])
        else:
            if self.card not in dict(TESTCARDS) or (dict(TESTCARDS)[self.card] and
                                                     testcard_path(dict(TESTCARDS)[self.card]) is None):
                self.card = next((n for n, s in TESTCARDS if s and testcard_path(s)), "NBTV Lab")
            self.load_card(self.card)
        self.select_line()

    # ------------------------------------------------------------ pictures
    @staticmethod
    def work_size(img):
        """Big or small pictures are worked on about 862 wide, so the font sizes mean the same."""
        h, w = img.shape[:2]
        if 640 <= w <= 1024:
            return img
        nw = TC_WORK_W
        nh = max(1, int(round(h * nw / float(w))))
        return fit_image(img, nw, nh)

    def load_card(self, name):
        stem = dict(TESTCARDS).get(name)
        try:
            img = self.app.builtin_card(864, 648) if stem is None else read_image(testcard_path(stem))
        except Exception as e:
            self.app.log("Test card: cannot read %s: %s" % (name, e))
            return
        self.card = name
        self.v_card.set(name)
        self.fit_for_card()
        self.set_base(img)

    def load_pattern(self, name):
        self.card = "P:" + name
        self.v_card.set(self.card)
        self.fit_for_card()
        self.set_base(None)                               # (drawn at the ratio's shape: its marks stay right)

    def load_file(self, path):
        try:
            img = read_image(path)
        except Exception as e:
            self.app.log("Test card: cannot read %s: %s" % (path, e))
            return False
        self.card = "User file"
        self.v_card.set("")
        self.app.ui["tc_userfile"] = path
        self.fit_for_card()
        self.set_base(img)
        return True

    @staticmethod
    def cut(img, ratio):
        """The middle of a picture, at 4:3 or 16:9."""
        A = 4 / 3.0 if ratio == "4:3" else 16 / 9.0
        H, W = img.shape[:2]
        if W > H * A:
            nw = int(round(H * A))
            return img[:, (W - nw) // 2:(W - nw) // 2 + nw]
        nh = int(round(W / A))
        return img[(H - nh) // 2:(H - nh) // 2 + nh]

    def set_base(self, img):
        """img: a card or picture as it came (kept, to cut again at another ratio); None: the one kept, or the
        pattern drawn at the ratio."""
        ratio = self.v_ratio.get()
        if str(self.card).startswith("P:"):
            self.raw = None
            self.base = make_pattern(self.card[2:], 864, 648 if ratio == "4:3" else 486)
        else:
            if img is not None:
                self.raw = img
            if getattr(self, "raw", None) is None:
                return
            if self.v_fit.get() == "Scale":
                # (5.61) Scale: the whole picture, resized to the ratio (TestX, drawn 16:9, starts on it)
                W_ = TC_WORK_W
                H_ = int(round(W_ * (3 / 4.0 if ratio == "4:3" else 9 / 16.0)))
                if Image is not None:
                    self.base = np.asarray(Image.fromarray(np.ascontiguousarray(self.raw[..., :3])).resize(
                        (W_, H_), Image.LANCZOS))
                else:
                    ys = (np.arange(H_) * self.raw.shape[0] / H_).astype(int)
                    xs = (np.arange(W_) * self.raw.shape[1] / W_).astype(int)
                    self.base = self.raw[ys][:, xs][..., :3]
            else:
                self.base = self.work_size(self.cut(self.raw, ratio))
        self.select_line()
        self.redraw()

    # ------------------------------------------------------------ the lines
    def select_line(self):
        self.sel = int(self.v_sel.get())
        self.pos_title.config(text=self.LINE_NAMES[self.sel])
        if self.base is None:
            return
        h, w = self.base.shape[:2]
        for j, (sc, v, vl) in enumerate(self.scales):
            n = w if j == 0 else h
            sc.configure(to=n)
            v.set(round(self.lines[self.sel][1 + j] * n))
            vl.config(text="%d" % v.get())

    def text_changed(self, r):
        self.lines[r][0] = self.v_text[r].get()
        self.redraw_soon()

    def size_changed(self, r):
        try:
            self.lines[r][3] = clamp(int(self.v_lsize[r].get()), 4, 400)
        except (ValueError, tk.TclError):
            return
        self.redraw_soon()

    def insert_field(self):
        v = self.v_field.get().split()[0] if self.v_field.get().startswith("{") else ""
        self.v_field.set("Insert field...")
        if not v:
            return
        e = self.entries_t[self.sel]
        try:
            e.insert(tk.INSERT, v)
        except Exception:
            self.v_text[self.sel].set(self.v_text[self.sel].get() + v)
        e.focus_set()

    def quick(self, fx=None, fy=None):
        if self.base is None:
            return
        h, w = self.base.shape[:2]
        ln = self.lines[self.sel]
        self.place(self.sel, (fx if fx is not None else ln[1]) * w, (fy if fy is not None else ln[2]) * h)

    # ------------------------------------------------------------ controls
    def slid(self, j):
        if self.base is None:
            return
        h, w = self.base.shape[:2]
        sc, v, vl = self.scales[j]
        x = float(v.get())
        vl.config(text="%d" % x)
        self.lines[self.sel][1 + j] = x / (w if j == 0 else h)
        self.redraw_soon()

    def to_pic(self, e):
        x0, y0, s = self.geo
        return (e.x - x0) / s, (e.y - y0) / s

    def hit(self, e):
        """Which line is under the mouse, or None."""
        if self.base is None or not getattr(self, "geo", None) or self.v_view.get() != "Edit":
            return None
        px, py = self.to_pic(e)
        m = 6 / self.geo[2]                               # a few screen pixels of slack
        for i in reversed(range(len(self.boxes))):        # the one drawn last is on top
            b = self.boxes[i]
            if b and b[0] - m <= px <= b[2] + m and b[1] - m <= py <= b[3] + m:
                return i
        return None

    def press(self, e):
        if self.v_view.get() != "Edit":
            self.status_msg("Switch the view to Edit to place the text")
            return
        i = self.hit(e)
        if i is None:
            self.drag = None
            self.click(e, self.sel)
            return
        self.v_sel.set(i)
        self.select_line()
        px, py = self.to_pic(e)
        h, w = self.base.shape[:2]
        self.drag = (i, self.lines[i][1] * w - px, self.lines[i][2] * h - py)   # the grab point stays under the mouse
        self.cv.config(cursor="fleur")

    def motion(self, e):
        if self.drag is None or self.base is None:
            return
        i, ox, oy = self.drag
        h, w = self.base.shape[:2]
        px, py = self.to_pic(e)
        self.place(i, clamp(px + ox, 0, w), clamp(py + oy, 0, h), soon=25)

    def release(self, e):
        if self.drag is not None:
            self.drag = None
            self.redraw()
        self.hover(e)

    def hover(self, e):
        try:
            self.cv.config(cursor="fleur" if self.hit(e) is not None else "crosshair")
        except Exception:
            pass

    def place(self, i, px, py, soon=60):
        h, w = self.base.shape[:2]
        self.lines[i][1], self.lines[i][2] = px / w, py / h
        if i == self.sel:
            for j, val in ((0, px), (1, py)):
                sc, v, vl = self.scales[j]
                v.set(round(val))
                vl.config(text="%d" % val)
        self.redraw_soon(ms=soon)

    def click(self, e, i):
        """Click on the picture: that line goes there (centred across, top at the click)."""
        if self.base is None or not getattr(self, "geo", None):
            return
        h, w = self.base.shape[:2]
        px, py = self.to_pic(e)
        self.place(i, clamp(px, 0, w), clamp(py, 0, h))

    def set_colour(self, c):
        self.colour = c
        self.col_show.config(bg=c)
        if getattr(self, "bg_show", None) is not None:
            self.show_bg_colour()
        self.redraw_soon()

    def pick_colour(self):
        try:
            from tkinter import colorchooser
            c = colorchooser.askcolor(color=self.colour, parent=self.win, title="Text colour")[1]
        except Exception:
            c = None
        if c:
            self.set_colour(c)

    def alpha_moved(self):
        self.alpha_lbl.config(text="%d%%" % self.v_alpha.get())
        if self.v_cauto.get():                            # (moving it by hand: Auto off)
            self.v_cauto.set(0)
        if self.v_bg.get():
            self.redraw_soon()

    def show_bg_colour(self):
        c = self.bg_colour
        if c == "auto":
            p = auto_panel(self.rgb())
            self.bg_show.config(bg="#%02x%02x%02x" % p)
        else:
            self.bg_show.config(bg="#%02x%02x%02x" % tuple(c))

    def set_bg_colour(self, c):
        c = c.lstrip("#")
        self.bg_colour = [int(c[k:k + 2], 16) for k in (0, 2, 4)]
        self.v_bgauto.set(0)
        if not self.v_bg.get():
            self.v_bg.set(1)
        self.show_bg_colour()
        self.redraw_soon()

    def bg_auto_changed(self):
        if self.v_bgauto.get():
            self.bg_colour = "auto"
        elif self.bg_colour == "auto":
            self.bg_colour = list(auto_panel(self.rgb()))
        self.show_bg_colour()
        self.redraw_soon()

    def pick_bg_colour(self):
        try:
            from tkinter import colorchooser
            c = colorchooser.askcolor(parent=self.win, title="Background colour")[1]
        except Exception:
            c = None
        if c:
            self.set_bg_colour(c)

    def fit_key(self):
        return "tc_fit_" + ("file" if self.card == "User file" else str(self.card))

    def fit_for_card(self):
        """The Fit kept for this card (TestX: Scale; the rest: Crop), on the buttons."""
        pat = str(self.card).startswith("P:")
        f = self.app.ui.get(self.fit_key(), "Scale" if self.card in CARDS_169 else "Crop")
        self.v_fit.set(f)
        for b in getattr(self, "fit_btns", []):
            try:
                b.config(state=tk.DISABLED if pat else tk.NORMAL)
            except Exception:
                pass
        try:
            self.fit_lbl.config(text="(drawn at the ratio)" if pat else "")
        except Exception:
            pass

    def fit_changed(self):
        if str(self.card).startswith("P:"):
            return
        self.app.ui[self.fit_key()] = self.v_fit.get()
        if getattr(self, "raw", None) is not None:
            self.set_base(None)

    def ratio_changed(self):
        """The picture's shape: the card cut again (a pattern drawn again) at it; the text stays where it was,
        as a share of the picture."""
        if getattr(self, "raw", None) is not None or str(self.card).startswith("P:"):
            self.set_base(None)

    def cn_moved(self):
        self.cn_lbl.config(text="%.0f dB" % self.v_cn.get())
        if self.v_view.get() == "After codec":
            self.redraw_soon(ms=250)

    def status_msg(self, t):
        try:
            self.view_lbl.config(text=t)
        except Exception:
            pass

    def rgb(self):
        c = self.colour.lstrip("#")
        return tuple(int(c[k:k + 2], 16) for k in (0, 2, 4)) if len(c) == 6 else (255, 255, 255)

    def mode_name(self):
        try:
            import nbtv_core as C
            cfg = self.app.cfg
            return C.enc_name(C.MODES[cfg.get("mode", "120x96")], int(cfg.get("enc", 1)))
        except Exception:
            return ""

    def values(self):
        return field_values(self.app.cfg, self.mode_name())

    def sync_text(self):
        """The lines' text as in their boxes now."""
        for r in range(self.NL):
            try:
                self.lines[r][0] = self.v_text[r].get()
            except Exception:
                pass

    def drawn_lines(self, values=None):
        self.sync_text()
        h, w = self.base.shape[:2]
        vals = values if values is not None else self.values()
        return [(fill_fields(t, vals), int(round(fx * w)), int(round(fy * h)), int(sz)) for t, fx, fy, sz in self.lines]

    def tick(self):
        """Live fields: the picture redrawn as the time moves on (once a second, only if a field is in the text)."""
        try:
            self.sync_text()
            if self.base is not None and has_fields([ln[0] for ln in self.lines]) and self.pending is None:
                self.redraw()
            self.win.after(1000, self.tick)
        except Exception:
            pass

    def redraw_soon(self, *_, ms=60):
        if self.pending is not None:
            try:
                self.win.after_cancel(self.pending)
            except Exception:
                pass
        if self.v_view.get() == "After codec":
            ms = max(ms, 200)
        self.pending = self.win.after(ms, self.redraw)

    def redraw(self):
        self.pending = None
        if self.base is None:
            return
        rat = []
        self.img = draw_lines(self.base, self.drawn_lines(), self.v_font.get(), self.rgb(), bool(self.v_bold.get()),
                              self.v_style.get(), boxes=self.boxes, bg=bool(self.v_bg.get()),
                              contrast="auto" if self.v_cauto.get() else float(self.v_alpha.get()),
                              bg_colour=self.bg_colour, ratios=rat)
        if self.v_bg.get() and rat:
            ks = [kk for kk, _ in rat]
            crs = [c for _, c in rat if c is not None]
            if self.v_cauto.get() and ks:
                self.v_alpha.set(round(100 * max(ks)))
                self.alpha_lbl.config(text="%d%%" % (100 * max(ks)))
            low = min(crs) if crs else None
            self.ratio_lbl.config(
                text=("Contrast ratio, the lowest line: %.1f:1%s" % (low, "  (aim %.0f:1%s)" % (
                    CONTRAST_AIM, "" if low >= CONTRAST_AIM - 0.05 else " - not reached: try another colour")
                    if self.v_cauto.get() else "")) if low is not None else "",
                fg=self.app.FG if (low is None or low >= 4.5) else "#e5c07b")
        else:
            self.ratio_lbl.config(text="")
        self.show()

    # ------------------------------------------------------------ the preview: as it will be sent
    def sent_size(self):
        import nbtv_core as C
        cfg = self.app.cfg
        mode = C.MODES[cfg.get("mode", "120x96")]
        enc = C.eff_enc(mode, int(cfg.get("enc", 1)))
        return mode, enc, C.pic_size(mode, enc)

    def preview(self, img):
        """The picture as it will be sent: cut to the aspect and scaled to the format's size; for After codec,
        then coded, given the channel's noise at the C/N (on the sent values; no fading or echo) and decoded with
        the receiver's settings, as the receiver would show it."""
        import nbtv_core as C
        cfg = self.app.cfg
        mode, enc, (w, h) = self.sent_size()
        img = self.cut(img, self.v_ratio.get())
        p = fit_image(img, w, h)
        info = "%s, %s: %dx%d, %s" % (cfg.get("mode", "120x96"), C.enc_name(mode, enc), w, h, self.v_ratio.get())
        if self.v_view.get() != "After codec":
            return p, info + " - as sent"
        cn = float(self.v_cn.get())
        n = C.pics_per_frame(enc)
        f = np.asarray(C.encode_frame([p] * n, mode, enc, detail=cfg.get("detail", "dct"),
                                      vemph=bool(cfg.get("vemph", 1))), np.float64)
        if self.dh is None:
            self.dh = C.DecodeHandler()
        dc = dict(cfg)
        dc.update(mode=cfg.get("mode", "120x96"), enc=int(cfg.get("enc", 1)), snr=cn)
        rng = np.random.RandomState(5)
        sig = C.noise_sigma(cn)
        out = None
        for _ in range(4):                                # (a few frames: the receiver settles, Key NR too)
            fb = np.clip(np.rint(f + rng.randn(len(f)) * sig), 0, 255).astype(np.uint8)
            r = self.dh.handle(("decode", fb, cfg.get("mode", "120x96"), dc, cn, None))
            if r.get("yccs"):
                out = r["yccs"][0]
        if out is None:
            return p, info + " - (no picture from the decoder)"
        return np.asarray(C.finish_picture(out), np.uint8), info + " - after the codec at %.0f dB C/N" % cn

    def show(self):
        if self.img is None:
            return
        cv = self.cv
        W, H = max(50, int(cv.winfo_width() or 0)), max(50, int(cv.winfo_height() or 0))
        img, note = self.img, ""
        if self.v_view.get() != "Edit":
            try:
                img, note = self.preview(self.img)
            except Exception as e:
                note = "Preview: %s" % e
        self.status_msg(note)
        h, w = img.shape[:2]
        s = min((W - 8) / float(w), (H - 8) / float(h))
        if self.v_view.get() != "Edit":
            s = min(s, 4.0)                               # (a small picture shown no more than 4x)
        dw, dh = max(1, int(w * s)), max(1, int(h * s))
        if Image is not None:
            a = np.asarray(Image.fromarray(np.ascontiguousarray(img)).resize((dw, dh), Image.LANCZOS))
        else:
            ys = np.minimum((np.arange(dh) / s).astype(int), h - 1)
            xs = np.minimum((np.arange(dw) / s).astype(int), w - 1)
            a = img[ys][:, xs]
        self.photo = tk.PhotoImage(data=b"P6 %d %d 255\n" % (dw, dh) + np.ascontiguousarray(a).tobytes(),
                                   format="PPM")
        x0, y0 = (W - dw) // 2, (H - dh) // 2
        if self.v_view.get() == "Edit":
            self.geo = (x0, y0, s)
        cv.delete("all")
        cv.create_image(x0, y0, image=self.photo, anchor="nw")
        cv.create_text(W - 6, H - 4, anchor="se", fill="#8a93a0", font=self.app.F_SMALL,
                       text=("drag a text to move it   click: the chosen line goes here" if self.v_view.get() == "Edit"
                             else "the picture as it will be sent - Edit to change it"))

    # ------------------------------------------------------------ your own pictures
    def fill_files(self):
        lb = self.files
        lb.delete(0, tk.END)
        self.entries = []
        d = self.dir
        self.dir_lbl.config(text=d if len(d) < 34 else "..." + d[-31:])
        try:
            names = sorted(os.listdir(d), key=str.lower)
        except OSError:
            names = []
        if os.path.dirname(d) != d:
            self.entries.append(os.path.dirname(d))
            lb.insert(tk.END, "[..]")
        for n in names:
            if n.startswith("."):
                continue
            p = os.path.join(d, n)
            if os.path.isdir(p):
                self.entries.append(p)
                lb.insert(tk.END, "[%s]" % n)
        for n in names:
            p = os.path.join(d, n)
            if os.path.isfile(p) and os.path.splitext(n)[1].lower() in TC_EXTS:
                self.entries.append(p)
                lb.insert(tk.END, n)

    def user_file(self):
        """User file: the picture chosen in the list (a folder opens), or ask for one."""
        sel = self.files.curselection()
        path = self.entries[sel[0]] if sel and sel[0] < len(self.entries) else None
        if path and os.path.isdir(path):
            self.dir = path
            self.app.ui["tc_dir"] = path
            self.fill_files()
            return
        if not path:
            if filedialog is None:
                return
            path = filedialog.askopenfilename(parent=self.win, title="Picture for the test card",
                                              filetypes=self.app.IMG_TYPES, initialdir=self.dir)
            if not path:
                return
            self.dir = os.path.dirname(path)
            self.app.ui["tc_dir"] = self.dir
            self.fill_files()
        self.load_file(path)

    # ------------------------------------------------------------ save and use
    def remember(self):
        self.sync_text()
        ui = self.app.ui
        ui.update(tc_card=self.card, tc_lines=[list(x) for x in self.lines], tc_font=self.v_font.get(),
                  tc_colour=self.colour, tc_bold=int(self.v_bold.get()), tc_style=self.v_style.get(),
                  tc_bg=int(self.v_bg.get()), tc_contrast=float(self.v_alpha.get()),
                  tc_contrast_auto=int(self.v_cauto.get()), tc_bg_colour=self.bg_colour,
                  tc_cn=float(self.v_cn.get()), tc_dir=self.dir,
                  # (the two-line editor's names too, for an older program reading the same settings)
                  tc_upper=self.lines[0][0], tc_lower=self.lines[1][0], tc_ux=self.lines[0][1],
                  tc_uy=self.lines[0][2], tc_lx=self.lines[1][1], tc_ly=self.lines[1][2], tc_size=self.lines[0][3],
                  tc_box=int(self.v_bg.get()), tc_alpha=float(self.v_alpha.get()))

    def save(self):
        """Set + Save: save the picture to Pictures/NBTV Lab and send it (the Picture source).  With live fields in
        the text, the card without text (-base.png) and the layout (.json) go beside it, and the source redraws
        the text as it sends (the clock ticks)."""
        if self.base is None:
            return
        self.redraw()
        d = os.path.join(pictures_dir(), "NBTV Lab")
        try:
            os.makedirs(d, exist_ok=True)
            stamp = time.strftime("%Y%m%d-%H%M%S")
            path = os.path.join(d, "testcard-%s.png" % stamp)
            k = 2
            while os.path.exists(path):
                path = os.path.join(d, "testcard-%s-%d.png" % (stamp, k))
                k += 1
            save_image(self.img, path)
            self.sync_text()
            live = has_fields([ln[0] for ln in self.lines])
            if live:
                stem = os.path.splitext(path)[0]
                save_image(self.base, stem + "-base.png")
                with open(stem + ".json", "w") as f:
                    json.dump(dict(base=os.path.basename(stem + "-base.png"), lines=[list(x) for x in self.lines],
                                   font=self.v_font.get(), colour=list(self.rgb()), bold=bool(self.v_bold.get()),
                                   style=self.v_style.get(), bg=bool(self.v_bg.get()),
                                   contrast="auto" if self.v_cauto.get() else float(self.v_alpha.get()),
                                   bg_colour=self.bg_colour, ratio=self.v_ratio.get()), f, indent=1)
        except Exception as e:
            self.app.log("Test card: cannot save: %s" % e)
            return
        self.remember()
        self.app.log("Test card: saved %s%s" % (path, " (live fields: redrawn as it is sent)" if live else ""))
        # (5.59) sent at the ratio it was made at: the program's aspect set to it
        ratio = self.v_ratio.get()
        lab = getattr(self.app, "lab", None)
        if lab is not None and self.app.cfg.get("aspect") != ratio:
            self.app.cfg["aspect"] = ratio
            try:
                lab.v_aspect.set(ratio)
            except Exception:
                pass
            self.app.log("Test card: picture ratio %s - the aspect set to it" % ratio)
        self.app.use_picture(path, self.img.copy())
        self.last_saved = path
        self.close()

    def close(self):
        if self.pending is not None:
            try:
                self.win.after_cancel(self.pending)
            except Exception:
                pass
            self.pending = None
        self.remember()
        if getattr(self.app, "tc_editor", None) is self:
            self.app.tc_editor = None
        try:
            self.win.destroy()
        except Exception:
            pass
