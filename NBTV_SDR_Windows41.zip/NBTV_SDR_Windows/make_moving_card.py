"""NBTV moving test card - a 60 s loop of moving picture and test tones, made for NBTV (VE3XTV).

Writes two video files (H.264 + AAC, 25 fps), ready for the lab's or NBTV SDR's Video file source:
    NBTV_moving_card_4x3.mp4    640 x 480
    NBTV_moving_card_16x9.mp4   854 x 480   (the 4:3 card in the middle, more test areas each side)

    python3 make_moving_card.py [--call VE3XTV] [--out folder] [--secs 60]

Made for NBTV: everything is laid out on the 240 x 192 grid NBTV's detail is sent on, the thinnest lines are two of
those pixels, so the card holds together at 120x96 and 180x96.  What it has:
  - a grid, and a large circle with grey steps, detail gratings, colour bars (75 %), a drifting checker band, the
    station's call and a running time code
  - detail gratings across at 30, 60, 90, 120 cycles a picture width - 60 is where 120 wide runs out, 90 is 180
    wide's, 120 the 240x192 detail's (marked by the tab under each: red 120x96, yellow 180x96, green 240x192)
  - motion at several speeds for the motion modes: two colour-gradient discs turning (one slow, one fast), sliding
    gradient bars, a spoked wheel (the wagon-wheel effect at 12.5 pictures a second shows on it), the checker band
  - a picture counter: 25 squares, one lit each frame (25 fps: NBTV's 12.5 pictures a second light every other
    one - a gap shows a dropped picture)
  - level bars for the left and right sound, and a label that says which test tone is playing
  - 16:9 only: gratings down the picture (24, 48, 96 cycles a height: 96 is where 96 lines run out, 192 lines'
    is 96 too at 240x192's), a bouncing ball and gradient bars moving up and down

The sound (48 kHz stereo, a 60 s loop; levels kept so 75 us pre-emphasis does not clip the highest tones):
     0-6 s   1 kHz, both channels, -18 dBFS - the reference level
     6-10 s  1 kHz, left only
    10-14 s  1 kHz, right only
    14-18 s  1 kHz, left and right in anti-phase (L-R: the sum/diff stereo's S channel alone)
    18-30 s  a sweep, 50 Hz to 11 kHz, both channels, -20 dBFS
    30-42 s  steps, 2 s each: 100 Hz, 400 Hz, 3 kHz, 6 kHz, 8 kHz, 11 kHz, -20 dBFS
    42-48 s  pink noise, both channels, -20 dBFS
    48-54 s  lip sync: a 40 ms 1 kHz pip once a second, at the same moment as a white flash on the picture
    54-60 s  silence - listen for the hiss
Needs numpy, Pillow and ffmpeg."""
import argparse
import math
import os
import subprocess
import sys
import wave

import numpy as np
from PIL import Image, ImageDraw, ImageFont


def flash_at(t):
    """The lip sync flash: white for 0.12 s (3 frames at 25 fps) from each pip, at 48 .. 53 s of the loop."""
    ts = t % SECS
    return 48.0 <= ts < 54.0 and (ts - int(ts)) < 0.12

FPS = 25
AFS = 48000
SECS = 60


def font(size, bold=True):
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
              "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
              "/Library/Fonts/Arial Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf"):
        try:
            return ImageFont.truetype(p, int(size))
        except Exception:
            pass
    return ImageFont.load_default()


# ---------------------------------------------------------------- the sound
SEGMENTS = [(0, 6, "1 kHz  L+R  -18 dBFS  (reference)"), (6, 10, "1 kHz  LEFT only"), (10, 14, "1 kHz  RIGHT only"),
            (14, 18, "1 kHz  L-R anti-phase  (S channel)"), (18, 30, "SWEEP  50 Hz - 11 kHz"),
            (30, 42, "STEPS"), (42, 48, "PINK NOISE  -20 dBFS"), (48, 54, "LIP SYNC  pip + flash"),
            (54, 60, "SILENCE  (listen for hiss)")]
STEPS = (100, 400, 3000, 6000, 8000, 11000)


def db(x):
    return 10 ** (x / 20.0)


def make_sound(secs=SECS, fs=AFS):
    """-> (n x 2 float, -1..1), the 60 s test sound (repeated to secs), at fs samples a second (48 kHz for the
    files; the lab and NBTV SDR make it at their own 24 kHz - the top tone, 11 kHz, is under its 12 kHz)."""
    AFS = fs
    n = int(SECS * AFS)
    t = np.arange(n) / AFS
    L = np.zeros(n)
    R = np.zeros(n)

    def seg(a, b):
        return slice(int(a * AFS), int(b * AFS))

    def ramp(x, ms=5):                                   # (5 ms ends: no clicks)
        k = int(ms * AFS / 1000)
        if len(x) > 2 * k:
            w = np.ones(len(x))
            w[:k] = np.linspace(0, 1, k)
            w[-k:] = np.linspace(1, 0, k)
            x = x * w
        return x

    ref = db(-18) * math.sqrt(2)                          # (-18 dBFS rms sine: its peak)
    s = seg(0, 6); L[s] = R[s] = ramp(ref * np.sin(2 * np.pi * 1000 * t[s]))
    s = seg(6, 10); L[s] = ramp(ref * np.sin(2 * np.pi * 1000 * t[s]))
    s = seg(10, 14); R[s] = ramp(ref * np.sin(2 * np.pi * 1000 * t[s]))
    s = seg(14, 18); x = ramp(ref * np.sin(2 * np.pi * 1000 * t[s])); L[s] = x; R[s] = -x
    s = seg(18, 30)                                       # log sweep 50 Hz - 11 kHz
    tt = t[s] - 18
    T, f0, f1 = 12.0, 50.0, 11000.0
    k = math.log(f1 / f0)
    ph = 2 * np.pi * f0 * T / k * (np.exp(tt / T * k) - 1)
    L[s] = R[s] = ramp(db(-20) * math.sqrt(2) * np.sin(ph))
    for i, f in enumerate(STEPS):
        s = seg(30 + 2 * i, 32 + 2 * i)
        L[s] = R[s] = ramp(db(-20) * math.sqrt(2) * np.sin(2 * np.pi * f * t[s]))
    s = seg(42, 48)                                       # pink noise (1/f, by FFT), -20 dBFS rms
    m = s.stop - s.start
    rng = np.random.RandomState(1)
    for ch in (L, R):
        X = np.fft.rfft(rng.randn(m))
        f = np.fft.rfftfreq(m, 1.0 / AFS)
        X[1:] /= np.sqrt(f[1:])
        X[0] = 0
        X[f > 11000] = 0
        x = np.fft.irfft(X, m)
        ch[s] = ramp(x / np.sqrt(np.mean(x ** 2)) * db(-20), 20)
    for k in range(6):                                    # lip sync pips: 40 ms, at 48.0, 49.0 ... 53.0 s
        s = seg(48 + k, 48 + k + 0.040)
        L[s] = R[s] = ramp(db(-12) * math.sqrt(2) * np.sin(2 * np.pi * 1000 * t[s]), 2)
    st = np.stack([L, R], 1)
    reps = int(math.ceil(secs / float(SECS)))
    return np.tile(st, (reps, 1))[:int(secs * AFS)]


def write_wav(path, st):
    a = np.clip(np.round(st * 32767), -32768, 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(AFS)
        w.writeframes(a.tobytes())


def segment_at(ts):
    ts = ts % SECS
    for a, b, name in SEGMENTS:
        if a <= ts < b:
            if name == "STEPS":
                i = int((ts - 30) // 2)
                f = STEPS[min(i, len(STEPS) - 1)]
                return "STEP  %s  -20 dBFS" % (("%d Hz" % f) if f < 1000 else ("%g kHz" % (f / 1000.0)))
            return name
    return ""


# ---------------------------------------------------------------- the picture
GRAD = np.array([(20, 60, 200), (70, 140, 255), (235, 235, 215), (255, 205, 40), (255, 120, 20), (220, 40, 30)],
                np.float32)                              # the discs' and bars' gradient: blue - white - yellow - orange - red


def gradient(v):
    """v (0..1, any shape) -> RGB along GRAD."""
    v = np.clip(v, 0, 1) * (len(GRAD) - 1)
    i = np.minimum(v.astype(int), len(GRAD) - 2)
    f = (v - i)[..., None]
    return GRAD[i] * (1 - f) + GRAD[i + 1] * f


class Card:
    def __init__(self, W, H, call):
        self.W, self.H, self.call = W, H, call
        self.cw = int(round(H * 4 / 3.0))                # the 4:3 card in the middle
        self.x0 = (W - self.cw) // 2
        self.u = self.cw / 240.0                         # one NBTV detail pixel (240 across the 4:3 card)
        self.f_big = font(15 * self.u)
        self.f_mid = font(10.5 * self.u)                 # (time code, tone label: big enough to read at 120x96)
        self.f_label = font(8.0 * self.u)
        self.f_small = font(6.2 * self.u)
        self.static = self._static()
        yy, xx = np.mgrid[0:H, 0:W]
        self.yy, self.xx = yy.astype(np.float32), xx.astype(np.float32)

    # coordinates on the 4:3 card, in NBTV pixels (0..240 across, 0..180 down) -> screen
    def X(self, x):
        return self.x0 + x * self.u

    def Y(self, y):
        return y * self.u

    def _static(self):
        W, H, u = self.W, self.H, self.u
        im = Image.new("RGB", (W, H), (24, 24, 28))
        d = ImageDraw.Draw(im)
        # the grid: 20 NBTV pixels a square, lines 2 thick (they stay visible at 120x96)
        lw = max(2, int(round(2 * u)))
        k = -int(self.x0 / (20 * u)) - 1
        while self.X(k * 20) < W:
            x = self.X(k * 20)
            d.rectangle((x - lw / 2, 0, x + lw / 2, H), fill=(210, 210, 210))
            k += 1
        for j in range(0, 10):
            y = self.Y(j * 20)
            d.rectangle((0, y - lw / 2, W, y + lw / 2), fill=(210, 210, 210))
        # 16:9 sides: gratings down the picture (24, 48, 96 cycles a height), each a band of stripes
        if self.x0 > 10 * u:
            for side in (0, 1):
                xa = 6 * u if side == 0 else W - self.x0 + 6 * u
                xb = self.x0 - 6 * u if side == 0 else W - 6 * u
                for i, cyc in enumerate((24, 48, 96)):
                    ya, yb = self.Y(96 + i * 26), self.Y(96 + i * 26 + 22)
                    a = np.zeros((int(yb - ya), int(xb - xa), 3), np.uint8)
                    ys = (np.arange(a.shape[0]) + ya) / H
                    a[:] = (128 + 110 * np.sign(np.sin(2 * np.pi * cyc * ys)))[:, None, None]
                    im.paste(Image.fromarray(a), (int(xa), int(ya)))
                    tab = (None, (220, 40, 30), (40, 200, 60))[i]   # (48: 96 lines' limit, red; 96: 192's, green)
                    if tab:
                        d.rectangle((xa, yb, xa + 10 * u, yb + 2.5 * u), fill=tab)
        # the big circle's black field
        cx, cy, r = self.X(120), self.Y(90), 78 * u
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(0, 0, 0))
        return np.asarray(im).copy()

    def circle_mask(self):
        cx, cy, r = self.X(120), self.Y(90), 78 * self.u
        return ((self.xx - cx) ** 2 + (self.yy - cy) ** 2) <= r * r

    def frame(self, n, level_l, level_r, flash, t=None):
        """Picture n (at 25 fps), or the picture at t seconds (the lab's and NBTV SDR's Moving card source: n is
        then the 25 fps frame of t, for the counter)."""
        W, H, u = self.W, self.H, self.u
        if t is None:
            t = n / float(FPS)
        img = self.static.copy()
        cm = getattr(self, "_cm", None)
        if cm is None:
            cm = self._cm = self.circle_mask()

        def band(ya, yb):                                  # rows of the circle (y in NBTV pixels)
            return slice(int(self.Y(ya)), int(self.Y(yb)))

        def put(rows, c0, c1, val):                        # into the circle only
            m = cm[rows, c0:c1]
            v = np.broadcast_to(np.asarray(val, np.uint8), m.shape + (3,))
            img[rows, c0:c1][m] = v[m]

        xa, xb = int(self.X(42)), int(self.X(198))
        cols = slice(xa, xb)
        # grey steps
        r_ = band(16, 34)
        steps = np.linspace(0, 255, 8)
        idx = np.minimum(((np.arange(xb - xa)) / (xb - xa) * 8).astype(int), 7)
        put(r_, xa, xb, np.repeat(steps[idx][None, :, None], r_.stop - r_.start, 0).repeat(3, 2))
        # gratings: 30, 60, 90, 120 cycles a width (across the 4:3 card), with tabs
        r_ = band(36, 58)
        q = (xb - xa) // 4
        for i, cyc in enumerate((30, 60, 90, 120)):
            x = np.arange(xa + i * q, xa + (i + 1) * q)
            v = 128 + 115 * np.cos(2 * np.pi * cyc * (x - self.x0) / self.cw)
            put(r_, x[0], x[-1] + 1, np.repeat(v[None, :, None], r_.stop - r_.start, 0).repeat(3, 2))
            if i:
                tab = ((220, 40, 30), (240, 200, 0), (40, 200, 60))[i - 1]
                put(band(58, 61), x[0] + 2, x[-1] - 1, tab)
        # colour bars, 75 %
        r_ = band(63, 92)
        bars = np.array([(191, 191, 191), (191, 191, 0), (0, 191, 191), (0, 191, 0), (191, 0, 191), (191, 0, 0),
                         (0, 0, 191), (0, 0, 0)], np.uint8)
        idx = np.minimum((np.arange(xb - xa) / (xb - xa) * 8).astype(int), 7)
        put(r_, xa, xb, np.repeat(bars[idx][None, :, :], r_.stop - r_.start, 0))
        # the checker band, drifting left (8 NBTV pixels a square, 6 pixels a second)
        r_ = band(94, 110)
        xs = (np.arange(xa, xb) - self.x0) / u + 6 * t
        ys = (np.arange(int(self.Y(94)), int(self.Y(110)))) / u
        chk = ((np.floor(xs / 8)[None, :] + np.floor(ys / 8)[:, None]) % 2) * 255
        put(r_, xa, xb, np.repeat(chk[..., None], 3, 2))
        # the call and the time code
        im = Image.fromarray(img)
        d = ImageDraw.Draw(im)
        cx = self.X(120)
        d.rectangle((self.X(66), self.Y(113), self.X(174), self.Y(133)), fill=(0, 0, 0))
        d.text((cx, self.Y(123)), self.call, font=self.f_big, fill=(255, 255, 255), anchor="mm")
        tc = "%02d:%02d.%d" % (int(t) // 60 % 60, int(t) % 60, int(t * 10) % 10)
        d.rectangle((self.X(78), self.Y(135), self.X(162), self.Y(149)), fill=(255, 255, 255))
        d.text((cx, self.Y(142)), tc, font=self.f_mid, fill=(0, 0, 0), anchor="mm")
        # the tone label (what is playing)
        lab = segment_at(t)
        d.rectangle((self.X(26), self.Y(151), self.X(214), self.Y(164)), fill=(20, 45, 130))
        d.text((cx, self.Y(157.5)), lab, font=self.f_label, fill=(255, 255, 255), anchor="mm")
        # level bars, left (L) and right (R) of the circle, from the sound's level (dBFS: -40 .. 0)
        for side, lv in ((0, level_l), (1, level_r)):
            bx = self.X(33) if side == 0 else self.X(202)
            top, bot = self.Y(40), self.Y(140)
            d.rectangle((bx, top, bx + 5 * u, bot), fill=(40, 40, 40))
            frac = min(1.0, max(0.0, (lv + 40) / 40.0))
            d.rectangle((bx, bot - (bot - top) * frac, bx + 5 * u, bot),
                        fill=(60, 200, 80) if lv < -9 else (240, 200, 0))
            d.text((bx + 2.5 * u, bot + 5 * u), "LR"[side], font=self.f_small, fill=(255, 255, 255), anchor="mm")
        # the spoked wheel (top left): 8 spokes, a turn every 2.4 s - at 12.5 pictures a second, close to the
        # rate where the wagon-wheel effect shows
        wx, wy, wr = self.X(22), self.Y(22), 15 * u
        d.ellipse((wx - wr, wy - wr, wx + wr, wy + wr), fill=(255, 255, 255))
        for k in range(8):
            a = 2 * math.pi * (t / 2.4 + k / 8.0)
            d.line((wx, wy, wx + wr * math.cos(a), wy + wr * math.sin(a)), fill=(0, 0, 0), width=max(2, int(2 * u)))
        # the picture counter (bottom): 25 squares, one lit each frame
        k = n % 25
        s0 = self.X(20)
        sw_ = (self.X(220) - s0) / 25.0
        for i in range(25):
            d.rectangle((s0 + i * sw_ + 1, self.Y(166.5), s0 + (i + 1) * sw_ - 1, self.Y(174)),
                        fill=(255, 255, 255) if i == k else (70, 70, 70))
        # the lip sync flash (top right): white for 3 frames from each pip
        if flash:
            d.rectangle((self.X(202), self.Y(7), self.X(236), self.Y(37)), fill=(255, 255, 255))
        else:
            d.rectangle((self.X(202), self.Y(7), self.X(236), self.Y(37)), outline=(200, 200, 200),
                        width=max(2, int(2 * u)))
        img = np.asarray(im).copy()
        # gradient discs, turning: left one slow (a turn in 8 s), right one fast (a turn in 1.5 s)
        discs = [(19, 151, 13, 8.0), (221, 151, 13, -1.5)]
        if self.x0 > 30 * u:                               # (16:9: the side panels' tops too)
            discs += [(-self.x0 / u / 2, 22, 16, 5.0), (240 + self.x0 / u / 2, 22, 16, -2.5)]
        for (dx, dy, dr, per) in discs:
            cx, cy, r = self.X(dx), self.Y(dy), dr * u
            ys_ = slice(max(0, int(cy - r)), min(H, int(cy + r) + 1))
            xs_ = slice(max(0, int(cx - r)), min(W, int(cx + r) + 1))
            X_, Y_ = self.xx[ys_, xs_] - cx, self.yy[ys_, xs_] - cy
            m = X_ ** 2 + Y_ ** 2 <= r * r
            a = 2 * math.pi * t / per
            v = 0.5 + (X_ * math.cos(a) + Y_ * math.sin(a)) / (2 * r)
            img[ys_, xs_][m] = gradient(v[m]).astype(np.uint8)
        # gradient bars sliding (top and bottom of the card)
        for (y0, y1, sp, off) in ((0.5, 5, 40.0, 0.0), (176, 180, -55.0, 90.0)):
            length = 90 * u
            x = self.x0 + ((sp * t + off) % (240 + 90) - 90) * u
            xa_, xb_ = int(max(0, x)), int(min(W, x + length))
            if xb_ > xa_:
                v = (np.arange(xa_, xb_) - x) / length
                img[int(self.Y(y0)):int(self.Y(y1)), xa_:xb_] = gradient(v)[None, :, :].astype(np.uint8)
        # 16:9 sides: a bouncing ball and gradient bars moving up and down
        if self.x0 > 10 * u:
            for side in (0, 1):
                xa_ = 6 * u if side == 0 else W - self.x0 + 6 * u
                xb_ = self.x0 - 6 * u if side == 0 else W - 6 * u
                # a vertical gradient bar moving up and down
                bx = int(xa_ + (xb_ - xa_) * (0.08 if side == 0 else 0.80))
                bw = int(5 * u)
                bl = int(20 * u)
                y = self.Y(42) + (0.5 + 0.5 * math.sin(2 * math.pi * t / (3.0 if side == 0 else 2.0))) * (self.Y(92) - self.Y(42) - bl)
                v = np.arange(bl) / float(bl)
                img[int(y):int(y) + bl, bx:bx + bw] = gradient(v)[:, None, :].astype(np.uint8)
                # a ball bouncing across the side area
                period = 1.6 if side == 0 else 1.1
                ph = (t / period) % 1.0
                rr = 6 * u
                by = self.Y(90) - rr - abs(math.sin(math.pi * ph)) * 36 * u
                bxc = xa_ + (xb_ - xa_) * (0.5 + 0.2 * math.sin(2 * math.pi * t / 5.0 + side))
                ys_ = slice(max(0, int(by - rr)), min(H, int(by + rr) + 1))
                xs_ = slice(max(0, int(bxc - rr)), min(W, int(bxc + rr) + 1))
                X_, Y_ = self.xx[ys_, xs_] - bxc, self.yy[ys_, xs_] - by
                m = X_ ** 2 + Y_ ** 2 <= rr * rr
                img[ys_, xs_][m] = (255, 60, 40) if side == 0 else (40, 220, 255)
        return img


def make(path, W, H, call, secs, wav):
    card = Card(W, H, call)
    snd = make_sound(secs)
    hop = AFS // FPS
    flashes = set()
    for k in range(6):                                   # (the pips' frames: 3 frames of white from each)
        f0 = int(round((48 + k) * FPS))
        flashes.update(range(f0, f0 + 3))
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "%dx%d" % (W, H),
           "-r", str(FPS), "-i", "pipe:0", "-i", wav, "-map", "0:v", "-map", "1:a",
           "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "320k", "-shortest", "-movflags", "+faststart", path]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    nfr = int(secs * FPS)
    for n in range(nfr):
        a = snd[n * hop:(n + 1) * hop]
        lv = [20 * math.log10(max(1e-6, float(np.sqrt(np.mean(a[:, c] ** 2))))) for c in (0, 1)]
        p.stdin.write(card.frame(n, lv[0], lv[1], (n % (SECS * FPS)) in flashes).tobytes())
        if n % 250 == 0:
            sys.stdout.write("\r%s: %d of %d frames" % (os.path.basename(path), n, nfr))
            sys.stdout.flush()
    p.stdin.close()
    p.wait()
    print("\r%s: done%s" % (os.path.basename(path), " " * 20))


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--call", default="VE3XTV")
    ap.add_argument("--out", default=".")
    ap.add_argument("--secs", type=float, default=60.0)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    wav = os.path.join(a.out, "NBTV_moving_card_tones.wav")
    write_wav(wav, make_sound(a.secs))
    for name, W, H in (("NBTV_moving_card_4x3.mp4", 640, 480), ("NBTV_moving_card_16x9.mp4", 854, 480)):
        make(os.path.join(a.out, name), W, H, a.call.upper(), a.secs, wav)


if __name__ == "__main__":
    main()
