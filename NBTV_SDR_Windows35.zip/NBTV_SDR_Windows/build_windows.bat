@echo off
rem NBTV SDR for Windows - builds dist\NBTV_SDR\NBTV_SDR.exe (a folder you can copy to any Windows PC) with PyInstaller
rem Needs Python 3.10 or newer from python.org.  Run this from the folder with nbtv_sdr.py.
cd /d "%~dp0"
echo Installing the Python packages NBTV SDR uses ...
py -m pip install --upgrade numpy sounddevice pyserial pillow pyinstaller
if errorlevel 1 goto failed
echo Building NBTV_SDR.exe ...
py -m PyInstaller --noconfirm --windowed --name NBTV_SDR --icon nbtv_sdr.ico --add-data "nbtv_logo.png;." --add-data "NBTV_SDR_Help.txt;." --add-data "testcards;testcards" --hidden-import nbtv_core --hidden-import nbtv_radio --hidden-import testcard_editor nbtv_sdr.py
if errorlevel 1 goto failed
echo.
echo Done: dist\NBTV_SDR\NBTV_SDR.exe  (copy the whole dist\NBTV_SDR folder)
pause
goto end
:failed
echo Something went wrong - see the messages above.
pause
:end
