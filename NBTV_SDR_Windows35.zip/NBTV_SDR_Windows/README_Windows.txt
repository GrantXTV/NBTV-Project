NBTV SDR for Windows
====================

NBTV SDR is one program for Linux and Windows. These are the same files as the Linux version. On Windows, sound and
the I/Q card go through PortAudio (the sounddevice package), and the radio's COM port through pyserial.

It has NOT been tried on a real Windows PC yet.

1. Install Python
   Install Python 3.10 or newer from https://www.python.org/downloads/windows/
   During setup, tick "Add python.exe to PATH". Keep "tcl/tk and IDLE" ticked, because the window needs it.

2. Start it
   Choose one of these:
   a) Double-click run_nbtv_sdr.bat. The first time, it installs numpy, sounddevice, pyserial and pillow,
      then it starts NBTV SDR.
   b) Double-click build_windows.bat. It makes dist\NBTV_SDR\NBTV_SDR.exe, with the NBTV logo as its icon.
      Copy the whole dist\NBTV_SDR folder to any Windows PC; that PC does not need Python.

3. Set up the I/Q sound card (ExSDR radio)
   - In Windows Sound settings, open the card's Properties > Advanced and set it to "2 channel, 24 bit, 192000 Hz".
     Do this for playback and for recording. Also turn "Audio enhancements" off.
   - In NBTV SDR, open Radio / I/Q setup > ExSDR radio, and set Card output and Card input to the card's
     [Windows WASAPI] entries. They are listed first, and they run at the card's own 192 kHz.
     The MME and DirectSound entries are marked "(no 192 kHz)".
   - Serial port: pick the radio's COM port from the drop-down. Device Manager > Ports shows which one it is.

4. Other tools
   ffmpeg (for video files, webcam, screen and streams) and the SDR tools must be found on the PATH. It is
   simplest to put the .exe files in the NBTV SDR folder, because the program looks there too:
     ffmpeg.exe                      https://www.gyan.dev/ffmpeg/builds/  (the "essentials" build)
     hackrf_transfer.exe             from the HackRF release for Windows (or PothosSDR)
     rtl_sdr.exe                     the RTL-SDR Blog Windows release
     airspyhf_rx.exe                 the Airspy HF+ Windows tools
   SDRplay and other SoapySDR radios need PothosSDR or radioconda, which provide SoapySDR's Python module.
   The programme sound "Loopback" on Windows is the card's "Stereo Mix" recording device. Turn it on under
   Sound settings > Recording.

5. Check what it sees
     py nbtv_sdr.py --list-devices        (or  NBTV_SDR.exe --list-devices  in a Command Prompt)
   This lists the sound devices (with 192k where they can run at it), the SDRs and the COM ports.

Settings are kept in C:\Users\<you>\.config\nbtv_sdr.json.
Help (top right in the window) explains every part of the program.
