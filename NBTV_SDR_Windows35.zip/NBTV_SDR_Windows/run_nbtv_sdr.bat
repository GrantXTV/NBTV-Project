@echo off
rem NBTV SDR - run it from the Python source (installs the packages the first time)
cd /d "%~dp0"
py -c "import numpy, sounddevice, serial, PIL" 2>nul || py -m pip install -r requirements.txt
start "" pyw nbtv_sdr.py
