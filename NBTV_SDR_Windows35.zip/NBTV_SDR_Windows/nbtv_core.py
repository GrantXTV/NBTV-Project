#!/usr/bin/env python3
"""NBTV OFDM Lab - core: video codec, OFDM modem, channel.  (c) Grant Taylor VE3XTV

The numbers follow the GNU Radio flowgraphs OFDM_Loopback_v2_120 / _180:
  100 kHz complex baseband, 200 point FFT, 500 Hz carrier spacing, 500 OFDM symbols a second,
  every carrier sending two bytes a symbol as an analogue QAM point (byte -> I, byte -> Q),
  carriers in groups (Mux_50: 24 data + 1 pilot, Mux_74: 36 data + 1 pilot),
  video 288 bytes a symbol (144 carriers), audio 96 bytes a symbol (48 carriers) = 24 kHz U8 stereo.
  120x96: 8 x Mux_50 = 200 carriers, a data frame (3 pictures) every 120 symbols (0.24 s, 12.5 fps)
  180x96: 2 x Mux_50 + 4 x Mux_74 = 198 carriers, a data frame every 180 symbols (0.36 s, 8.3 fps)
  Each I or Q of a video carrier carries one picture row per data frame, as the Mux_74 does.
"""
import collections
import math
import time
import os
import sys
import numpy as np

FS = 100000                      # complex samples a second
NFFT = 200                       # 500 Hz carrier spacing, 500 symbols a second
AUDIO_FS = 24000                 # audio: unsigned 8 bit stereo
VIDEO_BPS = 288                  # video bytes per OFDM symbol (144 carriers)
AUDIO_BPS = 96                   # audio bytes per OFDM symbol (48 carriers) = 48 stereo samples
PILOT_AMP = math.sqrt(2.0)       # pilots 3 dB above the strongest data point
# where the pilot sits in each group, from the middle: uneven, so the pilots have no common spacing
# (with every pilot 25 carriers apart the symbol timing could not be told from 8 samples either side)
PILOT_SHIFT = (-8, 1, -6, 0, -1, 0, 2, 7)
FRAC_SIGN = 1.0


class Mode:
    """A picture format and its OFDM layout."""

    def __init__(self, name, w, h, groups, video_groups, audio_groups, skip_bins=(), nfft=NFFT, halves=1,
                 shifts=PILOT_SHIFT, fixed_cp=0, pilots=1):
        self.name, self.w, self.h = name, w, h
        self.args = dict(groups=list(groups), video_groups=list(video_groups), audio_groups=list(audio_groups),
                         skip_bins=tuple(skip_bins), nfft=nfft, halves=halves, shifts=tuple(shifts), pilots=int(pilots))
        self.pilots_per_group = int(pilots)              # 2: the dense layout (16 pilots in 200 carriers, for HF)
        self.dense = self.pilots_per_group > 1
        self.fixed_cp = int(fixed_cp)                    # >0: a fixed 12.5 fps (or balanced) layout for this guard
        self.fixed_kind = 0                              # 1 fixed 12.5 fps, 2 balanced (set by _fixed_layout)
        # the OFDM layout: nfft carriers; "halves" codec frames (34560 bytes, 3 pictures each) per
        # data frame - the long-symbol layout (400 carriers, 4 ms symbols) carries two, so every
        # carrier still carries 120 bytes - one picture line - in each data frame (the line rule)
        self.nfft, self.halves = int(nfft), int(halves)
        self.vbps, self.abps = VIDEO_BPS * self.halves, AUDIO_BPS * self.halves
        self.long = self.halves > 1
        self.frame_bytes = 34560 * self.halves           # both formats: 720 columns x 48 rows (per half)
        self.syms = self.frame_bytes // self.vbps        # 120 OFDM symbols a data frame
        assert self.frame_bytes == self.syms * self.vbps
        self.period = self.syms / float(FS / self.nfft)  # seconds per data frame (no guard): 0.24 / 0.48
        # carrier layout: groups laid out from the bottom edge, skipping the bins asked for
        bins = [b for b in range(self.nfft) if b not in skip_bins]
        self.groups = []                                 # (data bins, first pilot bin) per group
        gp = []                                          # every pilot bin
        k = 0
        for gi, n in enumerate(groups):
            g = bins[k:k + n]
            k += n
            if self.pilots_per_group == 1:
                sh = shifts[gi] if n >= 25 else int(round(shifts[gi] * n / 25.0))   # (a narrowed sound group)
                pcs = [n // 2 + sh]                      # pilot near the middle of its group
            else:
                # two, near a quarter and three quarters of the way across, each moved its own way (the
                # spacings all different: an echo's pattern across them can't repeat)
                sh = int(round(shifts[gi] * n / 50.0))
                sh2 = int(round(shifts[(gi + 3) % len(shifts)] * n / 50.0))
                pcs = sorted({min(max(n // 4 + sh, 0), n - 1), min(max((3 * n) // 4 + sh2, 0), n - 1)})
            self.groups.append(([b for i, b in enumerate(g) if i not in pcs], g[pcs[0]]))
            gp += [g[p] for p in pcs]
        self.video_bins = np.array([b for gi in video_groups for b in self.groups[gi][0]])
        self.audio_bins = np.array([b for gi in audio_groups for b in self.groups[gi][0]])
        self.pilot_bins = np.array(sorted(gp))
        self.used = np.sort(np.concatenate((self.video_bins, self.audio_bins, self.pilot_bins)))
        self.abps = len(self.audio_bins) * 2             # (fewer with a fixed 12.5 fps layout and a guard)
        assert len(self.video_bins) * 2 == self.vbps and (self.fixed_cp or self.dense or self.abps == AUDIO_BPS * self.halves)
        # frame sync: a +-1 sequence on the pilots, one value per symbol (and a fixed +-1 per pilot)
        rng = np.random.RandomState(0x5EED + w)
        self.pn = np.where(rng.rand(self.syms) > 0.5, 1.0, -1.0)
        self.pn[0] = 1.0
        self.pilot_sign = np.where(np.random.RandomState(7).rand(len(self.pilot_bins)) > 0.5, 1.0, -1.0)

    @property
    def fps(self):
        return 3.0 * self.halves / self.period


MODES = {
    "120x96": Mode("120x96", 120, 96, [25] * 8, [1, 2, 3, 4, 5, 6], [0, 7]),
    # his OFDM_Loopback_v2_180: 2 x Mux_50 (audio) + 4 x Mux_74 (video, 8640 bytes each);
    # 198 carriers: the DC bin and the bottom (Nyquist) bin are left empty
    "180x96": Mode("180x96", 180, 96, [25, 37, 37, 37, 37, 25], [1, 2, 3, 4], [0, 5], skip_bins=(0, 100)),
}

# Long symbols: the same 100 kHz with 400 carriers at 250 Hz (4 ms symbols, so a guard can be twice as
# long for the same share - for HF echoes), 120 symbols a data frame of 0.48 s carrying two codec
# frames (6 pictures).  Each carrier still carries 120 bytes - one line - a frame: the cut points stay
# at the ends of lines.  120x96: 16 x Mux_50 (12 video, 4 audio); 180x96: 4 x Mux_50 (audio) +
# 8 x Mux_74 (video), DC, Nyquist and their neighbours left empty.
LONG_SHIFT = (-8, 1, -6, 0, -1, 0, 2, 7, -7, 3, -2, 5, -4, 1, 6, -3)
LONG_MODES = {
    "120x96": Mode("120x96", 120, 96, [25] * 16, list(range(2, 14)), [0, 1, 14, 15], nfft=400, halves=2,
                   shifts=LONG_SHIFT),
    "180x96": Mode("180x96", 180, 96, [25, 25] + [37] * 8 + [25, 25], list(range(2, 10)), [0, 1, 10, 11],
                   skip_bins=(0, 1, 200, 399), nfft=400, halves=2, shifts=LONG_SHIFT),
}


# Dense pilots (200 carriers, for HF sky wave): two pilots a group, 16 in 120x96 (12 in 180x96) - as many
# as the 400 carrier layouts have, which the echo fit needs to find a sky wave echo reliably.  The video
# groups grow by one carrier each (the video carriers stay as they are); the sound groups give it up:
# 120x96 40 sound carriers (of 48), 180x96 42 - the sound's sampling rate drops by that (as with a
# fixed 12.5 fps layout), 24 -> 20 / 21 kHz.
DENSE_MODES = {
    "120x96": Mode("120x96", 120, 96, [22] + [26] * 6 + [22], [1, 2, 3, 4, 5, 6], [0, 7], pilots=2),
    "180x96": Mode("180x96", 180, 96, [23, 38, 38, 38, 38, 23], [1, 2, 3, 4], [0, 5], skip_bins=(0, 100), pilots=2),
}


AUTO_FORMATS = ("120x96", "180x96")               # what the receiver's Auto looks for (told apart by the sync)


FRAME_RATES = ("Full sound", "Balanced", "Video first")  # cfg "fixed_fps": 0, 2, 1 (the old tick box was 0 / 1;
                                                          #  "Video first" was "Fixed 12.5" before 5.31)


def video_first_cut(base, cp):
    """Video first (5.31, was Fixed 12.5): how many bins the FFT gives up for a guard - all of it (12.5 fps)
    where the sound can spare that many carriers, else as many as it can: the sound down to its least
    (4 carriers a sound group, and its pilot), so the frame rate comes as near 12.5 as the guard allows
    instead of falling back to Full sound.  Never an FFT shorter than the guard (the receiver can't time a
    symbol shorter than its own guard)."""
    a = base.args
    N0 = a["nfft"]
    vid = sum(a["groups"][g] for g in a["video_groups"])
    most = N0 - len(a["skip_bins"]) - vid - (4 + a.get("pilots", 1)) * len(a["audio_groups"])
    return max(0, min(int(cp), most, N0 - int(cp)))


def balanced_cut(base, cp):
    """Balanced (5.15): how many bins the FFT gives up for a guard so the frame rate and the sound
    lose the same share - the frame rate's share of 12.5 fps (N0 / (N0 - cut + cp)) as near as can be
    to the sound carriers' share kept ((A0 - cut) / A0).  The sound being a quarter of the carriers,
    it doesn't buy many pictures back: about half of the way the guard took away at most."""
    N0, A0 = base.nfft, len(base.audio_bins)
    if cp <= 0:
        return 0
    # (never a guard longer than the FFT: the receiver can't time a symbol shorter than its own guard)
    cands = range(0, max(0, min(int(cp), A0 - 8, N0 - int(cp))) + 1)
    return min(cands, key=lambda c: abs(N0 / float(N0 - c + cp) - (A0 - c) / float(A0)))


def layout(mode, long=False, cp=0, fixed=False, dense=False):
    """The OFDM layout for a picture format: as now (200 carriers), or long symbols (400).
    fixed (with a guard): 1 (True) 12.5 pictures a second whatever the guard - the FFT is made shorter by
    the guard, so a symbol and its guard take what a symbol alone took (2 or 4 ms); 2 Balanced - the FFT
    shorter by part of the guard (balanced_cut), frame rate and sound losing the same share.  The video
    carriers are not touched (each still carries one picture line a frame); the sound's carriers are what
    is given up (fewer of them, a little wider)."""
    if isinstance(mode, str):
        mode = MODES[mode]
    base = LONG_MODES[mode.name] if long else (DENSE_MODES[mode.name] if dense else MODES[mode.name])
    cp = int(cp)
    kind = int(fixed)
    if not kind or cp <= 0:
        return base
    key = (base.name, base.long, cp, base.dense, kind)
    if key not in _FIXED_LAYOUTS:
        cut = video_first_cut(base, cp) if kind == 1 else balanced_cut(base, cp)
        try:
            _FIXED_LAYOUTS[key] = _fixed_layout(base, cp, cut, kind) if cut > 0 else base
        except ValueError:                               # too long a guard for it: the normal layout
            _FIXED_LAYOUTS[key] = base
    return _FIXED_LAYOUTS[key]


_FIXED_LAYOUTS = {}


def fixed_ok(mode, long, cp, dense=False):
    """Does Video first give the full 12.5 fps with this guard? (the whole guard taken off the FFT)"""
    if int(cp) <= 0:
        return False
    m = layout(mode, long, cp, 1, dense and not long)
    return m.fixed_kind == 1 and m.nfft + int(cp) == (2 * NFFT if long else NFFT)


def _fixed_layout(base, cp, cut=None, kind=1):
    a = base.args
    N0 = a["nfft"]
    N = N0 - (cp if cut is None else int(cut))
    # the skipped bins keep their places: the edge bin(s), and DC (the middle, after the shift)
    skip = tuple(sorted(set((N // 2 if b == N0 // 2 else (N - 1 if b == N0 - 1 else b)) for b in a["skip_bins"])))
    vid = sum(a["groups"][g] for g in a["video_groups"])
    room = N - len(skip) - vid                           # bins left for the sound groups (their pilots too)
    na = len(a["audio_groups"])
    if room < (4 + a.get("pilots", 1)) * na:
        raise ValueError("guard %d too long for a fixed 12.5 fps layout (%d carriers)" % (cp, N0))
    sizes = [room // na + (1 if i < room % na else 0) for i in range(na)]
    groups = list(a["groups"])
    for g, n in zip(a["audio_groups"], sizes):
        groups[g] = n
    md = Mode(base.name, base.w, base.h, groups, a["video_groups"], a["audio_groups"], skip_bins=skip, nfft=N,
              halves=a["halves"], shifts=a["shifts"], fixed_cp=cp, pilots=a.get("pilots", 1))
    md.fixed_kind = int(kind)                            # 1 fixed 12.5 fps, 2 balanced
    return md


# ======================================================================= video codec
# Grant's Gambas encoders and decoders (NBTV_TX_Code CPU1-CPU7, NBYV_RX_Code CPU1-CPU8), byte for byte.
# A data frame is 34560 bytes in both formats.  Every block is scanned column by column, 48 bytes down
# each column, so the whole frame read as 720 columns x 48 rows shows every block as a picture:
#   120x96  key   R-Y 60 | B-Y 60 | Y even lines 120 | Y odd lines 120   (17280 bytes, CPU1 YC_encode)
#           then 360 columns of motion, different for each encoder mode (CPU3 / CPU4 / CPU2 / CPU6)
#   180x96        R-Y 90 | B-Y 90 | (A+B+C)/3 even 180 | odd 180 | A+B-C 90 | A+C-B 90   (CPU1 W + CPU7)
# Three pictures (80 ms apart) go in a frame: A is the key, B and C ride in the motion blocks.
# The decoder needs the next frame too (its key refines picture C), so pictures come out one frame late.

def _down(a, fy, fx):
    h, w = a.shape[:2]
    return a.reshape(h // fy, fy, w // fx, fx, *a.shape[2:]).mean(axis=(1, 3))


def _cubic_1d(a, f, n_out, axis):
    """Upsample along one axis by an integer factor f with the Keys cubic (a = -0.5), pixel centres
    lined up, edges held."""
    a = np.moveaxis(np.asarray(a, np.float32), axis, 0)
    n = a.shape[0]
    x = (np.arange(n_out) + 0.5) / f - 0.5
    i0 = np.floor(x).astype(int)
    t = (x - i0).astype(np.float32)
    w = [((-0.5 * t + 1.0) * t - 0.5) * t,              # Keys cubic weights for i0-1 .. i0+2
         (1.5 * t - 2.5) * t * t + 1.0,
         ((-1.5 * t + 2.0) * t + 0.5) * t,
         (0.5 * t - 0.5) * t * t]
    out = 0
    for k in range(4):
        idx = np.clip(i0 - 1 + k, 0, n - 1)
        out = out + w[k].reshape((-1,) + (1,) * (a.ndim - 1)) * a[idx]
    return np.moveaxis(out, 0, axis)


def _up(a, fy, fx, shape):
    """Upsampling by whole factors with a cubic (sharper than repeat-and-smooth: about +0.7 dB on
    the colour and on mode 1's 240x192)."""
    u = np.asarray(a, np.float32)
    if fy > 1:
        u = _cubic_1d(u, fy, shape[0], 0)
    if fx > 1:
        u = _cubic_1d(u, fx, shape[1], 1)
    return u[:shape[0], :shape[1]]


def b8(a):
    return np.clip(np.round(a), 0, 255).astype(np.uint8)


def _t8(a):
    """Gambas: a float stored in a Byte / Integer (truncated)."""
    return np.clip(np.floor(a), 0, 255).astype(np.uint8)


def cm(a):
    """Picture block (rows, cols) -> bytes, column by column (For C ... For I ...)."""
    return np.ascontiguousarray(np.asarray(a).T).ravel()


def icm(b, rows, cols):
    """Bytes -> picture block (rows, cols), column by column."""
    return np.asarray(b)[:rows * cols].reshape(cols, rows).T


# ----------------------------------------------------------------------- colour coding
# How the key picture's colour is put into bytes (the TX and the RX must agree):
#   "1/4"    as CPU1 YC_encode: Y = (R+G+B)/3, Saturation(0.5), byte = (R + 255 - Y) / 2
#            -> the colour uses a quarter of the byte range (+-42 levels at full saturation), and the RX
#            multiplies it - and the channel's noise - by 4
#   "3/4"    the same Y, no desaturation, byte = 0.75 (R - Y) + 127.5: three times the swing (+-128 at
#            full saturation), the noise multiplied by 1.33 instead of 4
#   "BT.601" Y = 0.299 R + 0.587 G + 0.114 B (as digital TV / JPEG), Cr = 128 + 0.713 (R - Y),
#            Cb = 128 + 0.564 (B - Y): full range, and green - the colour the eye sees best - is rebuilt
#            with little of the colour bytes' noise in it
COLOUR_CODINGS = ("1/4", "3/4", "BT.601")
_CC = {"name": "1/4"}
_W601 = (0.299, 0.587, 0.114)


def set_colour_coding(name):
    """Choose the colour coding for this process (TX and RX each set it from the settings)."""
    _CC["name"] = name if name in COLOUR_CODINGS else "1/4"


def colour_coding():
    return _CC["name"]


def grey(rgb):
    """The luma Y: Image.Desaturate (R + G + B) / 3 - or BT.601's weighted sum."""
    f = rgb.astype(np.float32)
    if _CC["name"] == "BT.601":
        return _W601[0] * f[..., 0] + _W601[1] * f[..., 1] + _W601[2] * f[..., 2]
    return f.mean(axis=2)


def chroma_to_bytes(ry, by):
    """Colour differences (as _chroma gives them) -> the byte values that carry them."""
    n = _CC["name"]
    if n == "3/4":
        return 0.75 * ry + 127.5, 0.75 * by + 127.5
    if n == "BT.601":
        return 128.0 + 0.713 * ry, 128.0 + 0.564 * by
    return ry / 4.0 + 127.5, by / 4.0 + 127.5


def bytes_to_chroma(ryb, byb):
    """The reverse: bytes -> R - Y, B - Y."""
    ryb = np.asarray(ryb, np.float32)
    byb = np.asarray(byb, np.float32)
    n = _CC["name"]
    if n == "3/4":
        return (ryb - 127.5) / 0.75, (byb - 127.5) / 0.75
    if n == "BT.601":
        return (ryb - 128.0) / 0.713, (byb - 128.0) / 0.564
    return 4.0 * ryb - 510.0, 4.0 * byb - 510.0


def saturation(rgb, s):
    f = rgb.astype(np.float32)
    y = f.mean(axis=2, keepdims=True)
    return np.clip(y + s * (f - y), 0, 255)


def _il(p, q, nb=4):
    """His motion packing: the top nb bits of p go to the odd bit places (7, 5, 3, 1), of q to the even
    places (6, 4, 2, 0), most significant first."""
    p = p.astype(np.int32)
    q = q.astype(np.int32)
    out = np.zeros(p.shape, np.int32)
    for j in range(nb):
        out |= ((p >> (7 - j)) & 1) << (7 - 2 * j)
        out |= ((q >> (7 - j)) & 1) << (6 - 2 * j)
    return out.astype(np.uint8)


def _dil(x, nb=4):
    """Reverse of _il: -> (p, q), each in its top nb bits."""
    x = x.astype(np.int32)
    p = np.zeros(x.shape, np.int32)
    q = np.zeros(x.shape, np.int32)
    for j in range(nb):
        p |= ((x >> (7 - 2 * j)) & 1) << (7 - j)
        q |= ((x >> (6 - 2 * j)) & 1) << (7 - j)
    return p, q


def _hilbert(n):
    """Hilbert curve over an n x n grid: index d -> (x, y), and the table back."""
    xy = np.zeros((n * n, 2), int)
    for d in range(n * n):
        x = y = 0
        s, t = 1, d
        while s < n:
            rx = 1 & (t // 2)
            ry = 1 & (t ^ rx)
            if ry == 0:
                if rx == 1:
                    x, y = s - 1 - x, s - 1 - y
                x, y = y, x
            x += s * rx
            y += s * ry
            t //= 4
            s *= 2
        xy[d] = (x, y)
    inv = np.zeros((n, n), int)
    inv[xy[:, 0], xy[:, 1]] = np.arange(n * n)
    return xy, inv


_HIL = {nb: _hilbert(1 << nb) for nb in (2, 4)}


def _hil(p, q, nb=4):
    """Robust packing (modes 1R-3R): the same two pixels' top nb bits, but placed along a
    Hilbert curve, so a small error in the byte moves one pixel one step instead of flipping
    bits (and carries) in both.  nb 2: the 16 points spread over the whole byte."""
    xy, inv = _HIL[nb]
    d = inv[np.asarray(p, np.int32) >> (8 - nb), np.asarray(q, np.int32) >> (8 - nb)]
    sc = 256 // (4 ** nb)
    return (d * sc + sc // 2).astype(np.uint8)


def _dhil(x, nb=4):
    xy, inv = _HIL[nb]
    sc = 256 // (4 ** nb)
    d = np.clip(np.asarray(x, np.int32) // sc, 0, 4 ** nb - 1)
    return xy[d, 0] << (8 - nb), xy[d, 1] << (8 - nb)


WIDE = 6                                       # 180x96 mode 1: the format as it started (CPU1 W + CPU7)
WIDEK = 7                                      # 180x96 mode 2: with a key picture (improved)
KWL = 8                                        # 120x96 mode 2: 240x192, key + wavelet + motion at low size
KWD = 9                                        # 120x96 mode 1: 240x192, as 180x96 mode 1 (KMD) + wavelet
KWDM = 10                                      # 120x96 mode 5: mode 1's bytes; RX carries A's 240x192 detail to B, C
KMS = 14                                       # 120x96 mode 6: mode 3 (L KMM) with a 120x192 key as line sum / difference
MSV_W = (110, 10)                              # mode 6 key: samples across for each line pair's sum (M) and difference (S)
MSV_TAPS = 8                                   # the mode 6 resampler's Lanczos size (sharper than 3: +0.6 dB)
MSV_SHRINK = 1.0                               # how hard the RX holds back S where it is near the noise
MSV_MSHRINK = 0.5                              # the same for the sums' correction to the plain lines
MSV_RESID = False                              # TX sends S less the RX's prediction from the sums
MSV_GAIN = 2.0                                 # S sent at twice its level (as the stereo S), soft knee above 96
KMDE = 17                                      # (5.36's 180x96 KMD-E: video emphasis is every mode's now - KMD)
VEMPH = dict(k=0.5, s=1.0, g=0.85, knee=96.0)  # lift k of the detail above a Gaussian blur of s pixels; level g; soft knee
VEMPH_ON = True                                # video emphasis on (5.37: every mode; not in the mode word - as the
                                               #  sound's 75 us, both ends set alike)
VEMPH_S = {240: 2.0}                           # the blur in that picture width's pixels (240 wide: 120x96 ones)
KWSC = 18                                      # 120x96 mode 6 (5.40): mode 1 with SoftCast detail (replaces 5.34's L KMM-MS)
KWH = 19                                       # 120x96 mode 7 (5.43): mode 1 with its average key as a 4-line split
KMDW = 20                                      # 120x96 mode 5 (5.45; 8 till 5.47): 180x96 mode 1 (KMD) at 120 wide + 2x the detail
KMMW = 21                                      # 120x96 mode 6 (5.45; 9 till 5.47): 180x96 mode 2 (KMM) at 120 wide + 2x the detail
WW_CARRY = True                                # (modes 5, 6: B and C take A's detail along the motion)
WW_SPLIT = (8, 4)                              # modes 5, 6: DCT frequencies of the detail for A, and for B and C each
                                               #  (16 + 2 x 0 .. : 16 in all, 720 bytes each).  With B and C's own, each
                                               #  picture's detail is what its rebuilt 120x96 lacks (as the RX rebuilds it)
WW_RX_BASE = "rx"                              # (what the RX adds B and C's own detail to: "rx" its own rebuild, "tx" the TX's)
WW_REF_SNR = 45.0                              # (the rebuild the TX works the detail out against, and the RX adds it to)
WW_BC_CARRY = True                             # (B, C: A's frequencies they don't get themselves, along the motion)
SC_CH = (8, 10)                                # its detail chunks (rows, columns of the 192 x 240 detail's DCT)
SC_REP = 8                                     # each chunk's scale and energy sent this many times (median at the RX)
SC_RMS = 40.0                                  # the detail values' level on the air (rms, about mid grey)
SC_ORDER = (4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 31, 32, 33, 34, 35, 36, 37, 38,
            39, 40, 41, 42, 43, 46, 60, 61, 62, 63, 86, 87, 120, 144, 168, 192, 216, 240, 264, 288, 312, 336, 360,
            361, 384, 408, 432, 456, 480, 504, 528, 552)   # the chunks sent: the 60 with the most energy over the
                                               # test cards (fixed, so no chunk numbers go on the air)
KWD_SHRINK = True                              # (the noise-aware rebuild of mode 1's three pictures)


KMX_R = {4: 0.0, KWL: 0.0, WIDEK: 0.0}
KMM_CORRECT = True                             # (180x96 KMM: add back what the motion search missed)          # (per mode: the Key mix setting where its correction is
                                               #  left alone - set from measurement below)


def _wiener(D, k, sg2):
    """D (a picture's own part, carrying the channel's noise made k x in power) let through in
    proportion to how far it stands above that noise, over 5x5 areas."""
    if sg2 <= 0 or k <= 0:
        return D
    E = _box5(D * D)
    return D * np.clip(1.0 - k * sg2 / np.maximum(E, 1e-6), 0.0, 1.0)


def kmx_strength(kmx):
    """Key mix 1-5 -> how hard noisy motion detail is pulled to the keys: 0 (off) .. 1 (3) .. 2 (5)."""
    return (max(1, min(5, int(kmx))) - 1) / 2.0


def _box5(a):
    """5 x 5 mean (edges repeated)."""
    p = np.pad(np.asarray(a, np.float32), 2, mode="edge")
    c = np.cumsum(np.cumsum(np.pad(p, ((1, 0), (1, 0))), axis=0), axis=1)
    h, w = a.shape
    return (c[5:5 + h, 5:5 + w] - c[:h, 5:5 + w] - c[5:5 + h, :w] + c[:h, :w]) / 25.0
ROBUST = {11: 1, 12: 2, 13: 3}                 # the old robust variants (1R-3R) -> the one mode each now
ENC_MODES = collections.OrderedDict([
    (KWD, dict(name="1  240x192x12.5 KWMD", pics=3, size=(240, 192),
               text="R-Y, B-Y 60x48 + (A+B+C)/3 fields + 4x4 wavelet + A+B-C, A+C-B at 120x48 (as 180x96 mode 1)")),
    (1, dict(name="1  240x192x12.5 KWMM (old)", pics=3, size=(240, 192),
             text="key + 4x4 wavelet + B, C as 4 bit nibbles (CPU1 + CPU3)")),
    (KMDW, dict(name="5  240x192x12.5 KWWD", pics=3, size=(240, 192),
                text="180x96 mode 1 at 120x96 (A+B-C, A+C-B at 60x48) + 16 frequency DCT detail, shared A / B / C")),
    (KMMW, dict(name="6  240x192x12.5 KWWM", pics=3, size=(240, 192),
                text="180x96 mode 2 at 120x96 (A key, B, C at 60x48) + 16 frequency DCT detail, shared A / B / C")),
    (KWL, dict(name="2  240x192x12.5 KWMM", pics=3, size=(240, 192),
               text="key + 4x4 wavelet + (B+C)/2 at 120x48 + B, C at 60x48; RX motion search (as 180x96 mode 2)")),
    (2, dict(name="-  120x96x12.5 H KMM (old)", pics=3, size=(120, 96),
             text="key + B, C top nibbles bit-interleaved + low nibble average in Hilbert order (CPU4)")),
    (3, dict(name="-  120x96x12.5 M KMM (old)", pics=3, size=(120, 96),
             text="key + B, C top 2 bits interleaved + 2 bit average in Hilbert order (CPU2)")),
    (4, dict(name="3  120x96x12.5 KMM", pics=3, size=(120, 96),
             text="key + (B+C)/2 fields + B, C at 60x48")),
    (5, dict(name="4  120x96x8.3 KK", pics=2, size=(120, 96),
             text="two keys, the second sent Y first")),
    (WIDE, dict(name="1  180x96x12.5 KMD", pics=3, size=(180, 96),
                text="R-Y, B-Y 90x48 + (A+B+C)/3 fields + A+B-C, A+C-B at 90x48")),
    (WIDEK, dict(name="2  180x96x12.5 KMM", pics=3, size=(180, 96),
                 text="R-Y, B-Y 90x48 + A full 180x96 (key) + B, C at 90x48; RX motion search (improved)")),
])


def enc_list(mode):
    """The encoder modes a format has: four motion modes + KK for 120x96, the wide one for 180x96."""
    return [WIDE, WIDEK] if mode.w == 180 else [KWD, KWL, 4, 5, KMDW, KMMW]


def eff_enc(mode, enc):
    if mode.w == 180 and int(enc) == KMMW:
        return WIDEK
    if mode.w == 180 and int(enc) in (KWDM, KMDE, KWH, KMDW):   # (5.36's KMD-E, code 2 in 180x96: KMD)
        return WIDE
    if int(enc) in (KMS, KWDM, KWSC, KWH):           # (5.47: the old modes 5-7 KWMD-MC, -SC, -H gone - mode 1)
        return KWD
    enc = ROBUST.get(int(enc), int(enc))             # (1R-3R from old settings: now 1-3)
    if enc == 1 and mode.w == 120:                   # mode 1 is KWMD now (the old KWMM: inside only)
        enc = KWD
    # (the old H KMM and M KMM, and anything else unknown: L KMM, the most robust 120x96 mode)
    return enc if enc in enc_list(mode) else (enc_list(mode)[0] if mode.w == 180 else 4)


def enc_name(mode, enc):
    return ENC_MODES[eff_enc(mode, enc)]["name"]


def enc_short(enc):
    """'1', '2' ... for labels (180x96 has its own 1 and 2)."""
    return ENC_MODES[int(enc)]["name"].split()[0] if int(enc) in ENC_MODES else str(enc)


def pic_size(mode, enc):
    return ENC_MODES[eff_enc(mode, enc)]["size"]


def frame_seconds(mode, cp=0):
    """Air time of one data frame (the guard makes every symbol longer)."""
    return mode.syms * (mode.nfft + int(cp)) / float(FS)


def audio_capacity(mode):
    """Stereo samples a data frame carries (5760: 0.24 s at 24 kHz with no guard)."""
    return mode.syms * mode.abps // 2


def resample_stereo(a, n_out):
    """Interleaved stereo (any dtype) -> n_out stereo samples, linear, float32 (n_out x 2)."""
    x = np.asarray(a, np.float32).reshape(-1, 2)
    n = len(x)
    if n == n_out:
        return x.copy()
    if n < 2:
        return np.repeat(x[:1], n_out, axis=0) if n else np.full((n_out, 2), 128.0, np.float32)
    pos = (np.arange(n_out) + 0.5) * (n / float(n_out)) - 0.5
    pos = np.clip(pos, 0, n - 1.0001)
    i = pos.astype(np.int64)
    f = (pos - i)[:, None]
    return (1 - f) * x[i] + f * x[i + 1]


class AudioClock:
    """How many sound samples a data frame stands for: the frame's air time at 24 kHz.  With no
    guard that is exactly what the frame carries (5760); with a guard the frame lasts longer, so
    the TX squeezes a little more sound into it and the RX stretches it back - else the sound runs
    ahead of the pictures by the guard's share (1.5 % with guard 3: 13 s an hour)."""

    def __init__(self, seconds):
        self.per = round(float(seconds) * AUDIO_FS, 6)
        self.acc = 0.0

    def next(self):
        """Samples for the next frame (whole numbers that add up exactly over time)."""
        self.acc += self.per
        n = int(self.acc)
        self.acc -= n
        return n


def _kaiser_sinc(taps=16, phases=256, cut=0.45, beta=8.0):
    """Interpolation filters: for each of `phases` fractions of a sample, `taps` weights (a
    Kaiser-windowed sinc, passing up to cut x the sample rate)."""
    k = np.arange(taps) - (taps // 2 - 1)                # -7 .. 8
    fr = np.arange(phases) / float(phases)
    x = k[None, :] - fr[:, None]
    w = np.i0(beta * np.sqrt(np.clip(1 - (x / (taps / 2.0)) ** 2, 0, 1))) / np.i0(beta)
    h = 2 * cut * np.sinc(2 * cut * x) * w
    return (h / h.sum(axis=1, keepdims=True)).astype(np.float32), k


_SINC, _SINC_K = _kaiser_sinc()


def interp_sinc(buf, pos):
    """buf (N x 2) read at fractional positions pos (N indices from 7 to len-9 are safe; outside,
    the ends are held).  Unlike straight-line interpolation, this keeps the high notes (and the
    hiss) at the same level whatever the fraction - so a slowly changing speed doesn't make the
    hiss flutter."""
    pos = np.asarray(pos, np.float64)
    i = np.floor(pos).astype(np.int64)
    ph = np.minimum(((pos - i) * _SINC.shape[0]).astype(np.int64), _SINC.shape[0] - 1)
    idx = np.clip(i[:, None] + _SINC_K[None, :], 0, len(buf) - 1)
    h = _SINC[ph]                                         # n x taps
    return np.einsum("nk,nkc->nc", h, buf[idx])


class StreamResampler:
    """A steady change of sample rate for a stream that comes in blocks (no seams between them):
    `step` input samples per output sample."""

    def __init__(self, step):
        self.step = float(step)
        self.buf = np.full((16, 2), 128.0, np.float32)
        self.pos = 8.0

    def process(self, x, n_out):
        """Add input x (stereo, any length); take n_out output samples."""
        self.buf = np.concatenate((self.buf, np.asarray(x, np.float32).reshape(-1, 2)))
        p = self.pos + self.step * np.arange(n_out)
        out = interp_sinc(self.buf, p)
        self.pos += self.step * n_out
        k = int(self.pos) - 8
        if k > 0:
            self.buf = self.buf[k:]
            self.pos -= k
        return out


EMPHASIS = ("Off", "50 us", "75 us")


def emph_tau(name):
    """The time constant (s) of an emphasis setting, None for Off."""
    return {"50 us": 50e-6, "75 us": 75e-6}.get(name)


class Emphasis:
    """FM-style sound pre-emphasis (TX) and de-emphasis (RX), at the 24 kHz sound rate.

    Pre:  y = g (x - k x[n-1]),  k = exp(-1 / (tau fs)), g = 1 / (1 - k): unity at DC, the treble lifted
          from the corner 1 / (2 pi tau) up (50 us: 3.2 kHz, +7.8 dB at 10 kHz; 75 us: 2.1 kHz, +11 dB).
    De:   y = x / g + k y[n-1]: the exact inverse - the sound comes back flat, and the channel's
          hiss (flat across 0-12 kHz) loses its treble: about -4.0 dB (50 us) / -5.7 dB (75 us) overall,
          more than that where the ear hears hiss most.
    The TX also has a soft limiter after the lift, so bright sounds (cymbals, sibilants) round off
    near full scale instead of hitting the 8-bit end stop."""

    BLK = 128

    def __init__(self, tau, pre, fs=AUDIO_FS):
        self.tau, self.pre = tau, pre
        self.k = math.exp(-1.0 / (tau * fs))
        self.g = 1.0 / (1.0 - self.k)
        i = np.arange(self.BLK)
        self.M = np.tril(self.k ** (i[:, None] - i[None, :]).clip(0)).astype(np.float64)   # de: y = M u + k^(i+1) y0
        self.kp = self.k ** (i + 1.0)
        self.reset()

    def reset(self):
        self.last = np.zeros(2)                          # pre: the last input; de: the last output

    def process(self, x):
        """x: stereo (n x 2), 0 = silence (U8 - 128)."""
        x = np.asarray(x, np.float64).reshape(-1, 2)
        if self.pre:
            prev = np.vstack((self.last[None, :], x[:-1]))
            self.last = x[-1].copy() if len(x) else self.last
            y = self.g * (x - self.k * prev)
            # soft limiter: straight to 100, then rounding off towards 127
            a = np.abs(y)
            over = a > 100.0
            y[over] = np.sign(y[over]) * (100.0 + 27.0 * np.tanh((a[over] - 100.0) / 27.0))
            return y
        out = np.empty_like(x)
        y0 = self.last.copy()
        u = x / self.g
        for s in range(0, len(x), self.BLK):
            uc = u[s:s + self.BLK]
            n = len(uc)
            yc = self.M[:n, :n] @ uc + self.kp[:n, None] * y0[None, :]
            out[s:s + n] = yc
            y0 = yc[-1]
        self.last = y0
        return out


# ----------------------------------------------------------------------- stereo as sum and difference
# "Sum/diff": the sound sent as M = (L+R)/2 and S = (L-R)/2 instead of L and R.  When there is less
# room for sound (a fixed 12.5 fps layout with a guard), M keeps as much bandwidth as it can (24 kHz
# sampling - the full 12 kHz - if it fits) and S, the stereo image, takes what is left: above S's top
# the sound is mono.  Both stay analogue bytes, so the sound still fades into noise gently.
# L and R are rebuilt as M + S and M - S, so M and S must line up to the sample at every frequency
# (a 42 us slip costs the stereo above a few kHz).  Here they can: they ride in the same OFDM symbols
# (one clock - no drift between them), the rate changes are linear-phase FIR filters (the same delay
# at every frequency), and the paths' delays are whole samples at 24 kHz, matched by a delay line.
STEREO_CODINGS = ("Sum/diff",)                   # (always, since 5.11)
MS_FULL = 5760                                   # samples per codec frame at 24 kHz (0.24 s)


# How the sound's room is shared between M (R+L) and S (R-L) when it can't carry both at 24 kHz:
# Auto gives M its full 24 kHz first (12 kHz audio), S the rest; the others give M that share of the
# room (S then has more: a wider stereo image, M's top end a little lower).  Sent in the mode word.
MS_SPLITS = ("Auto", "M 55%", "M 50%")       # (never less for M: S wider than M puts L-R alone, out of phase, at the top)


def ms_split(nbytes, split="Auto"):
    """Bytes a codec frame has for sound -> (M samples, S samples) per codec frame (multiples of
    120, so the rate changes are exact fractions of 24 kHz)."""
    nb = int(nbytes) // 120 * 120
    if split in MS_SPLITS[1:] and nb < 2 * MS_FULL:
        f = float(split.split()[1].rstrip("%")) / 100.0
        nm = min(MS_FULL, int(round(f * nb / 120.0)) * 120)
        ns = min(MS_FULL, nb - nm)
        return nm, ns
    if nb >= 2 * MS_FULL:
        return MS_FULL, MS_FULL
    if nb - MS_FULL >= int(0.3 * MS_FULL):       # M at full rate, S gets the rest (S at 7.2 kHz or more)
        return MS_FULL, nb - MS_FULL
    ns = int(round(0.3 * nb / 120.0)) * 120      # less room: about 70 / 30
    return nb - ns, ns


class PolyResampler:
    """Rate change by up/down, a stream in pieces with no seams: one linear-phase (Kaiser windowed
    sinc) FIR, run as a polyphase filter.  The same filter both ways (TX down, RX up), so the two
    together delay by exactly `delay24` samples at 24 kHz."""

    def __init__(self, up, down, h):
        self.P, self.Q = int(up), int(down)
        T = -(-len(h) // self.P)
        hp = np.zeros(T * self.P)
        hp[:len(h)] = h * self.P
        self.H = hp.reshape(T, self.P).T.copy()            # H[phase, tap] = h[phase + tap * P]
        self.T = T
        self.tt = np.arange(T)
        self.buf = np.zeros(T - 1)
        self.n0 = -(T - 1)                                 # absolute input index of buf[0]
        self.k = 0                                         # next output (absolute)

    def process(self, x):
        buf = np.concatenate((self.buf, np.asarray(x, np.float64)))
        n_end = self.n0 + len(buf)
        kmax = (n_end * self.P - 1) // self.Q
        ks = np.arange(self.k, kmax + 1)
        m = ks * self.Q
        i0, ph = m // self.P, m % self.P
        y = (self.H[ph] * buf[i0[:, None] - self.tt[None, :] - self.n0]).sum(axis=1)
        self.k = kmax + 1
        start = (self.k * self.Q) // self.P - (self.T - 1)
        self.buf = buf[start - self.n0:]
        self.n0 = start
        return y


def _ms_filter(n):
    """The rate n / 5760 of 24 kHz: (P, Q, h, delay of a down+up pair in 24 kHz samples)."""
    g = math.gcd(int(n), MS_FULL)
    P, Q = int(n) // g, MS_FULL // g
    if P == Q:
        return 1, 1, None, 0
    mx = max(P, Q)
    Ld = int(math.ceil(16.0 * mx / P))                     # 16 taps a phase, each way
    N = P * Ld + 1                                         # (N-1) = P * Ld: the pair delays Ld samples
    t = np.arange(N) - (N - 1) / 2.0
    fc = 0.92 / mx                                         # of the filter's Nyquist: 8 % to roll off
    h = fc * np.sinc(fc * t) * np.kaiser(N, 8.0)
    return P, Q, h / h.sum(), Ld


class _Delay:
    def __init__(self, n):
        self.buf = np.zeros(int(n))

    def process(self, x):
        if len(self.buf) == 0:
            return np.asarray(x, np.float64)
        b = np.concatenate((self.buf, x))
        self.buf = b[len(b) - len(self.buf):]
        return b[:len(x)]


MS_SGAIN = 2.0            # S sent at twice its level: its noise is halved back at the RX (L, R get
MS_KNEE = 96.0            # 1.25 x the noise instead of 2 x); a soft knee above 96 keeps it in the
                          # byte (only L and R far apart in opposite directions reach it) - undone at the RX


def ms_limit(x, inverse=False):
    """The soft knee: linear to MS_KNEE, then a tanh curve that never passes 127 (and its inverse)."""
    x = np.asarray(x, np.float64)
    a, K, R = np.abs(x), MS_KNEE, 127.0 - MS_KNEE
    if inverse:
        u = np.clip((a - K) / R, 0.0, 0.995)
        y = np.where(a > K, K + R * np.arctanh(u), a)
    else:
        y = np.where(a > K, K + R * np.tanh((a - K) / R), a)
    return np.sign(x) * y


class MSCoder:
    """Stereo (n x 2, centred on 0, U8 scale) of a codec frame <-> the bytes of a codec frame, as M
    and S at their own rates.  One for the TX, one for the RX (they keep their filters' history)."""

    def __init__(self, nbytes, split="Auto"):
        self.nbytes = int(nbytes)
        self.split = split if split in MS_SPLITS else "Auto"
        self.nM, self.nS = ms_split(nbytes, self.split)
        self.fM, self.fS = _ms_filter(self.nM), _ms_filter(self.nS)
        self.txM = self.txS = self.rxM = self.rxS = None
        if self.fM[2] is not None:
            self.txM, self.rxM = PolyResampler(self.fM[0], self.fM[1], self.fM[2]), PolyResampler(self.fM[1], self.fM[0], self.fM[2])
        if self.fS[2] is not None:
            self.txS, self.rxS = PolyResampler(self.fS[0], self.fS[1], self.fS[2]), PolyResampler(self.fS[1], self.fS[0], self.fS[2])
        dM, dS = self.fM[3], self.fS[3]
        self.delay = max(dM, dS)                            # the coder's delay (24 kHz samples)
        self.alignM, self.alignS = _Delay(self.delay - dM), _Delay(self.delay - dS)
        self.blend = 1.0

    def describe(self):
        return "M %.1f kHz, S %.1f kHz sampling (audio to %.1f / %.1f kHz)" % (
            self.nM / 240.0, self.nS / 240.0, self.nM / 480.0, self.nS / 480.0)

    def encode(self, st):
        st = np.asarray(st, np.float64).reshape(-1, 2)
        M, S = 0.5 * (st[:, 0] + st[:, 1]), 0.5 * (st[:, 0] - st[:, 1])
        if self.txM is not None:
            M = self.txM.process(M)
        if self.txS is not None:
            S = self.txS.process(S)
        out = np.full(self.nbytes, 128, np.uint8)
        out[:self.nM] = np.clip(np.round(M[:self.nM] + 128.0), 0, 255)
        S = ms_limit(MS_SGAIN * S[:self.nS])
        out[self.nM:self.nM + self.nS] = np.clip(np.round(S + 128.0), 0, 255)
        return out

    def decode(self, b, blend=1.0):
        """-> (5760 x 2) L, R centred on 0 (floats: 16 bit sound keeps the fractions).  blend < 1:
        the stereo turned down (its noise with it) - as an FM receiver blends to mono."""
        b = np.asarray(b, np.float64)
        M, S = b[:self.nM] - 128.0, ms_limit(b[self.nM:self.nM + self.nS] - 128.0, inverse=True) / MS_SGAIN
        if self.rxM is not None:
            M = self.rxM.process(M)
        if self.rxS is not None:
            S = self.rxS.process(S)
        M, S = self.alignM.process(M), self.alignS.process(S) * float(blend)
        return np.stack((M + S, M - S), axis=1)


class DualCoder:
    """Dual mono (5.29): two separate sound channels - Ch 1 and Ch 2, say two languages - each on half the
    sound bytes, at the same rate (no sum and difference: one channel's noise never lands in the other).
    Ch 1 is the input's left, Ch 2 its right.

    Common mode: when the two channels are the same programme, Ch 1 goes out on both halves and the
    receiver averages the two copies - the same sound with half the noise power (+3 dB), for nothing."""

    def __init__(self, nbytes):
        self.nbytes = int(nbytes)
        self.split = "Dual"
        n = min(MS_FULL, (self.nbytes // 2) // 120 * 120)
        self.nM = self.nS = self.n = n
        f = _ms_filter(n)
        self.tx = self.rx = None
        if f[2] is not None:
            self.tx = [PolyResampler(f[0], f[1], f[2]) for _ in range(2)]
            self.rx = [PolyResampler(f[1], f[0], f[2]) for _ in range(2)]
        self.delay = f[3]

    def describe(self):
        return "dual mono: Ch 1 and Ch 2 each %.1f kHz sampling (audio to %.1f kHz)" % (self.n / 240.0, self.n / 480.0)

    def encode(self, st, common=False):
        st = np.asarray(st, np.float64).reshape(-1, 2)
        ch = [st[:, 0], st[:, 0] if common else st[:, 1]]
        if self.tx is not None:
            ch = [r.process(x) for r, x in zip(self.tx, ch)]
        out = np.full(self.nbytes, 128, np.uint8)
        for k in range(2):
            out[k * self.n:(k + 1) * self.n] = np.clip(np.round(ch[k][:self.n] + 128.0), 0, 255)
        return out

    def decode(self, b, common=False):
        """-> (5760 x 2) Ch 1, Ch 2 centred on 0; common: both the average of the two copies."""
        b = np.asarray(b, np.float64)
        ch = [b[:self.n] - 128.0, b[self.n:2 * self.n] - 128.0]
        if self.rx is not None:
            ch = [r.process(x) for r, x in zip(self.rx, ch)]
        if common:
            a = 0.5 * (ch[0] + ch[1])
            ch = [a, a]
        return np.stack(ch, axis=1)


AUDIO_MODES = ("Stereo", "Dual mono")
COMMON_MODES = ("Auto", "On", "Off")
LISTEN = ("Both", "Ch 1", "Ch 2")


def sound_coder(nbytes, split):
    """The sound coder for a split: "Dual" -> dual mono, else sum and difference."""
    return DualCoder(nbytes) if split == "Dual" else MSCoder(nbytes, split)


def is_common(st):
    """Are the two input channels the same programme? (difference 40 dB down, or under half a step)"""
    st = np.asarray(st, np.float64).reshape(-1, 2)
    st = st - 128.0 if st.mean() > 64.0 else st              # (on the U8 scale: centred first)
    d = np.sqrt(np.mean((st[:, 0] - st[:, 1]) ** 2))
    return bool(d <= max(0.5, 0.01 * np.sqrt(np.mean(st ** 2))))


def ms_blend(snr):
    """Auto stereo blend from the RX SNR (dB): full stereo from 20 dB, down to 0.3 at 9.5 dB and below."""
    if snr is None:
        return 1.0
    return float(np.clip((snr - 5.0) / 15.0, 0.3, 1.0))


class Compander:
    """Differential (sum and difference) noise reduction for the stereo sound: a 2:1 compander on
    R+L and R-L, as FM stereo (and dbx) do it.

    TX (compress=True):  M = (R+L)/2, S = (R-L)/2, then each through a 2:1 compressor: below 0 dB
        the level in dB is halved (-40 dB goes out at -20 dB); at 0 dB and over it is left alone.
    RX (compress=False): each expanded 1:2 again, then L = M - S, R = M + S.
    0 dB = a full-scale sine's RMS (90 on the 8-bit sound).  The most it lifts is +30 dB (at -60 dB).

    Quiet sound goes over the air louder, and the receiver turns it - and the hiss that the
    channel added to it - back down: hiss in quiet passages drops by about half its level in dB.
    The difference S is quiet whenever the sound is near mono, so its hiss - the noise that
    makes a stereo picture wander and fizz between the speakers - is pushed right down.

    The compressor takes its gain from its own output (feedback, as dbx), so the expander, which
    sees that same signal over the air, works out the same gain from it: with no noise the two
    track exactly.  Gains change once every 16 samples (0.67 ms), ramped across the block; the level
    is RMS, rising with a 1 ms and falling with a 60 ms time constant.  No delay.  A jump from
    quiet to loud overshoots (clips) for about 1 ms, as on any compander."""

    BLK = 16
    REF = 90.0                                           # 0 dB: a full-scale sine's RMS
    FLOOR = 10 ** (-30.0 / 20.0)                         # most lift: +30 dB (an input of -60 dB)

    def __init__(self, compress, fs=AUDIO_FS):
        self.compress = bool(compress)
        dt = self.BLK / float(fs)
        self.a_att = math.exp(-dt / 0.001)
        self.a_rel = math.exp(-dt / 0.060)
        self.reset()

    def reset(self):
        self.env2 = np.full(2, self.REF ** 2)            # start at 0 dB: no lift (both ends alike)
        self.g = np.ones(2)
        self.lift_db = 0.0

    def process(self, x):
        """x: stereo (n x 2), 0 = silence (U8 - 128).  TX: L, R in -> M, S out; RX: M, S in -> L, R."""
        x = np.asarray(x, np.float64).reshape(-1, 2)
        if self.compress:
            u = np.column_stack(((x[:, 1] + x[:, 0]) * 0.5, (x[:, 1] - x[:, 0]) * 0.5))
        else:
            u = x
        out = np.empty_like(u)
        B = self.BLK
        lifts = []
        for s0 in range(0, len(u), B):
            ub = u[s0:s0 + B]
            n = len(ub)
            e = np.clip(np.sqrt(self.env2) / self.REF, self.FLOOR, 1.0)
            g_new = 1.0 / e if self.compress else e
            ramp = self.g[None, :] + (g_new - self.g)[None, :] * (np.arange(1, n + 1)[:, None] / float(n))
            yb = ub * ramp
            if self.compress:
                yb = np.clip(yb, -127.0, 127.0)
                meas = yb                                # the compressor hears what it sends
            else:
                meas = ub                                # the expander hears what came
            p = np.mean(meas * meas, axis=0)
            a = np.where(p > self.env2, self.a_att, self.a_rel)
            self.env2 = a * self.env2 + (1.0 - a) * p
            self.g = g_new
            out[s0:s0 + n] = yb
            lifts.append(g_new)
        if lifts:
            gl = np.mean(lifts, axis=0)
            self.lift_db = float(20 * np.log10(max(gl[1], 1e-9)))   # the difference channel's (for the info line)
        if self.compress:
            return out
        return np.column_stack((out[:, 0] - out[:, 1], out[:, 0] + out[:, 1]))


class InstantCompander:
    """The instantaneous form: no detector, no attack or release - each sample goes through a fixed
    2:1 curve (its level in dB halved, up to 0 dB = full scale 127) and the expander through the exact
    inverse curve, so it tracks the compressor sample for sample with no delay.
      compress:  y = 127 sign(x) sqrt(|x| / 127)      (below -60 dB a straight +30 dB, so the
      expand:    x = sign(y) y^2 / 127                  curve has no infinite slope at zero)
    Same sum and difference (R+L, R-L) as Compander."""

    A0 = 127.0
    KNEE = A0 * 1e-3                                     # -60 dB: below it a fixed +30 dB lift
    LIFT = 10 ** 1.5

    def __init__(self, compress):
        self.compress = bool(compress)
        self.lift_db = None

    def reset(self):
        pass

    def _c(self, x):
        a = np.abs(x)
        return np.sign(x) * np.where(a < self.KNEE, a * self.LIFT, self.A0 * np.sqrt(np.minimum(a, self.A0) / self.A0))

    def _e(self, y):
        a = np.abs(y)
        kn = self.KNEE * self.LIFT
        return np.sign(y) * np.where(a < kn, a / self.LIFT, a * a / self.A0)

    def process(self, x):
        x = np.asarray(x, np.float64).reshape(-1, 2)
        if self.compress:
            u = np.column_stack(((x[:, 1] + x[:, 0]) * 0.5, (x[:, 1] - x[:, 0]) * 0.5))
            return self._c(u)
        u = self._e(x)
        return np.column_stack((u[:, 0] - u[:, 1], u[:, 0] + u[:, 1]))


COMPANDERS = ("Off", "Syllabic")                 # (Instant: kept inside, not offered - impulse noise)


def compander_name(v):
    """The setting as a name (older settings kept 0 / 1; Instant is no longer used: Off)."""
    if isinstance(v, (int, float)):
        return COMPANDERS[int(v)] if 0 <= int(v) < len(COMPANDERS) else "Off"
    return v if v in COMPANDERS else "Off"


def make_compander(name, compress):
    return {"Syllabic": Compander, "Instant": InstantCompander}[name](compress) if name in ("Syllabic", "Instant") else None


AUDIO_NR = ("Off", "Light", "Strong", "Auto")


def nr_mode(mode, snr):
    """Auto: Off with a clean signal, Light, then Strong as the signal goes into the noise - and Light again
    below 2 dB (5.41): there Strong took the programme down with the hiss (19 dB of a tone at 0 dB C/N) for
    no better SNR."""
    if mode != "Auto":
        return mode
    if snr is None or snr >= 32:
        return "Off"
    return "Light" if (snr >= 21 or snr < 2) else "Strong"


def sound_noise(coder, snr, blend=1.0, common=False):
    """The noise on each decoded sound sample (U8 scale) for the RX's SNR - for the sound NR (5.41).  The
    bytes' noise (noise_sigma) is band-limited by the coder's resampling (M at nM, S at nS of MS_FULL
    samples a frame) and S's comes down by its gain; before 5.41 the NR was told sqrt(1 + blend^2) times
    the bytes' noise, 14-38% too high, and turned the programme down with the hiss below 10 dB C/N."""
    s = noise_sigma(snr)
    if isinstance(coder, DualCoder):
        return s * math.sqrt(coder.n / float(MS_FULL)) * (math.sqrt(0.5) if common else 1.0)
    return s * math.sqrt(coder.nM / float(MS_FULL) + blend * blend * (coder.nS / float(MS_FULL)) / MS_SGAIN ** 2)


def noise_sigma(snr):
    """The noise on each received byte (sound or picture level, 0-255) for the RX's SNR estimate."""
    return 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 40.0, 45.0), -5.0) / 10.0))


NR_DD = 0.90                                           # the sound NR's "decision directed" smoothing (0.98 before 5.41: quiet sound held at the floor)


class AudioNR:
    """Noise reduction for the received sound (the RX's own, per channel).

    The noise on the sound is the channel's noise on the audio carriers: white, and of a level the
    receiver already knows from its SNR estimate (the pilots) - so it needn't be guessed from the
    sound.  The sound is cut into 21 ms pieces (512 samples, half overlapping, sqrt-Hann), and in
    each piece every frequency is turned down by how much of it is noise: a Wiener gain, with the
    "decision directed" smoothing (Ephraim-Malah) that stops the left-over hiss turning into
    twittering ("musical noise"), the gains smoothed across neighbouring frequencies, and a floor
    so that it is never cut to nothing (the hiss is lowered, the sound left natural).  Quiet parts
    and the frequencies the sound doesn't use go down to the floor; where the sound is loud, it is
    left alone.  At a good SNR it does nothing.
      Light:  floor -12 dB, noise taken as measured
      Strong: floor -20 dB, noise taken 1.5x (more off, a little more colouring)
    Delay: 512 samples (21 ms)."""

    N, HOP = 512, 256
    DELAY = 512                                          # samples (the sound comes out this much later)

    def __init__(self):
        self.win = np.sqrt(0.5 - 0.5 * np.cos(2 * np.pi * np.arange(self.N) / self.N)).astype(np.float32)
        self.reset()

    def reset(self):
        self.inb = np.zeros((self.N - self.HOP, 2), np.float32)        # the last part of the last piece
        self.ola = np.zeros((self.N - self.HOP, 2), np.float32)
        self.out = np.zeros((self.N - self.HOP, 2), np.float32)        # ready (the delay, at first silence)
        self.prev = None                                               # |cleaned|^2 of the last piece
        self.used = 0.0

    def process(self, x, sigma, mode="Light"):
        """x: stereo samples (n x 2, 0 = silence, i.e. U8 - 128); sigma: the noise per sample (same
        units).  -> n samples, 21 ms later."""
        x = np.asarray(x, np.float32).reshape(-1, 2)
        n = len(x)
        if mode not in AUDIO_NR[1:]:
            mode = None
        floor, over = (0.25, 1.0) if mode == "Light" else (0.1, 1.5)
        nps = over * max(float(sigma), 0.3) ** 2 * float(np.sum(self.win ** 2))   # noise power per bin
        buf = np.concatenate((self.inb, x))
        outs = [self.out]
        i = 0
        gsum, gn = 0.0, 0
        while i + self.N <= len(buf):
            fr = buf[i:i + self.N] * self.win[:, None]
            if mode is None:
                y = fr
            else:
                S = np.fft.rfft(fr, axis=0)
                P = np.abs(S) ** 2
                gam = np.minimum(P / nps, 1e4)                              # a posteriori SNR
                if self.prev is None:
                    xi = np.maximum(gam - 1.0, 0.0)
                else:
                    xi = NR_DD * self.prev / nps + (1.0 - NR_DD) * np.maximum(gam - 1.0, 0.0)
                G = xi / (1.0 + xi)
                G = (np.roll(G, 1, 0) + 2 * G + np.roll(G, -1, 0)) / 4.0    # neighbours: no lone tones
                G = np.maximum(G, floor)
                Y = G * S
                self.prev = np.abs(Y) ** 2
                y = np.fft.irfft(Y, self.N, axis=0)
                gsum += float(np.mean(G))
                gn += 1
            y = y * self.win[:, None]
            y[:self.N - self.HOP] += self.ola
            outs.append(y[:self.HOP])
            self.ola = y[self.HOP:].copy()
            i += self.HOP
        self.inb = buf[i:]
        o = np.concatenate(outs)
        self.out = o[n:]
        if gn:
            self.used = 1.0 - gsum / gn                                   # how much it is taking off
        return o[:n]


class AVSync:
    """Keeps the received pictures and sound together, however long it runs.

    Timeline: every data frame is one frame time of the transmitter's own time (its media time):
    frame k starts at k x frame time, its sound runs from there for one frame time, and its
    pictures (two or three) are evenly spaced across it.  The receiver counts frames by where they
    start in its own samples, so a lost frame leaves a gap of silence (and no pictures) instead of
    pulling everything after it forward.

    Clock: the sound is the master.  It is played from a buffer held at a set depth.  If frames
    come a little faster or slower than the sound card plays (TX clock against RX clock), the sound
    plays that much faster or slower to hold the depth - but slowly: the depth is averaged over
    seconds (it saw-tooths by a frame each time one arrives), the speed moves by a few ppm a second
    at most and stays put inside a dead band, so there is no flutter.  The resampling is a 16 tap
    windowed sinc (straight-line interpolation makes hiss flutter as the fraction drifts).  A
    picture is shown when the sound reaches its time.  With the sound off the same clock runs on
    the computer's time."""

    def __init__(self, period, n_pics, lag_frames=1):
        self.period, self.n = float(period), int(n_pics)
        self.lag = int(lag_frames)                       # pictures come this many frames after their sound
        self.fs = float(AUDIO_FS)
        self.base = self.lag * self.period + 0.40        # sound held in hand (s): the pictures' wait + slack
        self.target = self.base                          # (raised if the pictures come later than that)
        self.lip = 0.0                                   # pictures earlier (+) / later (-), seconds
        self.reset()

    def reset(self):
        self.target = self.base
        self.cap = None                                  # samples a frame carries
        self.buf = np.zeros((0, 2), np.float32)          # sound as carried, not yet played
        self.buf_t = None                                # media time of buf[0]
        self.pos = 0.0                                   # play position in buf (samples)
        self.playing = False
        self.trim = 1.0                                  # speed against the frame rate
        self.integ = 0.0                                 # its long-term part (the clocks' difference)
        self.davg = None                                 # depth, averaged
        self.k = None                                    # media frame number of the last frame in
        self.last_start = None                           # its start, in RX seconds
        self.kmap = collections.OrderedDict()            # frame start (RX ms) -> media frame number
        self.lag_seen = 0.0                              # how late pictures have come (s)
        self.vq = collections.deque()                    # (media time, picture)
        self.st = dict(frames=0, lost=0, under=0, skips=0, late=0, shown=0, restarts=0)
        self.err = collections.deque(maxlen=50)          # picture shown minus clock (s)

    @property
    def bfs(self):
        """Buffer samples per second of media time (5760 per frame time)."""
        return (self.cap or self.period * self.fs) / self.period

    # ---- in
    def push(self, audio_u8, start, pics=()):
        """One received frame: its sound (the samples the frame carries, interleaved U8) and where
        it started (RX seconds); pics: the pictures that came with it (those of `lag` frames back)."""
        if self.last_start is None:
            dk = 1
            self.k = -1
        else:
            dk = int(round((start - self.last_start) / self.period))
            if dk <= 0 or dk > 25:                       # the receiver re-synced: carry straight on
                self.st["restarts"] += 1                 # (no gap, no refilling the buffer)
                dk = 1
        self.last_start = start
        self.k += dk
        self.st["frames"] += 1
        a = np.asarray(audio_u8, np.float32).reshape(-1, 2)
        if self.cap != len(a):                           # (first frame, or the sound's coding changed)
            self.cap = len(a)
        if self.buf_t is None:
            self.buf_t, self.pos = self.k * self.period, 8.0
            self.buf = np.full((8, 2), 128.0, np.float32)
        if dk > 1:                                       # frames lost: their time in silence
            self.st["lost"] += dk - 1
            self.buf = np.concatenate((self.buf, np.full(((dk - 1) * self.cap, 2), 128.0, np.float32)))
        self.buf = np.concatenate((self.buf, a))
        self.kmap[int(round(start * 1000))] = self.k
        while len(self.kmap) > 32:
            self.kmap.popitem(last=False)
        if pics:
            self.push_pics(start, pics)

    def push_pics(self, start, pics, part=0, nparts=1):
        """The pictures of the frame that started at `start` (RX seconds) - they come later than its
        sound (the decoder waits for the next key, then the upscaler) and are put in its time."""
        if not pics or not self.kmap:
            return
        key = int(round(start * 1000))
        k = self.kmap.get(key)
        if k is None:                                    # (rounding) the nearest frame start
            near = min(self.kmap, key=lambda s_: abs(s_ - key))
            if abs(near - key) > 500 * self.period:
                return
            k = self.kmap[near]
        n = len(pics) * nparts                           # (long symbols: two halves a frame)
        t0 = k * self.period + part * self.period / nparts
        # the sound must be at least this far behind the newest sound for this picture to be in time:
        # the target depth follows the latest pictures need (up at once, down slowly)
        if self.buf_t is not None:
            need = (self.buf_t + (len(self.buf) - 8) / self.bfs - t0) - self.lip + 0.15
            self.lag_seen = need
            self.target = float(min(3.0, max(self.base, need, self.target - 0.003)))
        for i, p in enumerate(pics):
            self.vq.append((t0 + i * self.period / n, p))
        if len(self.vq) > 1 and self.vq[-1][0] < self.vq[-2][0]:
            self.vq = collections.deque(sorted(self.vq, key=lambda q: q[0]))

    # ---- the clock
    def depth(self):
        return (len(self.buf) - 8 - self.pos) / self.bfs

    def clock(self, latency=0.0):
        """The media time being heard (and to be shown) now."""
        if self.buf_t is None or not self.playing:
            return None
        return self.buf_t + (self.pos - 8) / self.bfs - latency

    def _rate(self, dt):
        if not self.playing:
            if self.buf_t is not None and self.depth() >= self.target:
                self.playing = True
                self.davg = self.depth()
            else:
                return False
        d = self.depth()
        if d < self.target - self.period - 0.15:          # well short (frames came late): the pictures
            self.playing = False                          # would all be late - wait (a short gap) and
            self.st["rebuf"] = self.st.get("rebuf", 0) + 1   # start again from a full buffer
            return False
        self.davg += min(1.0, dt / 3.0) * (d - self.davg)     # averaged over ~3 s (the saw-tooth goes)
        e = self.davg - self.target
        if d - self.target > 1.5:                         # far behind (the computer stalled): catch up
            self.pos += (d - self.target) * self.bfs
            self.davg = self.target
            self.st["skips"] += 1
            return True
        # wanted speed: 0.1 s too much in hand -> 200 ppm faster; nothing inside +-0.04 s
        ee = 0.0 if abs(e) < 0.04 else e - 0.04 * np.sign(e)
        self.integ = float(np.clip(self.integ + 2e-4 * ee * dt, -0.004, 0.004))   # learns the ppm
        want = 1.0 + float(np.clip(self.integ + 0.002 * ee, -0.005, 0.005))
        # move towards it slowly (at most 30 ppm a second): no audible pitch change
        self.trim += float(np.clip(want - self.trim, -30e-6 * dt, 30e-6 * dt)) if abs(e) < 0.4 else \
            float(np.clip(want - self.trim, -300e-6 * dt, 300e-6 * dt))
        return True

    def _trim(self):
        k = int(self.pos) - 16
        if k > 24000:
            self.buf = self.buf[k:]
            self.buf_t += k / self.bfs
            self.pos -= k

    def audio(self, n):
        """The next n stereo samples to play (float, U8 levels; n x 2)."""
        if not self._rate(n / self.fs):
            return np.full((n, 2), 128.0, np.float32)
        step = self.bfs / self.fs * self.trim             # buffer samples per output sample
        p = self.pos + step * np.arange(n)
        have = len(self.buf) - 9
        out = np.full((n, 2), 128.0, np.float32)
        ok = p < have
        if not ok.all():
            self.st["under"] += 1
        if ok.any():
            out[ok] = interp_sinc(self.buf, p[ok])
        self.pos = min(self.pos + step * n, float(max(have, 8)))
        self._trim()
        return out

    def advance(self, dt):
        """No sound out: the clock runs on the computer's time instead."""
        if not self._rate(dt):
            return
        self.pos = min(self.pos + self.bfs * self.trim * dt, float(max(len(self.buf) - 9, 8)))
        self._trim()

    # ---- out
    def pick(self, clock):
        """The picture to show at this clock (None: keep the one shown)."""
        if clock is None:
            return None
        show = None
        c = clock + self.lip
        while self.vq and self.vq[0][0] <= c:
            pt, p = self.vq.popleft()
            if show is not None:
                self.st["late"] += 1                     # (skipped: a newer one is due too)
            show = (pt, p)
        if show is None:
            return None
        self.st["shown"] += 1
        self.err.append(show[0] - c)
        return show[1]

    def report(self):
        e = np.array(self.err) if self.err else np.zeros(1)
        return dict(self.st, av_ms=1000.0 * float(np.mean(e)), av_jit_ms=1000.0 * float(np.std(e)),
                    depth=self.depth() if self.buf_t is not None else 0.0, ppm=(self.trim - 1.0) * 1e6,
                    playing=self.playing, queued=len(self.vq))


def pics_per_frame(enc):
    return ENC_MODES[int(enc)]["pics"] if int(enc) in ENC_MODES else 3


def frame_layout(mode, enc, detail="masks"):
    """The blocks of a data frame in the order sent: [(name, columns, what)].  Each block is 48 rows,
    scanned a column at a time; the columns add up to 720."""
    enc = ROBUST.get(eff_enc(mode, enc), eff_enc(mode, enc))
    if enc == KWH:                                 # (mode 7: mode 1's frame, its average key as the 4-line split)
        return [("R-Y", 60, "colour 60x48"), ("B-Y", 60, "colour 60x48"),
                ("4-line mean", 160, "(A+B+C)/3 at 240x192: each 4 lines' mean, 160 points"),
                ("Diff 1", 50, "top 2 - bottom 2, x%g, 50 points" % KWH_G[1]),
                ("Diff 2", 20, "middle - outer, x%g, 20 points" % KWH_G[2]),
                ("Diff 3", 10, "alternate lines, x%g, 10 points" % KWH_G[3]),
                ("Wavelet", 120, "the 240x192 detail of A (DCT)"),
                ("A+B-C", 120, "(A+B+255-C)/3 at 120x48"), ("A+C-B", 120, "(A+C+255-B)/3 at 120x48")]
    if enc in (KMDW, KMMW):                        # (modes 5, 6: the 180x96 modes at 120 wide + 16 frequency detail)
        mid = ([("(A+B+C)/3 even", 120, "even lines"), ("(A+B+C)/3 odd", 120, "odd lines")] if enc == KMDW else
               [("A even", 120, "key luma, even lines"), ("A odd", 120, "key luma, odd lines")])
        low = ([("A+B-C", 60, "(A+B+255-C)/3 at 60x48"), ("A+C-B", 60, "(A+C+255-B)/3 at 60x48")] if enc == KMDW else
               [("B", 60, "B at 60x48"), ("C", 60, "C at 60x48")])
        na, nb = WW_SPLIT
        det = ([("Detail DCT 1", 120, "8x8 DCT detail of 240x192: H | V at 4 frequencies"),
                ("Detail DCT 2", 120, "8x8 DCT detail of 240x192: 8 more frequencies")] if not nb else
               [("Detail A", 15 * na, "A's 240x192 detail: %d DCT frequencies" % na),
                ("Detail B", 15 * nb, "B's own detail, against its rebuilt 120x96: %d frequencies" % nb),
                ("Detail C", 15 * nb, "C's own detail, against its rebuilt 120x96: %d frequencies" % nb)])
        return [("R-Y", 60, "colour 60x48"), ("B-Y", 60, "colour 60x48")] + mid + det + low
    enc = KWD if enc in (KWDM, KWSC) else enc      # (modes 5 and 6 send mode 1's frame; 6's detail is SoftCast)
    key = [("R-Y", 60, "key colour 60x48"), ("B-Y", 60, "key colour 60x48"),
           ("Y even", 120, "key luma, even lines"), ("Y odd", 120, "key luma, odd lines")]
    lay = {1: key + [("Wavelet", 120, "4x4 blocks of 240x192, 16 bit masks, row by row"),
                     ("B|C even", 120, "B, C nibbles, even lines"), ("B|C odd", 120, "B, C nibbles, odd lines")],
           2: key + [("Low avg", 120, "(B+C)/2 low nibbles"), ("Motion B", 120, "B top nibbles"),
                     ("Motion C", 120, "C top nibbles")],
           3: key + [("Low avg", 120, "(B+C)/2 bits 5-4"), ("Motion B", 120, "B bits 7-6"),
                     ("Motion C", 120, "C bits 7-6")],
           4: key + [("(B+C)/2 even", 120, "even lines"), ("(B+C)/2 odd", 120, "odd lines"),
                     ("B", 60, "B at 60x48"), ("C", 60, "C at 60x48")],
           KWD: [("R-Y", 60, "colour 60x48"), ("B-Y", 60, "colour 60x48"),
                 ("(A+B+C)/3 even", 120, "even lines"), ("(A+B+C)/3 odd", 120, "odd lines"),
                 ("Wavelet", 120, "4x4 blocks of 240x192, 16 bit masks, row by row"),
                 ("A+B-C", 120, "(A+B+255-C)/3 at 120x48"), ("A+C-B", 120, "(A+C+255-B)/3 at 120x48")],
           KMS: [("R-Y", 60, "key colour 60x48"), ("B-Y", 60, "key colour 60x48"),
                 ("M even", 105, "key line pair sums, pairs 0, 2, 4 .."), ("M odd", 105, "key line pair sums, pairs 1, 3, 5 .."),
                 ("S even", 15, "key line pair differences x2"), ("S odd", 15, "key line pair differences x2"),
                 ("(B+C)/2 even", 120, "even lines"), ("(B+C)/2 odd", 120, "odd lines"),
                 ("B", 60, "B at 60x48"), ("C", 60, "C at 60x48")],
           KWL: key + [("Wavelet", 120, "4x4 blocks of 240x192, 16 bit masks, row by row"),
                        ("(B+C)/2", 120, "120x48: line pairs averaged"), ("B", 60, "B at 60x48"), ("C", 60, "C at 60x48")],
           5: [("K1 R-Y", 60, ""), ("K1 B-Y", 60, ""), ("K1 Y even", 120, ""), ("K1 Y odd", 120, ""),
               ("K2 Y even", 120, ""), ("K2 Y odd", 120, ""), ("K2 R-Y", 60, ""), ("K2 B-Y", 60, "")],
           WIDE: [("R-Y", 90, "colour 90x48"), ("B-Y", 90, "colour 90x48"),
                  ("(A+B+C)/3 even", 180, "even lines"), ("(A+B+C)/3 odd", 180, "odd lines"),
                  ("A+B-C", 90, "(A+B+255-C)/3 at 90x48"), ("A+C-B", 90, "(A+C+255-B)/3 at 90x48")],
           WIDEK: [("R-Y", 90, "colour 90x48"), ("B-Y", 90, "colour 90x48"),
                   ("A even", 180, "key luma, even lines"), ("A odd", 180, "key luma, odd lines"),
                   ("B", 90, "B at 90x48"), ("C", 90, "C at 90x48")]}[enc]
    if detail == "dct" and enc in (1, KWL, KWD):
        lay = [x if x[0] != "Wavelet" else ("Detail DCT", 120, "8x8 DCT detail of 240x192: H | V at 4 frequencies")
               for x in lay]
    assert sum(c for _, c, _ in lay) == 720
    return lay


def carrier_groups(mode):
    """Which bytes of the data frame each video carrier group sends: (group number, first byte, bytes).
    Each carrier's I and Q carry `syms` bytes in a row, so a group of n carriers carries 2 n syms bytes."""
    out, k = [], 0
    vb = set(mode.video_bins.tolist())
    for gi, (data, pilot) in enumerate(mode.groups):
        if data[0] in vb:
            n = 2 * len(data) * mode.syms
            out.append((gi, k, n))
            k += n
    return out


# ----------------------------------------------------------------------- encoder (TX)
def _key_colour(rgb, cw, ch):
    """The key's colour at cw x ch, coded as set_colour_coding says.  "1/4" is CPU1's exactly:
    Saturation(0.5), Y = (R+G+B)/3, R-Y byte = (R + 255 - Y) / 2."""
    if _CC["name"] != "1/4":
        lo = _down(rgb.astype(np.float32), rgb.shape[0] // ch, rgb.shape[1] // cw)
        Y = grey(lo)
        ryb, byb = chroma_to_bytes(lo[..., 0] - Y, lo[..., 2] - Y)
        return cm(_t8(np.round(ryb))), cm(_t8(np.round(byb)))
    lo = saturation(_down(rgb.astype(np.float32), rgb.shape[0] // ch, rgb.shape[1] // cw), 0.5)
    R, G, B = np.floor(lo[..., 0]), np.floor(lo[..., 1]), np.floor(lo[..., 2])
    Y = np.floor((R + G + B) / 3)
    return cm(_t8((R + (255 - Y)) / 2)), cm(_t8((B + (255 - Y)) / 2))


def _key(rgb120, second=False):
    """CPU1 YC_encode: R-Y, B-Y (60x48), Y even, Y odd (120x48 each), 17280 bytes.
    Mode 5's second key is sent Y even, Y odd, R-Y, B-Y."""
    ry, by = _key_colour(rgb120, 60, 48)
    Y = _t8(grey(rgb120))
    ye, yo = cm(Y[0::2]), cm(Y[1::2])
    return np.concatenate((ye, yo, ry, by) if second else (ry, by, ye, yo))


def _wavelet(rgb240):
    """CPU1 mode 1: 240x192 grey in 4x4 blocks (block rows, then across); a 16 bit mask of the pixels
    above the block average (bit n = pixel n, row by row), sent high byte, low byte.  (His GrayAve was
    never cleared between blocks and the block was read one pixel down and right; both put right here.)"""
    g = grey(rgb240)
    blk = g.reshape(48, 4, 60, 4).transpose(0, 2, 1, 3).reshape(48, 60, 16)
    bits = blk > blk.mean(axis=2, keepdims=True)
    v = (bits * (1 << np.arange(16))).sum(axis=2).astype(np.int64).ravel()
    out = np.empty(2 * v.size, np.uint8)
    out[0::2], out[1::2] = v >> 8, v & 0xFF
    return out


# Analog detail for 240x192 (the alternative to the wavelet masks, same 5760 bytes): the picture
# minus the cubic upsample of the key's own 120x96 luma, in 8x8 blocks (30 x 24 of them), as the
# 8 DCT coefficients that carry most of that detail - horizontal and vertical frequencies 3 to 6
# of 7, i.e. just below and above the 120x96 limit.  Each sent as a level (128 + c / step), so
# noise only adds a little noise to the detail - nothing like a wrong mask bit.
DCT_SEL = [(0, 3), (3, 0), (0, 4), (4, 0), (0, 5), (5, 0), (0, 6), (6, 0)]
DCT_STEP = np.array([2.0, 1.0, 4.5, 1.5, 2.8, 1.1, 1.3, 1.0])     # 99.5 % of test pictures fit


def _dct8():
    D = np.zeros((8, 8))
    for k in range(8):
        for i in range(8):
            D[k, i] = math.sqrt((1 if k == 0 else 2) / 8.0) * math.cos(math.pi * (2 * i + 1) * k / 16.0)
    return np.stack([np.outer(D[k], D[l]).ravel() for k, l in DCT_SEL])      # 8 x 64


DCT_B = _dct8()


def _blocks8(x):
    return x.reshape(24, 8, 30, 8).transpose(0, 2, 1, 3).reshape(24, 30, 64)


def _unblocks8(x):
    return x.reshape(24, 30, 8, 8).transpose(0, 2, 1, 3).reshape(192, 240)


def _detail_dct(rgb240, y120, extra=None):
    """-> 5760 bytes: 4 strips of 30 columns, each the H (top 24 rows) and V (bottom) coefficient
    of one frequency, column by column - so the monitor shows them as little pictures.
    extra (mode 7): detail the receiver has already (the 4-line split's) - only what is left is sent."""
    r = grey(rgb240) - _up(y120.astype(np.float32), 2, 2, (192, 240))
    if extra is not None:
        r = r - extra
    c = _blocks8(r) @ DCT_B.T                                      # 24 x 30 x 8
    q = np.clip(np.round(128 + c / DCT_STEP), 0, 255).astype(np.uint8)
    out = []
    for i in range(4):
        out.append(cm(np.vstack((q[:, :, 2 * i], q[:, :, 2 * i + 1]))))   # 48 x 30
    return np.concatenate(out)


DCT_SEL16 = DCT_SEL + [(0, 7), (7, 0), (0, 2), (2, 0), (1, 4), (4, 1), (4, 5), (5, 5)]   # (modes 5, 6: the
                                               #  next 8 by energy over the test cards: 86 % of the detail, not 70 %)
DCT_STEP16 = np.concatenate((DCT_STEP, [1.35, 1.2, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]))


def _dct8_sel(sel):
    D = np.zeros((8, 8))
    for k in range(8):
        for i in range(8):
            D[k, i] = math.sqrt((1 if k == 0 else 2) / 8.0) * math.cos(math.pi * (2 * i + 1) * k / 16.0)
    return np.stack([np.outer(D[k], D[l]).ravel() for k, l in sel])


DCT_B16 = _dct8_sel(DCT_SEL16)


def _detail_dct16(rgb240, y120):
    """Modes 5, 6 -> 11520 bytes: mode 1's detail (its 4 strips, as _detail_dct) and 4 more strips of
    8 more frequencies - twice the bytes, for the 240x192 detail mode 1 has to leave out."""
    r = grey(rgb240) - _up(y120.astype(np.float32), 2, 2, (192, 240))
    c = _blocks8(r) @ DCT_B16.T                                    # 24 x 30 x 16
    q = np.clip(np.round(128 + c / DCT_STEP16), 0, 255).astype(np.uint8)
    return np.concatenate([cm(np.vstack((q[:, :, 2 * i], q[:, :, 2 * i + 1]))) for i in range(8)])


def _detail_dct16_coefs(b):
    c = np.empty((24, 30, 16), np.float32)
    for i in range(8):
        blk = icm(b[i * 1440:(i + 1) * 1440], 48, 30).astype(np.float32)
        c[:, :, 2 * i], c[:, :, 2 * i + 1] = blk[:24], blk[24:]
    return (c - 128.0) * DCT_STEP16


# modes 5, 6 with B and C's own detail: the frequencies by energy (over the test cards, moving) of what
# each picture's rebuilt 120x96 lacks - A's (as the 16 above), and B and C's (more low frequencies: the
# rebuild misses some of their own 120x96 too)
WW_ORDER_A = [(0, 4), (0, 5), (4, 0), (0, 6), (5, 0), (0, 3), (0, 7), (6, 0), (7, 0), (3, 0), (0, 2), (1, 4),
              (2, 0), (4, 5), (5, 5), (4, 1)]
WW_ORDER_BC = {20: [(0, 2), (0, 3), (0, 4), (0, 5), (4, 0), (3, 0), (5, 0), (0, 1), (2, 0), (6, 0), (0, 6), (1, 2)],
               21: [(0, 2), (2, 0), (0, 3), (0, 4), (3, 0), (0, 5), (4, 0), (5, 0), (6, 0), (0, 1), (1, 2), (1, 0)]}
WW_STEPS = {
    ('a', 20, (0, 4)): 2.7,
    ('a', 20, (0, 5)): 3.05,
    ('a', 20, (4, 0)): 1.91,
    ('a', 20, (0, 6)): 1.45,
    ('a', 20, (5, 0)): 1.39,
    ('a', 20, (0, 3)): 2.24,
    ('a', 20, (0, 7)): 1.36,
    ('a', 20, (6, 0)): 1.27,
    ('a', 20, (7, 0)): 1.15,
    ('a', 20, (3, 0)): 1.28,
    ('a', 20, (0, 2)): 2.81,
    ('a', 20, (1, 4)): 1.0,
    ('a', 20, (2, 0)): 1.11,
    ('a', 20, (4, 5)): 1.0,
    ('a', 20, (5, 5)): 1.0,
    ('a', 20, (4, 1)): 1.0,
    ('bc', 20, (0, 2)): 2.37,
    ('bc', 20, (0, 3)): 1.91,
    ('bc', 20, (0, 4)): 2.61,
    ('bc', 20, (0, 5)): 2.81,
    ('bc', 20, (4, 0)): 1.69,
    ('bc', 20, (3, 0)): 1.04,
    ('bc', 20, (5, 0)): 1.19,
    ('bc', 20, (0, 1)): 1.11,
    ('bc', 20, (2, 0)): 1.0,
    ('bc', 20, (6, 0)): 1.14,
    ('bc', 20, (0, 6)): 1.27,
    ('bc', 20, (1, 2)): 1.0,
    ('a', 21, (0, 4)): 2.69,
    ('a', 21, (0, 5)): 2.76,
    ('a', 21, (4, 0)): 1.9,
    ('a', 21, (0, 6)): 1.35,
    ('a', 21, (5, 0)): 1.31,
    ('a', 21, (0, 3)): 1.65,
    ('a', 21, (0, 7)): 1.4,
    ('a', 21, (6, 0)): 1.2,
    ('a', 21, (7, 0)): 1.18,
    ('a', 21, (3, 0)): 1.0,
    ('a', 21, (0, 2)): 1.0,
    ('a', 21, (1, 4)): 1.0,
    ('a', 21, (2, 0)): 1.0,
    ('a', 21, (4, 5)): 1.0,
    ('a', 21, (5, 5)): 1.0,
    ('a', 21, (4, 1)): 1.0,
    ('bc', 21, (0, 2)): 2.74,
    ('bc', 21, (2, 0)): 1.83,
    ('bc', 21, (0, 3)): 1.81,
    ('bc', 21, (0, 4)): 2.49,
    ('bc', 21, (3, 0)): 1.51,
    ('bc', 21, (0, 5)): 2.73,
    ('bc', 21, (4, 0)): 1.72,
    ('bc', 21, (5, 0)): 1.32,
    ('bc', 21, (6, 0)): 1.14,
    ('bc', 21, (0, 1)): 1.0,
    ('bc', 21, (1, 2)): 1.0,
    ('bc', 21, (1, 0)): 1.0,
}                                              # (0.7 x the 99.5 % level / 127, as mode 1's)
_WW_B = {}


WW_SPLITS = collections.OrderedDict([("16 (A only)", (16, 0)), ("10+3+3", (10, 3)), ("8+4+4", (8, 4)), ("6+5+5", (6, 5))])


def set_ww_split(name):
    """Modes 5, 6: how the 16 detail frequencies are shared - A's, then B's and C's each (both ends alike)."""
    global WW_SPLIT
    WW_SPLIT = WW_SPLITS.get(name, WW_SPLIT)


def ww_sels(enc):
    """-> (A's frequencies, B and C's) for modes 5, 6 as WW_SPLIT says."""
    na, nb = WW_SPLIT
    if nb == 0:
        return DCT_SEL16[:na] if na == 16 else WW_ORDER_A[:na], []
    sa = DCT_SEL if na == 8 else WW_ORDER_A[:na]
    return sa, WW_ORDER_BC[enc][:nb]


def _ww_basis(sel):
    k = tuple(sel)
    if k not in _WW_B:
        _WW_B[k] = _dct8_sel(sel)
    return _WW_B[k]


def ww_steps(enc, sel, bc):
    if not WW_SPLIT[1]:
        return DCT_STEP16[:len(sel)]
    return np.array([WW_STEPS.get(("bc" if bc else "a", enc, f), 1.0) for f in sel], np.float32)


def ww_pack(r, sel, steps):
    """Detail r (192 x 240) -> its frequencies' coefficients as bytes (720 each: in pairs, 48 x 30 blocks)."""
    c = _blocks8(r) @ _ww_basis(sel).T
    q = np.clip(np.round(128 + c / steps), 0, 255).astype(np.uint8)
    out = [cm(np.vstack((q[:, :, i], q[:, :, i + 1]))) for i in range(0, len(sel) - 1, 2)]
    if len(sel) % 2:
        out.append(cm(q[:, :, -1]))
    return np.concatenate(out)


def ww_unpack(b, sel, steps):
    n = len(sel)
    c = np.empty((24, 30, n), np.float32)
    k = 0
    for i in range(0, n - 1, 2):
        blk = icm(b[k:k + 1440], 48, 30).astype(np.float32)
        c[:, :, i], c[:, :, i + 1] = blk[:24], blk[24:]
        k += 1440
    if n % 2:
        c[:, :, -1] = icm(b[k:k + 720], 24, 30).astype(np.float32)
    return (c - 128.0) * steps


def ww_plane(c, sel, steps, snr):
    """The detail of frequencies sel from their coefficients c, each held back by how much is noise."""
    sig = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 30.0, 45.0), -5.0) / 10.0))
    nv = (sig * steps) ** 2
    tv = c.reshape(-1, len(sel)).var(axis=0)
    w = np.clip(1.0 - nv / np.maximum(tv, 1e-6), 0.0, 1.0)
    return _unblocks8((c * w) @ _ww_basis(sel)).astype(np.float32)


def ww_base(enc, F):
    """Modes 5, 6: the three 120x96 lumas as the receiver rebuilds them from this frame alone (no noise
    allowed for) - what B and C's own detail is worked out against.  Mode 9's B and C: the motion search
    in A only (the next key is not known to the transmitter), put right to the 60x48 pictures sent."""
    if enc == KMDW:
        ps = Decoder._wide(None, F, F, False, WW_REF_SNR, 3, w=120, lo_at=28800)
        return [p[0] for p in ps]
    AO = np.empty((96, 120), np.float32)
    AO[0::2], AO[1::2] = icm(F[5760:11520], 48, 120), icm(F[11520:17280], 48, 120)
    out = [AO]
    for k in (28800, 31680):
        xl = icm(F[k:k + 2880], 48, 60).astype(np.float32)
        Y = motion_search([AO], xl, prefer=0, snr=WW_REF_SNR)[0]
        out.append(np.clip(Y + _up(xl + 0.5 - _down(Y, 2, 2), 2, 2, (96, 120)), 0, 255))
    return out


def _detail_dct_coefs(b):
    """5760 bytes -> 24 x 30 x 8 coefficients (as received, before any noise shrinking)."""
    c = np.empty((24, 30, 8), np.float32)
    for i in range(4):
        blk = icm(b[i * 1440:(i + 1) * 1440], 48, 30).astype(np.float32)
        c[:, :, 2 * i], c[:, :, 2 * i + 1] = blk[:24], blk[24:]
    return (c - 128.0) * DCT_STEP


def _cpu3(yb, yc, robust=False):
    """Mode 1 motion: B and C split into even / odd line fields, then each byte carries two pixels'
    top nibbles - odd bytes from B, even bytes from C.  11520 bytes."""
    va = np.concatenate((cm(yb[0::2]), cm(yb[1::2])))
    vc = np.concatenate((cm(yc[0::2]), cm(yc[1::2])))
    pk = _hil if robust else _il
    out = np.empty(11520, np.uint8)
    out[0::2] = pk(va[0::2], va[1::2])
    out[1::2] = pk(vc[1::2], vc[0::2])
    return out


def _cpu42(yb, yc, nb, robust=False):
    """Mode 2 (CPU4, nb 4) and mode 3 (CPU2, nb 2): pixel pairs (two lines of a column) of B and C,
    their top bits interleaved, and the average of the next bits of B and C.  -> low avg, B, C."""
    a, b = cm(yb).astype(np.int32), cm(yc).astype(np.int32)
    if nb == 2:
        a, b = a & 0xF0, b & 0xF0
    a1, a2, b1, b2 = a[0::2], a[1::2], b[0::2], b[1::2]
    k = np.arange(5760)
    if nb == 4:
        s = k < 2880
        d1, d2 = ((a1 & 0x0F) + (b1 & 0x0F)) // 2 * 16, ((a2 & 0x0F) + (b2 & 0x0F)) // 2 * 16
    else:
        s = (k % 2) == 1
        d1, d2 = ((a1 & 0x30) + (b1 & 0x30)) // 2 * 4, ((a2 & 0x30) + (b2 & 0x30)) // 2 * 4
    # the pixel pairs as his CPU4 / CPU2 pack them; the averages in Hilbert order (a small error in
    # the byte moves one average one step) - the best of the two versions there were (2 / 2R, 3 / 3R)
    pk = _hil if robust else _il
    c1 = np.where(s, pk(a1, a2, nb), pk(a2, a1, nb))
    c2 = np.where(s, pk(b2, b1, nb), pk(b1, b2, nb))
    e = np.where(s, _hil(d2, d1, nb), _hil(d1, d2, nb))
    return np.concatenate((e, c1, c2)).astype(np.uint8)


def _cpu6(yb, yc):
    """Mode 4: (B+C)/2 as even / odd line fields, then B and C at 60x48."""
    ys = _t8((yb.astype(np.int32) + yc) / 2)
    return np.concatenate((cm(ys[0::2]), cm(ys[1::2]), cm(_t8(_down(yb, 2, 2))), cm(_t8(_down(yc, 2, 2)))))


def _cpu7(ya, yb, yc):
    """180x96: (A+B+C)/3 as even / odd line fields, then (A+B+255-C)/3 and (A+C+255-B)/3 at 90x48.
    (His TX gave CPU7 the newest picture as A, the same one as C; here A is the key picture.)"""
    ys = _t8((ya.astype(np.float32) + yb + yc) / 3)
    a, b, c = _down(ya, 2, 2), _down(yb, 2, 2), _down(yc, 2, 2)
    return np.concatenate((cm(ys[0::2]), cm(ys[1::2]), cm(_t8((a + b + 255 - c) / 3)), cm(_t8((a + c + 255 - b) / 3))))


def _keep8(x, like):
    """A smaller copy of a picture: bytes as before, or (with video emphasis) left as floats - the lifted
    luma may take R, G or B past 0-255 while the luma itself fits, and clipping them would change it."""
    return b8(x) if like.dtype == np.uint8 else np.asarray(x, np.float32)


def encode_frame(pics, mode, enc=2, detail="masks", vemph=None):
    """The pictures (RGB uint8 at pic_size: three, or two for mode 5) -> the 34560 byte data frame.
    vemph: video emphasis (None: VEMPH_ON) - each picture's luma lifted in its fine detail first."""
    if VEMPH_ON if vemph is None else vemph:
        pics = [vemph_pic(p) for p in pics]
    enc = eff_enc(mode, enc)
    rob = enc in ROBUST
    enc = ROBUST.get(enc, enc)
    if enc == WIDE:
        ry, by = _key_colour(pics[0], 90, 48)
        ya, yb, yc = [_t8(grey(p)) for p in pics]
        out = np.concatenate((ry, by, _cpu7(ya, yb, yc)))
    elif enc == WIDEK:
        # a key for 180x96: A whole (two line fields, as the 120x96 key sends its luma), B and C at
        # 90x48 - the receiver puts the detail back from the keys either side
        ry, by = _key_colour(pics[0], 90, 48)
        ya, yb, yc = [_t8(grey(p)) for p in pics]
        out = np.concatenate((ry, by, cm(ya[0::2]), cm(ya[1::2]),
                              cm(_t8(_down(yb.astype(np.float32), 2, 2))), cm(_t8(_down(yc.astype(np.float32), 2, 2)))))
    elif enc in (KMDW, KMMW):
        # 180x96 modes 1 and 2 at 120x96 (colour 60x48, the key 120x96, the other two at 60x48); the
        # 2 x 120x48 left over carries 16 frequencies of A's 240x192 detail (mode 1 sends 8)
        p120 = [_keep8(_down(p.astype(np.float32), 2, 2), p) for p in pics]
        ry, by = _key_colour(p120[0], 60, 48)
        ya, yb, yc = [_t8(grey(p)) for p in p120]
        wl = _detail_dct16(pics[0], ya)
        if enc == KMDW:
            ys = _t8((ya.astype(np.float32) + yb + yc) / 3)
            a, b, c = _down(ya, 2, 2), _down(yb, 2, 2), _down(yc, 2, 2)
            out = np.concatenate((ry, by, cm(ys[0::2]), cm(ys[1::2]), wl,
                                  cm(_t8((a + b + 255 - c) / 3)), cm(_t8((a + c + 255 - b) / 3))))
        else:
            out = np.concatenate((ry, by, cm(ya[0::2]), cm(ya[1::2]), wl,
                                  cm(_t8(_down(yb.astype(np.float32), 2, 2))), cm(_t8(_down(yc.astype(np.float32), 2, 2)))))
        if WW_SPLIT[1]:
            # each picture's own detail, against its 120x96 as the receiver will rebuild it
            sa, sb = ww_sels(enc)
            base = ww_base(enc, out)
            parts = []
            for i, (P, Yr) in enumerate(zip(pics, base)):
                r = grey(P) - _up(Yr, 2, 2, (192, 240))
                sel = sa if i == 0 else sb
                parts.append(ww_pack(r, sel, ww_steps(enc, sel, i > 0)))
            out[17280:28800] = np.concatenate(parts)
    elif enc == 5:
        out = np.concatenate((_key(pics[0]), _key(pics[1], second=True)))
    elif enc in (KWD, KWDM, KWSC, KWH):
        # 180x96 mode 1 at 120x96, with mode 1's 240x192 detail of A (mode 6: as SoftCast; mode 7: the
        # average key as the 4-line split of the 240x192 average)
        p120 = [_keep8(_down(p.astype(np.float32), 2, 2), p) for p in pics]
        ry, by = _key_colour(p120[0], 60, 48)
        ya, yb, yc = [grey(p).astype(np.float32) for p in p120]
        ys = _t8((ya + yb + yc) / 3)
        a, b, c = [_down(np.floor(y), 2, 1) for y in (ya, yb, yc)]
        key = (kwh_split(sum(grey(p).astype(np.float64) for p in pics) / 3.0) if enc == KWH
               else np.concatenate((cm(ys[0::2]), cm(ys[1::2]))))
        extra = None
        if enc == KWH and KWH_E == "all" and KWH_COMPLEMENT:   # (what the receiver will add from the split)
            S = kwh_join(key, None, est=False)
            extra = S - _up(np.clip(_down(S, 2, 2), 0, 255).astype(np.float32), 2, 2, (192, 240))
        if enc == KWSC:
            wl = sc_detail(pics[0], _t8(ya))
        else:
            wl = _detail_dct(pics[0], _t8(ya), extra) if detail == "dct" else _wavelet(pics[0])
        out = np.concatenate((ry, by, key, wl,
                              cm(_t8((a + b + 255 - c) / 3)), cm(_t8((a + c + 255 - b) / 3))))
    else:
        p120 = [_keep8(_down(p.astype(np.float32), 2, 2), p) if p.shape[1] == 240 else p for p in pics]
        yb, yc = _t8(grey(p120[1])), _t8(grey(p120[2]))
        k = _key(p120[0])
        if enc == 1:
            if detail == "dct":
                y120 = _t8(grey(p120[0]))                 # the key's luma, as sent
                wl = _detail_dct(pics[0], y120)
            else:
                wl = _wavelet(pics[0])
            out = np.concatenate((k, wl, _cpu3(yb, yc, rob)))
        elif enc == 2:
            out = np.concatenate((k, _cpu42(yb, yc, 4, rob)))
        elif enc == 3:
            out = np.concatenate((k, _cpu42(yb, yc, 2, rob)))
        elif enc == KWL:
            # mode 1's key and 240x192 detail; B and C as plain levels at low size (as 180x96 mode 2),
            # with (B+C)/2 at 120x48 to put right what the receiver's motion search gets wrong
            wl = _detail_dct(pics[0], _t8(grey(p120[0]))) if detail == "dct" else _wavelet(pics[0])
            ys = _t8(_down((yb.astype(np.float32) + yc) / 2.0, 2, 1))
            out = np.concatenate((k, wl, cm(ys), cm(_t8(_down(yb.astype(np.float32), 2, 2))),
                                  cm(_t8(_down(yc.astype(np.float32), 2, 2)))))
        elif enc == KMS:
            out = np.concatenate((_key_ms(pics[0], p120[0]), _cpu6(yb, yc)))
        else:
            out = np.concatenate((k, _cpu6(yb, yc)))
    assert len(out) == mode.frame_bytes, (enc, len(out))
    return out


# ----------------------------------------------------------------------- decoder (RX)
def _keymix(mo, ref, mask, kmx):
    """His KeyMix / Ave_Mix: where the motion pixel's known top bits agree with the key's, take the key
    (full 8 bits); else blend: kmx 1 = motion only ... 5 = (motion + 4 key) / 5."""
    mo = mo.astype(np.float32)
    ref = ref.astype(np.float32)
    same = (mo.astype(np.int32) & mask) == (ref.astype(np.int32) & mask)
    return np.where(same, ref, (mo + (kmx - 1) * ref) / kmx)


def _keymix2(mo, key, mref, mask, kmx):
    """_keymix with two references: the key first, then the motion-searched picture."""
    k = np.asarray(key, np.float32)
    same = (mo.astype(np.int32) & mask) == (np.clip(k, 0, 255).astype(np.int32) & mask)
    return np.where(same, k, _keymix(mo, mref, mask, kmx))


def _chroma(ry, by, shape):
    """R-Y, B-Y bytes -> R - Y and B - Y at full size.  The TX halved the saturation, so x 2 here:
    R - Y = 2 (2 RY - 255)."""
    fy, fx = shape[0] // ry.shape[0], shape[1] // ry.shape[1]
    cr, cb = bytes_to_chroma(ry, by)
    return _up(cr, fy, fx, shape), _up(cb, fy, fx, shape)


_RSM = {}


def _rs_matrix(n_in, n_out):
    """Resampling n_in -> n_out samples along a line (Lanczos MSV_TAPS, widened to filter when going down;
    edges held): an n_out x n_in matrix."""
    if (n_in, n_out) not in _RSM:
        sc = min(1.0, n_out / float(n_in))
        x = (np.arange(n_out) + 0.5) * n_in / float(n_out) - 0.5
        j = np.arange(n_in)
        t = (j[None, :] - x[:, None]) * sc
        w = np.sinc(t) * np.sinc(t / float(MSV_TAPS)) * (np.abs(t) < MSV_TAPS)
        _RSM[(n_in, n_out)] = (w / w.sum(axis=1, keepdims=True)).astype(np.float32)
    return _RSM[(n_in, n_out)]


def _rs(a, n):
    a = np.asarray(a, np.float32)
    return a if a.shape[-1] == n else a @ _rs_matrix(a.shape[-1], n).T


def _key_ms(rgb240, rgb120):
    """Mode 6 key: colour as the 120x96 key; the luma at 120x192, each line pair as its sum M (at
    MSV_W[0] across) and difference S (at MSV_W[1], x MSV_GAIN, soft knee) - 17280 bytes."""
    ry, by = _key_colour(rgb120, 60, 48)
    Y = _down(grey(rgb240).astype(np.float32), 1, 2)              # 192 x 120
    M = _rs((Y[0::2] + Y[1::2]) / 2.0, MSV_W[0])                  # 96 x 105
    bM = b8(M)
    S = (Y[0::2] - Y[1::2]) / 2.0
    if MSV_RESID:                                                 # less what the RX predicts from M
        U = _up(_rs(bM, 120), 2, 1, (192, 120))
        S = S - (U[0::2] - U[1::2]) / 2.0
    S = _rs(S, MSV_W[1])                                          # 96 x MSV_W[1]
    bS = b8(ms_limit(MSV_GAIN * S) + 128.0)
    return np.concatenate((ry, by, cm(bM[0::2]), cm(bM[1::2]), cm(bS[0::2]), cm(bS[1::2])))


def _key_ms_parts(b, snr):
    """Mode 6 key bytes -> R-Y, B-Y (48 x 60), Y at 120x192 and the line pair sums at 120x96."""
    ry, by = icm(b[:2880], 48, 60), icm(b[2880:5760], 48, 60)
    wm, ws = MSV_W
    k = 5760
    M = np.empty((96, wm), np.float32)
    M[0::2], M[1::2] = icm(b[k:k + 48 * wm], 48, wm), icm(b[k + 48 * wm:k + 96 * wm], 48, wm)
    k += 96 * wm
    S = np.empty((96, ws), np.float32)
    S[0::2], S[1::2] = icm(b[k:k + 48 * ws], 48, ws), icm(b[k + 48 * ws:k + 96 * ws], 48, ws)
    S = ms_limit(S - 128.0, inverse=True) / MSV_GAIN
    M = _rs(M, 120)
    # the line pairs' difference as the plain (cubic) 96 -> 192 lines would have it; the received S
    # puts right only what it carries (its low part across), each place as far as it stands above the
    # noise - so where S says nothing, the picture is mode 3's, never repeated lines
    U = _up(M, 2, 1, (192, 120))
    Sp = (U[0::2] - U[1::2]) / 2.0
    if MSV_RESID:
        R = S                                                      # TX sent S less that prediction
    else:
        R = S - _rs(Sp, MSV_W[1])
    sg = noise_sigma(snr) / MSV_GAIN
    R = R * np.clip(1.0 - MSV_SHRINK * sg * sg / np.maximum(_box5(R * R), 1e-6), 0.0, 1.0)
    S = Sp + _rs(R, 120)
    # the sum likewise: the plain lines' own pair mean, put right by the received sum where that
    # stands above the noise (the plain lines average neighbours, so carry less noise)
    Mp = (U[0::2] + U[1::2]) / 2.0
    Cm = M - Mp
    sgm = noise_sigma(snr)
    Cm = Cm * np.clip(1.0 - MSV_MSHRINK * sgm * sgm / np.maximum(_box5(Cm * Cm), 1e-6), 0.0, 1.0)
    Mx = Mp + Cm
    Y = np.empty((192, 120), np.float32)
    Y[0::2], Y[1::2] = Mx + S, Mx - S
    return ry, by, np.clip(Y, 0, 255), np.clip(M, 0, 255)


# ----------------------------------------------------------------------- 4-line split (5.43, mode 7)
# As Ambisonics / UHJ send what all the microphones share at full quality and the differences with less:
# each 4 lines of the 240x192 average picture go as their mean (an ordinary picture line, 160 points) and
# three half-differences - top two less bottom two, middle less outer, alternate lines - each scaled up
# (KWH_G) and at fewer points (KWH_W): 240 values for every 4 lines, the bytes of the 120x96 average key.
# Sent as picture values (not DCT coefficients, whose peaks would have to be scaled down to fit a byte).
KWH_W = (160, 50, 20, 10)
KWH_G = (1.0, 3.0, 4.0, 4.0)
KWH_E = "all"                                  # which pictures take the split's own detail: "all", "bc", "none"
KWH_COMPLEMENT = False                         # A's detail layer sends only what the split's detail leaves
_KM4 = np.array([[1, 1, 1, 1], [1, 1, -1, -1], [1, -1, -1, 1], [1, -1, 1, -1]], np.float64) / 4.0
_KM4I = np.linalg.inv(_KM4)
_KWH_T = {}


def _kwh_mats(w):
    """240 points -> w (band-limited, as picture values), and back."""
    if w not in _KWH_T:
        D, Dw = _dct_mat(240), _dct_mat(w)
        T = math.sqrt(w / 240.0) * (Dw.T @ D[:w, :])
        U = math.sqrt(240.0 / w) * (D[:w, :].T @ Dw)
        _KWH_T[w] = (T.astype(np.float32), U.astype(np.float32))
    return _KWH_T[w]


def kwh_split(Y240):
    """240x192 luma -> 11520 bytes: for 48 groups of 4 lines, the mean and three differences."""
    P = np.einsum("ij,gjw->giw", _KM4, np.asarray(Y240, np.float64).reshape(48, 4, 240))
    out = []
    for i, (w, g) in enumerate(zip(KWH_W, KWH_G)):
        v = P[:, i] @ _kwh_mats(w)[0].T.astype(np.float64)
        out.append(cm(np.clip(np.round(v if i == 0 else 128.0 + g * v), 0, 255).astype(np.uint8)))
    return np.concatenate(out)


def kwh_join(b, snr=None, est=True):
    """11520 received bytes -> the 240x192 average picture (each part cleaned for the measured noise)."""
    b = np.asarray(b).astype(np.float32)
    sg2 = noise_sigma(snr) ** 2 if snr is not None else 0.0
    Q, a = [], 0
    for i, (w, g) in enumerate(zip(KWH_W, KWH_G)):
        x = icm(b[a:a + 48 * w], 48, w)
        a += 48 * w
        if i == 0:
            if est and sg2 > 0:
                x = _lee(x, sg2, RXE_K, 5)
        else:
            x = (x - 128.0) / g
            if est and sg2 > 0:
                x = x * np.clip(1.0 - (sg2 / (g * g)) / np.maximum(_box5(x * x), 1e-6), 0.0, 1.0)
        Q.append(x @ _kwh_mats(w)[1].T)
    Q = np.stack(Q, 1)
    return np.einsum("ji,giw->gjw", _KM4I.astype(np.float32), Q).reshape(192, 240)


# ----------------------------------------------------------------------- RX estimate (5.42)
# The key picture's luma and colour come through with the channel's noise on every byte (its level
# known from the receiver's own C/N estimate).  Each value is taken as its local average plus as much
# of its own difference from it as stands above that noise (a local LLSE / Wiener estimate, over
# RXE_WIN x RXE_WIN areas): flat areas lose their noise, edges stay.  Receiver only - nothing is sent.
# The rest of each mode (its differences, motion and detail) already has its own noise handling.
RX_ESTS = ("Off", "On")
RXE_WIN = 5
RXE_K = 0.5                                    # how much of the noise to allow for, luma (measured best: 0.5)
RXE_KC = 1.0                                   # (the colour)


def rxe_regions(mode, enc):
    """-> ([luma: (even field start, odd field start, rows, cols)], [colour: (start, rows, cols)])."""
    enc = eff_enc(mode, enc)
    if enc in (WIDE, WIDEK):
        return [(8640, 17280, 48, 180)], [(0, 48, 90), (4320, 48, 90)]
    if enc == KWH:                                 # (mode 7: the split cleans its own key; the colour here)
        return [], [(0, 48, 60), (2880, 48, 60)]
    if enc in (KWD, KWDM, KWSC, KWL, 4, 1, 2, 3, KMDW, KMMW):
        return [(5760, 11520, 48, 120)], [(0, 48, 60), (2880, 48, 60)]
    if enc == 5:                                   # two keys, the second sent Y first
        return ([(5760, 11520, 48, 120), (17280, 23040, 48, 120)],
                [(0, 48, 60), (2880, 48, 60), (28800, 48, 60), (31680, 48, 60)])
    return [], []


def _lee(P, sg2, k, win):
    if win == 5:
        mu = _box5(P)
        m2 = _box5(P * P)
    else:
        pad = np.pad(P, 1, mode="reflect")
        mu = sum(pad[i:i + P.shape[0], j:j + P.shape[1]] for i in range(3) for j in range(3)) / 9.0
        pad2 = pad * pad
        m2 = sum(pad2[i:i + P.shape[0], j:j + P.shape[1]] for i in range(3) for j in range(3)) / 9.0
    var = np.maximum(m2 - mu * mu, 1e-6)
    g = np.clip(1.0 - k * sg2 / var, 0.0, 1.0)
    return mu + g * (P - mu)


def rx_estimate(data, mode, enc, snr, win=None, k=None, kc=None):
    """The received frame's key luma and colour each as its local LLSE estimate (see above)."""
    if snr is None:
        return data
    lum, col = rxe_regions(mode, enc)
    if not lum and not col:
        return data
    sg2 = noise_sigma(snr) ** 2
    win = RXE_WIN if win is None else win
    k = RXE_K if k is None else k
    kc = RXE_KC if kc is None else kc
    out = np.asarray(data).astype(np.float32)
    for e, o, r, c in lum:
        Y = np.empty((2 * r, c), np.float32)
        Y[0::2], Y[1::2] = icm(out[e:e + r * c], r, c), icm(out[o:o + r * c], r, c)
        Y = _lee(Y, sg2, k, win)
        out[e:e + r * c], out[o:o + r * c] = cm(Y[0::2]), cm(Y[1::2])
    if kc > 0:
        for a, r, c in col:
            out[a:a + r * c] = cm(_lee(icm(out[a:a + r * c], r, c), sg2, kc, win))
    return np.clip(np.round(out), 0, 255).astype(np.uint8)


def _key_parts(b, second=False):
    """17280 key bytes -> R-Y, B-Y (48 x 60) and Y (96 x 120)."""
    if second:
        b = np.concatenate((b[11520:], b[:11520]))
    ry, by = icm(b[:2880], 48, 60), icm(b[2880:5760], 48, 60)
    Y = np.empty((96, 120), np.float32)
    Y[0::2], Y[1::2] = icm(b[5760:11520], 48, 120), icm(b[11520:17280], 48, 120)
    return ry, by, Y


def _wl_mask(b):
    v = (b[0::2].astype(np.int64) << 8) | b[1::2]
    bits = ((v[:, None] >> np.arange(16)) & 1).reshape(48, 60, 4, 4)
    return bits.transpose(0, 2, 1, 3).reshape(192, 240).astype(np.float32)


_HAM = np.array([[bin(a ^ b).count("1") for b in range(256)] for a in range(256)], np.float32)


def _wl_mask_soft(b, Yup, snr, lam=1.2):
    """Soft decoding of the mask bytes: each byte is the 8 mask bits of 8 pixels, so a small error on
    the air flips the low bits (or a carry flips many).  Try all 256 values; keep the best fit to the
    byte as received (allowing for the noise) and to the mask the upsampled key predicts (pixels above
    their block's average), counted in bits that differ."""
    pred = _wavelet_bits(Yup)                                        # predicted bytes
    sig = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 30.0, 45.0), -5.0) / 10.0))
    sig = max(sig, 0.7)
    x = np.asarray(b, np.float32)
    v = np.arange(256, dtype=np.float32)
    out = np.empty(len(x), np.int32)
    for a in range(0, len(x), 2048):
        cost = ((x[a:a + 2048, None] - v[None, :]) / sig) ** 2 + lam * _HAM[pred[a:a + 2048]]
        out[a:a + 2048] = np.argmin(cost, axis=1)
    return _wl_mask(out.astype(np.uint8))


def _wavelet_bits(g):
    """The mask bytes a grey 240x192 picture gives (as _wavelet, from grey)."""
    blk = g.reshape(48, 4, 60, 4).transpose(0, 2, 1, 3).reshape(48, 60, 16)
    bits = blk > blk.mean(axis=2, keepdims=True)
    v = (bits * (1 << np.arange(16))).sum(axis=2).astype(np.int64).ravel()
    out = np.empty(2 * v.size, np.int64)
    out[0::2], out[1::2] = v >> 8, v & 0xFF
    return out


def _detail_dct_add(Y, c, snr):
    """Add the DCT detail, each coefficient shrunk by how much of it is signal (Wiener): the noise in
    a coefficient is the byte noise times its step; its signal is what is left of its spread."""
    return np.clip(Y + _detail_dct_plane(c, snr), 0, 255)


def _detail_dct_plane(c, snr):
    """The detail _detail_dct_add adds, on its own (192 x 240, zero mean)."""
    sig = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 30.0, 45.0), -5.0) / 10.0))
    n = c.shape[-1]                                # (8: mode 1's detail; 16: modes 5, 6)
    nv = (sig * (DCT_STEP if n == 8 else DCT_STEP16)) ** 2
    tv = c.reshape(-1, n).var(axis=0)
    w = np.clip(1.0 - nv / np.maximum(tv, 1e-6), 0.0, 1.0)
    return _unblocks8((c * w) @ (DCT_B if n == 8 else DCT_B16)).astype(np.float32)


def _wl_add(Y, mask, gain):
    """CPU1: the wavelet mask x WLin, smoothed, added on.  Here it is made zero-mean per 4x4 block (so it
    sharpens without lifting the brightness) and held to the block's own contrast in the 120x96 picture
    (so smooth areas stay smooth; gain is the most it adds)."""
    d = mask - mask.reshape(48, 4, 60, 4).mean(axis=(1, 3)).repeat(4, 0).repeat(4, 1)
    p = np.pad(d, 1, mode="edge")
    d = (p[1:-1, 1:-1] * 2 + p[:-2, 1:-1] + p[1:-1, :-2] + p[2:, 1:-1] + p[1:-1, 2:] + p[2:, 2:]) / 7.0
    q = np.pad(Y, 2, mode="edge")
    win = np.stack([q[i:i + 192, j:j + 240] for i in range(0, 5, 2) for j in range(0, 5, 2)])
    rng = (win.max(axis=0) - win.min(axis=0)).reshape(48, 4, 60, 4).max(axis=(1, 3))
    amp = np.minimum(gain, 0.8 * rng).repeat(4, 0).repeat(4, 1)
    return np.clip(Y + amp * d, 0, 255)


_SOFT = {}


def _soft_unpack(x, nb, rob, pp, pq, snr, tau=20.0, w=1.0):
    """Soft decoding of a byte holding two pixels' top nb bits (modes 1-3 and their R forms).
    The hard way reads the bits as they arrive, so a small error on the air can flip a high bit
    (or a carry) and throw a pixel far off.  Here every possible pair is tried, and the one kept
    is the best fit to both the byte as received (allowing for the noise the receiver measures)
    and what the keys before and after say the two pixels should be.  Where the picture moves,
    the key's say is capped, so the byte decides.
      x       received bytes;  pp, pq  predicted values of the pixels packed first / second
      -> (p, q) top-justified, as _dil / _dhil give."""
    key = (nb, rob)
    if key not in _SOFT:
        L = 1 << nb
        lv = np.arange(L) << (8 - nb)
        P, Q = np.meshgrid(lv, lv, indexing="ij")
        P, Q = P.ravel(), Q.ravel()
        X = (_hil if rob else _il)(P, Q, nb).astype(np.float32)
        _SOFT[key] = (P, Q, X, float(1 << (8 - nb)) / 2.0)
    P, Q, X, off = _SOFT[key]
    # byte noise: data levels +-1 = 255 bytes; SNR per carrier, I and Q each carry half
    sig = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 30.0, 45.0), -5.0) / 10.0))
    sig = max(sig, 0.7)
    x = np.asarray(x, np.float32)
    out_p = np.empty(len(x), np.int32)
    out_q = np.empty(len(x), np.int32)
    for a in range(0, len(x), 2048):                  # in slices: n x 256 at a time
        xs = x[a:a + 2048, None]
        cost = ((xs - X[None, :]) / sig) ** 2
        dp = (np.asarray(pp[a:a + 2048], np.float32)[:, None] - (P + off)[None, :]) ** 2
        dq = (np.asarray(pq[a:a + 2048], np.float32)[:, None] - (Q + off)[None, :]) ** 2
        cost += w * np.minimum((dp + dq) / tau ** 2, 6.0)
        i = np.argmin(cost, axis=1)
        out_p[a:a + 2048], out_q[a:a + 2048] = P[i], Q[i]
    return out_p, out_q


# ----------------------------------------------------------------------- video pre-emphasis (180x96 mode 3)
_VEH = {}


def _vemph_resp(shape, s, pad):
    key = (shape, s, pad)
    if key not in _VEH:
        h, w = shape[0] + 2 * pad, shape[1] + 2 * pad
        fy, fx = np.fft.fftfreq(h)[:, None], np.fft.fftfreq(w)[None, :]
        _VEH[key] = np.exp(-2 * (math.pi * s) ** 2 * (fy ** 2 + fx ** 2))      # a Gaussian blur's response
    return _VEH[key]


def _vemph_filter(Y, inverse, pad=12):
    k, s = VEMPH["k"], VEMPH["s"] * VEMPH_S.get(int(np.shape(Y)[1]), 1.0)
    P = np.pad(np.asarray(Y, np.float64), pad, mode="reflect")
    H = 1.0 + k * (1.0 - _vemph_resp(Y.shape, s, pad))                       # the lift: 1 (flat) .. 1 + k (finest)
    F = np.fft.fft2(P)
    return np.real(np.fft.ifft2(F / H if inverse else F * H))[pad:-pad, pad:-pad]


def _vknee(x, K, inverse=False):
    R = 127.0 - K
    a = np.abs(x)
    if inverse:
        y = np.where(a > K, K + R * np.arctanh(np.clip((a - K) / R, 0.0, 0.999)), a)
    else:
        y = np.where(a > K, K + R * np.tanh((a - K) / R), a)
    return np.sign(x) * y


def vemph_tx(Y):
    """Video pre-emphasis (TX): the luma's fine detail lifted, the level brought down by g to make room,
    and what still overshoots squeezed in by a soft knee (as the stereo S) - all undone at the RX."""
    return 128.0 + _vknee(VEMPH["g"] * (_vemph_filter(Y, False) - 128.0), VEMPH["knee"])


def vemph_pic(rgb):
    """An RGB picture with its luma pre-emphasised (vemph_tx), the colour differences left as they were
    (the same added to R, G and B) - as floats, not clipped."""
    rgb = np.asarray(rgb, np.float32)
    Y = grey(rgb).astype(np.float64)
    return rgb + (vemph_tx(Y) - Y).astype(np.float32)[..., None]


def vemph_rx(Y):
    """Video de-emphasis (RX): the knee and the level undone, then the lift - and the noise's fine grain
    with it."""
    Y = 128.0 + _vknee(np.asarray(Y, np.float64) - 128.0, VEMPH["knee"], inverse=True) / VEMPH["g"]
    return _vemph_filter(Y, True).astype(np.float32)


# ----------------------------------------------------------------------- mode 6: SoftCast detail
_SCM = {}


def _dct_mat(n):
    """The orthonormal DCT-II as an n x n matrix."""
    if n not in _SCM:
        k, i = np.arange(n)[:, None], np.arange(n)[None, :]
        A = np.cos(np.pi * (2 * i + 1) * k / (2.0 * n)) * math.sqrt(2.0 / n)
        A[0] /= math.sqrt(2.0)
        _SCM[n] = A
    return _SCM[n]


def _sc_keep():
    cy, cx = SC_CH
    keep = np.zeros((192 // cy) * (240 // cx), bool)
    keep[list(SC_ORDER)] = True
    return keep.reshape(192 // cy, 240 // cx)


def _sc_q(v, lo, hi):                                  # a positive number as a byte, on a log2 scale lo .. hi
    return np.clip(np.round((np.log2(np.maximum(v, 1e-12)) - lo) / (hi - lo) * 255.0), 0, 255)


def _sc_unq(b, lo, hi):
    return 2.0 ** (np.asarray(b, np.float64) / 255.0 * (hi - lo) + lo)


SC_G, SC_L = (-12.0, 6.0), (-4.0, 22.0)                # (the scale's and the energy's log2 ranges)


def sc_detail(rgb240, y120):
    """Mode 6's detail of A -> 5760 bytes.  The detail (240x192 less the 120x96 picture brought up) as a whole-
    picture DCT; the SC_ORDER chunks, each scaled by lambda^-1/4 (SoftCast's best power for analogue) and capped
    so its biggest value fits; then each chunk's scale and energy, as bytes on a log scale, SC_REP times."""
    D = grey(rgb240).astype(np.float64) - _up(y120.astype(np.float32), 2, 2, (192, 240))
    X = _dct_mat(192) @ D @ _dct_mat(240).T
    cy, cx = SC_CH
    blk = X.reshape(192 // cy, cy, 240 // cx, cx)
    keep = _sc_keep()
    lam = (blk ** 2).mean(axis=(1, 3))[keep]
    pk = np.abs(blk).max(axis=(1, 3))[keep]
    g = np.maximum(lam, 1e-6) ** -0.25
    g *= SC_RMS / math.sqrt(np.mean(g ** 2 * lam))
    g = np.minimum(g, 124.0 / np.maximum(pk, 1e-9))
    qg, ql = _sc_q(g, *SC_G), _sc_q(lam, *SC_L)
    g = _sc_unq(qg, *SC_G)                              # (the scale the RX will read)
    vals = blk.transpose(0, 2, 1, 3)[keep].reshape(len(SC_ORDER), -1) * g[:, None]
    data = np.clip(np.round(128.0 + vals), 0, 255).ravel()
    side = np.tile(np.concatenate((qg, ql)), SC_REP)    # (repeat by repeat: each copy 120 bytes from the last)
    out = np.concatenate((data, side)).astype(np.uint8)
    assert out.size == 5760, out.size
    return out


def sc_detail_plane(b, snr):
    """Mode 6's 5760 detail bytes -> the 192 x 240 detail: each chunk's scale and energy as the median of their
    copies, then each coefficient's best linear estimate (g lam / (g^2 lam + s^2) y)."""
    n = len(SC_ORDER)
    cy, cx = SC_CH
    b = np.asarray(b, np.float64)
    data = b[:n * cy * cx].reshape(n, cy * cx) - 128.0
    side = np.median(b[n * cy * cx:].reshape(SC_REP, 2 * n), axis=0)
    g, lam = _sc_unq(side[:n], *SC_G), _sc_unq(side[n:], *SC_L)
    sg2 = noise_sigma(snr if snr is not None else 30.0) ** 2
    x = (g * lam / (g * g * lam + sg2))[:, None] * data
    X = np.zeros((192 // cy, 240 // cx, cy, cx))
    X[_sc_keep()] = x.reshape(n, cy, cx)
    X = X.transpose(0, 2, 1, 3).reshape(192, 240)
    return (_dct_mat(192).T @ X @ _dct_mat(240)).astype(np.float32)


# ----------------------------------------------------------------------- mode 5: detail along the motion
CARRY_BS = 6                                     # block size at 120x96 (12 at 240x192)
CARRY_R = (4, 8)                                 # search range at 120x96, rows and columns (+-)
CARRY_LAM = (5.0, 0.5)                          # cost of each pixel of move (+ per unit of noise)
CARRY_SOFT = 0.35                                # how sharply the better-fitting A is preferred
CARRY_FAR = 0.5                                  # cost of the farther A
CARRY_HALF = 40.0                                # cost of a half-pixel step (240x192) off the whole pixel
CARRY_AGREE = 0.5                                # how much the two A's disagreeing cuts the detail


def _bm_coarse(tgt, ref, bs, ry, rx, lam):
    """Whole-pixel block match at 120x96: for each bs x bs block of tgt, the shift of ref that fits best.
    -> (vectors nby x nbx x 2, errors)."""
    H, W = tgt.shape
    nby, nbx = H // bs, W // bs
    t = np.asarray(tgt[:nby * bs, :nbx * bs], np.float32)
    P = np.pad(np.asarray(ref, np.float32), ((ry, ry), (rx, rx)), mode="edge")
    best = np.full((nby, nbx), np.inf, np.float32)
    vec = np.zeros((nby, nbx, 2), np.int32)
    dxs = np.arange(-rx, rx + 1)
    cost_x = lam * np.abs(dxs).astype(np.float32)
    for dy in range(-ry, ry + 1):
        rows = P[ry + dy:ry + dy + nby * bs]                                   # h x (W + 2 rx)
        win = np.lib.stride_tricks.sliding_window_view(rows, nbx * bs, axis=1)  # h x n x w
        e = np.abs(win - t[:, None, :])                                        # h x n x w
        e = e.reshape(nby, bs, len(dxs), nbx, bs).sum(axis=(1, 4))             # nby x n x nbx
        e = e + (cost_x + lam * abs(dy))[None, :, None]
        k = np.argmin(e, axis=1)
        eb = np.take_along_axis(e, k[:, None, :], axis=1)[:, 0]
        m = eb < best
        best[m] = eb[m]
        vec[m] = np.stack((np.full_like(k, dy), dxs[k]), axis=-1)[m]
    return vec, best


def _gather(img, vec, bs, pad=24):
    """img moved block by block: out(y, x) = img(y + vy, x + vx) of the block (y, x) is in."""
    H, W = img.shape
    nby, nbx = vec.shape[:2]
    P = np.pad(np.asarray(img, np.float32), pad, mode="edge")
    win = np.lib.stride_tricks.sliding_window_view(P, (bs, bs))             # every bs x bs block
    y0 = pad + np.arange(nby)[:, None] * bs + vec[..., 0]
    x0 = pad + np.arange(nbx)[None, :] * bs + vec[..., 1]
    return win[y0, x0].transpose(0, 2, 1, 3).reshape(nby * bs, nbx * bs)[:H, :W]


def carry_detail(Y, AO, AN, DO, DN, wO, snr):
    """Mode 5: picture Y (B or C, 120x96) at 240x192 with the detail of the A pictures either side
    (DO, DN: their 240x192 DCT detail) brought along the motion.  Each 6x6 block is matched in both
    A's (whole pixels at 120x96, then the half pixel at 240x192); the detail is taken from where the
    block came from, from the A that fits better (nearer A first when both fit), and only as much as
    the fit can be trusted - something new in the picture gets none."""
    bs, (ry, rx) = CARRY_BS, CARRY_R
    sig = 1.5 * noise_sigma(snr)                      # B and C's own parts are noisier than the bytes
    lam = CARRY_LAM[0] + CARRY_LAM[1] * sig
    up = _up(Y, 2, 2, (192, 240))
    ups = [_up(A, 2, 2, (192, 240)) for A in (AO, AN)]
    bs2 = 2 * bs
    nby, nbx = 192 // bs2, 240 // bs2
    vecs, errs = [], []
    for ri, (A, A2) in enumerate(zip((AO, AN), ups)):
        far = 0.0 if (wO >= 0.5) == (ri == 0) else CARRY_FAR * bs * bs * (0.5 + 0.1 * sig)
        v, _ = _bm_coarse(Y, A, bs, ry, rx, lam)
        v2 = 2 * v
        best = np.full((nby, nbx), np.inf, np.float32)
        bv = v2.copy()
        for oy in (-1, 0, 1):                         # the half pixel, at 240x192
            for ox in (-1, 0, 1):
                vv = v2 + np.array((oy, ox), np.int32)
                e = np.abs(_gather(A2, vv, bs2) - up).reshape(nby, bs2, nbx, bs2).sum(axis=(1, 3)) / 4.0
                e = e + 0.5 * lam * (np.abs(vv[..., 0]) + np.abs(vv[..., 1])) + far + CARRY_HALF * (abs(oy) + abs(ox))
                m = e < best
                best[m] = e[m]
                bv[m] = vv[m]
        vecs.append(bv)
        errs.append(best)
    expect = bs * bs * (1.2 * sig + 4.0)              # a good match's error (per 6x6 at 120x96), noise in
    emin = np.minimum(errs[0], errs[1])
    ws = [p_ * np.exp(-(e - emin) / (CARRY_SOFT * expect)) for p_, e in zip((wO, 1.0 - wO), errs)]
    tot = ws[0] + ws[1]
    conf = np.clip(2.0 - emin / expect, 0.0, 1.0)
    rep = lambda a: _up(a, bs2, bs2, (192, 240))      # smooth across the blocks
    gO, gN = _gather(DO, vecs[0], bs2), _gather(DN, vecs[1], bs2)
    D = rep(ws[0] / tot) * gO + rep(ws[1] / tot) * gN
    if CARRY_AGREE > 0:
        # the two A's detail, each carried here, must say the same thing: a wrong match (aliased
        # patterns fool a 120x96 search) brings detail that disagrees, so less of it is used
        bsum = lambda x: x.reshape(nby, bs2, nbx, bs2).sum(axis=(1, 3))
        nv = (noise_sigma(snr) * 0.5) ** 2 * bs2 * bs2
        agree = np.clip(2.0 * bsum(gO * gN) / (bsum(gO * gO) + bsum(gN * gN) + nv + 1e-3), 0.0, 1.0)
        conf = conf * (1.0 - CARRY_AGREE + CARRY_AGREE * agree)
    return np.clip(up + np.clip(rep(conf), 0, 1) * D, 0, 255)



class Decoder:
    """Holds the last frame: motion frames are decoded when the next one arrives (its key refines C)."""

    def __init__(self):
        self.prev = None

    def reset(self):
        self.prev = None

    def push(self, data, mode, enc, kmx=3, key_only=False, wl=24.0, snap=True, soft=False, snr=None,
             detail="masks", msearch=True, ctrack=False, vemph=None):
        """As _push; with video emphasis (None: VEMPH_ON) the pictures' luma (and the next key, for the
        upscaler) taken back down - and the channel's fine-grain noise with it."""
        if str(getattr(self, "rx_est", "Off")) in ("On", "1", "True") and len(data) == mode.frame_bytes:
            data = rx_estimate(data, mode, enc, snr)
        out = self._push(data, mode, enc, kmx, key_only, wl, snap, soft, snr, detail, msearch, ctrack)
        if not (VEMPH_ON if vemph is None else vemph):
            return out
        if getattr(self, "next_key", None) is not None:
            self.next_key = np.clip(vemph_rx(self.next_key), 0, 255)
        return [(np.clip(vemph_rx(o[0]), 0, 255),) + tuple(o[1:]) for o in out]

    def _push(self, data, mode, enc, kmx=3, key_only=False, wl=24.0, snap=True, soft=False, snr=None,
              detail="masks", msearch=True, ctrack=False):
        """A received data frame -> its pictures as (Y, R-Y, B-Y) float arrays (none the first time).
        ctrack: B and C (sent without colour) take the keys' colour along the motion (track_colour)."""
        self.ctrack = bool(ctrack)
        enc = eff_enc(mode, enc)
        self.next_key = None                          # the key after these pictures (for the upscaler)
        key_enc = enc
        rob = enc in ROBUST
        enc = ROBUST.get(enc, enc)
        dil = _dhil if rob else _dil
        data = np.asarray(data, np.uint8)
        if len(data) != mode.frame_bytes:
            self.prev = None
            return []
        if enc == 5:                                  # two keys, nothing to wait for
            out = []
            for i, b in enumerate((data[:17280], data[17280:])):
                ry, by, Y = _key_parts(b, second=i == 1)
                out.append((Y,) + _chroma(ry, by, Y.shape))
            self.prev = None
            return out
        prev, self.prev = self.prev, (key_enc, mode.name, data)
        if prev is None or prev[:2] != (key_enc, mode.name):
            return []
        O, N = prev[2], data
        kmx = max(1, min(5, int(kmx)))
        if enc == WIDE:
            return self._wide(O, N, key_only, snr, kmx)
        if enc == WIDEK:
            return self._widek(O, N, key_only, msearch, snr, kmx)
        if enc in (KMDW, KMMW):
            return self._wwd(enc, O, N, key_only, msearch, snr, kmx)
        if enc in (KWD, KWDM, KWSC, KWH):
            return self._kwd(O, N, key_only, soft, snr, "sc" if enc == KWSC else detail, wl, kmx,
                             carry=enc in (KWDM, KWSC) and not key_only, split=enc == KWH)
        ms = enc == KMS
        if ms:                                        # mode 6: mode 3 with the 120x192 key
            enc = 4
            ryO, byO, KO, YO = _key_ms_parts(O[:17280], snr)
            ryN, byN, KN, YN = _key_ms_parts(N[:17280], snr)
            self.next_key = None
        else:
            ryO, byO, YO = _key_parts(O[:17280])
            ryN, byN, YN = _key_parts(N[:17280])
            self.next_key = YN
        cB = ((2.0 * ryO + ryN) / 3, (2.0 * byO + byN) / 3)
        cC = ((ryO + 2.0 * ryN) / 3, (byO + 2.0 * byN) / 3)
        m0 = O[17280:].astype(np.int32)

        def decode_bc(prB, prC, soft=soft):
            """The motion pictures B and C from their bytes; prB, prC = what B and C are expected to be
            (for the soft decoding)."""
            m = m0
            if enc == 1:                                  # CPU3
                m = m[5760:]
                if soft:
                    fb = np.concatenate((cm(prB[0::2]), cm(prB[1::2])))
                    fc = np.concatenate((cm(prC[0::2]), cm(prC[1::2])))
                    pa, pb = _soft_unpack(m[0::2], 4, rob, fb[0::2], fb[1::2], snr)
                    qb, qa = _soft_unpack(m[1::2], 4, rob, fc[1::2], fc[0::2], snr)
                else:
                    pa, pb = dil(m[0::2])
                    qb, qa = dil(m[1::2])
                va = np.empty(11520, np.int32)
                vc = np.empty(11520, np.int32)
                va[0::2], va[1::2], vc[0::2], vc[1::2] = pa, pb, qa, qb
                yb, yc = np.empty((96, 120)), np.empty((96, 120))
                yb[0::2], yb[1::2] = icm(va[:5760], 48, 120), icm(va[5760:], 48, 120)
                yc[0::2], yc[1::2] = icm(vc[:5760], 48, 120), icm(vc[5760:], 48, 120)
                yb, yc, mask = yb + 8, yc + 8, 0xF0          # the missing low nibble: half way
            elif enc in (2, 3):                           # CPU4 / CPU2
                nb = 4 if enc == 2 else 2
                e, c1, c2 = m[:5760], m[5760:11520], m[11520:]
                if nb == 2 and not rob and snap and not soft:   # his Noise_Reduction (the averages,
                    c1, c2 = snap_levels(c1), snap_levels(c2)    # in Hilbert order, need none)
                k = np.arange(5760)
                s = k < 2880 if nb == 4 else (k % 2) == 1
                if soft:
                    fb, fc = cm(prB), cm(prC)                # column order, pairs down a column
                    pb1, pb2, pc1, pc2 = fb[0::2], fb[1::2], fc[0::2], fc[1::2]
                    x1, x2 = _soft_unpack(c1, nb, rob, np.where(s, pb1, pb2), np.where(s, pb2, pb1), snr)
                    a1, a2 = np.where(s, x1, x2), np.where(s, x2, x1)
                    x1, x2 = _soft_unpack(c2, nb, rob, np.where(s, pc2, pc1), np.where(s, pc1, pc2), snr)
                    b2, b1 = np.where(s, x1, x2), np.where(s, x2, x1)
                else:
                    x1, x2 = dil(c1, nb)
                    a1, a2 = np.where(s, x1, x2), np.where(s, x2, x1)
                    x1, x2 = dil(c2, nb)
                    b2, b1 = np.where(s, x1, x2), np.where(s, x2, x1)
                x1, x2 = _dhil(e, nb)
                d2, d1 = np.where(s, x1, x2), np.where(s, x2, x1)
                sh = 4 if nb == 4 else 2
                ya = np.empty(11520, np.float32)
                yc_ = np.empty(11520, np.float32)
                ya[0::2], ya[1::2] = a1 + (d1 >> sh), a2 + (d2 >> sh)
                yc_[0::2], yc_[1::2] = b1 + (d1 >> sh), b2 + (d2 >> sh)
                if nb == 2:
                    ya, yc_ = ya + 8, yc_ + 8
                yb, yc = icm(ya, 96, 120), icm(yc_, 96, 120)
                mask = 0xF0 if nb == 4 else 0xC0
            elif enc == KWL:                              # (B+C)/2 at 120x48, B and C at 60x48
                ys = _up(icm(m[5760:11520], 48, 120).astype(np.float32) + 0.5, 2, 1, (96, 120))
                d = _up((icm(m[11520:14400], 48, 60) - icm(m[14400:], 48, 60).astype(np.float32)) / 2.0, 2, 2, (96, 120))
                yb, yc, mask = np.clip(ys + d, 0, 255), np.clip(ys - d, 0, 255), 0xE0
            else:                                         # CPU6 -> CPU8
                ys = np.empty((96, 120), np.float32)
                ys[0::2], ys[1::2] = icm(m[:5760], 48, 120), icm(m[5760:11520], 48, 120)
                d = _up((icm(m[11520:14400], 48, 60) - icm(m[14400:], 48, 60).astype(np.float32)) / 2.0, 2, 2, (96, 120))
                yb, yc, mask = np.clip(ys + d, 0, 255), np.clip(ys - d, 0, 255), 0xE0
            return yb, yc, mask

        # what the keys say B and C should be (B is 1/3 of the way from this key to the next, C 2/3)
        prB, prC = (2.0 * YO + YN) / 3.0, (YO + 2.0 * YN) / 3.0
        search = msearch and not key_only
        yb, yc, mask = decode_bc(prB, prC, soft and not (search and enc not in (4, KWL)))   # (soft: after the search)
        refB, refC = YO, YN
        mot = None
        if search:
            # the WK way: find where each part of B and C came from in the keys either side, from
            # a half-size picture of each (mode 4 sends one; 1-3: the nibbles as received, halved)
            if enc in (4, KWL):
                lb, lc = icm(m0[11520:14400], 48, 60).astype(np.float32), icm(m0[14400:], 48, 60).astype(np.float32)
                mot = gpu_run("_motion_pair", YO, YN, ryO, byO, ryN, byN, lb, lc, snr)
            else:
                mot = gpu_run("_motion_pair", YO, YN, ryO, byO, ryN, byN, yb, yc, snr, mask=mask)
            (mB, crB, cbB), (mC, crC, cbC) = mot
            if enc == 4:
                # the full-size (B+C)/2 puts right what the search got wrong in the sum
                ys = np.empty((96, 120), np.float32)
                ys[0::2], ys[1::2] = icm(m0[:5760], 48, 120), icm(m0[5760:11520], 48, 120)
                r = ys + 0.5 - (mB + mC) / 2.0
                r = _wiener(r, max(0.0, kmx_strength(kmx) - KMX_R[4]), noise_sigma(snr) ** 2)
                yb, yc = np.clip(mB + r, 0, 255), np.clip(mC + r, 0, 255)
            elif enc == KWL:
                # the same with (B+C)/2 at 120x48: the correction at that size, then brought up
                ys48 = icm(m0[5760:11520], 48, 120).astype(np.float32) + 0.5
                r = _wiener(ys48 - _down((mB + mC) / 2.0, 2, 1), 0.5 * max(0.0, kmx_strength(kmx) - KMX_R[KWL]),
                            noise_sigma(snr) ** 2)
                r = _up(r, 2, 1, (96, 120))
                yb, yc = np.clip(mB + r, 0, 255), np.clip(mC + r, 0, 255)
            else:
                # block by block: keep the plain key where the received bits agree with it at least
                # as well as with the moved picture (still parts - and noise can't fool it there)
                # the moved picture is chosen to fit the bits, so in noise it fits them better by
                # chance: it must win by more than the share of top bits the noise is likely to flip
                sg = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 30.0, 45.0), -5.0) / 10.0))
                marg = 0.05 + 0.6 * min(1.0, 2.0 * sg / float(256 - mask))
                marg = min(marg, 0.15)

                def pick_ref(y, key, mv, pr):
                    m_ = mask
                    yi = np.clip(y, 0, 255).astype(np.int32) & m_
                    ak = (yi == (np.clip(key, 0, 255).astype(np.int32) & m_)).reshape(16, 6, 20, 6).mean(axis=(1, 3))
                    am = (yi == (np.clip(mv, 0, 255).astype(np.int32) & m_)).reshape(16, 6, 20, 6).mean(axis=(1, 3))
                    st = (ak >= am - marg).repeat(6, 0).repeat(6, 1)
                    return np.where(st, key, mv), np.where(st, pr, mv), st
                refB, pB, stB = pick_ref(yb, YO, mB, prB)
                refC, pC, stC = pick_ref(yc, YN, mC, prC)
                # the colour stays the keys' blend there too
                mot = [(m_[0], np.where(st_, c0, m_[1]), np.where(st_, c1, m_[2])) for m_, st_, (c0, c1) in
                       zip(mot, (stB, stC), [_chroma(r_, b_, (96, 120)) for r_, b_ in (cB, cC)])]
                if soft:                               # the bytes again, expecting the moved keys
                    yb, yc, mask = decode_bc(pB, pC)
        if key_only:
            yb, yc = YO, YN
        elif mot is not None and enc not in (4, KWL):
            # the key itself where the received bits agree with it (still parts: exact), else the
            # motion-searched picture where they agree with that, else a blend towards it
            yb = _keymix2(yb, YO, refB, mask, kmx)
            yc = _keymix2(yc, YN, refC, mask, kmx)
        elif not (mot is not None and enc in (4, KWL)):
            yb, yc = _keymix(yb, refB, mask, kmx), _keymix(yc, refC, mask, kmx)
        if self.ctrack and not key_only:
            # the colour tracked from both keys along the motion of each part of the picture
            cOf, cNf = list(_chroma(ryO, byO, YO.shape)), list(_chroma(ryN, byN, YO.shape))
            oth = [None, None] if mot is None else [mot[0][1:], mot[1][1:]]
            cB, cC = [chroma_to_bytes(*track_colour(y_, YO, YN, cOf, cNf, wO=w_, other=o_))
                      for y_, w_, o_ in ((yb, 2.0 / 3, oth[0]), (yc, 1.0 / 3, oth[1]))]
        elif mot is not None:                         # the colour moved with the picture
            cB, cC = chroma_to_bytes(mot[0][1], mot[0][2]), chroma_to_bytes(mot[1][1], mot[1][2])
        pics = [(YO, ryO, byO), (yb,) + cB, (yc,) + cC]
        if enc in (1, KWL):
            return self._detail240(pics, O, N, YO, YN, soft, snr, detail, wl)
        if ms:
            # A: the key's 192 lines; B and C: the keys' extra lines (what the 192 lines add to the line
            # pair sums) brought along the motion, as mode 5 carries mode 1's detail
            sh = (192, 240)
            DO = _up(KO, 1, 2, sh) - _up(YO, 2, 2, sh)
            DN = _up(KN, 1, 2, sh) - _up(YN, 2, 2, sh)
            out = [(np.clip(_up(KO, 1, 2, sh), 0, 255),) + _chroma(ryO, byO, sh)]
            for (Y, ry, by), wO in zip(pics[1:], (2.0 / 3, 1.0 / 3)):
                Y2 = Y if key_only else carry_detail(Y, YO, YN, DO, DN, wO, snr)
                if key_only:
                    Y2 = _up(KO if wO > 0.5 else KN, 1, 2, sh)
                out.append((np.clip(Y2, 0, 255),) + _chroma(ry, by, sh))
            return out
        return [(Y,) + _chroma(ry, by, Y.shape) for Y, ry, by in pics]

    def _detail240(self, pics, O, N, YO, YN, soft, snr, detail, wl):
        """The 240x192 detail (wavelet masks, or DCT) of the key pictures on top of the three pictures:
        the first takes this frame's, B and C what both keys either side agree on."""
        if detail == "dct":
            # the analog detail belongs to the key pictures; B and C take it 2:1 / 1:2 from the keys
            # either side, where they still look like those keys (not where the picture moved)
            cO = _detail_dct_coefs(O[17280:23040])
            cN = _detail_dct_coefs(N[17280:23040])
            out = []
            for i, (Y, ry, by) in enumerate(pics):
                up = _up(Y, 2, 2, (192, 240))
                if i == 0:
                    Y2 = _detail_dct_add(up, cO, snr)
                else:
                    wO = 2.0 / 3 if i == 1 else 1.0 / 3
                    d = _detail_dct_add(up, wO * cO + (1 - wO) * cN, snr) - up
                    ref = _up(YO if i == 1 else YN, 2, 2, (192, 240))
                    still = np.clip(1.0 - np.abs(up - ref) / 24.0, 0.0, 1.0)
                    Y2 = np.clip(up + d * still, 0, 255)
                out.append((Y2,) + _chroma(ry, by, Y2.shape))
            return out
        if True:
            if soft:
                mO = _wl_mask_soft(O[17280:23040], _up(YO, 2, 2, (192, 240)), snr)
                mN = _wl_mask_soft(N[17280:23040], _up(YN, 2, 2, (192, 240)), snr)
            else:
                mO = _wl_mask(O[17280:23040])
                mN = _wl_mask(N[17280:23040])
            both = mO * mN                            # his CPU3: the two masks ANDed for B and C
            out = []
            for i, (Y, ry, by) in enumerate(pics):
                Y2 = _wl_add(_up(Y, 2, 2, (192, 240)), mO if i == 0 else both, wl)
                out.append((Y2,) + _chroma(ry, by, Y2.shape))
            return out

    def _kwd(self, O, N, key_only, soft, snr, detail, wl, kmx=3, carry=False, split=False):
        """120x96 mode 1 (KWMD), as 180x96 mode 1 (CPU7) at 120x96 plus mode 1's 240x192 detail:
        the three lumas from their average (full size) and the two sums and differences (120x48).
        carry (mode 5): B and C take A's detail along the motion, from this frame's A and the next's."""
        S240 = {}

        def parts(F):
            ry, by = icm(F[:2880], 48, 60), icm(F[2880:5760], 48, 60)
            if split:                                     # (mode 7: the average at 240x192, from the split)
                S = kwh_join(F[5760:17280], snr)
                S240[id(F)] = S
                return ry, by, np.clip(_down(S, 2, 2), 0, 255).astype(np.float32)
            ys = np.empty((96, 120), np.float32)
            ys[0::2], ys[1::2] = icm(F[5760:11520], 48, 120), icm(F[11520:17280], 48, 120)
            return ry, by, ys

        def lumas(F, ys, only_a=False):
            m = F.astype(np.float32)
            d1, d2 = icm(m[23040:28800], 48, 120), icm(m[28800:34560], 48, 120)
            s = _down(ys, 2, 1) + 1 / 3.0                 # the TX truncated each /3
            c = 1.5 * (s + 85.0 - d1 - 1 / 3.0)
            b = 1.5 * (s + 85.0 - d2 - 1 / 3.0)
            a = 3.0 * s - b - c
            # each picture's own part (x - s) comes through with the channel's noise made 2.4x (B, C)
            # to 5x (A) in power by the sums and differences: where it is smaller than that noise it
            # is mostly noise, so it is let through in proportion (a Wiener gain over 5x5 areas)
            sg2 = noise_sigma(snr) ** 2 if KWD_SHRINK else 0.0
            st = kmx_strength(kmx)                        # Key mix: how hard (3: as measured best)
            lows = [s + _wiener(x - s, k * st, sg2) for x, k in ((a, 5.0), (b, 2.4), (c, 2.4))]
            if KMD_JOINT:
                # A from B and C's cleaned parts (the three parts add up to nothing: the average is
                # what was sent) - not cleaned on its own, where its 2x more noise made it fall back to
                # the average (the other pictures showing through) twice as readily
                lows[0] = s - (lows[1] - s) - (lows[2] - s)
            return [np.clip(ys + _up(lo - s, 2, 1, (96, 120)), 0, 255) for lo in lows[:1 if only_a else 3]]

        ryO, byO, ys = parts(O)
        ryN, byN, ysN = parts(N)
        Ys = [ys, ys, ys] if key_only else lumas(O, ys)
        self.next_key = None
        cols = [(ryO, byO), ((2.0 * ryO + ryN) / 3, (2.0 * byO + byN) / 3), ((ryO + 2.0 * ryN) / 3, (byO + 2.0 * byN) / 3)]
        pics = [(Y, r, bb) for Y, (r, bb) in zip(Ys, cols)]
        if detail == "sc" and not carry:                 # (mode 6, keys only: A's detail on A, B and C)
            DO = sc_detail_plane(O[17280:23040], snr)
            return [(np.clip(_up(Y, 2, 2, (192, 240)) + DO, 0, 255),) + _chroma(r, bb, (192, 240)) for Y, r, bb in pics]
        if carry and detail in ("dct", "sc"):
            AN = lumas(N, ysN, only_a=True)[0]            # the next frame's A, worked out now
            plane = sc_detail_plane if detail == "sc" else (lambda b, sn: _detail_dct_plane(_detail_dct_coefs(b), sn))
            DO = plane(O[17280:23040], snr)
            DN = plane(N[17280:23040], snr)
            out = [(np.clip(_up(Ys[0], 2, 2, (192, 240)) + DO, 0, 255),) + _chroma(ryO, byO, (192, 240))]
            for Y, (r, bb), wO in zip(Ys[1:], cols[1:], (2.0 / 3, 1.0 / 3)):
                Y2 = carry_detail(Y, Ys[0], AN, DO, DN, wO, snr)
                out.append((Y2,) + _chroma(r, bb, Y2.shape))
            return out
        # the detail belongs to A of each frame: this frame's A, and the next frame's (its average as
        # the stand-in where the next frame's own A is not worked out yet)
        out = self._detail240(pics, O, N, Ys[0], ysN, soft, snr, detail, wl)
        if split and KWH_E != "none" and id(O) in S240:
            # (mode 7) the split's own detail - what the 240x192 average has beyond its 120x96 - on the pictures
            E = S240[id(O)] - _up(ys, 2, 2, (192, 240))
            out = [((np.clip(o[0] + E, 0, 255),) + tuple(o[1:])) if (KWH_E == "all" or i > 0) else o
                   for i, o in enumerate(out)]
        return out

    def _widek(self, O, N, key_only, search=True, snr=None, kmx=3, w=180, lo_at=None):
        """180x96 mode 2: A is the key; B and C are rebuilt from their 90x48 pictures plus the detail of the keys
        either side (B nearer this key, C nearer the next), found by the motion search."""
        h = w // 2                                     # (w 120: the 120x96 modes 5 and 6, as these at 120 wide)
        c1 = 48 * h
        k0, k1, k2 = 2 * c1, 2 * c1 + 48 * w, 2 * c1 + 96 * w
        lp = k2 if lo_at is None else lo_at
        ryO, byO = icm(O[:c1], 48, h), icm(O[c1:2 * c1], 48, h)
        ryN, byN = icm(N[:c1], 48, h), icm(N[c1:2 * c1], 48, h)

        def key(F):
            Y = np.empty((96, w), np.float32)
            Y[0::2], Y[1::2] = icm(F[k0:k1], 48, w), icm(F[k1:k2], 48, w)
            return Y
        AO, AN = key(O), key(N)
        self.next_key = AN
        bl, cl = icm(O[lp:lp + c1], 48, h), icm(O[lp + c1:lp + 2 * c1], 48, h)
        if key_only:
            Ys = [AO, AO, AN]
        elif search:
            # B and C from their 90x48 pictures and the keys' detail; the colour moves with them
            (yb, crb, cbb), (yc, crc, cbc) = gpu_run("_motion_pair", AO, AN, ryO, byO, ryN, byN, bl, cl, snr)
            if KMM_CORRECT:
                # what the search missed, from the received 90x48 pictures (Key mix: how much of that
                # noisy correction gets through - 1 all, 5 next to none)
                sg2 = noise_sigma(snr) ** 2
                st = kmx_strength(kmx)
                yb = np.clip(yb + _up(_wiener(bl + 0.5 - _down(yb, 2, 2), st, sg2), 2, 2, (96, w)), 0, 255)
                yc = np.clip(yc + _up(_wiener(cl + 0.5 - _down(yc, 2, 2), st, sg2), 2, 2, (96, w)), 0, 255)
            crO, cbO = _chroma(ryO, byO, (96, w))
            if self.ctrack:
                cNf = list(_chroma(ryN, byN, (96, w)))
                crb, cbb = track_colour(yb, AO, AN, [crO, cbO], cNf, wO=2.0 / 3, other=(crb, cbb))
                crc, cbc = track_colour(yc, AO, AN, [crO, cbO], cNf, wO=1.0 / 3, other=(crc, cbc))
            return [(AO, crO, cbO), (yb, crb, cbb), (yc, crc, cbc)]
        else:                                          # no search: the low pictures plus still detail
            Ys = [AO]
            for xl, ref in ((bl, AO), (cl, AN)):
                up = _up(xl.astype(np.float32) + 0.5, 2, 2, (96, w))
                d = ref - _up(_down(ref, 2, 2), 2, 2, (96, w))
                still = _up(np.clip(1.0 - np.abs(xl + 0.5 - _down(ref, 2, 2)) / 10.0, 0, 1), 2, 2, (96, w))
                Ys.append(np.clip(up + d * still, 0, 255))
        if self.ctrack and not key_only:
            crO, cbO = _chroma(ryO, byO, (96, w))
            cNf = list(_chroma(ryN, byN, (96, w)))
            out = [(AO, crO, cbO)]
            for Y, w_ in zip(Ys[1:], (2.0 / 3, 1.0 / 3)):
                out.append((Y,) + tuple(track_colour(Y, AO, AN, [crO, cbO], cNf, wO=w_)))
            return out
        cols = [(ryO, byO), ((2.0 * ryO + ryN) / 3, (2.0 * byO + byN) / 3), ((ryO + 2.0 * ryN) / 3, (byO + 2.0 * byN) / 3)]
        return [(Y,) + _chroma(r, bb, Y.shape) for Y, (r, bb) in zip(Ys, cols)]

    def _wwd(self, enc, O, N, key_only, search, snr, kmx):
        """Modes 5, 6: the 180x96 modes' decoders at 120 wide, then A's 16 frequency 240x192 detail on A,
        and on B and C brought along the motion from the A's either side (as mode 5), or where still."""
        if enc == KMDW:
            pics = self._wide(O, N, key_only, snr, kmx, w=120, lo_at=28800)
        else:
            pics = self._widek(O, N, key_only, search, snr, kmx, w=120, lo_at=28800)
        AO = pics[0][0]
        if enc == KMMW:
            AN = self.next_key
        else:                                          # the next frame's A, from its own sums and differences
            AN = self._wide(N, N, False, snr, kmx, w=120, lo_at=28800)[0][0]
        self.next_key = None
        sh = (192, 240)
        if WW_SPLIT[1]:
            return self._wwd_own(enc, O, N, pics, AO, AN, key_only, snr)
        DO = _detail_dct_plane(_detail_dct16_coefs(O[17280:28800]), snr)
        DN = _detail_dct_plane(_detail_dct16_coefs(N[17280:28800]), snr)
        out = [(np.clip(_up(AO, 2, 2, sh) + DO, 0, 255), _up(pics[0][1], 2, 2, sh), _up(pics[0][2], 2, 2, sh))]
        for (Y, cr, cb), wO in zip(pics[1:], (2.0 / 3, 1.0 / 3)):
            if key_only:
                Y2 = np.clip(_up(Y, 2, 2, sh) + (DO if wO > 0.5 else DN), 0, 255)
            elif WW_CARRY:
                Y2 = carry_detail(Y, AO, AN, DO, DN, wO, snr)
            else:
                up = _up(Y, 2, 2, sh)
                d = wO * DO + (1 - wO) * DN
                ref = _up(AO if wO > 0.5 else AN, 2, 2, sh)
                Y2 = np.clip(up + d * np.clip(1.0 - np.abs(up - ref) / 24.0, 0.0, 1.0), 0, 255)
            out.append((Y2, _up(cr, 2, 2, sh), _up(cb, 2, 2, sh)))
        return out

    def _wwd_own(self, enc, O, N, pics, AO, AN, key_only, snr):
        """Modes 5, 6 with B and C's own detail: each picture's 120x96 as the transmitter took it (ww_base)
        plus its own detail; B and C also take A's other frequencies along the motion (WW_BC_CARRY)."""
        sa, sb = ww_sels(enc)
        sh = (192, 240)
        # the detail goes on the receiver's own (noise-aware) rebuild - the same as the transmitter's
        # without noise; with noise, the rebuild's own clean-up matters more than the match
        base = [p[0] for p in pics] if WW_RX_BASE == "rx" else ww_base(enc, O)
        na, nb = 720 * len(sa), 720 * len(sb)
        bufs = (O[17280:17280 + na], O[17280 + na:17280 + na + nb], O[17280 + na + nb:17280 + na + 2 * nb])
        sA = ww_steps(enc, sa, False)
        DA = ww_plane(ww_unpack(bufs[0], sa, sA), sa, sA, snr)
        out = [(np.clip(_up(base[0], 2, 2, sh) + DA, 0, 255), _up(pics[0][1], 2, 2, sh), _up(pics[0][2], 2, 2, sh))]
        rest = [f for f in sa if f not in sb]
        sB = ww_steps(enc, sb, True)
        for j, wO in ((1, 2.0 / 3), (2, 1.0 / 3)):
            Y = base[j]
            D = ww_plane(ww_unpack(bufs[j], sb, sB), sb, sB, snr)
            Y2 = np.clip(_up(Y, 2, 2, sh) + D, 0, 255)
            if WW_BC_CARRY and rest and not key_only:
                # A's frequencies B and C don't have, from the A's either side along the motion
                ix = [sa.index(f) for f in rest]
                cO = ww_unpack(bufs[0], sa, sA)[..., ix]
                cN = ww_unpack(N[17280:17280 + na], sa, sA)[..., ix]
                PO, PN = ww_plane(cO, rest, sA[ix], snr), ww_plane(cN, rest, sA[ix], snr)
                Y2 = np.clip(Y2 + carry_detail(Y, AO, AN, PO, PN, wO, snr) - _up(Y, 2, 2, sh), 0, 255)
            out.append((Y2, _up(pics[j][1], 2, 2, sh), _up(pics[j][2], 2, 2, sh)))
        return out

    def _wide(self, O, N, key_only, snr=None, kmx=3, w=180, lo_at=None):
        """CPU7 undone: the three lumas from their average and the two 90x48 differences."""
        h = w // 2                                     # (w 120: the 120x96 modes 5 and 6, as these at 120 wide)
        c1 = 48 * h
        k0, k1, k2 = 2 * c1, 2 * c1 + 48 * w, 2 * c1 + 96 * w
        lp = k2 if lo_at is None else lo_at
        ryO, byO = icm(O[:c1], 48, h), icm(O[c1:2 * c1], 48, h)
        ryN, byN = icm(N[:c1], 48, h), icm(N[c1:2 * c1], 48, h)
        m = O.astype(np.float32)
        ys = np.empty((96, w), np.float32)
        ys[0::2], ys[1::2] = icm(m[k0:k1], 48, w), icm(m[k1:k2], 48, w)
        ya_, yb_ = icm(m[lp:lp + c1], 48, h), icm(m[lp + c1:lp + 2 * c1], 48, h)
        s = _down(ys, 2, 2) + 1 / 3.0                 # the TX truncated each /3
        c = 1.5 * (s + 85.0 - ya_ - 1 / 3.0)
        b = 1.5 * (s + 85.0 - yb_ - 1 / 3.0)
        a = 3.0 * s - b - c
        if key_only:
            Ys = [ys, ys, ys]
        else:
            # as 120x96 mode 1: each picture's own part, with the noise made 4.75x (A) / 2.3x (B, C)
            # in power by the sums and differences, let through as it stands above that (Key mix)
            sg2 = noise_sigma(snr) ** 2 if KWD_SHRINK else 0.0
            st = kmx_strength(kmx)
            lows = [s + _wiener(x - s, k * st, sg2) for x, k in ((a, 4.75), (b, 2.3), (c, 2.3))]
            if KMD_JOINT:
                # A from B and C's cleaned parts (the three parts add up to nothing: the average is
                # what was sent) - not cleaned on its own, where its 2x more noise made it fall back to
                # the average (the other pictures showing through) twice as readily
                lows[0] = s - (lows[1] - s) - (lows[2] - s)
            Ys = [np.clip(ys + _up(lo - s, 2, 2, (96, w)), 0, 255) for lo in lows]
        cols = [(ryO, byO), ((2.0 * ryO + ryN) / 3, (2.0 * byO + byN) / 3), ((ryO + 2.0 * ryN) / 3, (byO + 2.0 * byN) / 3)]
        return [(Y,) + _chroma(r, bb, Y.shape) for Y, (r, bb) in zip(Ys, cols)]


KMD_JOINT = True
def _fill_vectors(pick, ref, bs=6, t_min=3.0):
    """The vectors again, for moving the colour: where the key's block has next to no luma detail,
    the luma search could not see the motion (a flat area - and colour edges between equally bright
    colours are invisible to it), so such blocks take the average vector of their detailed
    neighbours, spreading in from the edges of the flat area."""
    nby, nbx = pick.shape[:2]
    t = np.asarray(ref, np.float32)[:nby * bs, :nbx * bs].reshape(nby, bs, nbx, bs).std(axis=(1, 3))
    ok = t > t_min
    if not ok.any() or ok.all():
        return pick
    out = pick.copy()
    v = out[..., 1:].astype(np.float32)
    for _ in range(max(nby, nbx)):
        if ok.all():
            break
        okp = np.pad(ok, 1)
        vp = np.pad(v * ok[..., None], ((1, 1), (1, 1), (0, 0)))
        n = sum(okp[1 + dy:1 + dy + nby, 1 + dx:1 + dx + nbx] for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        sv = sum(vp[1 + dy:1 + dy + nby, 1 + dx:1 + dx + nbx] for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        new = (~ok) & (n > 0)
        v[new] = sv[new] / n[new][:, None]
        ok = ok | new
    out[..., 1:] = np.round(v).astype(int)
    return out


def _motion_pair(AO, AN, ryO, byO, ryN, byN, bl, cl, snr, qn=0.0, mask=None, bs=6):
    """B and C rebuilt from their half-size pictures bl, cl and the keys AO, AN either side (the
    receiver's motion search); the colour taken from the same places in the keys.
    -> [(Y, R-Y, B-Y) of B, of C] at full size (R-Y, B-Y as differences, as _chroma gives)."""
    shape = AO.shape
    crO, cbO = _chroma(ryO, byO, shape)
    crN, cbN = _chroma(ryN, byN, shape)
    out = []
    for xl, pref, w in ((bl, 0, 2.0 / 3), (cl, 1, 1.0 / 3)):
        if mask is None:
            Y, picks, ws, conf = motion_search([AO, AN], xl, bs=bs, prefer=pref, snr=snr, qn=qn)
        else:                                          # xl: the received motion picture (top bits)
            Y, picks, ws, conf = motion_search_bits([AO, AN], xl, mask, prefer=pref, snr=snr)
        up6 = lambda x: x.repeat(bs, 0).repeat(bs, 1)
        picks = [_fill_vectors(pk, (AO, AN)[pk[0, 0, 0]], bs) for pk in picks]
        cmv = sum(up6(wt) * apply_vectors(pk, [crO, crN], bs) for wt, pk in zip(ws, picks))
        bmv = sum(up6(wt) * apply_vectors(pk, [cbO, cbN], bs) for wt, pk in zip(ws, picks))
        # where the picture hardly moved, the keys' own blend is the better colour (a luma match says
        # little about the colour in flat areas); the moved colour where it really moved
        mv = sum(wt * (np.abs(pk[..., 1]) + np.abs(pk[..., 2])) for wt, pk in zip(ws, picks))
        g = conf * _up(np.clip((mv - 1.0) / 2.0, 0, 1), bs, bs, shape)
        g = np.clip(g, 0, 1)
        cr = g * cmv + (1 - g) * (w * crO + (1 - w) * crN)
        cb = g * bmv + (1 - g) * (w * cbO + (1 - w) * cbN)
        out.append((Y, cr, cb))
    return out


def _shift(img, dy, dx, pad=16):
    p = np.pad(img, pad, mode="edge")
    h, w = img.shape
    return p[pad + dy:pad + dy + h, pad + dx:pad + dx + w]


def motion_search(refs, lo, bs=6, ry=4, rx=12, prefer=0, lam=0.4, snr=None, qn=0.0):
    """Receiver-side motion search, guided by the low-resolution picture that was sent.
    refs: full-size pictures to borrow detail from (the keys either side); lo: the received 90x48
    (half size) picture.  For every 6x6 block, every shift (+-ry, +-rx pixels) of each ref is tried,
    and the one whose half-size version matches the received block best is used - so the sharp key's
    detail lands where the object is now.  Where both keys match about as well (still parts), the two
    are averaged, which also halves their noise.  A small cost on long moves, and on the farther key,
    keeps it steady in noise.  The match's low frequencies are then put right with the received
    picture, and where even the best match is poor (something new, or noise), the plain half-size
    picture is used instead.  -> (picture, vectors per ref, weights per ref, confidence)."""
    H, W = refs[0].shape
    hb = bs // 2
    nby, nbx = H // bs, W // bs
    # the noise in the received half-size picture, from the SNR: in noise, long moves must earn it
    sig = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 35.0, 45.0), -5.0) / 10.0))
    sig = math.hypot(sig, qn)                           # plus any rounding in the half-size picture
    lam = lam + 0.25 * sig
    lo = lo.astype(np.float32) + 0.5                   # the TX truncated
    bests, picks = [], []
    pad = 16
    for ri, ref in enumerate(refs):
        far = 0.0 if ri == prefer else hb * hb * (0.5 + 0.3 * sig)
        # every shift at once: the padded key halved in size at its 4 half-pixel phases; a shift
        # (dy, dx) of the key is then just a slice of one of them
        P = np.pad(np.asarray(ref, np.float32), pad, mode="edge")
        Hp, Wp = P.shape
        ph = {(py, px): P[py:py + (Hp - 2) // 2 * 2, px:px + (Wp - 2) // 2 * 2].reshape(
            (Hp - 2) // 2, 2, (Wp - 2) // 2, 2).mean(axis=(1, 3)) for py in (0, 1) for px in (0, 1)}
        h2, w2 = nby * hb, nbx * hb
        lo_t = lo[:h2, :w2]
        best = np.full((nby, nbx), np.inf)
        pick = np.zeros((nby, nbx, 3), int)
        for dy in range(-ry, ry + 1):
            q = pad + dy
            for px in (0, 1):
                dxs = np.array([dx for dx in range(-rx, rx + 1) if (pad + dx) % 2 == px])
                j0s = (pad + dxs) // 2
                L = ph[(q % 2, px)][q // 2:q // 2 + h2]
                win = np.lib.stride_tricks.sliding_window_view(L, w2, axis=1)[:, j0s]   # h2 x n x w2
                e = np.abs(np.moveaxis(win, 1, 0) - lo_t[None])
                e = e.reshape(len(dxs), nby, hb, nbx, hb).sum(axis=(2, 4))
                e = e + (lam * (abs(dy) + np.abs(dxs)) + far)[:, None, None]
                k = np.argmin(e, axis=0)
                eb = np.take_along_axis(e, k[None], axis=0)[0]
                m = eb < best
                best[m] = eb[m]
                pick[m] = np.stack((np.full_like(k, ri), np.full_like(k, dy), dxs[k]), axis=-1)[m]
        bests.append(best)
        picks.append(pick)
    expect = hb * hb * (1.2 * sig + 4.0)              # a good match's error, noise included
    emin = np.minimum(*bests) if len(bests) == 2 else bests[0]
    ws = [np.exp(-(b - emin) / (0.35 * expect)) for b in bests]
    tot = sum(ws)
    P = sum(w_.repeat(bs, 0).repeat(bs, 1) * apply_vectors(pk, refs, bs)
            for w_, pk in zip(ws, picks)) / tot.repeat(bs, 0).repeat(bs, 1)
    # the low-frequency correction: in noise, shrink it by how much of it is more than the noise
    dl = lo - _down(P, 2, 2)
    bv = (dl[:nby * hb, :nbx * hb].reshape(nby, hb, nbx, hb) ** 2).mean(axis=(1, 3))
    kw = np.clip(1.0 - (0.75 * sig ** 2) / np.maximum(bv, 1e-6), 0.0, 1.0)
    corr = _up(dl * np.repeat(np.repeat(kw, hb, 0), hb, 1), 2, 2, (H, W))
    conf = np.clip(2.0 - emin / expect, 0.0, 1.0)
    conf = _up(np.repeat(np.repeat(conf, hb, 0), hb, 1), 2, 2, (H, W))
    plain = _up(lo, 2, 2, (H, W))
    Y = conf * (P + corr) + (1 - conf) * plain
    return np.clip(Y, 0, 255), picks, [w_ / tot for w_ in ws], conf


def motion_search_bits(refs, mo, mask, bs=6, ry=4, rx=12, prefer=0, snr=None, lam=None, cap=None, beta=None):
    """Receiver motion search for the modes that send the top bits of each motion pixel (1, 2, 3):
    every shift of each key is scored, at full size, by how far its pixels fall outside the range
    the received bits allow (plus a little for the distance from the received value, which carries
    the averaged low bits).  -> (picture, vectors per ref, weights per ref, confidence)."""
    lam = 2.0 if lam is None else lam
    cap = 40.0 if cap is None else cap
    beta = 0.1 if beta is None else beta
    H, W = refs[0].shape
    nby, nbx = H // bs, W // bs
    sig = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 35.0, 45.0), -5.0) / 10.0))
    mi = np.clip(np.asarray(mo, np.float32), 0, 255)
    lo = (mi.astype(np.int32) & mask).astype(np.float32)
    hi = lo + float(255 & ~mask)
    lam = lam * (1.0 + 0.25 * sig)
    pad = 16
    h, w = nby * bs, nbx * bs
    bests, picks = [], []
    for ri, ref in enumerate(refs):
        far = 0.0 if ri == prefer else bs * bs * (1.0 + 0.3 * sig)
        P = np.pad(np.asarray(ref, np.float32), pad, mode="edge")
        best = np.full((nby, nbx), np.inf)
        pick = np.zeros((nby, nbx, 3), int)
        dxs = np.arange(-rx, rx + 1)
        for dy in range(-ry, ry + 1):
            rows = P[pad + dy:pad + dy + h]
            win = np.lib.stride_tricks.sliding_window_view(rows, w, axis=1)[:, pad - rx:pad + rx + 1]  # h x n x w
            r = np.moveaxis(win, 1, 0)                                   # n x h x w (a view)
            e = lo[None, :h, :w] - r
            np.maximum(e, r - hi[None, :h, :w], out=e)
            np.maximum(e, 0, out=e)
            t = r - mi[None, :h, :w]
            np.abs(t, out=t)
            t *= beta
            e += t
            np.minimum(e, cap, out=e)
            e = e.reshape(len(dxs), nby, bs, nbx * bs).sum(axis=2).reshape(len(dxs), nby, nbx, bs).sum(axis=3)
            e = e + (lam * (abs(dy) + np.abs(dxs)) + far)[:, None, None]
            k = np.argmin(e, axis=0)
            eb = np.take_along_axis(e, k[None], axis=0)[0]
            m = eb < best
            best[m] = eb[m]
            pick[m] = np.stack((np.full_like(k, ri), np.full_like(k, dy), dxs[k]), axis=-1)[m]
        bests.append(best)
        picks.append(pick)
    expect = bs * bs * (0.8 * sig + 2.0 + beta * (255 & ~mask) / 4.0)
    emin = np.minimum(*bests) if len(bests) == 2 else bests[0]
    ws = [np.exp(-(b_ - emin) / (0.35 * expect)) for b_ in bests]
    tot = sum(ws)
    Pm = sum(w_.repeat(bs, 0).repeat(bs, 1) * apply_vectors(pk, refs, bs) for w_, pk in zip(ws, picks)) \
        / tot.repeat(bs, 0).repeat(bs, 1)
    conf = _up(np.clip(2.0 - emin / expect, 0.0, 1.0), bs, bs, (H, W))
    return np.clip(Pm, 0, 255), picks, [w_ / tot for w_ in ws], np.clip(conf, 0, 1)


def apply_vectors(pick, refs, bs=6, pad=16):
    """Build a picture from refs block by block with the vectors the motion search chose."""
    H, W = refs[0].shape
    Ps = [np.pad(np.asarray(r, np.float32), pad, mode="edge") for r in refs]
    nby, nbx = pick.shape[:2]
    # gather: for every output pixel, the pixel of the chosen ref at the chosen shift
    yy, xx = np.mgrid[0:nby * bs, 0:nbx * bs]
    pk = pick.repeat(bs, 0).repeat(bs, 1)
    out = np.empty((H, W), np.float32)
    out[:] = np.asarray(refs[0], np.float32)
    for ri, Pp in enumerate(Ps):
        m = pk[:, :, 0] == ri
        out[:nby * bs, :nbx * bs][m] = Pp[(yy + pad + pk[:, :, 1])[m], (xx + pad + pk[:, :, 2])[m]]
    return out


def ycc_to_rgb(y, ry, by, colour=1.0):
    """Y and R - Y, B - Y -> RGB (Y = (R+G+B)/3, or BT.601's with that coding)."""
    r = y + colour * ry
    b = y + colour * by
    if _CC["name"] == "BT.601":
        g = y - colour * (_W601[0] * ry + _W601[2] * by) / _W601[1]
    else:
        g = y - colour * (ry + by)
    return np.clip(np.stack((r, g, b), axis=-1), 0, 255).astype(np.uint8)


def finish_picture(ycc, colour=1.0, bright=0.0, contrast=1.0, sharp=0.0, mono=False):
    """Decoder controls on a (Y, R-Y, B-Y) picture -> RGB."""
    y, cr, cb = [np.asarray(a, np.float32) for a in ycc]
    if sharp > 0:
        p = np.pad(y, 1, mode="edge")
        blur = (p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:]) / 4.0
        y = y + sharp * (y - blur)
    y = (y - 128.0) * contrast + 128.0 + bright
    return ycc_to_rgb(y, cr, cb, 0.0 if mono else colour)



# ----------------------------------------------------------------------- upscaler (RX display)
# The decoded pictures are small (120x96, 180x96, 240x192) and are shown 2 to 3 times bigger.
# Plain bilinear enlarging (as before) is soft.  Here the enlarged picture is solved for instead:
# it must, when reduced the way the camera picture was reduced (a triangle over f pixels, as PIL
# BILINEAR), give back the received picture (iterative back-projection).  With "Super-res", the key
# pictures before and after (the same scene, a fraction of a pixel apart as things move) must fit
# too, each shifted by its measured motion - so detail finer than one received pixel comes back.
# Parts that moved differently (or a new scene) don't fit, and are left out pixel by pixel.  The
# colour (sent at half that size again) is enlarged guided by the enlarged luma, so its edges sit
# on the luma's edges - and its noise is smoothed where the luma is smooth.

def _tri_taps(f, sh=0.0):
    """(offset, weight) of the HR pixels f i + offset that make LR pixel i, the picture being
    shifted by sh HR pixels first (a shifted triangle: no separate interpolation needed)."""
    lo, hi = int(math.floor(sh)) - f, int(math.ceil(sh)) + 2 * f
    t = [(o, max(0.0, 1.0 - abs(o + 0.5 - f / 2.0 - sh) / f)) for o in range(lo, hi + 1)]
    t = [(o, w) for o, w in t if w > 1e-6]
    s = sum(w for _, w in t)
    return [(o, w / s) for o, w in t]


def _down_f(x, f, ty=None, tx=None):
    """The triangle reduce by f (edges held) - of x shifted, if given shifted taps - by strided
    slices: fast."""
    for axis, taps in ((0, ty or _tri_taps(f)), (1, tx or _tri_taps(f))):
        n = x.shape[axis] // f
        pd = max(abs(o) for o, _ in taps) + f
        p = np.pad(x, [(pd, pd) if a == axis else (0, 0) for a in (0, 1)], mode="edge")
        acc = None
        for o, w in taps:
            sl = slice(pd + o, pd + o + f * n, f)
            part = p[sl, :] if axis == 0 else p[:, sl]
            acc = w * part if acc is None else acc + w * part
        x = acc
    return x


def _up_f(e, f, ty=None, tx=None):
    """The adjoint of _down_f (each LR value spread back over the HR pixels it came from)."""
    for axis, taps in ((0, ty or _tri_taps(f)), (1, tx or _tri_taps(f))):
        n = e.shape[axis]
        pd = max(abs(o) for o, _ in taps) + f
        shp = list(e.shape)
        shp[axis] = f * n + 2 * pd
        z = np.zeros(shp, np.float32)
        for o, w in taps:
            sl = slice(pd + o, pd + o + f * n, f)
            if axis == 0:
                z[sl, :] += w * e
            else:
                z[:, sl] += w * e
        e = z[pd:pd + f * n, :] if axis == 0 else z[:, pd:pd + f * n]
    return e


def _box(a, r):
    c = np.cumsum(np.cumsum(np.pad(a, ((r + 1, r), (r + 1, r)), mode="edge"), 0), 1)
    n = 2 * r + 1
    return (c[n:, n:] - c[:-n, n:] - c[n:, :-n] + c[:-n, :-n]) / float(n * n)


def guided(I, p, r, eps):
    """He's guided filter: p smoothed, with the edges of I."""
    mI, mp = _box(I, r), _box(p, r)
    a = (_box(I * p, r) - mI * mp) / (_box(I * I, r) - mI * mI + eps)
    b = mp - a * mI
    return _box(a, r) * I + _box(b, r)


def fshift(a, dy, dx):
    """a sampled at (i + dy, j + dx), linear, edges held."""
    if dy == 0 and dx == 0:
        return a
    h, w = a.shape
    iy, ix = int(math.floor(dy)), int(math.floor(dx))
    fy, fx = dy - iy, dx - ix
    py, px = abs(iy) + 2, abs(ix) + 2
    p = np.pad(a, ((py, py), (px, px)), mode="edge")
    r0 = p[py + iy:py + iy + h + 1, px + ix:px + ix + w + 1]
    top = (1 - fx) * r0[:h, :w] + fx * r0[:h, 1:w + 1]
    bot = (1 - fx) * r0[1:h + 1, :w] + fx * r0[1:h + 1, 1:w + 1]
    return (1 - fy) * top + fy * bot


def est_shift(A, B, ry=3, rx=6, iters=6):
    """Global translation d (pixels) with B(p) ~ A(p + d): a whole-pixel search, then Lucas-Kanade.
    -> (d, mean abs error left)."""
    A = _box(np.asarray(A, np.float32), 1)
    B = _box(np.asarray(B, np.float32), 1)
    h, w = A.shape
    my, mx = ry + 2, rx + 2
    Bc = B[my:h - my, mx:w - mx]
    best = None
    for dy in range(-ry, ry + 1):
        for dx in range(-rx, rx + 1):
            e = float(np.mean(np.abs(A[my + dy:h - my + dy, mx + dx:w - mx + dx] - Bc)))
            if best is None or e < best[0]:
                best = (e, dy, dx)
    d = np.array(best[1:], float)
    for _ in range(iters):
        As = fshift(A, d[0], d[1])
        gy = np.gradient(As, axis=0)[my:h - my, mx:w - mx]
        gx = np.gradient(As, axis=1)[my:h - my, mx:w - mx]
        e = Bc - As[my:h - my, mx:w - mx]
        M = np.array([[np.sum(gy * gy), np.sum(gy * gx)], [np.sum(gy * gx), np.sum(gx * gx)]]) + 1e-3 * np.eye(2)
        st = np.clip(np.linalg.solve(M, [np.sum(gy * e), np.sum(gx * e)]), -1, 1)
        d += st
        if np.abs(st).max() < 0.01:
            break
    d = np.clip(d, [-ry, -rx], [ry, rx])
    err = float(np.mean(np.abs(Bc - fshift(A, d[0], d[1])[my:h - my, mx:w - mx])))
    return d, err


def sr_luma(y, f, obs=(), iters=6, step=1.5, sigma=10.0):
    """Back-projection enlarging of the luma y by f.  obs: [(picture, d)] other pictures of the
    scene, d (pixels) such that picture(p) ~ y(p + d)."""
    h, w = y.shape
    y = np.asarray(y, np.float32)
    x = _up(y, f, f, (h * f, w * f))
    views = [(y, None, None)] + [(np.asarray(o, np.float32), _tri_taps(f, d[0] * f), _tri_taps(f, d[1] * f))
                                 for o, d in obs]
    wts = [None] * len(views)
    norm = None
    for it in range(iters):
        g = np.zeros_like(x)
        upd = it < 3                                   # which parts each picture is trusted for
        for k, (o, sy, sx) in enumerate(views):
            e = o - _down_f(x, f, sy, sx)
            if upd:
                wts[k] = np.ones_like(e) if sy is None else np.exp(-(e / sigma) ** 2)
            g += _up_f(e * wts[k], f, sy, sx)
        if upd:
            nrm = sum(_up_f(wt, f, sy, sx) for wt, (o, sy, sx) in zip(wts, views))
            norm = 1.0 / np.maximum(nrm, 1e-3)
        x += step * g * norm
    # no ringing past what the received neighbourhood holds
    p = np.pad(y, 1, mode="edge")
    st = np.stack([p[i:i + h, j:j + w] for i in range(3) for j in range(3)])
    lo = st.min(axis=0).repeat(f, 0).repeat(f, 1) - 4.0
    hi = st.max(axis=0).repeat(f, 0).repeat(f, 1) + 4.0
    return np.clip(x, lo, hi)


# ----------------------------------------------------------------------- in-between pictures
# 12.5 pictures a second (25 with mode 5's 8.3: x3) made up to 25: each missing picture is worked
# out from the two either side - where each part of the picture went between them (motion search
# from both ends, meeting in the middle), then each picture moved part of the way and the two
# blended.  Where the two don't agree once moved (something uncovered, or the search fooled), the
# nearer picture alone is used.  The last gap of a frame reaches to the next frame's key, which the
# decoder already has (its luma; the colour comes from this side).


def _warp(img, fy, fx):
    """img sampled at (y + fy, x + fx) per pixel (bilinear, edges held)."""
    h, w = img.shape[:2]
    yy = np.clip(np.arange(h, dtype=np.float32)[:, None] + fy, 0, h - 1.001)
    xx = np.clip(np.arange(w, dtype=np.float32)[None, :] + fx, 0, w - 1.001)
    y0 = yy.astype(np.int32)
    x0 = xx.astype(np.int32)
    ay, ax = yy - y0, xx - x0
    f = np.asarray(img, np.float32).ravel()
    i = y0 * w + x0
    a = np.take(f, i) * (1 - ax) + np.take(f, i + 1) * ax
    b = np.take(f, i + w) * (1 - ax) + np.take(f, i + w + 1) * ax
    return a * (1 - ay) + b * ay


def _warp3(img, fy, fx):
    """img sampled at (y + fy, x + fx) per pixel, cubic (Keys, a = -0.5): sharper than _warp."""
    h, w = img.shape[:2]
    yy = np.clip(np.arange(h, dtype=np.float32)[:, None] + fy, 0, h - 1.001)
    xx = np.clip(np.arange(w, dtype=np.float32)[None, :] + fx, 0, w - 1.001)
    y0 = yy.astype(np.int32)
    x0 = xx.astype(np.int32)
    ty, tx = yy - y0, xx - x0

    def kern(t):
        t2 = t * t
        t3 = t2 * t
        return (-0.5 * t3 + t2 - 0.5 * t, 1.5 * t3 - 2.5 * t2 + 1, -1.5 * t3 + 2 * t2 + 0.5 * t, 0.5 * t3 - 0.5 * t2)
    ky, kx = kern(ty), kern(tx)
    p = np.pad(np.asarray(img, np.float32), 2, mode="edge")
    W = w + 4
    f = p.ravel()
    base = (y0 + 1) * W + (x0 + 1)                      # (y0 - 1, x0 - 1) in the padded picture
    out = 0.0
    for i in range(4):
        r = base + i * W
        row = kx[0] * np.take(f, r) + kx[1] * np.take(f, r + 1) + kx[2] * np.take(f, r + 2) + kx[3] * np.take(f, r + 3)
        out = out + ky[i] * row
    return out


def mid_vectors(A, B, bs=6, ry=4, rx=8, lam=0.6, t=0.5):
    """Motion between pictures A and B as seen from half way: per block the v (pixels, A -> B)
    for which A at x - v/2 matches B at x + v/2 best (so every in-between pixel has a vector - no
    holes).  -> (vy, vx) per pixel, smooth, and the match error per block."""
    A = _box(np.asarray(A, np.float32), 1)
    B = _box(np.asarray(B, np.float32), 1)
    h, w = A.shape
    nby, nbx = h // bs, w // bs
    if t != 0.5:
        return _flow_t(A, B, bs, ry, rx, lam, t)
    pad = max(ry, rx) // 2 + 2
    # half-pixel versions, so v/2 is always a whole number of half pixels
    Ah = {(py, px): np.pad(fshift(A, -0.5 * py, -0.5 * px), pad, mode="edge") for py in (0, 1) for px in (0, 1)}
    Bh = {(py, px): np.pad(fshift(B, 0.5 * py, 0.5 * px), pad, mode="edge") for py in (0, 1) for px in (0, 1)}
    H, W = nby * bs, nbx * bs
    cube = np.empty((2 * ry + 1, 2 * rx + 1, nby, nbx), np.float32)
    for dy in range(-ry, ry + 1):
        for dx in range(-rx, rx + 1):
            # A at x - v/2: v/2 = dy/2 -> whole part floor(dy/2) and a half if dy is odd
            ay, ax = -(dy // 2) if dy % 2 == 0 else -((dy - 1) // 2), -(dx // 2) if dx % 2 == 0 else -((dx - 1) // 2)
            py, px = dy % 2, dx % 2
            a = Ah[(py, px)][pad + ay:pad + ay + H, pad + ax:pad + ax + W]
            by_, bx_ = dy // 2, dx // 2
            b = Bh[(py, px)][pad + by_:pad + by_ + H, pad + bx_:pad + bx_ + W]
            cube[dy + ry, dx + rx] = np.abs(a - b).reshape(nby, bs, nbx, bs).sum(axis=(1, 3)) \
                + lam * bs * bs * 0.1 * (abs(dy) + abs(dx))
    flat = cube.reshape(-1, nby, nbx)
    k = np.argmin(flat, axis=0)
    iy, ix = k // (2 * rx + 1), k % (2 * rx + 1)
    best = np.take_along_axis(flat, k[None], 0)[0]
    # to a fraction of a pixel: a parabola through the best and its neighbours, each way
    def frac(c0, cm, cp):
        den = cm - 2 * c0 + cp
        return np.where(den > 1e-6, np.clip(0.5 * (cm - cp) / np.maximum(den, 1e-6), -0.5, 0.5), 0.0)
    gy, gx = np.meshgrid(np.arange(nby), np.arange(nbx), indexing="ij")
    iym, iyp = np.clip(iy - 1, 0, 2 * ry), np.clip(iy + 1, 0, 2 * ry)
    ixm, ixp = np.clip(ix - 1, 0, 2 * rx), np.clip(ix + 1, 0, 2 * rx)
    fy_ = np.where((iy > 0) & (iy < 2 * ry), frac(best, cube[iym, ix, gy, gx], cube[iyp, ix, gy, gx]), 0.0)
    fx_ = np.where((ix > 0) & (ix < 2 * rx), frac(best, cube[iy, ixm, gy, gx], cube[iy, ixp, gy, gx]), 0.0)
    vy = (iy - ry + fy_).astype(np.float32)
    vx = (ix - rx + fx_).astype(np.float32)
    # tidy the field: 3x3 median of each part (a lone wrong block takes its neighbours' motion)
    def med3(v):
        p = np.pad(v, 1, mode="edge")
        st = np.stack([p[i:i + nby, j:j + nbx] for i in range(3) for j in range(3)])
        return np.median(st, axis=0)
    vy, vx = med3(vy), med3(vx)
    # then to a hundredth of a pixel: Lucas-Kanade from both ends, block by block
    bsum = lambda z: z[:H, :W].reshape(nby, bs, nbx, bs).sum(axis=(1, 3))
    for _ in range(3):
        fy = _up(vy, bs, bs, (h, w))
        fx = _up(vx, bs, bs, (h, w))
        a = _warp(A, -0.5 * fy, -0.5 * fx)
        b = _warp(B, 0.5 * fy, 0.5 * fx)
        r = b - a
        gy = 0.5 * (np.gradient(a, axis=0) + np.gradient(b, axis=0))
        gx = 0.5 * (np.gradient(a, axis=1) + np.gradient(b, axis=1))
        syy, sxx, sxy = bsum(gy * gy) + 1.0, bsum(gx * gx) + 1.0, bsum(gx * gy)
        by_, bx_ = bsum(gy * r), bsum(gx * r)
        det = syy * sxx - sxy * sxy
        dvy = -(sxx * by_ - sxy * bx_) / det
        dvx = -(syy * bx_ - sxy * by_) / det
        vy = np.clip(vy + np.clip(dvy, -0.5, 0.5), -ry, ry)
        vx = np.clip(vx + np.clip(dvx, -0.5, 0.5), -rx, rx)
    fy = _up(vy, bs, bs, (h, w))
    fx = _up(vx, bs, bs, (h, w))
    return fy, fx, best / (bs * bs)


def _flow_t(A, B, bs, ry, rx, lam, t):
    """mid_vectors seen from one end: t = 1 - from B's place (A at x - v matches B at x);
    t = 0 - from A's place (B at x + v matches A at x).  (A, B already smoothed.)"""
    h, w = A.shape
    nby, nbx = h // bs, w // bs
    H, W = nby * bs, nbx * bs
    pad = max(ry, rx) + 2
    Ap, Bp = np.pad(A, pad, mode="edge"), np.pad(B, pad, mode="edge")
    cube = np.empty((2 * ry + 1, 2 * rx + 1, nby, nbx), np.float32)
    for dy in range(-ry, ry + 1):
        for dx in range(-rx, rx + 1):
            if t >= 1.0:
                a = Ap[pad - dy:pad - dy + H, pad - dx:pad - dx + W]
                b = B[:H, :W]
            else:
                a = A[:H, :W]
                b = Bp[pad + dy:pad + dy + H, pad + dx:pad + dx + W]
            cube[dy + ry, dx + rx] = np.abs(a - b).reshape(nby, bs, nbx, bs).sum(axis=(1, 3)) \
                + lam * bs * bs * 0.1 * (abs(dy) + abs(dx))
    flat = cube.reshape(-1, nby, nbx)
    k = np.argmin(flat, axis=0)
    best = np.take_along_axis(flat, k[None], 0)[0]
    vy = (k // (2 * rx + 1) - ry).astype(np.float32)
    vx = (k % (2 * rx + 1) - rx).astype(np.float32)

    def med3(v):
        p = np.pad(v, 1, mode="edge")
        return np.median(np.stack([p[i:i + nby, j:j + nbx] for i in range(3) for j in range(3)]), axis=0)
    vy, vx = med3(vy), med3(vx)
    bsum = lambda z: z[:H, :W].reshape(nby, bs, nbx, bs).sum(axis=(1, 3))
    for _ in range(3):                                  # Lucas-Kanade, to a fraction of a pixel
        fy = _up(vy, bs, bs, (h, w))
        fx = _up(vx, bs, bs, (h, w))
        a = _warp(A, -t * fy, -t * fx)
        b = _warp(B, (1 - t) * fy, (1 - t) * fx)
        r = b - a
        gy = t * np.gradient(a, axis=0) + (1 - t) * np.gradient(b, axis=0)
        gx = t * np.gradient(a, axis=1) + (1 - t) * np.gradient(b, axis=1)
        syy, sxx, sxy = bsum(gy * gy) + 1.0, bsum(gx * gx) + 1.0, bsum(gx * gy)
        by_, bx_ = bsum(gy * r), bsum(gx * r)
        det = syy * sxx - sxy * sxy
        vy = np.clip(vy + np.clip(-(sxx * by_ - sxy * bx_) / det, -0.5, 0.5), -ry, ry)
        vx = np.clip(vx + np.clip(-(syy * bx_ - sxy * by_) / det, -0.5, 0.5), -rx, rx)
    return _up(vy, bs, bs, (h, w)), _up(vx, bs, bs, (h, w)), best / (bs * bs)


def track_colour(Y, YO, YN, cO, cN, wO=0.5, sig=10.0, other=None):
    """The colour of a picture that was sent without colour (B or C), carried from the key pictures
    either side along the motion: each part of Y is found in YO and in YN (sub-pixel), and the keys'
    colour is taken from there - weighted by how near each key is (wO: the earlier key's share) and
    by how well its luma matches there (a part that was hidden in one key takes the other's colour).
    cO, cN: [R-Y, B-Y] of each key, full size.  other: a colour from elsewhere (the motion search's)
    to use where neither key matches well.  -> [R-Y, B-Y] for Y."""
    Y = np.asarray(Y, np.float32)
    fyO, fxO, _ = mid_vectors(YO, Y, t=1.0, rx=8)        # YO at x - v  ~  Y at x
    fyN, fxN, _ = mid_vectors(Y, YN, t=0.0, rx=8)        # YN at x + v  ~  Y at x
    eO = _box(np.abs(_warp(np.asarray(YO, np.float32), -fyO, -fxO) - Y), 2)
    eN = _box(np.abs(_warp(np.asarray(YN, np.float32), fyN, fxN) - Y), 2)
    aO = wO * np.exp(-(eO / sig) ** 2) + 1e-4
    aN = (1 - wO) * np.exp(-(eN / sig) ** 2) + 1e-4
    q = np.maximum(np.exp(-(eO / sig) ** 2), np.exp(-(eN / sig) ** 2))      # how well it was found
    out = []
    for i, (o, n) in enumerate(zip(cO, cN)):
        co = _warp(np.asarray(o, np.float32), -fyO, -fxO)
        cn = _warp(np.asarray(n, np.float32), fyN, fxN)
        c = (aO * co + aN * cn) / (aO + aN)
        if other is not None:
            c = q * c + (1 - q) * np.asarray(other[i], np.float32)
        out.append(c)
    return out


def mid_picture(A, B, fy, fx, t=0.5, sig=8.0, colour=None, cubic=True):
    """The picture a fraction t of the way from A to B (luma A, B; colour: optional list of
    (chroma of A, chroma of B or None)).  B None: A moved on alone.  cubic False: the luma moved with
    straight-line (bilinear) sampling - for enlarged pictures, already smooth at that size, where it
    looks the same and costs a quarter."""
    wp = _warp3 if cubic else _warp
    a = wp(A, -t * fy, -t * fx)
    if B is None:
        Y = a
        wA = np.ones_like(a)
    else:
        b = wp(B, (1 - t) * fy, (1 - t) * fx)
        d = np.abs(a - b)
        agree = np.exp(-(d / sig) ** 2)                  # 1 where both moved pictures agree
        nearA = 1.0 if t <= 0.5 else 0.0
        wA = agree * (1 - t) + (1 - agree) * nearA
        Y = wA * a + (1 - wA) * b
        # where the two unmoved pictures already agree better than the moved ones (hardly any
        # motion), the plain blend: no resampling at all
        A_, B_ = np.asarray(A, np.float32), np.asarray(B, np.float32)
        r = max(1, int(round(A_.shape[1] / 120.0)))
        keep = _box((_box(np.abs(A_ - B_), r) < _box(d, r)).astype(np.float32), r)
        Y = keep * ((1 - t) * A_ + t * B_) + (1 - keep) * Y
    cols = []
    for cA, cB in (colour or []):
        ca = _warp(cA, -t * fy, -t * fx)
        if B is None or cB is None:
            cols.append(ca)
        else:
            cm = wA * ca + (1 - wA) * _warp(cB, (1 - t) * fy, (1 - t) * fx)
            cols.append(keep * ((1 - t) * np.asarray(cA, np.float32) + t * np.asarray(cB, np.float32)) + (1 - keep) * cm)
    return Y, cols


def fps_factor(period, n_pics, want=25.0):
    """How many pictures to show for each one received, to come near `want` a second."""
    return max(1, int(round(want / (n_pics / period))))


def _fi_pair(lo, nxt, last_v, o, o2, F):
    """The F-1 pictures after o (FrameInterp.process): lo, nxt = this and the next received luma
    (nxt None: keep moving as last_v).  -> (pictures, vectors used)."""
    H, W = o[0].shape
    h, w = lo.shape
    sy, sx = H / float(h), W / float(w)
    if nxt is not None:
        fy, fx, err = mid_vectors(lo, nxt)
        last_v = (fy, fx)
    elif last_v is not None:                         # no next picture: keep moving as before
        fy, fx = last_v
    else:
        fy = fx = np.zeros((h, w), np.float32)
    FY, FX = (_up(fy, int(round(sy)), int(round(sx)), (H, W)) * sy,
              _up(fx, int(round(sy)), int(round(sx)), (H, W)) * sx) if (H, W) != (h, w) else (fy, fx)
    Ya = np.asarray(o[0], np.float32)
    cA = [np.asarray(o[1], np.float32), np.asarray(o[2], np.float32)]
    if o2 is not None:
        Yb = np.asarray(o2[0], np.float32)
        cB = [np.asarray(o2[1], np.float32), np.asarray(o2[2], np.float32)]
    else:
        Yb, cB = None, [None, None]
    res = []
    for j in range(1, F):
        t = j / float(F)
        Y, cols = mid_picture(Ya, Yb, FY, FX, t, colour=list(zip(cA, cB)), cubic=(H, W) == (h, w))
        res.append((Y.astype(np.float16), cols[0].astype(np.float16), cols[1].astype(np.float16)))
    return res, last_v


class FrameInterp:
    """Puts F-1 pictures between each pair of received ones (see above)."""

    def __init__(self):
        self.last_v = None

    def reset(self):
        self.last_v = None

    def process(self, lows, outs, next_low, F):
        """lows: the received pictures' luma as received (for the motion); outs: the pictures to
        show (Y, R-Y, B-Y), maybe enlarged; next_low: the next frame's first picture (luma), or None.
        -> the pictures, F per received one."""
        if F <= 1 or not outs:
            return outs
        H, W = np.asarray(outs[0][0]).shape
        h, w = np.asarray(lows[0]).shape
        sy, sx = H / float(h), W / float(w)
        jobs = []
        for i, (lo, o) in enumerate(zip(lows, outs)):
            nxt = lows[i + 1] if i + 1 < len(lows) else next_low
            if nxt is not None and np.asarray(nxt).shape != (h, w):
                nxt = None
            jobs.append((lo, nxt, o, outs[i + 1] if i + 1 < len(outs) else None))
        # the pairs with a next picture don't depend on each other: side by side on the CPU's cores
        # (a pair without one keeps the previous pair's motion, so it waits for that)
        got = [None] * len(jobs)
        par = [k for k, j in enumerate(jobs) if j[1] is not None]
        if len(par) > 1 and not (_GPU["want"] and _GPU["cp"] is not None):
            ex = _threads()
            futs = {k: ex.submit(_fi_pair, jobs[k][0], jobs[k][1], None, jobs[k][2], jobs[k][3], F) for k in par}
            for k in par:
                got[k] = futs[k].result()
        res = []
        for k, (lo, nxt, o, o2) in enumerate(jobs):
            if got[k] is None:
                got[k] = gpu_run("_fi_pair", lo, nxt, self.last_v, o, o2, F)
            pics, self.last_v = got[k]
            res.append(o)
            res.extend(pics)
        return res


_POOL = []


def _threads():
    """A few threads for the picture work (numpy lets go of the interpreter in its loops, so they
    run on separate cores).  One per core, up to 4, at least 2."""
    if not _POOL:
        import concurrent.futures as _cf
        _POOL.append(_cf.ThreadPoolExecutor(max_workers=max(2, min(4, os.cpu_count() or 2))))
    return _POOL[0]


UPSCALE = ("Off", "Sharp", "Super-res")


def up_factor(shape):
    """How much the window enlarges a picture of this size: 120 wide x3, 180 / 240 wide x2."""
    return 3 if shape[1] <= 120 else 2


def _upscale_one(Y, cr, cb, others, f, H, sig, r, eps, soft_colour):
    """One picture enlarged (Upscaler.process): others = the other pictures of the scene to fit."""
    obs = []
    for K in others:
        d, err = est_shift(Y, K)
        if err < 6.0 + 1.5 * sig:                      # the same scene (not a cut)
            obs.append((K, d))
    Yh = sr_luma(Y, f, obs)
    Yg = np.clip(Yh, 0, 255)
    if soft_colour:                                  # Fuzzy colour / colour median on: keep it soft
        crh, cbh = _up(np.asarray(cr, np.float32), f, f, H), _up(np.asarray(cb, np.float32), f, f, H)
    else:                                            # the colour's edges put on the luma's
        crh = guided(Yg, _up(np.asarray(cr, np.float32), f, f, H), r, eps)
        cbh = guided(Yg, _up(np.asarray(cb, np.float32), f, f, H), r, eps)
    return Yh.astype(np.float16), crh.astype(np.float16), cbh.astype(np.float16)


class Upscaler:
    """The receiver's enlarging for the screen (and the recording), picture by picture."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.hist = collections.deque(maxlen=2)        # the last key pictures' luma (as received)
        self.shape = None

    def process(self, yccs, key_idx, next_key=None, method="Super-res", snr=None, soft_colour=False):
        """yccs: the decoded pictures (Y, R-Y, B-Y); key_idx: which of them are key pictures (true
        pictures, not rebuilt ones); next_key: the next frame's key luma, if known.
        -> the pictures enlarged (float16, to keep the hand-over small)."""
        if not yccs or method not in UPSCALE[1:]:
            return yccs
        shape = yccs[0][0].shape
        if shape != self.shape:
            self.reset()
            self.shape = shape
        f = up_factor(shape)
        H = (shape[0] * f, shape[1] * f)
        sig = 127.5 * math.sqrt((1.0 / 3.0) / 10 ** (max(min(snr if snr is not None else 35.0, 45.0), -5.0) / 10.0))
        keys = [yccs[i][0] for i in key_idx]
        cand = list(self.hist) + keys + ([next_key] if next_key is not None and next_key.shape == shape else [])
        r = 4 if f == 3 else 3
        eps = 60.0 + 4.0 * sig * sig
        args = [(Y, cr, cb, [K for K in cand if K is not Y] if method == "Super-res" else [])
                for Y, cr, cb in yccs]
        if len(args) > 1 and not (_GPU["want"] and _GPU["cp"] is not None):
            ex = _threads()                              # (the pictures side by side on the CPU's cores)
            futs = [ex.submit(_upscale_one, Y, cr, cb, oth, f, H, sig, r, eps, soft_colour) for Y, cr, cb, oth in args]
            out = [ft.result() for ft in futs]
        else:
            out = [gpu_run("_upscale_one", Y, cr, cb, oth, f, H, sig, r, eps, soft_colour) for Y, cr, cb, oth in args]
        for K in keys:
            self.hist.append(K)
        return out


# ----------------------------------------------------------------------- picture filters (RX)
def stack_blur(a, r):
    """Gambas Image.Fuzzy: Mario Klingemann's StackBlur - a separable blur whose weights fall off in a
    triangle, radius r pixels (here r may be fractional: 0.3 is a light touch)."""
    if r <= 0:
        return a
    n = int(math.ceil(r))
    k = np.maximum(0.0, r + 1 - np.abs(np.arange(-n, n + 1)))
    k = k / k.sum()
    h, w = a.shape
    p = np.pad(a, ((0, 0), (n, n)), mode="edge")
    a = sum(k[i] * p[:, i:i + w] for i in range(2 * n + 1))
    p = np.pad(a, ((n, n), (0, 0)), mode="edge")
    return sum(k[i] * p[i:i + h, :] for i in range(2 * n + 1))


def median3(a, s=1):
    """3 x 3 median, the neighbours s pixels apart (s = the colour's own pixel size): takes out single
    wrong colour pixels (speckle) and leaves edges sharp."""
    s = max(1, int(round(s)))
    p = np.pad(a, s, mode="edge")
    h, w = a.shape
    st = [p[s + dy:s + dy + h, s + dx:s + dx + w] for dy in (-s, 0, s) for dx in (-s, 0, s)]
    return np.median(np.stack(st), axis=0)


def snap_levels(b):
    """His Noise_Reduction (RX CPU2, mode 3): mode 3 bytes only use the top 4 bits, so put each
    received byte back on the nearest of the 16 levels (0, 0x10 .. 0xF0) - small noise goes away."""
    b = np.asarray(b, np.int32)
    return np.minimum((b + 8) // 16 * 16, 0xF0)


TNR_MODES = ("Off", "Light", "Auto", "Strong")


class TemporalNR:
    """Temporal noise reduction for the received pictures (luma and colour): each picture is
    averaged with the one before it (as cleaned), moved to match by a block motion search, wherever
    the two agree - a recursive filter, so on a still part the noise keeps coming down picture after
    picture.  Where they disagree by more than the noise (something moved differently, a new scene,
    a cut) it lets the new picture through untouched, so moving things are not smeared.  The noise is
    measured from the pictures themselves (each mode and picture type is different), so it does
    next to nothing on a clean signal."""

    KMAX = {"Light": 0.5, "Auto": 0.7, "Strong": 0.85}

    def __init__(self):
        self.prev = None
        self.used = 0.0

    def reset(self):
        self.prev = None

    @staticmethod
    def _search(P, Y, bs, r, lam):
        """Integer block vectors (pixels) such that P moved by them matches Y: SAD of 3x3-smoothed
        pictures, a small cost for longer moves (noise must not move still parts)."""
        h, w = Y.shape
        nby, nbx = h // bs, w // bs
        Ps, Ys = _box(P, 1), _box(Y, 1)
        pad = r
        Pp = np.pad(Ps, pad, mode="edge")
        best = np.full((nby, nbx), np.inf)
        vy = np.zeros((nby, nbx), np.int32)
        vx = np.zeros((nby, nbx), np.int32)
        Yc = Ys[:nby * bs, :nbx * bs]
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                Q = Pp[pad + dy:pad + dy + nby * bs, pad + dx:pad + dx + nbx * bs]
                e = np.abs(Q - Yc).reshape(nby, bs, nbx, bs).sum(axis=(1, 3)) + lam * (abs(dy) + abs(dx))
                m = e < best
                best[m], vy[m], vx[m] = e[m], dy, dx
        return vy, vx

    @staticmethod
    def _refine(P, Y, vy, vx, bs, lam):
        """The vectors put right to the pixel at full size (each block tries +-1 around its own)."""
        h, w = Y.shape
        nby, nbx = vy.shape
        Ps, Ys = _box(P, 1), _box(Y, 1)
        r = int(max(np.abs(vy).max(), np.abs(vx).max())) + 1
        Pp = np.pad(Ps, r, mode="edge")
        yy, xx = np.mgrid[0:nby * bs, 0:nbx * bs]
        by, bx = yy // bs, xx // bs
        Yc = Ys[:nby * bs, :nbx * bs]
        best = np.full((nby, nbx), np.inf)
        oy, ox = vy.copy(), vx.copy()
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                cy, cx = vy + dy, vx + dx
                Q = Pp[yy + r + cy[by, bx], xx + r + cx[by, bx]]
                e = np.abs(Q - Yc).reshape(nby, bs, nbx, bs).sum(axis=(1, 3)) + lam * (np.abs(cy) + np.abs(cx))
                m = e < best
                best[m], oy[m], ox[m] = e[m], cy[m], cx[m]
        return oy, ox

    @staticmethod
    def _move(P, vy, vx, bs):
        h, w = P.shape
        nby, nbx = vy.shape
        r = int(max(np.abs(vy).max(), np.abs(vx).max(), 1))
        Pp = np.pad(P, r, mode="edge")
        yy, xx = np.mgrid[0:h, 0:w]
        by = np.minimum(yy // bs, nby - 1)
        bx = np.minimum(xx // bs, nbx - 1)
        return Pp[yy + r + vy[by, bx], xx + r + vx[by, bx]]

    def apply(self, yccs, mode="Auto", snr=None, enc=None):
        if mode == "Auto" and enc is not None and int(enc) in (KWD, KWL, KWDM, KMS, KMDW, KMMW):
            mode = "Off"         # 240x192 modes: their in-between pictures, rebuilt from the keys, differ
            #                      from each other with no noise at all - it would take that for noise and
            #                      soften the detail (and it gains them only ~0.4 dB in noise)
        if mode not in self.KMAX or not yccs:
            self.prev = None
            self.used = 0.0
            return yccs
        kmax = self.KMAX[mode]
        out = []
        ks = []
        for y, cr, cb in yccs:
            Y = np.asarray(y, np.float32)
            Cr, Cb = np.asarray(cr, np.float32), np.asarray(cb, np.float32)
            pv = self.prev
            if pv is None or pv[0].shape != Y.shape or pv[1].shape != Cr.shape:
                self.prev = (Y, Cr, Cb)
                out.append((y, cr, cb))
                continue
            # the motion: searched at about 120 wide (bigger pictures halved), then scaled up
            f = 2 if Y.shape[1] >= 240 else 1
            Ys, Ps = (_down(Y, 2, 2), _down(pv[0], 2, 2)) if f == 2 else (Y, pv[0])
            bs = 6
            vy, vx = self._search(Ps, Ys, bs, 3, 6.0)
            vy, vx, bsf = vy * f, vx * f, bs * f
            if f > 1:
                vy, vx = self._refine(pv[0], Y, vy, vx, bsf, 6.0)
            Pm = self._move(pv[0], vy, vx, bsf)
            d = Y - Pm
            # the noise in the difference, from the pictures themselves (robust: moving parts are few)
            sd = 1.4826 * float(np.median(np.abs(d - np.median(d)))) + 1e-3
            sk = sd
            if mode == "Auto" and snr is not None:
                # no more than the radio's noise could make (two pictures' worth): a difference the codec
                # or the source makes (camera noise, rebuilt pictures) must not switch it on
                sk = min(sd, 1.5 * noise_sigma(snr))
            k = kmax * float(np.clip((sk - 3.0) / 6.0, 0.0, 1.0))   # clean (3 or less): nothing done
            ks.append(k)
            if k <= 0.0:
                self.prev = (Y, Cr, Cb)
                out.append((y, cr, cb))
                continue
            e = _box(d, 1)                                # the local disagreement, the noise averaged down
            # how much of that is noise: measured on e itself (white noise averages down x3, but noise
            # that came up from a smaller picture - 240x192, the colour - is smooth and hardly does)
            se = max(1.4826 * float(np.median(np.abs(e - np.median(e)))), sd / 3.0) + 1e-3
            g = np.exp(-(e / (2.0 * se)) ** 2)            # 1 where they agree within the noise, 0 where not
            wY = k * g
            Yo = Y + wY * (Pm - Y)
            if Cr.shape == Y.shape:
                Crm, Cbm = self._move(pv[1], vy, vx, bsf), self._move(pv[2], vy, vx, bsf)
                dc = np.abs(_box(Cr - Crm, 1)) + np.abs(_box(Cb - Cbm, 1))
                sc = 1.4826 * float(np.median(dc)) + 1e-3
                wC = wY * np.exp(-(dc / (1.5 * sc)) ** 2)
                Cro, Cbo = Cr + wC * (Crm - Cr), Cb + wC * (Cbm - Cb)
            else:
                Cro, Cbo = Cr, Cb
            self.prev = (Yo, Cro, Cbo)
            out.append((Yo, Cro, Cbo))
        self.used = float(np.mean(ks)) if ks else 0.0
        return out


class PictureFilter:
    """The receiver's clean-up for poor signals, as on your NBTV RX plus a few more:
      fuzzy_c   Fuzzy (StackBlur) on the colour, radius in 120x96 pixels (your CPic.Fuzzy(Clvel))
      fuzzy_p   Fuzzy on the whole picture, radius in 360x288 pixels (your hPic.Fuzzy(Slider11))
      median_c  3x3 median on the colour (speckle)
      cavg      colour averaged over frames where it is not moving (0 = off .. 0.8)
      auto      choose those from the measured SNR."""

    def __init__(self):
        self.prev = None
        self.tnr = TemporalNR()

    def reset(self):
        self.prev = None
        self.tnr.reset()

    @staticmethod
    def auto_settings(snr):
        """SNR (dB, per carrier) -> (fuzzy_c, fuzzy_p, median_c, cavg)."""
        if snr is None or snr >= 30:
            return 0, 0, False, 0.0
        fc = int(np.clip(round((30 - snr) / 4.5), 0, 5))
        return fc, (1 if snr < 24 else 0), snr < 18, float(np.clip((26 - snr) / 20.0, 0.0, 0.7))

    def apply(self, yccs, fuzzy_c=0, fuzzy_p=0, median_c=False, cavg=0.0, auto=False, snr=None, tnr="Off", enc=None):
        yccs = self.tnr.apply(yccs, tnr, snr, enc)       # temporal noise reduction first (it wants the noise as it came)
        if auto:
            fuzzy_c, fuzzy_p, median_c, cavg = self.auto_settings(snr)
        self.used = (fuzzy_c, fuzzy_p, median_c, cavg, self.tnr.used)
        out = []
        for y, cr, cb in yccs:
            sc = y.shape[0] / 96.0                       # picture pixels per 120x96 pixel
            if median_c:
                cr, cb = median3(cr, sc * 2), median3(cb, sc * 2)    # the colour is sent at half size
            if fuzzy_c > 0:
                cr, cb = stack_blur(cr, fuzzy_c * sc), stack_blur(cb, fuzzy_c * sc)
            if cavg > 0:
                pv = self.prev
                if pv is not None and pv[0].shape == cr.shape:
                    still = (np.abs(cr - pv[0]) + np.abs(cb - pv[1])) < 60.0
                    cr = np.where(still, cavg * pv[0] + (1 - cavg) * cr, cr)
                    cb = np.where(still, cavg * pv[1] + (1 - cavg) * cb, cb)
                self.prev = (cr, cb)
            else:
                self.prev = None
            if fuzzy_p > 0:
                r = fuzzy_p * y.shape[0] / 288.0
                y, cr, cb = stack_blur(y, r), stack_blur(cr, r), stack_blur(cb, r)
            out.append((y, cr, cb))
        return out


TX200 = ("Repeat + filter", "2x IFFT")


class TxDroop:
    """What the flowgraph's way to 200 kHz (each sample twice, then the 50 kHz low pass) does to the
    carriers, as a filter at 100 kHz: the outer carriers rolled off (-2.2 dB at 44 kHz, the last few
    -4 to -9 dB).  The receiver's equaliser puts their level back, but not the noise: the lab's
    channel then gives what the real transmitter gives.  (With the 2x IFFT there is none of it.)"""

    def __init__(self, taps=81):
        h2 = Upsampler().h                                # the low pass at 200 kHz (gain 2)
        n = 1024
        f = np.fft.fftfreq(n) * FS                        # the 100 kHz grid
        w = 2 * np.pi * f / (2 * FS)
        G = np.abs(np.exp(-1j * np.outer(w, np.arange(len(h2)))) @ h2) * np.abs(1 + np.exp(-1j * w)) / 2 / 2
        t = np.arange(taps) - (taps - 1) / 2.0
        h = np.real(np.fft.ifft(G * np.exp(-2j * np.pi * np.fft.fftfreq(n) * 0))) # zero phase
        h = np.roll(h, (taps - 1) // 2)[:taps] * np.blackman(taps)
        self.h = (h / math.sqrt(np.sum(np.abs(G) ** 2) / n) / max(np.sum(h * h) ** 0.5, 1e-12) *
                  math.sqrt(np.sum(h * h))).astype(np.float32)
        self.hist = np.zeros(taps - 1, np.complex64)

    def process(self, x):
        buf = np.concatenate((self.hist, np.asarray(x, np.complex64)))
        y = np.convolve(buf, self.h, mode="valid")
        self.hist = buf[-(len(self.h) - 1):]
        return y.astype(np.complex64)


def interp2(x):
    """x (100 kHz) at 200 kHz, band-limited (as a 2N IFFT gives it): for the RF view."""
    x = np.asarray(x, np.complex64)
    n = len(x)
    X = np.fft.fft(x)
    Y = np.zeros(2 * n, complex)
    Y[:n // 2] = X[:n // 2]
    Y[-(n - n // 2):] = X[n // 2:]
    return (np.fft.ifft(Y) * 2).astype(np.complex64)


class Upsampler:
    """TX output to 200 kHz the way the GNU Radio flowgraph does it: each sample twice, then a 50 kHz
    low pass (Blackman windowed sinc, 5 kHz transition) - what the SDR would be sent."""

    def __init__(self, taps=161):
        n = np.arange(taps) - (taps - 1) / 2.0
        fc = 50000.0 / (2 * FS)                          # 50 kHz at 200 kHz
        h = 2 * fc * np.sinc(2 * fc * n) * np.blackman(taps)
        self.h = (h / h.sum() * 2.0).astype(np.float32)  # gain 2: the repeat halves the level
        self.hist = np.zeros(taps - 1, np.complex64)

    def process(self, x):
        y = np.repeat(np.asarray(x, np.complex64), 2) * 0.5
        buf = np.concatenate((self.hist, y))
        out = np.convolve(buf, self.h, mode="valid")
        self.hist = buf[-(len(self.h) - 1):]
        return out.astype(np.complex64)


def clamp_f(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def byte_to_level(b):
    return (b.astype(np.float32) - 127.5) / 127.5


def level_to_byte(x):
    return np.clip(np.round(x * 127.5 + 127.5), 0, 255).astype(np.uint8)


# ----------------------------------------------------------------------- pilot sync schemes
# What the pilots carry for synchronisation.  All three have the same average pilot power.
#   std   your GNU Radio / Gambas sync: every pilot carries two slow sines, one on I and one on Q
#         (Sync_control: the 80-symbol table and the 120-symbol table, 90 / 120 in 180x96; every
#         other Mux swaps I and Q).  The pattern repeats every 240 (360) symbols.
#   hxdx  as HxDX 1.4: a steady carrier plus a +-1 chip per symbol in quadrature (constant size),
#         from a 120-chip sequence: one frame.
#   lab   "PN": +-1 per symbol (a 120-chip PN sequence), as the lab had it.
SYNC_SCHEMES = collections.OrderedDict([("std", "Std"), ("hxdx", "HxDX"), ("lab", "PN")])
SYNC_POWER = {"std": 1, "hxdx": 4, "lab": 2}     # power that wipes the pilot values off (acquisition)


def _balanced_chips(n, seed):
    rng = np.random.RandomState(seed)
    best, bs = None, 1e9
    for _ in range(300):
        x = np.array([1.0] * (n // 2) + [-1.0] * (n - n // 2))
        rng.shuffle(x)
        c = np.real(np.fft.ifft(np.abs(np.fft.fft(x)) ** 2))[1:]
        if np.max(np.abs(c)) < bs:
            best, bs = x, np.max(np.abs(c))
    return best


def pilot_table(mode, sync):
    """The pilot values over one period of the sync pattern: (period, pilots) complex."""
    cache = mode.__dict__.setdefault("_ptab", {})
    if sync in cache:
        return cache[sync]
    S, npl = mode.syms, len(mode.pilot_bins)
    if sync == "std":
        p1, p2 = (90, 120) if mode.w == 180 else (80, 120)
        Lp = p1 * p2 // math.gcd(p1, p2)
        n = np.arange(Lp)
        a, b = np.sin(2 * np.pi * n / p1), np.sin(2 * np.pi * n / p2)
        T = np.empty((Lp, npl), complex)
        for j in range(npl):
            T[:, j] = PILOT_AMP * ((a + 1j * b) if j % 2 == 0 else (b + 1j * a))
    elif sync == "hxdx":
        x = _balanced_chips(S, 4242 + mode.w)
        v = PILOT_AMP * ((1 - 1j) + (1 + 1j) * x) / 2.0
        T = np.outer(v, mode.pilot_sign)
    else:
        T = PILOT_AMP * np.outer(mode.pn, mode.pilot_sign)
    cache[sync] = T
    return T


# ----------------------------------------------------------------------- mode word (Auto)
# 16 bits that tell the receiver how the transmitter is set, sent every data frame on the pilots
# of a few symbols spread over the frame (each pilot there turned +-1 by the word's chips) - the data
# carriers, and so the lines and their cut points, are not touched.  CRC-8 makes 24 bits.
WORD_ENCS = (KWD, KMDW, KMMW, 4, 5, 6, 7, KWL)   # (5.47: codes 1, 2 were modes 6, 5 KWMD-SC, -MC)        # 120x96 modes (internal numbers), 180x96 KMD (6), KMM (7)
#                         (code 2 was the old M KMM: mode 5, KWMD-MC, from 5.33; code 1 the old H KMM: mode 6, L KMM-MS, 5.34)
WORD_COMP = ("Off", "Syllabic")
WORD_BITS = 24
# Always the same, so not sent: interleave on, emphasis 75 us, colour BT.601, the 240x192 detail as DCT.
WORD_FIXED = dict(interleave=True, colour_coding="BT.601", emph="75 us", detail="dct")


WORD_SPARE = 0b000000000000                     # no spare bits left  (4-5: the spreading, 5.25;
                                                 #  10: I/Q flip, picture by line pair and sound by symbol, 5.28/5.29;
                                                 #  7-8 = 3: dual mono, 11: common mode (both channels the same), 5.29;
                                                 #  9: tone injection - values to be folded, 5.27)


def word_pack(enc, compander="Off", scrambled=True, ms_split="Auto", spread="Off", fold=False, iqflip=False,
              audio_mode="Stereo", common=False):
    """The settings page (5.11): bits 0-2 the encoder mode, 3 the compander (Syllabic), 6 the data
    carriers' phases scrambled, 7-8 the sum/difference split (MS_SPLITS); 4, 5 and 9-11 spare (0) -
    16 bit sound (was bit 4) and sound as sum and difference (was bit 5) are always so now.
    12-15 page 1."""
    enc = WIDE if int(enc) == KMDE else enc
    e = WORD_ENCS.index(int(enc)) if int(enc) in WORD_ENCS else WORD_ENCS.index(4)
    sp = MS_SPLITS.index(ms_split) if ms_split in MS_SPLITS else 0
    if audio_mode == "Dual mono":                 # (the split's fourth value: dual mono)
        sp = 3
    sd = SPREADS.index(spread) if spread in SPREADS else 0
    return (e | (int(compander == "Syllabic") << 3) | (sd << 4) | (int(bool(scrambled)) << 6) | (sp << 7) |
            (int(bool(fold)) << 9) | (int(bool(iqflip)) << 10) |
            (int(bool(common) and audio_mode == "Dual mono") << 11) | (1 << 12))


# Pages (bits 12-15 of the word), 12 bits of data each:
#   1       the mode settings (as it always was)
#   2-5     the callsign, two characters each (8)
#   6       the time: UTC minute of the day (0-1439)
#   9       the date: day of the year (1-366) and the year's last 3 bits
#   7, 8    the Maidenhead locator: 6 characters in 24 bits (or 4)
#   10-15   the programme title, two characters each (12)
# The transmitter goes round 32 frames: the settings every other frame, and between them the pages
# that are on, in turn (repeated to fill the 16 places - a short list just comes round more often).
# Nothing extra goes on the air: the same 96 chips on the pilots every frame, whichever page it is.
CALL_CHARS = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-."
TITLE_CHARS = CALL_CHARS + "?!:,'&+()#_"
CALL_LEN = 8
TITLE_LEN = 12
CYCLE = 32
P_SET, P_CALL, P_TIME, P_GRID, P_DATE, P_TITLE = 1, 2, 6, 7, 9, 10
P_EXT = 0                                         # (5.49) more settings: modes 5, 6's detail split (bits 0-1);
P_EXT_MARK = 0xA                                  #  bits 8-11 this mark, 2-7 zero (an older receiver drops the page)


def word_pack_ext(ww_split):
    """Page 0: modes 5, 6's detail split (WW_SPLITS, by its place in the list)."""
    names = list(WW_SPLITS)
    i = names.index(ww_split) if ww_split in names else names.index("8+4+4")
    return (P_EXT_MARK << 8) | i | (P_EXT << 12)


def word_ext_split(d):
    """Page 0's 12 bits -> the split's name."""
    return list(WW_SPLITS)[d & 3]
_GRID6 = 18 * 16 * 100 * 576                      # 6 characters (latitude fields B-Q: 80 S to 80 N)


def _pack2(text, k, chars):
    c = [chars.index(ch) if ch in chars else 0 for ch in text[2 * k:2 * k + 2]]
    return c[0] | (c[1] << 6)


def word_pack_call(call, k):
    """Callsign page k (0-3): characters 2k and 2k+1, 6 bits each."""
    call = (str(call or "").upper() + " " * CALL_LEN)[:CALL_LEN]
    return _pack2(call, k, CALL_CHARS) | ((P_CALL + k) << 12)


def word_pack_title(title, k):
    """Title page k (0-5): characters 2k and 2k+1."""
    t = (str(title or "").upper() + " " * TITLE_LEN)[:TITLE_LEN]
    return _pack2(t, k, TITLE_CHARS) | ((P_TITLE + k) << 12)


def word_pack_time(t=None):
    """-> (time page, date page) for a UTC time (time.gmtime() form; now if None)."""
    g = time.gmtime() if t is None else t
    return (g.tm_hour * 60 + g.tm_min) | (P_TIME << 12), (g.tm_yday | ((g.tm_year & 7) << 9)) | (P_DATE << 12)


def grid_ok(loc):
    """A Maidenhead locator the word can carry (4 or 6 characters; not above 80 N / below 80 S)."""
    return grid_value(loc) is not None


def grid_value(loc):
    s = str(loc or "").strip().upper()
    if len(s) not in (4, 6):
        return None
    try:
        lo, la = ord(s[0]) - 65, ord(s[1]) - 65
        if not (0 <= lo < 18 and 1 <= la <= 16 and s[2].isdigit() and s[3].isdigit()):
            return None
        v4 = ((lo * 16 + la - 1) * 10 + int(s[2])) * 10 + int(s[3])
        if len(s) == 4:
            return _GRID6 + v4
        so, sa = ord(s[4]) - 65, ord(s[5]) - 65
        if not (0 <= so < 24 and 0 <= sa < 24):
            return None
        return (v4 * 24 + so) * 24 + sa
    except (ValueError, IndexError):
        return None


def grid_text(v):
    v = int(v)
    six = v < _GRID6
    if not six:
        v -= _GRID6
        if v >= 18 * 16 * 100:
            return None
        v4 = v
    else:
        sa, v = v % 24, v // 24
        so, v4 = v % 24, v // 24
    d3, v4 = v4 % 10, v4 // 10
    d2, v4 = v4 % 10, v4 // 10
    la, lo = v4 % 16 + 1, v4 // 16
    t = "%s%s%d%d" % (chr(65 + lo), chr(65 + la), d2, d3)
    return t + ("%s%s" % (chr(97 + so), chr(97 + sa)) if six else "")


def word_pack_grid(loc):
    """-> (page 7, page 8): the locator's 24 bits, top half first; None if it can't be sent."""
    v = grid_value(loc)
    if v is None:
        return None
    return ((v >> 12) & 0xFFF) | (P_GRID << 12), (v & 0xFFF) | ((P_GRID + 1) << 12)


def word_page(w):
    return (int(w) >> 12) & 15


def word_ok(w):
    """A word the CRC passed is one we know (each page's values checked, so noise that slips past
    the CRC is less likely to be taken)."""
    p = word_page(w)
    d = int(w) & 0xFFF
    if p == P_SET:
        return word_unpack(w) is not None
    if p == P_EXT:
        return (d >> 8) == P_EXT_MARK and (d & 0xFC) == 0 and (d & 3) < len(WW_SPLITS)
    if P_CALL <= p < P_CALL + 4:
        return (d & 63) < len(CALL_CHARS) and (d >> 6) < len(CALL_CHARS)
    if p == P_TIME:
        return d < 1440
    if p == P_DATE:
        return 1 <= (d & 511) <= 366
    if p == P_GRID:
        return d <= (1 << 24) // 4096 - 1
    if p == P_GRID + 1:
        return True
    if P_TITLE <= p < P_TITLE + 6:
        return (d & 63) < len(TITLE_CHARS) and (d >> 6) < len(TITLE_CHARS)
    return False


def tx_pages(call="", stamp=False, grid="", title="", t=None, ext=None):
    """The pages that are on, in the order they go round (page 0, if any, then the callsign)."""
    pages = [] if ext is None else [int(ext)]
    if str(call or "").strip():
        pages += [word_pack_call(call, k) for k in range(4)]
    if stamp:
        pages += list(word_pack_time(t))
    g = word_pack_grid(grid) if str(grid or "").strip() else None
    if g:
        pages += list(g)
    if str(title or "").strip():
        pages += [word_pack_title(title, k) for k in range(6)]
    return pages


def tx_word(seq, settings, call, stamp=False, grid="", title="", t=None, ext=None):
    """The word for data frame number seq: the settings every frame if nothing else is on, else
    the 32-frame round - the settings every other frame, the pages that are on in between."""
    pages = tx_pages(call, stamp, grid, title, t, ext)
    if not pages:
        return settings
    pos = seq % CYCLE
    return settings if pos % 2 == 0 else pages[(pos // 2) % len(pages)]


def word_unpack(w):
    w = int(w)
    e = w & 7
    if e >= len(WORD_ENCS) or (w >> 12) != 1 or (w & WORD_SPARE):    # (the spare bits must be 0)
        return None
    enc = WORD_ENCS[e]
    d = dict(enc=enc, fmt="180x96" if enc in (6, 7) else "120x96",
             compander="Syllabic" if (w >> 3) & 1 else "Off", audio16=True,
             stereo="Sum/diff", scrambled=bool((w >> 6) & 1),
             ms_split=MS_SPLITS[min((w >> 7) & 3, len(MS_SPLITS) - 1)])
    d["audio_mode"] = "Dual mono" if (w >> 7) & 3 == 3 else "Stereo"
    if d["audio_mode"] == "Dual mono":
        d["ms_split"] = "Auto"
    d["common"] = bool((w >> 11) & 1)
    sd = (w >> 4) & 3
    if sd >= len(SPREADS):
        return None
    d["spread"] = SPREADS[sd]
    d["fold"] = bool((w >> 9) & 1)
    d["iqflip"] = bool((w >> 10) & 1)
    d.update(WORD_FIXED)
    return d


def _crc8(bits):
    reg = 0
    for b in bits:
        fb = ((reg >> 7) & 1) ^ int(b)
        reg = ((reg << 1) & 0xFF) ^ (0x07 if fb else 0)
    return reg


def word_bits(w):
    """16 bit word -> 24 bits (word, then CRC-8), 0/1."""
    b = [(int(w) >> (15 - i)) & 1 for i in range(16)]
    c = _crc8(b)
    return np.array(b + [(c >> (7 - i)) & 1 for i in range(8)], np.int8)


def word_check(bits):
    """24 bits -> the 16 bit word if the CRC agrees, else None."""
    bits = [int(x) for x in bits]
    if _crc8(bits[:16]) != sum(bits[16 + i] << (7 - i) for i in range(8)):
        return None
    return sum(bits[i] << (15 - i) for i in range(16))


def word_layout(mode):
    """Where the word goes: W symbols spread over the frame (all their pilots), at least 96 chips
    (4 for each of the 24 bits).  -> (symbols, chip scrambler W x pilots, bit of each chip W x pilots)."""
    cache = mode.__dict__.setdefault("_wlay", None)
    if cache is not None:
        return cache
    npl = len(mode.pilot_bins)
    W = int(math.ceil(96.0 / npl))
    syms = np.array([int((j + 0.5) * mode.syms / W) for j in range(W)])
    rng = np.random.RandomState(9090 + npl)
    pn = np.where(rng.rand(W, npl) > 0.5, 1.0, -1.0)
    bit = (np.arange(W * npl).reshape(W, npl) * 7) % WORD_BITS     # spread each bit over symbols and pilots
    mode._wlay = (syms, pn, bit)
    return mode._wlay


def pilot_steady(mode, sync):
    """The part of each pilot that never changes (HxDX's steady carrier; nothing for the others).
    The mode word turns over only the rest, so the steady carrier stays steady."""
    T = pilot_table(mode, sync)
    return T.mean(axis=0) if sync == "hxdx" else np.zeros(T.shape[1], complex)


def word_chips(mode, w):
    """The +-1 each word pilot is turned by (W x pilots)."""
    syms, pn, bit = word_layout(mode)
    b = word_bits(w)
    return pn * (1.0 - 2.0 * b[bit])


class Modulator:
    """Data frame + audio bytes -> complex baseband at 100 kHz."""

    def __init__(self, mode, cp=0, interleave=False, sync="lab"):
        self.mode, self.cp, self.interleave = mode, int(cp), interleave
        self.sync = sync
        self.T = pilot_table(mode, sync)
        self.pat = 0                                       # where the sync pattern is
        self.scale = 3.6 / math.sqrt(len(mode.used) * 0.75)   # output RMS about 0.25
        self.clip_db = None                              # peak limit (dB over the RMS), None = off
        self.clip_iter = 3
        self.scramble = True                             # the data carriers' quarter turns (5.4 on)
        self.clip_shaped = True                          # (unscrambled: the clipping error steered)
        self.enc = None                                  # (the encoder mode: from the settings word)
        self.word = None                                   # the mode word to send (None: none)

    def video_matrix(self, frame):
        """Data frame -> (symbols x 288) bytes: column j carries bytes j*S .. j*S+S-1 (one picture row)."""
        m = self.mode
        f = frame
        if self.interleave:
            f = f[interleaver(m)]
        return f.reshape(self.mode.vbps, m.syms).T

    def modulate(self, frame, audio):
        m = self.mode
        S = m.syms
        X = np.zeros((S, self.mode.nfft), np.complex64)
        v = byte_to_level(self.video_matrix(frame))
        vc = v[:, 0::2] + 1j * v[:, 1::2]
        if getattr(self, "iqflip", False):                 # (I and Q the other way round on odd lines)
            vc = iq_swap(vc, iqflip_mask(m, self.interleave))
        X[:, m.video_bins] = spread_values(vc, m, getattr(self, "spread", "Off"))
        a = byte_to_level(audio.reshape(S, self.mode.abps))
        ac = a[:, 0::2] + 1j * a[:, 1::2]
        if getattr(self, "iqflip", False):                 # (and the sound's on odd symbols)
            ac = iq_swap(ac, iqflip_mask_audio(m))
        X[:, m.audio_bins] = ac
        X[:, m.pilot_bins] = self.T[(self.pat + np.arange(S)) % len(self.T)]
        if self.word is not None:                          # the mode word: some pilots turned over
            ws = word_layout(m)[0]
            st = pilot_steady(m, self.sync)
            Xw = X[np.ix_(ws, m.pilot_bins)]
            X[np.ix_(ws, m.pilot_bins)] = st + (Xw - st) * word_chips(m, self.word)
        self.pat = (self.pat + S) % len(self.T)
        if self.scramble:
            ph = scramble_phase(self.mode.nfft)
            X[:, m.video_bins] *= ph[m.video_bins]
            X[:, m.audio_bins] *= ph[m.audio_bins]
        self.ti_moves = 0
        if getattr(self, "ti", False) and self.scramble and getattr(self, "spread", "Off") == "Off":
            self.ti_moves = tone_inject(X, m)                # (the peaks: values moved a fold away)
        if self.clip_db is not None:
            self.clip_stats = {}
            if self.clip_shaped and getattr(self, "enc", None) is not None and not self.scramble \
                    and getattr(self, "spread", "Off") == "Off":
                tol = clip_tolerance(m, eff_enc(m, self.enc), self.interleave)
                X = papr_clip_shaped(X, m, self.clip_db, tol, stats=self.clip_stats)
            else:
                X = papr_clip(X, m, self.clip_db, self.clip_iter, stats=self.clip_stats)
        t = np.fft.ifft(np.fft.ifftshift(X, axes=1), axis=1) * math.sqrt(self.mode.nfft) * self.scale
        if self.cp:
            # (the symbol's end repeated before it; a guard longer than the symbol wraps round it again)
            t = t[:, np.arange(-self.cp, t.shape[1]) % t.shape[1]]
        return t.ravel().astype(np.complex64)


# ----------------------------------------------------------------------- I/Q flip by line (5.28)
# Every other picture line pair, a carrier's I and Q change places (PAL's idea, done on the I/Q pair): a phase
# error left after the equaliser leaks some of Q into I (and I into Q) - with the flip that leak changes
# sign from line to line, so instead of a steady shift it alternates and the eye (or a line average)
# takes it out.  A line is 120 or 180 bytes of the frame, by the format; the line a cell belongs to is
# that of the byte on its I (after the interleaver, as it is sent).  It changes nothing in plain noise -
# noise is the same on I as on Q - only what leaks between them.
_IQF = {}


def iqflip_mask(mode, interleave):
    """symbols x picture carriers: True where I and Q are sent the other way round."""
    key = (mode.name, mode.frame_bytes, len(mode.video_bins), bool(interleave))
    mk = _IQF.get(key)
    if mk is None:
        W = int(mode.w)                                           # (a picture line's bytes)
        pos = np.arange(mode.frame_bytes)
        orig = interleaver(mode)[pos] if interleave else pos       # (the frame byte at each place sent)
        idx = orig.reshape(mode.vbps, mode.syms).T                # symbols x (2 x carriers), as video_matrix
        mk = ((idx[:, 0::2] // (2 * W)) % 2).astype(bool)   # (by line pairs: a carrier's I and Q can carry
                                                             #  two neighbouring lines, as without the interleaver)
        _IQF[key] = mk
    return mk


def iqflip_mask_audio(mode):
    """symbols x sound carriers: True on odd symbols (sound has no lines; a symbol is its block)."""
    return np.repeat((np.arange(mode.syms) % 2).astype(bool)[:, None], len(mode.audio_bins), axis=1)


def iq_swap(v, mask):
    """I and Q exchanged where mask is set (its own inverse)."""
    return np.where(mask, v.imag + 1j * v.real, v)


# ----------------------------------------------------------------------- tone injection (5.27)
# Peaks taken down with nothing given up and nothing to tell the receiver each symbol: a picture or sound
# value may also be sent TI_STEP away (on its I or on its Q, up or down) - the receiver folds every value
# back modulo TI_STEP before it reads it, so it comes out the same.  For each symbol the sender looks at
# its highest peak and makes the one such move (of all the carriers' I's and Q's) that brings the symbol's
# peak down most - up to TI_MOVES of them.  Measured on encoded frames: the peaks ~1.35 dB lower at the
# same average power (PAPR ~7.8 against Scramble's 9.5 dB, for +0.4-0.5 dB of power on the moved values).
# The step is 3.0 (the values' range is -1..1): a full-scale value has 0.5 of room before noise could
# fold it to the far side - 0.02 % of the time at C/N 12 dB, never at 15 dB and up.  (Not with Spread:
# spread carriers aren't bounded by the values' square, so folding would break them.)
TI_STEP = 3.0
TI_MOVES = 4
_TI_CACHE = {}


def _ti_basis(mode):
    """Each picture / sound carrier's waveform (unit, its scramble turn on it), 4x oversampled."""
    key = (mode.nfft, len(mode.video_bins), len(mode.audio_bins), tuple(mode.pilot_bins[:2]))
    b = _TI_CACHE.get(key)
    if b is None:
        N = mode.nfft
        db = np.concatenate([np.asarray(mode.video_bins), np.asarray(mode.audio_bins)])
        ph = scramble_phase(N)
        E = np.zeros((len(db), N), np.complex64)
        E[np.arange(len(db)), db] = ph[db]
        b = (db, ph, _osamp(E))
        _TI_CACHE[key] = b
    return b


def _osamp(X, k=4):
    """Symbols' carriers (centred) -> their time signal, k x oversampled."""
    N = X.shape[1]
    Z = np.zeros((len(X), k * N), np.complex64)
    Xs = np.fft.ifftshift(X, axes=1)
    Z[:, :N // 2] = Xs[:, :N // 2]
    Z[:, -(N - N // 2):] = Xs[:, N // 2:]
    return np.fft.ifft(Z, axis=1).astype(np.complex64)


def tone_inject(X, mode, moves=TI_MOVES, step=TI_STEP):
    """X: symbols x carriers, scrambled (as sent): the moves made in place -> how many were made."""
    db, ph, B = _ti_basis(mode)
    M = np.concatenate([B, 1j * B, -B, -1j * B]) * step                 # 4 x carriers candidate moves
    turn = np.array([1, 1j, -1, -1j], np.complex64) * step
    x_all = _osamp(X)
    made = 0
    for s in range(len(X)):
        x = x_all[s]
        top = float(np.max(np.abs(x)))
        for _ in range(moves):
            n = int(np.argmax(np.abs(x)))
            cand = np.argsort(np.abs(x[n] + M[:, n]))[:12]
            pk = np.max(np.abs(x[None, :] + M[cand]), axis=1)
            j = int(np.argmin(pk))
            if pk[j] >= top * 0.995:
                break
            c = int(cand[j])
            x = x + M[c]
            top = float(pk[j])
            k, q = c % len(db), c // len(db)
            X[s, db[k]] += ph[db[k]] * turn[q]
            made += 1
    return made


def ti_fold(v, step=TI_STEP):
    """The receiver's side: a value moved by +-step (or noise far past full scale) folded back."""
    h = step / 2.0
    return ((v + h) % step) - h


# ----------------------------------------------------------------------- spreading across carriers (5.25)
# Each symbol's picture values, in groups of carriers next to each other (one group to a pilot group:
# 8 for 200 carriers, 16 for 400 - about 25 each - or the whole band as one), are each turned a fixed
# quarter turn and then DFT-spread across their group: every value rides on all the group's carriers.
# A fade, or one bad carrier, is then shared by the group's values as a little noise rather than wiping
# a few of them out (fewer wavelet blocks and hue errors), and spread over the whole band the signal
# starts to behave as one carrier (its peaks ~2 dB lower).  Nothing else changes: the pilots, the sound
# carriers, the codec.  (The quarter turns keep a picture's average, which is not mid grey, from all
# landing on one carrier of each group.)  The receiver equalises the picture carriers MMSE (a carrier in
# a fade is not boosted into its whole group), despreads, and takes off what MMSE leaves (the bias).
SPREADS = ("Off", "Groups", "Whole band", "Hadamard")
# (5.42) Hadamard: real Walsh-Hadamard codes of HAD_N, each group's carriers taken spread right across
# the band (every G-th picture carrier) - I and Q stay apart, and a group's carriers fade on their own;
# random +-1 signs keep a picture's average off one carrier.  Any carriers left over go unspread.
HAD_N = 16
_SPREAD_CACHE = {}


def spread_groups(mode, spread):
    """-> list of (positions in the symbol's video bins (frequency order), quarter turns) for the groups."""
    key = (mode.nfft, len(mode.video_bins), tuple(mode.pilot_bins[:2]), spread)
    g = _SPREAD_CACHE.get(key)
    if g is not None:
        return g
    vb = np.asarray(mode.video_bins)
    order = np.argsort(vb)                         # (by frequency)
    if spread == "Hadamard":
        G = len(order) // HAD_N
        rs = np.random.RandomState(0x4AD + mode.nfft)
        g = [(order[i:G * HAD_N:G], rs.choice([-1.0, 1.0], HAD_N).astype(np.float32)) for i in range(G)]
        _SPREAD_CACHE[key] = g
        return g
    if spread == "Whole band":
        parts = [order]
    else:
        G = max(1, int(round(mode.nfft / 25.0)))   # 8 for 200 carriers, 16 for 400
        parts = [p for p in np.array_split(order, G) if len(p)]
    rs = np.random.RandomState(0x5D + mode.nfft)
    g = [(p, (1j ** rs.randint(0, 4, len(p))).astype(np.complex64)) for p in parts]
    _SPREAD_CACHE[key] = g
    return g


def _had(n):
    H = np.array([[1.0]], np.float32)
    while H.shape[0] < n:
        H = np.block([[H, H], [H, -H]])
    return H / math.sqrt(n)


def spread_values(V, mode, spread):
    """Picture values (symbols x video bins) -> what goes on the carriers."""
    if spread not in ("Groups", "Whole band", "Hadamard"):
        return V
    if spread == "Hadamard":
        out = V.copy()
        H = _had(HAD_N)
        for p, q in spread_groups(mode, spread):
            out[:, p] = (V[:, p] * q[None, :]) @ H.T
        return out
    out = np.empty_like(V)
    for p, q in spread_groups(mode, spread):
        out[:, p] = np.fft.fft(V[:, p] * q[None, :], axis=1, norm="ortho")
    return out


def despread_values(Z, mode, spread, bias=None):
    """The equalised picture carriers -> the values; bias: (symbols x video bins) the MMSE gain
    |H|^2 / (|H|^2 + n) to take off, group by group."""
    if spread not in ("Groups", "Whole band", "Hadamard"):
        return Z
    if spread == "Hadamard":
        out = Z.copy()
        H = _had(HAD_N)
        for p, q in spread_groups(mode, spread):
            d = (Z[:, p] @ H) * q[None, :]
            if bias is not None:
                d = d / np.maximum(bias[:, p].mean(axis=1, keepdims=True), 0.05)
            out[:, p] = d
        return out
    out = np.empty_like(Z)
    for p, q in spread_groups(mode, spread):
        d = np.fft.ifft(Z[:, p], axis=1, norm="ortho") * np.conj(q)[None, :]
        if bias is not None:
            d = d / np.maximum(bias[:, p].mean(axis=1, keepdims=True), 0.05)
        out[:, p] = d
    return out


# ----------------------------------------------------------------------- carrier scrambling
# The pictures' bytes don't average mid scale (a typical frame sits near 105, not 127.5), so every data
# carrier carries a little of the same value, all in step: once a symbol they add up into one tall
# peak - the PAPR of real pictures was 12-14 dB against 9.6 for random bytes.  Each data carrier's
# value is turned by a fixed quarter turn (0, 90, 180 or 270 degrees: I and Q swapped and/or negated,
# nothing rounded) from a fixed sequence, and turned back at the receiver.  That common part no longer
# adds up: the peaks come down to random data's 9.6 dB, with nothing done to the values themselves.
SCRAMBLE_SEED = 0x5C4A


def scramble_phase(nfft):
    """The quarter turns for each bin of an nfft-point symbol (shifted order, as the modulator builds
    it): complex values 1, j, -1, -j.  Pilots and empty bins are left alone by the users of this."""
    q = np.random.RandomState(SCRAMBLE_SEED + int(nfft)).randint(0, 4, int(nfft))
    return (1j ** q).astype(np.complex64)


# ----------------------------------------------------------------------- peak limiting (PAPR)
# OFDM's peaks run about 11 dB over its average (9.7 dB one sample in 10,000), so the transmitter
# must run that far below its peak rating.  Clipping the peaks and filtering what that splashes back
# into the band (repeated: the filtering lets the peaks grow back a little) lets the average go up
# for the same peak.  Done per symbol at 2x oversampling (so the peaks between samples - what the
# DAC makes - are seen too); the clipping noise is kept to the data carriers: the pilots (sync, the
# channel estimate, the mode word) are put back exactly each time, the empty bins kept empty, and
# the data carriers scaled back up by what the clipping took off them (Bussgang), so the received
# levels - brightness, colour, sound - stay right.  The noise it leaves is analogue noise like any
# other: a little everywhere, no cliff.
CLIP_LEVELS = ("Off", "9 dB", "7 dB", "6 dB", "5 dB", "4 dB")


# Peak limiting with the error steered (5.12): how far each kind of byte may be moved (byte steps, either
# way).  The colour (errors show as hue shifts) and the DCT / wavelet detail (errors show as blocks)
# barely; the luma levels and the sound take the rest (errors there are fine grain, like noise).
CLIP_TOL = {"colour": 1.0, "detail": 1.0, "diff": 3.0, "levels": 24.0, "audio": 24.0}
_CLIP_TOLS = {}


def clip_tolerance(mode, enc, interleave=True):
    """(I, Q) tolerances (as levels: byte steps / 127.5) of the video carriers (symbols x carriers) for
    this encoder mode, through the interleaver, as the modulator lays the bytes out."""
    key = (mode.name, mode.nfft, len(mode.video_bins), int(enc), bool(interleave), tuple(sorted(CLIP_TOL.items())), WW_SPLIT)
    if key not in _CLIP_TOLS:
        t = np.full(mode.frame_bytes, CLIP_TOL["levels"], np.float32)
        k = 0
        lay = frame_layout(mode, enc, "dct")
        per = mode.frame_bytes // sum(c for _, c, _ in lay)          # bytes per column
        for name, cols, what in lay:
            n = cols * per
            if "R-Y" in name or "B-Y" in name:
                t[k:k + n] = CLIP_TOL["colour"]
            elif "Detail" in name or "Wavelet" in name or "nibble" in what or "bits" in what:
                t[k:k + n] = CLIP_TOL["detail"]
            elif ("+" in name and "-" in name) or name.startswith("Diff "):   # sums and differences (mode 7's too)
                t[k:k + n] = CLIP_TOL["diff"]
            k += n
        if interleave:
            t = t[interleaver(mode)]
        v = t.reshape(mode.vbps, mode.syms).T / 127.5
        _CLIP_TOLS[key] = (v[:, 0::2], v[:, 1::2])
    return _CLIP_TOLS[key]


def papr_clip_shaped(X, mode, clip_db, tol, iters=8, os=2, stats=None):
    """Clipping with the error steered: after each clip and filter, every data value is put back to
    within its tolerance of what it was (the pilots exactly, the empty bins empty).  What the peaks
    lose comes from the values that can spare it; the clip level is reached as nearly as they allow."""
    S, N = X.shape
    Nos = N * os
    lo = Nos // 2 - N // 2
    X0 = np.asarray(X, np.complex128)
    Xc = X0.copy()
    vb, ab = mode.video_bins, mode.audio_bins
    tI, tQ = tol
    ta = CLIP_TOL["audio"] / 127.5
    lim = None
    for it in range(int(iters)):
        F = np.zeros((S, Nos), complex)
        F[:, lo:lo + N] = Xc
        t = np.fft.ifft(np.fft.ifftshift(F, axes=1), axis=1)
        a = np.abs(t)
        if lim is None:
            if stats is not None:
                stats["papr_in"] = papr_db(t)
            lim = math.sqrt(float(np.mean(a ** 2))) * 10 ** (clip_db / 20.0)
        t = np.where(a > lim, t * (lim / np.maximum(a, 1e-12)), t)
        Fn = np.fft.fftshift(np.fft.fft(t, axis=1), axes=1)[:, lo:lo + N]
        Xc = np.zeros_like(Fn)
        d = Fn[:, vb] - X0[:, vb]
        Xc[:, vb] = X0[:, vb] + np.clip(d.real, -tI, tI) + 1j * np.clip(d.imag, -tQ, tQ)
        d = Fn[:, ab] - X0[:, ab]
        Xc[:, ab] = X0[:, ab] + np.clip(d.real, -ta, ta) + 1j * np.clip(d.imag, -ta, ta)
        Xc[:, mode.pilot_bins] = X0[:, mode.pilot_bins]
    if stats is not None:
        F = np.zeros((S, Nos), complex)
        F[:, lo:lo + N] = Xc
        stats["papr"] = papr_db(np.fft.ifft(np.fft.ifftshift(F, axes=1), axis=1))
    return Xc.astype(np.complex64)


def papr_clip(X, mode, clip_db, iters=3, os=2, stats=None):
    """X: symbols x nfft (shifted order, as Modulator builds it) -> the same, its peaks limited to
    clip_db over the frame's RMS (at os x oversampling)."""
    S, N = X.shape
    Nos = N * os
    lo = Nos // 2 - N // 2                              # where bin 0 of the shifted N goes (DC to DC)
    data = np.concatenate((mode.video_bins, mode.audio_bins))
    keep = np.zeros(N, bool)
    keep[mode.used] = True
    X0 = np.asarray(X, np.complex128)
    Xc = X0.copy()
    for it in range(int(iters)):
        F = np.zeros((S, Nos), complex)
        F[:, lo:lo + N] = Xc
        t = np.fft.ifft(np.fft.ifftshift(F, axes=1), axis=1)
        a = np.abs(t)
        if it == 0 and stats is not None:               # the PAPR as it would have been (2x, as the DAC)
            stats["papr_in"] = papr_db(t)
        lim = math.sqrt(float(np.mean(a ** 2))) * 10 ** (clip_db / 20.0)
        t = np.where(a > lim, t * (lim / np.maximum(a, 1e-12)), t)
        F = np.fft.fftshift(np.fft.fft(t, axis=1), axes=1)
        Xc = F[:, lo:lo + N].copy()
        Xc[:, ~keep] = 0.0                               # out of the used carriers: filtered away
        Xc[:, mode.pilot_bins] = X0[:, mode.pilot_bins]  # the pilots exactly as they were
    # Bussgang: the clipping scales the data by alpha and adds noise uncorrelated with it - undo alpha
    d0, dc = X0[:, data], Xc[:, data]
    alpha = float(np.real(np.vdot(d0, dc)) / max(float(np.real(np.vdot(d0, d0))), 1e-12))
    Xc[:, data] = dc / max(alpha, 0.5)
    return Xc.astype(np.complex64)


PAPR_PLAIN = 9.6          # dB: the unclipped signal's PAPR (one sample in 10,000), every layout 9.5-9.7


def clip_value(name):
    """'6 dB' -> 6.0, 'Off' -> None."""
    try:
        return float(str(name).split()[0])
    except (ValueError, IndexError):
        return None


_CLIP_GAIN = {}


def clip_gain(mode, clip_db):
    """dB more average power at the same peak with this clip level (measured once per layout)."""
    key = (mode.name, mode.nfft, mode.halves, len(mode.pilot_bins), float(clip_db))
    if key not in _CLIP_GAIN:
        rng = np.random.RandomState(7)
        f = rng.randint(0, 256, mode.frame_bytes).astype(np.uint8)
        a = rng.randint(40, 216, mode.syms * mode.abps).astype(np.uint8)
        out = []
        for cl in (None, clip_db):
            m = Modulator(mode)
            m.clip_db = cl
            out.append(papr_db(Upsampler().process(np.concatenate([m.modulate(f, a) for _ in range(3)]))[200:]))
        _CLIP_GAIN[key] = max(0.0, out[0] - out[1])
    return _CLIP_GAIN[key]


def papr_db(x, p=1e-4):
    """Peak to average power (dB) of a signal: the level exceeded by a fraction p of its samples."""
    a = np.abs(np.asarray(x)) ** 2
    return 10 * math.log10(float(np.quantile(a, 1 - p)) / float(np.mean(a)))


_ILV = {}


def interleaver(mode):
    """A fixed pseudo random order of the frame bytes (spreads a bad carrier over the picture)."""
    key = (mode.name, mode.frame_bytes)
    if key not in _ILV:
        _ILV[key] = np.random.RandomState(1234).permutation(mode.frame_bytes)
    return _ILV[key]


# Fading profiles: (delay in samples at 100 kHz = 10 us each, mean power dB, Rice K factor (0 = Rayleigh)).
# Each path fades on its own with the Doppler spread set by the Doppler control.
RAMP_SIGN = -1.0
FRAC_TRACK_Q = 0.97                     # timing quality above which a fraction of a sample is followed
GUARD_BACKOFF = 8                       # samples the window sits back into the guard with no echo (<= cp/8)
FADING = collections.OrderedDict([
    ("Off", []),
    ("Flat Rayleigh", [(0, 0.0, 0.0)]),
    ("Rician K 6 dB (line of sight)", [(0, 0.0, 4.0)]),
    ("Two-path 30 us", [(0, 0.0, 0.0), (3, -3.0, 0.0)]),
    ("Hilly terrain (COST207 HT)", [(0, 0.0, 0.0), (0, -1.5, 0.0), (0, -4.5, 0.0), (1, -7.5, 0.0),
                                    (2, -8.0, 0.0), (2, -17.7, 0.0)]),
    ("HF good (0.5 ms, Watterson)", [(0, 0.0, 0.0), (50, 0.0, 0.0)]),
    ("HF moderate (1 ms, Watterson)", [(0, 0.0, 0.0), (100, 0.0, 0.0)]),
])


class Fader:
    """Time-varying multipath: every path a sum-of-sinusoids Rayleigh (or Rice) process."""

    M = 16

    def __init__(self, profile, seed=5):
        self.taps = FADING.get(profile, [])
        rng = np.random.RandomState(seed)
        p = np.array([10 ** (db / 10.0) for _, db, _ in self.taps]) if self.taps else np.zeros(0)
        self.amp = np.sqrt(p / p.sum()) if len(p) else p
        self.alpha = rng.uniform(0, 2 * np.pi, (len(self.taps), self.M))
        self.phi = rng.uniform(0, 2 * np.pi, (len(self.taps), self.M))
        self.los = rng.uniform(0, 2 * np.pi, len(self.taps))
        self.dmax = max([d for d, _, _ in self.taps] or [0])
        self.hist = np.zeros(self.dmax, np.complex64)
        self.n = 0

    def gains(self, n, doppler):
        t = (self.n + np.arange(n)) / float(FS)
        G = np.zeros((len(self.taps), n), np.complex64)
        for k, (d, db, K) in enumerate(self.taps):
            w = 2 * np.pi * doppler * np.cos(self.alpha[k])[:, None]
            g = np.exp(1j * (w * t[None, :] + self.phi[k][:, None])).sum(axis=0) / np.sqrt(self.M)
            if K > 0:
                g = np.sqrt(1.0 / (K + 1)) * g + np.sqrt(K / (K + 1.0)) * np.exp(1j * (2 * np.pi * doppler * 0.7 * t + self.los[k]))
            G[k] = self.amp[k] * g
        return G

    def process(self, x, doppler):
        if not self.taps:
            return x
        n = len(x)
        buf = np.concatenate((self.hist, x))
        G = self.gains(n, doppler)
        y = np.zeros(n, np.complex64)
        for k, (d, _, _) in enumerate(self.taps):
            y += G[k] * buf[self.dmax - d:self.dmax - d + n]
        self.hist = buf[len(buf) - self.dmax:] if self.dmax else self.hist
        self.n += n
        self.last_gain = np.abs(G.sum(axis=0))       # flat-band gain now (for the display)
        return y


class Channel:
    """The loop back path: echo, delay, multipath fading, sample clock offset, frequency offset,
    phase noise, I/Q imbalance, DC offset, noise and impulse noise."""

    def __init__(self):
        self.snr_db = 40.0
        self.noise_on = True
        self.cfo_hz = 0.0
        self.delay = 0
        self.echo_delay = 0
        self.echo_db = -60.0
        self.ppm = 0.0
        self.phase = 0.0
        self.hist = np.zeros(0, np.complex64)
        self.rs_buf = np.zeros(16, np.complex64)
        self.pos = 16.0
        self.rng = np.random.RandomState(1)
        # real-world impairments
        self.fade = "Off"
        self.doppler = 1.0                       # Hz
        self.fader = Fader("Off")
        self.imp_rate = 0.0                      # impulses a second
        self.imp_db = 10.0                       # impulse peak above the signal's mean power
        self.pn_hz = 0.0                         # phase noise: Wiener process, this 3 dB linewidth
        self.pn_phase = 0.0
        self.iq_gain_db = 0.0                    # receiver I/Q imbalance
        self.iq_phase_deg = 0.0
        self.dc_db = -60.0                       # DC offset below the signal's mean power (-60 = off)
        self.p_avg = None
        self.fade_gain = 1.0
        # the receiver's front end (after the antenna): slow fading of the whole signal (QSB), the level
        # at the receiver, its gain (fixed, or an RF AGC ahead of the converter) and an 8-bit converter
        self.qsb_db = 0.0                        # QSB depth (dB either side)
        self.qsb_hz = 0.2                        # QSB rate
        self.rf_db = 0.0                         # level at the receiver against nominal (-12 dBFS at 0 dB gain)
        self.rx_agc = "Fixed"                    # "Fixed" or "AGC"
        self.rx_gain_db = 0.0                    # the fixed gain
        self.adc_bits = 0                        # 0 = no converter model; 8 = HackRF
        self.agc_db = 0.0                        # the AGC's gain now
        self.t_n = 0                             # samples so far (for the QSB)
        self.adc_rms_dbfs = -12.0
        self.adc_clip = 0.0

    AGC_TARGET = 0.25                            # RMS (complex) the AGC holds at the converter: -12 dBFS

    def front_end(self, y):
        """Receiver input level, gain (fixed or AGC) and the converter (clipping, 8-bit steps)."""
        n = len(y)
        if not n:
            return y
        y = y * np.complex64(10 ** (self.rf_db / 20.0))
        if self.rx_agc == "AGC":
            # a power-measuring AGC ahead of the converter, block by block (1 ms): quick down when the
            # signal rises (attack ~2 ms), slowly up when it falls (release ~150 ms), as a radio's
            B = 100
            out = np.empty_like(y)
            if not getattr(self, "agc_on", False):        # switched on: start at the right gain
                self.agc_on = True
                p0 = float(np.mean(np.abs(y[:2000]) ** 2)) + 1e-12
                self.agc_db = min(60.0, max(-30.0, 20 * math.log10(self.AGC_TARGET / math.sqrt(p0))))
            g = self.agc_db
            for s0 in range(0, n, B):
                blk = y[s0:s0 + B]
                out[s0:s0 + B] = blk * np.float32(10 ** (g / 20.0))
                p = float(np.mean(np.abs(blk) ** 2)) + 1e-12
                want = 20 * math.log10(self.AGC_TARGET / math.sqrt(p))
                e = want - g
                g += e * (0.5 if e < 0 else 0.007)
                g = min(60.0, max(-30.0, g))
            self.agc_db = g
            y = out
        else:
            self.agc_on = False
            self.agc_db = self.rx_gain_db
            y = y * np.float32(10 ** (self.rx_gain_db / 20.0))
        self.adc_rms_dbfs = 10 * math.log10(float(np.mean(np.abs(y) ** 2)) / 2.0 + 1e-12)   # per I or Q
        if self.adc_bits:
            q = float(2 ** (self.adc_bits - 1) - 1)
            i = np.clip(np.round(y.real * q), -q - 1, q)
            k = np.clip(np.round(y.imag * q), -q - 1, q)
            self.adc_clip = float(np.mean((np.abs(i) >= q) | (np.abs(k) >= q)))
            y = ((i + 1j * k) / q).astype(np.complex64)
        else:
            self.adc_clip = 0.0
        return y

    def set_fading(self, profile):
        if profile != self.fade:
            self.fade = profile
            self.fader = Fader(profile)

    def process(self, x):
        x = np.asarray(x, np.complex64)
        p_sig = float(np.mean(np.abs(x) ** 2)) if len(x) else 0.0
        # delay and echo (one tap)
        need = max(self.delay, self.delay + self.echo_delay) + 1
        buf = np.concatenate((self.hist, x))
        if len(self.hist) < need:
            buf = np.concatenate((np.zeros(need - len(self.hist), np.complex64), buf))
        n = len(x)
        start = len(buf) - n
        y = buf[start - self.delay:start - self.delay + n].copy()
        if self.echo_delay > 0 and self.echo_db > -59:
            e = 10 ** (self.echo_db / 20.0)
            d = self.delay + self.echo_delay
            y += e * buf[start - d:start - d + n]
        self.hist = buf[-need:]
        # multipath fading (the propagation)
        if self.fader.taps:
            y = self.fader.process(y, self.doppler).astype(np.complex64)
            self.fade_gain = float(np.mean(self.fader.last_gain))
        else:
            self.fade_gain = 1.0
        # sample clock offset: resample by (1 + ppm) with a 16 tap windowed sinc (clean to the band edges)
        if abs(self.ppm) > 0.01:
            r = 1.0 + self.ppm * 1e-6
            buf = np.concatenate((self.rs_buf, y))
            last = len(buf) - 17                         # the newest position with 16 samples after it
            cnt = int(math.floor((last - self.pos) / r)) + 1 if last >= self.pos else 0
            pos = self.pos + np.arange(cnt) * r
            i = np.floor(pos).astype(np.int64)
            f = pos - i
            k = np.arange(-15, 17)
            t = k[None, :] - f[:, None]
            w = np.sinc(t) * np.i0(8.0 * np.sqrt(np.clip(1 - (t / 16.5) ** 2, 0, 1))) / np.i0(8.0)
            w /= w.sum(axis=1, keepdims=True)
            y = np.sum(buf[i[:, None] + k[None, :]] * w, axis=1).astype(np.complex64)
            nxt = self.pos + cnt * r
            cut = max(0, int(math.floor(nxt)) - 16)
            self.rs_buf = buf[cut:]
            self.pos = nxt - cut
        # frequency offset
        if self.cfo_hz:
            ph = self.phase + 2 * math.pi * self.cfo_hz / FS * np.arange(len(y))
            y = y * np.exp(1j * ph).astype(np.complex64)
            self.phase = float((ph[-1] + 2 * math.pi * self.cfo_hz / FS) % (2 * math.pi)) if len(y) else self.phase
        n = len(y)
        # phase noise (receiver oscillator): a random walk, linewidth pn_hz
        if self.pn_hz > 0 and n:
            st = math.sqrt(2 * math.pi * self.pn_hz / FS)
            ph = self.pn_phase + np.cumsum(self.rng.randn(n) * st)
            y = y * np.exp(1j * ph).astype(np.complex64)
            self.pn_phase = float(ph[-1] % (2 * math.pi))
        # I/Q imbalance (receiver): Q gain and a phase error between the I and Q mixers
        if (abs(self.iq_gain_db) > 1e-3 or abs(self.iq_phase_deg) > 1e-3) and n:
            a = 10 ** (self.iq_gain_db / 20.0)
            ph = math.radians(self.iq_phase_deg)
            i, q = y.real, y.imag
            y = (i + 1j * a * (q * math.cos(ph) - i * math.sin(ph))).astype(np.complex64)
        # QSB: the whole signal slowly up and down (the noise stays: the SNR goes with it)
        if self.qsb_db > 0 and n:
            t = (self.t_n + np.arange(n)) / float(FS)
            y = y * (10 ** (self.qsb_db / 20.0 * np.sin(2 * math.pi * self.qsb_hz * t))).astype(np.float32)
        self.t_n += n
        # the reference level for DC and impulses: the signal's mean power (before fading)
        if p_sig > 0:
            self.p_avg = p_sig if self.p_avg is None else 0.9 * self.p_avg + 0.1 * p_sig
        pa = self.p_avg or 0.0
        # DC offset (LO leakage / converter offset)
        if self.dc_db > -59.5 and n:
            y = y + np.complex64(math.sqrt(pa) * 10 ** (self.dc_db / 20.0) * np.exp(1j * 0.7))
        # noise: SNR over the whole 100 kHz (= per carrier, all bins are carriers)
        p_ref = p_sig if p_sig > 0 else pa              # (transmitter off: the noise stays as it was)
        if self.noise_on and p_ref > 0:
            sig = math.sqrt(p_ref / (10 ** (self.snr_db / 10.0)) / 2.0)
            y = y + (self.rng.randn(n) + 1j * self.rng.randn(n)).astype(np.complex64) * sig
        # impulse noise (ignition, switching): bursts of about 100 us, Poisson in time
        if self.imp_rate > 0 and n and pa > 0:
            k = self.rng.poisson(self.imp_rate * n / float(FS))
            L = 10
            env = np.exp(-np.arange(L) / 3.0)
            amp = math.sqrt(pa) * 10 ** (self.imp_db / 20.0)
            for at in self.rng.randint(0, max(1, n - L), k):
                y[at:at + L] += (amp * env * (self.rng.randn(L) + 1j * self.rng.randn(L)) / math.sqrt(2)).astype(np.complex64)
        return self.front_end(y.astype(np.complex64))


def apply_front_end(ch, c):
    """The receiver front end settings from the lab's settings."""
    ch.qsb_db, ch.qsb_hz = float(c.get("qsb_db", 0.0)), float(c.get("qsb_hz", 0.2))
    ch.rf_db = float(c.get("rf_db", 0.0))
    ch.rx_agc = c.get("rx_agc", "Fixed")
    ch.rx_gain_db = float(c.get("rx_gain", 0.0))
    ch.adc_bits = 8 if int(c.get("adc", 0)) else 0


def _pilot_gcd(mode):
    """The common factor of the pilots' spacings (1: no look-alike timings within the symbol)."""
    g = 0
    pb = [int(b) for b in mode.pilot_bins]
    for b in pb[1:]:
        g = math.gcd(g, b - pb[0])
    return max(g, 1)


class Demodulator:
    """Complex baseband -> data frames.  Finds the symbol timing (no guard interval needed: the timing
    that keeps the pilots clean), the frequency offset, the frame start (the pilots' +-1 sequence) and
    equalises every carrier from the pilots."""

    def __init__(self, mode, cp=0, interleave=False, sync="lab"):
        self.mode, self.cp, self.interleave = mode, int(cp), interleave
        self.sync = sync
        self.T = pilot_table(mode, sync)
        self.Tac = self.T - self.T.mean(axis=0)          # the part that changes (the steady line out)
        self.pat0 = 0                                    # sync pattern index of the next frame's symbol 0
        self.L = self.mode.nfft + self.cp
        self.buf = np.zeros(0, np.complex64)
        self.base = 0                                    # absolute sample number of buf[0]
        self.locked = False
        self.start = 0.0                                 # absolute sample number of the next frame
        self.rate = 0.0                                  # extra samples per symbol (sample clock)
        self.cfo = 0.0
        self.eq = "pilots"                               # "off", "common", "pilots", "taps"
        self.timing = "auto"                             # or "manual"
        self.manual_offset = 0
        self.track = True
        self.bad = 0
        self.stats = {}
        self.last_const = None
        self.timing_curve = None
        self.scale = Modulator(mode).scale
        self.read_word = True                            # look for a mode word (and put its pilots back)
        self.auto_word = False                           # follow the word's interleave setting
        # (NBTV SDR 1.20) the signal mirrored on the channel (I/Q swapped at either end): while searching, the
        # same samples are tried both ways; the way that locks is kept, so nothing moves on the channel
        self.auto_mirror = False
        self.mirror = False
        self.word_reset()

    def word_reset(self):
        self.wacc = np.zeros(WORD_BITS)
        self.word = None                                 # the last good settings word (page 1)
        self.word_age = 99                               # frames since a word was last read
        self.word_frames = 0                             # frames in a row it has been read
        self.word_soft = None
        self.slot = -1                                   # this frame's place in the 32-frame round
        self.sacc = np.zeros((CYCLE, WORD_BITS))         # soft bits added up for each place
        self.sword = [None] * CYCLE                      # the word each place carried, as last read
        self.sseen = [0] * CYCLE                         # how often in a row each place agreed
        self.call = [None] * 4                           # callsign pages, as read
        self.call_age = 99
        self.pages = {}                                  # page -> (data, frame count when read): time, grid, title
        self.nfr = 0
        self.breaks = 0                                  # frames found missing or out of turn

    def reset(self):
        self.locked = False
        self.bad = 0
        self.word_reset()

    # ------------------------------------------------------------ helpers
    def _fft(self, x):
        return np.fft.fftshift(np.fft.fft(x, axis=-1), axes=-1) / (math.sqrt(self.mode.nfft) * self.scale)

    def _derotate(self, seg, abs0):
        if not self.cfo:
            return seg
        n = abs0 + np.arange(len(seg))
        return seg * np.exp(-2j * math.pi * self.cfo / FS * n).astype(np.complex64)

    def _guard_match(self, o0, o1):
        """How well the signal matches itself one FFT length on, over offsets o0..o1 from each symbol's
        start (as the timing has it), over this frame (the matches of each 8 symbols added coherently,
        their sizes added): a share 0..1.  None if the buffer doesn't hold it."""
        o0, o1 = int(o0), int(o1)
        if o1 <= o0:
            return None
        N, S = self.mode.nfft, self.mode.syms
        st = np.floor(self.start + np.arange(S) * (self.L + self.rate) + 0.5).astype(np.int64) - self.base
        idx = st[:, None] + np.arange(o0, o1)[None, :]
        if idx.min() < 0 or idx.max() + N >= len(self.buf):
            return None
        a = self.buf[idx]
        b = self.buf[idx + N]
        c = np.sum(a * np.conj(b), axis=1)
        e = 0.5 * np.sum(np.abs(a) ** 2 + np.abs(b) ** 2, axis=1)
        nb = max(1, S // 8)
        cs = np.abs(c[:nb * 8].reshape(nb, 8).sum(axis=1)).sum()
        return float(cs / max(float(e[:nb * 8].sum()), 1e-12))

    def _symbols(self, abs0, count, rate=None):
        """FFT of `count` symbols, the first starting at absolute sample abs0 (may be fractional), each
        L + rate samples on (rate follows a sample clock difference)."""
        rate = self.rate if rate is None else rate
        exact = abs0 + np.arange(count) * (self.L + rate)
        st = np.floor(exact + 0.5).astype(np.int64)
        w0 = self.cp - getattr(self, "adv", 0)          # (the window moved into the guard: see _echo_fit)
        idx = (st - self.base)[:, None] + w0 + np.arange(self.mode.nfft)[None, :]
        idx = np.clip(idx, 0, len(self.buf) - 1)
        seg = self.buf[idx]
        if self.cfo:
            seg = seg * np.exp(-2j * math.pi * self.cfo / FS * (st[:, None] + w0 + np.arange(self.mode.nfft)[None, :])).astype(np.complex64)
        Y = self._fft(seg)
        # each window starts on a whole sample: turn the fraction left over into a phase slope
        frac = exact - st
        if np.any(np.abs(frac) > 1e-6):
            k = np.arange(self.mode.nfft) - self.mode.nfft / 2.0
            Y = Y * np.exp(FRAC_SIGN * 2j * math.pi * np.outer(frac, k) / self.mode.nfft)
        return Y

    # ------------------------------------------------------------ acquisition
    def _timing_metric(self, i0, offsets, K, power=None, pre=0.0):
        """Pilot cleanliness for each trial offset: |sum Y^2 Y'^2*| / sum |Y|^2|Y'|^2 over pilots,
        consecutive symbols (squaring removes the +-1).  1 = clean, lower = symbols mixing."""
        m = self.mode
        idx = (np.asarray(offsets)[:, None, None] + i0 + np.arange(K)[None, :, None] * self.L
               + self.cp + np.arange(self.mode.nfft)[None, None, :])
        seg = self.buf[idx]
        if pre:                                          # a known coarse frequency offset taken out first
            seg = seg * np.exp(-2j * math.pi * pre / FS * idx).astype(np.complex64)
        Y = self._fft(seg)[:, :, m.pilot_bins]
        pw = SYNC_POWER[self.sync] if power is None else power
        Z = Y ** pw
        prod = Z[:, 1:] * np.conj(Z[:, :-1])
        num = np.abs(prod.sum(axis=(1, 2)))
        den = (np.abs(Z[:, 1:]) * np.abs(Z[:, :-1])).sum(axis=(1, 2)) + 1e-12
        # frequency offset from the same products (squared: +-125 Hz without ambiguity)
        ang = np.angle(prod.sum(axis=(1, 2)))
        return num / den, ang

    def _guard_metric(self, i0, K):
        """For every offset 0..L-1: how well the guard matches the symbol's end there (0..1)."""
        N, cp, L = self.mode.nfft, self.cp, self.L
        x = self.buf[i0:i0 + K * L + N + cp]
        c = x[:-N] * np.conj(x[N:])
        e = 0.5 * (np.abs(x[:-N]) ** 2 + np.abs(x[N:]) ** 2)
        k = np.ones(cp, np.float32)
        cs = np.convolve(c, k, "valid")[:K * L].reshape(K, L).sum(axis=0)
        es = np.convolve(e, k, "valid")[:K * L].reshape(K, L).sum(axis=0) + 1e-12
        r = np.abs(cs) / es
        return r / max(float(r.max()), 1e-12)

    def acquire(self):
        """Find the signal.  With auto_mirror: the same samples are tried as they come and mirrored about the
        channel's centre (its I and Q the other way round); the way that locks - and fits the sync better - is
        kept, and every sample after it is taken that way.  Nothing is moved in frequency."""
        if not self.auto_mirror or getattr(self, "mirror_hold", False):
            ok = self._acquire()
            if ok:
                self.mirror_hold = False
                self.stats["mirror"] = self.mirror
            return ok
        # both ways on the same samples; if both lock, the one whose sync pattern fits better (a mirrored
        # signal can still lock on the pilots that land on pilots - fewer of them, so a weaker fit)
        snap0 = dict(self.__dict__, stats=dict(self.stats))
        ok_a = self._acquire()
        if not ok_a and getattr(self, "_nosig", True):
            return False                                  # (too little, or no signal filling it: nothing to try)
        res_a = dict(self.__dict__, stats=dict(self.stats))
        q_a = float(getattr(self, "sync_q", 0.0)) if ok_a else -1.0
        self.__dict__.clear()
        self.__dict__.update(snap0)
        self.stats = dict(snap0["stats"])
        self.buf = np.conj(self.buf)
        self.mirror = not self.mirror
        ok_b = self._acquire()
        q_b = float(getattr(self, "sync_q", 0.0)) if ok_b else -1.0
        both = ok_a and ok_b
        if ok_b and q_b > q_a:
            self.stats["mirror"] = self.mirror
        else:
            self.__dict__.clear()                          # the way it was (locked or still searching)
            self.__dict__.update(res_a)
        # both ways locked (180x96: a mirrored signal's pilots partly land on pilots - its fit about 3/4 of the
        # right way's, closer deep in noise): the mode word decides - if none is read the way taken, the other
        # way is tried, and if none comes that way either, back to the better fit.  (Only where a word has been
        # read before, or the two fits are close: a sender with no word is not upset.)
        close = both and min(q_a, q_b) > 0.85 * max(q_a, q_b)
        self.mirror_check = [0, 0] if (both and self.read_word and (getattr(self, "words_ever", False) or close)) else None
        return ok_a or ok_b

    def _acquire(self):
        m = self.mode
        self.adv, self.next_adv, self.echo_hold, self.sync_nc = 0, None, 0, 0.0
        need = (2 * m.syms + 4) * self.L
        self._nosig = True
        if len(self.buf) < need:
            return False
        # the signal must fill the buffer: timing measured where it is only starting comes out wrong
        e = np.abs(self.buf[:need]) ** 2
        q4 = [float(np.mean(e[i * need // 4:(i + 1) * need // 4])) for i in range(4)]
        if q4[0] < 0.4 * max(q4[1:]):
            self.stats.update(state="searching")
            cut = len(self.buf) - need // 2
            self.buf = self.buf[cut:]
            self.base += cut
            return False
        self._nosig = False
        K = 24
        if self.timing == "manual":
            offs = [int(self.manual_offset) % self.L]
        else:
            offs = list(range(self.L))
        tail = (2 * m.syms + 4) - (K + 2)              # measure on the newest symbols of the buffer
        pre = 0.0
        if self.sync == "hxdx":
            # HxDX: the steady carrier gives the frequency first, at any timing (it does not change
            # from symbol to symbol) - then the 4th power timing search is not upset by it
            # (measured at four timings across the symbol and the clearest kept: a window across the
            # join of two symbols can hide it - the pilots' phase jumps there when a guard is long)
            q4o = [0, self.L // 4, self.L // 2, 3 * self.L // 4]
            m1, a1 = self._timing_metric(tail * self.L, q4o, K, power=1)
            pre = float(a1[int(np.argmax(m1))]) / (2 * math.pi * self.L / FS)
        met, ang = self._timing_metric(tail * self.L, offs, K, pre=pre)
        pws = np.full(len(offs), SYNC_POWER[self.sync])
        if self.sync == "std":
            # Standard: the pilots as they are (best deep in noise), or squared (blind to the mode
            # word's +-1 pilots, which upset the plain metric) - whichever fits better at each timing
            met2, ang2 = self._timing_metric(tail * self.L, offs, K, power=2)
            use2 = met2 > met
            met, ang = np.where(use2, met2, met), np.where(use2, ang2, ang)
            pws = np.where(use2, 2, 1)
        if self.sync == "hxdx" and len(offs) > 1:
            # HxDX: time on the sequence itself (as HxDX Classic does) - the window where the
            # chips line up best.  The 4th power metric needs far more signal than this.
            self.cfo = pre
            grid = list(range(0, self.L, 4))
            qs = []
            for o in grid:
                Yg = self._symbols(self.base + o + (m.syms + 2) * self.L, m.syms, 0.0)[:, m.pilot_bins]
                qs.append(self._sync_search(Yg)[2])
            qs = np.array(qs)
            gb = int(np.argmax(qs))
            met = np.interp(np.arange(self.L), grid, qs / max(qs[gb], 1e-9) * 0.5 + 0.5)
            ang = np.zeros(self.L)
            met[grid[gb]] = 1.0
        if self.cp > 0 and len(offs) == self.L and self.mode.nfft / float(_pilot_gcd(self.mode)) < self.L:
            # pilots that can't tell a timing from one nfft/gcd away (180x96): the guard can - it is a
            # copy of the symbol's end only at the right timing
            met = np.asarray(met) * (0.3 + 0.7 * self._guard_metric(tail * self.L, K))
        b = int(np.argmax(met))
        self.timing_curve = met if len(offs) > 1 else None
        if met[b] < 0.35 and self.timing == "auto":
            self.stats.update(state="searching", metric=float(met[b]))
            cut = len(self.buf) - need // 2                       # keep searching on newer samples
            self.buf = self.buf[cut:]
            self.base += cut
            return False
        off = offs[b]
        pw = int(pws[b])
        f0 = pre + float(ang[b]) / (pw * 2 * math.pi * self.L / FS)  # +-250 / power Hz
        # frame start from the sync pattern; the frequency estimate repeats every 500 / power Hz:
        # the right one is the one the pattern fits best
        S = m.syms
        step = FS / float(self.L) / pw
        cands = [f0 + k * step for k in range(-6, 7) if abs(f0 + k * step) <= 260.0]
        if self.sync == "hxdx":
            # the steady carrier's estimate (within about 8 Hz); the sequence search covers +-12 Hz
            cands = [pre]
        top = None
        ws = self.base + off + (S + 2) * self.L         # search the second half of the buffer
        for f in cands:
            self.cfo = f
            Y = self._symbols(ws, S, 0.0)[:, m.pilot_bins]
            o, df, q, q2 = self._sync_search(Y)
            if top is None or q > top[0]:
                top = (q, o, f + df, q2)
        q, o, self.cfo, q2 = top
        if q < 2.0 * q2 and self.timing == "auto" and self.sync != "std":
            # no clear peak over the whole frame: perhaps a channel fading faster than that - try the
            # pattern a few symbols at a time (stricter: a noise peak is likelier this way)
            topn = None
            for f in cands:
                self.cfo = f
                Y = self._symbols(ws, S, 0.0)[:, m.pilot_bins]
                on, _, qn, qn2 = self._sync_search_nc(Y)
                if topn is None or qn / max(qn2, 1e-12) > topn[0] / max(topn[3], 1e-12):
                    topn = (qn, on, f, qn2)
            if topn[0] >= 1.6 * topn[3]:                 # (noise alone: under 1.2)
                self.sync_nc = topn[0] / max(topn[3], 1e-12)
                q, o, self.cfo, q2 = topn[0], topn[1], topn[2], min(topn[3], topn[0] / 2.01)
        self.sync_q, self.sync_q2 = q, q2
        if self.sync != "std" and q < 2.0 * q2 and self.timing == "auto":
            # no clear sequence peak: this was noise - keep searching on newer samples
            self.stats.update(state="searching", metric=float(met[b]), sync_q=q, sync_q2=q2)
            cut = len(self.buf) - need // 2
            self.buf = self.buf[cut:]
            self.base += cut
            return False
        i0 = (-o) % S                                  # first frame start in the window
        self.pat0 = (o + i0) % len(self.T)
        self.start = float(ws + i0 * self.L)
        self.rate = 0.0
        # fine timing: the pilot phases across the band (resolves the coarse search's near misses)
        if self.timing == "auto":
            n = min(S, 60)
            Y = self._symbols(self.start, n, 0.0)
            # (wide enough to cover the guard: the coarse metric is flat across it, and may land anywhere on it)
            dt, q = self.fine_timing(self.pilot_channel(Y)[0], 40 + self.cp)
            self.start += int(round(dt))
            if self.start - self.base < 0:
                self.start += S * self.L
                self.pat0 = (self.pat0 + S) % len(self.T)
            # the sample clock difference: the timing now and one frame later
            if self.start - self.base + (2 * S) * self.L + 8 < len(self.buf):
                Y2 = self._symbols(self.start + S * self.L, n, 0.0)
                Y1 = self._symbols(self.start, n, 0.0)
                d2, q2 = self.fine_timing(self.pilot_channel(Y2, self.pat0 + S)[1], 6)
                d1, q1 = self.fine_timing(self.pilot_channel(Y1)[1], 6)
                if q1 > 0.5 and q2 > 0.5:
                    self.rate = clamp_f((d2 - d1) / S, -0.1, 0.1)
        self.locked = True
        self.bad = 0
        self.stats.update(state="locked", metric=float(met[b]), offset=int(off), cfo=self.cfo,
                          sync_q=self.sync_q, sync_q2=self.sync_q2, mirror=self.mirror)
        self.acquisitions = getattr(self, "acquisitions", 0) + 1
        return True

    def _sync_search_nc(self, Y, Lb=8):
        """As _sync_search, but each short block of symbols on its own (their matches' powers added
        up): for a channel that fades faster than a frame (sky wave with several Hz of Doppler
        spread), where a match across the whole frame at once comes apart.  Each block's own mean
        taken off first (the steady part of the pilots matches any start, and over a few symbols the
        pattern doesn't average it away).  -> (index, 0.0, quality 0..1, best elsewhere)."""
        Lp = len(self.T)
        W, npl = Y.shape
        nb = W // Lb
        W = nb * Lb
        Yb = Y[:W].reshape(nb, Lb, npl)
        Yc = Yb - Yb.mean(axis=1, keepdims=True)
        idx = (np.arange(Lp)[:, None] + np.arange(W)[None, :]) % Lp
        Tw = self.Tac[idx].reshape(Lp, nb, Lb, npl)
        Tc = Tw - Tw.mean(axis=2, keepdims=True)
        c = np.einsum("blp,oblp->obp", Yc, np.conj(Tc))
        ey = np.sum(np.abs(Yc) ** 2, axis=1)                                  # nb x pilots
        et = np.sum(np.abs(Tc) ** 2, axis=2)                                  # Lp x nb x pilots
        q = np.sum(np.abs(c) ** 2, axis=(1, 2)) / (np.sum(ey[None] * et, axis=(1, 2)) + 1e-30)
        o = int(np.argmax(q))
        dist = np.minimum(np.abs(np.arange(Lp) - o), Lp - np.abs(np.arange(Lp) - o))
        q2 = float(np.max(q[dist > 4])) if np.any(dist > 4) else 0.0
        return o, 0.0, float(q[o]), q2

    def _sync_search(self, Y):
        """Where in the sync pattern is this window of pilots (window x pilots)?  Each pilot is
        correlated with the pattern's changing part at every start, coherently over 8-symbol blocks
        that are then added up coherently too, over a fine grid of left-over frequency error.
        -> (pattern index of the window's first symbol, frequency error Hz, quality 0..1,
            best quality more than 4 symbols away from the peak)."""
        Lp = len(self.T)
        W, npl = Y.shape
        Lb = 8
        nb = W // Lb
        W = nb * Lb
        Y = Y[:W]
        idx = (np.arange(Lp)[:, None] + np.arange(W)[None, :]) % Lp          # Lp x W
        Tw = self.Tac[idx]                                                    # Lp x W x pilots
        c = (Y[None, :, :] * np.conj(Tw)).reshape(Lp, nb, Lb, npl).sum(axis=2)   # Lp x nb x pilots
        span = 12.0 if self.sync in ("std", "hxdx") else 3.0   # (HxDX: the steady carrier's estimate is +-8 Hz)
        dfs = np.arange(-span, span + 1e-9, 0.5)
        tb = (np.arange(nb) * Lb + Lb / 2.0) * self.L / FS
        ph = np.exp(-2j * np.pi * np.outer(dfs, tb))                         # ndf x nb
        Cc = np.einsum("db,obp->odp", ph, c)                                  # Lp x ndf x pilots
        num = np.sum(np.abs(Cc) ** 2, axis=2)
        ey = np.sum(np.abs(Y) ** 2, axis=0)                                   # per pilot
        et = np.sum(np.abs(Tw) ** 2, axis=1)                                  # Lp x pilots
        q = num / (np.sum(ey[None, :] * et, axis=1)[:, None] + 1e-30)
        # the steady part of the pilots (HxDX) cannot match the sequence: scale so a clean match is 1
        q = q * (np.mean(np.abs(self.T) ** 2) / max(np.mean(np.abs(self.Tac) ** 2), 1e-12))
        o, d = np.unravel_index(int(np.argmax(q)), q.shape)
        qo = q.max(axis=1)
        dist = np.minimum(np.abs(np.arange(Lp) - o), Lp - np.abs(np.arange(Lp) - o))
        q2 = float(np.max(qo[dist > 4])) if np.any(dist > 4) else 0.0
        return int(o), float(dfs[d]), float(q[o, d]), q2

    def pilot_channel(self, Y, pat=None):
        """Per symbol channel at the pilots (frame sync known), and its average over the symbols with
        each symbol's common phase taken out (so a little frequency error does not blur it).
        Divided by the known pilot values (gently where they are small: the sine pilots pass 0)."""
        m = self.mode
        S = len(Y)
        pat = self.pat0 if pat is None else pat
        Pk = self.T[(pat + np.arange(S)) % len(self.T)]
        num = Y[:, m.pilot_bins] * np.conj(Pk)
        den = np.abs(Pk) ** 2
        if self.sync == "std":
            # the sine pilots pass through 0: measure over 9 symbols, weighted by their size
            k = 4
            cn = np.cumsum(np.vstack((np.zeros((1, num.shape[1])), num)), axis=0)
            cd = np.cumsum(np.vstack((np.zeros((1, den.shape[1])), den)), axis=0)
            lo = np.clip(np.arange(S) - k, 0, S)
            hi = np.clip(np.arange(S) + k + 1, 0, S)
            num, den = cn[hi] - cn[lo], cd[hi] - cd[lo]
        P = num / np.maximum(den, 1e-9)
        adv = getattr(self, "adv", 0)
        if adv:                                          # (as if the window were where the timing is)
            P = P * self._ramp(m.pilot_bins, -adv)[None, :]
        c = P.sum(axis=1)
        Pa = (P * np.conj(c / (np.abs(c) + 1e-12))[:, None]).mean(axis=0)
        return P, Pa

    def _ramp(self, bins, s):
        """The phase across the band of a window moved s samples later."""
        return np.exp(RAMP_SIGN * 2j * math.pi * (np.asarray(bins) - self.mode.nfft / 2.0) * s / self.mode.nfft)

    def fine_timing(self, Pa, span, refine=False):
        """Timing error in samples from the pilots' phase across the band: the window that makes them
        line up best.  + = this window starts late."""
        k = self.mode.pilot_bins - self.mode.nfft / 2.0
        d = np.arange(-span, span + 0.001, 0.25)
        E = np.exp(2j * math.pi * np.outer(d, k) / self.mode.nfft)
        if np.ndim(Pa) == 2:
            # per symbol, added up without their phases: a fading channel turns the pilots' common phase
            # from symbol to symbol, which an average over the symbols would smear (wrong timing peaks)
            a = np.abs(E @ Pa.T).sum(axis=1)
            norm = np.abs(Pa).sum() + 1e-12
        else:
            a = np.abs(E @ Pa)
            norm = np.abs(Pa).sum() + 1e-12
        i = int(np.argmax(a))
        di = float(d[i])
        if refine and 0 < i < len(a) - 1:                # (between the 1/4-sample steps: the peak's top -
                                                         # tracking only: with an echo the peak leans)
            y0, y1, y2 = float(a[i - 1]), float(a[i]), float(a[i + 1])
            den = y0 - 2 * y1 + y2
            if den < 0:
                di += 0.25 * 0.5 * (y0 - y2) / den
        # pilots whose spacings share a factor (180x96's are all on odd carriers) can't tell a timing
        # from one P = nfft / that factor away: their phases come out the same.  The coarse search
        # lands in the guard, so the right correction is in [0, guard]: of the look-alikes, take the
        # one nearest the middle of that.
        P = self.mode.nfft / float(_pilot_gcd(self.mode))
        if P < 2 * span:
            lo = -P / 2.0 + self.cp / 2.0
            di = (di - lo) % P + lo
        return di, float(a[i] / norm)

    # ------------------------------------------------------------ frames
    def feed(self, x):
        """New samples in, decoded frames out: list of dicts."""
        x = np.asarray(x, np.complex64)
        if self.mirror:
            x = np.conj(x)
        self.buf = np.concatenate((self.buf, x))
        out = []
        m = self.mode
        for _ in range(4):
            if not self.locked:
                if not self.acquire():
                    break
            need = int(self.start) - self.base + int((m.syms + 2) * (self.L + abs(self.rate))) + 4
            if len(self.buf) < need:
                break
            r = self.frame()
            if r is not None:
                out.append(r)
            if self.word_age == 0:
                self.words_ever = True
            mc = getattr(self, "mirror_check", None)
            if mc is not None and self.locked:
                if self.word_age == 0:
                    self.mirror_check = None              # the word read: this way is right
                else:
                    mc[0] += 1
                    if mc[0] >= 8:                        # no word in 8 frames: the other way round
                        mc[0], mc[1] = 0, mc[1] + 1
                        if mc[1] >= 2:
                            self.mirror_check = None      # (no word either way: back to the first, and stay)
                        self.mirror = not self.mirror
                        self.buf = np.conj(self.buf)
                        self.locked = False
                        self.mirror_hold = True           # (not searched both ways again: this way)
                        break
        # drop what has been used (keep a little before the next frame for tracking)
        keep_from = int(self.start - 2 * self.L) if self.locked else (self.base + len(self.buf) - (2 * m.syms + 4) * self.L)
        cut = max(0, keep_from - self.base)
        if cut > 0:
            self.buf = self.buf[cut:]
            self.base += cut
        return out

    def _read_word(self, Y):
        """The mode word from this frame's pilots: each word pilot against the channel that the
        pilots of the symbols either side of it show (so fading and drift do not matter), the bits
        added up over their chips, and over the frames before (while the word stays the same).
        -> the +-1 to put the word pilots back with (W x pilots), or None."""
        m = self.mode
        S = m.syms
        ws, pn, bit = word_layout(m)
        Pk = self.T[(self.pat0 + np.arange(S)) % len(self.T)]
        R = Y[:, m.pilot_bins] * np.conj(Pk)
        wt = np.abs(Pk) ** 2
        isw = np.zeros(S, bool)
        isw[ws] = True
        st = pilot_steady(m, self.sync)
        soft = np.empty((len(ws), R.shape[1]))
        Hc = np.empty((len(ws), R.shape[1]), complex)
        for j, s0 in enumerate(ws):
            nb = [n for n in range(max(0, s0 - 4), min(S, s0 + 5)) if not isw[n]]
            H = R[nb].sum(axis=0) / np.maximum(wt[nb].sum(axis=0), 1e-9)
            Hc[j] = H * (Pk[s0] - st)                      # what the turning part looks like here
            soft[j] = np.real((Y[s0, m.pilot_bins] - H * st) * np.conj(Hc[j]))
        self.word_Hc = Hc
        d = soft * pn
        sb = np.array([d[bit == i].sum() for i in range(WORD_BITS)])
        sb = sb / (np.sqrt(np.mean(sb ** 2)) + 1e-12)

        def check(v):
            w_ = word_check((v < 0).astype(np.int8))
            return w_ if (w_ is not None and word_ok(w_)) else None
        self.slot = (self.slot + 1) % CYCLE
        sl = self.slot
        self.nfr += 1
        w_f = check(sb)                                  # this frame alone
        if w_f is not None and self.sword[sl] is not None and word_page(w_f) != word_page(self.sword[sl]):
            if self.sseen[sl] >= 1:                     # out of turn: a frame missed (or the TX restarted)
                self.breaks += 1
            self.sacc[:] = 0.0                           # start the round again from here
            self.sword = [None] * CYCLE
            self.sseen = [0] * CYCLE
        elif w_f is not None and self.sword[sl] is not None and w_f != self.sword[sl]:
            self.sacc[sl] = 0.0                          # the same page, new contents (settings changed)
        self.sacc[sl] = 0.7 * self.sacc[sl] + sb
        w_a = check(self.sacc[sl])                       # this place's own copies, frames back
        # the settings come every other frame (or every frame): those places added up together; any
        # other page: every place that carried the same word (a short list comes round several times)
        w_p = None
        if self.sword[sl] is None or word_page(self.sword[sl]) == 1:
            par = self.sacc[[(sl + 2 * k) % CYCLE for k in range(CYCLE // 2)]].sum(axis=0)
            w_p = check(par)
            if w_p is not None and word_page(w_p) != 1:
                w_p = None
        else:
            ks = [k for k in range(CYCLE) if self.sword[k] == self.sword[sl]]
            if len(ks) > 1:
                w_p = check(self.sacc[ks].sum(axis=0))
                if w_p is not None and w_p != self.sword[sl]:
                    w_p = None
        w = w_f if w_f is not None else (w_a if w_a is not None else w_p)
        self.word_soft = float(np.min(np.abs(self.sacc[sl])) / (np.sqrt(np.mean(self.sacc[sl] ** 2)) + 1e-12))
        if w is None and self.sword[sl] is not None and self.sseen[sl] >= 2:
            w_put = self.sword[sl]                      # not read now, but this place's word is known
        else:
            w_put = w
        if w is not None:
            self.sseen[sl] = self.sseen[sl] + 1 if self.sword[sl] == w else 1
            self.sword[sl] = w
            self.word_age = 0
            pg = word_page(w)
            if pg == P_SET:
                self.word_frames = self.word_frames + 1 if w == self.word else 1
                self.word = w
            elif P_CALL <= pg < P_CALL + 4:
                self.call[pg - P_CALL] = (CALL_CHARS[w & 63], CALL_CHARS[(w >> 6) & 63])
                self.call_age = 0
            else:
                self.pages[pg] = (int(w) & 0xFFF, self.nfr)
        else:
            self.word_age += 1
        self.call_age += 1 if (w is None or word_page(w) == 1) else 0
        self.this_page = word_page(w) if w is not None else None
        if w_put is not None and self.word_age <= 8:
            return word_chips(m, w_put)
        return None

    def side_data(self):
        """What the extra pages have brought: dict(time 'HH:MM', date 'YYYY-MM-DD', time_age (frames
        since), grid, title) - each only once read, and dropped when not heard for two rounds."""
        out = {}
        fresh = {p: d for p, (d, n) in self.pages.items() if self.nfr - n <= 2 * CYCLE}
        if P_TIME in fresh:
            m = fresh[P_TIME]
            out["time"] = "%02d:%02d" % (m // 60, m % 60)
            out["time_age"] = self.nfr - self.pages[P_TIME][1]
        if P_DATE in fresh:
            d = fresh[P_DATE]
            yday, y3 = d & 511, d >> 9
            yr = time.gmtime().tm_year
            yr = yr - ((yr - y3) & 7)                    # the nearest year (this or before) with those bits
            try:
                out["date"] = time.strftime("%Y-%m-%d", time.strptime("%d %d" % (yr, yday), "%Y %j"))
            except ValueError:
                pass
        if P_GRID in fresh and P_GRID + 1 in fresh:
            g = grid_text((fresh[P_GRID] << 12) | fresh[P_GRID + 1])
            if g:
                out["grid"] = g
        if P_EXT in self.pages:                          # (held: it only changes with the TX's setting)
            out["ww_split"] = word_ext_split(self.pages[P_EXT][0])
        tp = [fresh.get(P_TITLE + k) for k in range(6)]
        if any(v is not None for v in tp):
            out["title"] = "".join((TITLE_CHARS[v & 63] + TITLE_CHARS[v >> 6]) if v is not None else "??"
                                   for v in tp).rstrip()
        return out

    def callsign(self):
        """The callsign as read so far ('?' where a part is still missing), or None."""
        if all(c is None for c in self.call) or self.call_age > 4 * CYCLE:
            return None
        return "".join("".join(c) if c is not None else "??" for c in self.call).strip()

    def _unword(self, Y, ws, chips):
        """Put the word pilots back as the pattern has them (in place)."""
        pb = self.mode.pilot_bins
        if self.sync == "hxdx":                          # only the turning part was turned
            Y[np.ix_(ws, pb)] += self.word_Hc * (1.0 - chips)
        else:
            Y[np.ix_(ws, pb)] *= chips

    def frame(self):
        m = self.mode
        S = m.syms
        nxt = getattr(self, "next_adv", None)
        self.adv = nxt if (nxt is not None and self.eq == "taps") else (getattr(self, "adv", 0) if self.eq == "taps" else 0)
        self.next_adv = None
        Y = self._symbols(self.start, S)
        chips = self._read_word(Y) if self.read_word else None
        ws = word_layout(m)[0]
        if chips is not None:
            self._unword(Y, ws, chips)
            wd = word_unpack(self.word) if (self.auto_word and self.word is not None) else None
            if wd is not None:
                self.interleave = wd["interleave"]
            ws_ = word_unpack(self.word) if self.word is not None else None
            if ws_ is not None:                          # (the sender says if its carriers are scrambled,
                self.scramble = ws_["scrambled"]         #  and spread)
                self.spread = ws_.get("spread", "Off")
                self.fold = ws_.get("fold", False)
                self.iqflip = ws_.get("iqflip", False)
        P, Pa = self.pilot_channel(Y)
        # follow the timing (sample clock differences): the pilot phase slope across the band gives the
        # timing error; a second order loop follows both the error and its drift (the clock difference)
        # (not while the echo fit holds two paths: their phases together would pull the timing between
        # them - the fit moves the timing onto the earliest path itself)
        if self.track and self.timing == "auto" and not (self.eq == "taps" and getattr(self, "echo_hold", 0) > 0):
            dt, q = self.fine_timing(Pa, 4)
            if q > FRAC_TRACK_Q:                         # (a clean single path: the finer estimate)
                dt, q = self.fine_timing(Pa, 4, refine=True)
            self.timing_err = dt
            if q > 0.5:
                self.rate = clamp_f(self.rate + 0.35 * dt / S, -2.0, 2.0)
                # the window onto the timing - a fraction of a sample too: a path's delay is never a whole
                # number of samples, and what was left (under half a sample) the echo fit, whose paths are
                # whole samples, could only come near (~35 dB at half a sample, every carrier)
                # (only on a clean single path - q near 1: on a fading sky wave the estimate wanders, and
                # following it there cost frames)
                step = dt if abs(dt) >= 0.5 else (0.5 * dt if (abs(dt) >= 0.03 and q > FRAC_TRACK_Q) else 0.0)
                if step:
                    self.start += step
                    Y = self._symbols(self.start, S)
                    if chips is not None:
                        self._unword(Y, ws, chips)
                    P, Pa = self.pilot_channel(Y)
        frame_ok = float(np.mean(np.real(np.sum(P, axis=1) * np.conj(np.sum(P, axis=1).mean()))) > 0)
        # 1 = steady pilots (over 8 symbols at a time: a sky wave channel fading a few times a second is
        # still a signal)
        nb8 = max(1, S // 8)
        Pb8 = P[:nb8 * 8].reshape(nb8, 8, -1)
        coh = float(np.abs(Pb8.mean(axis=1)).mean() / (np.abs(P).mean() + 1e-12))
        # residual frequency offset from the pilot phase drift
        if S > 2:
            drift = np.angle(np.sum(P[1:] * np.conj(P[:-1])))
            self.cfo += 0.5 * drift / (2 * math.pi * self.L / FS)
        # the level reaching the receiver, from the pilots (for the display)
        self.level_db = float(20 * np.log10(np.mean(np.sqrt(np.mean(np.abs(Y[:, m.pilot_bins]) ** 2, axis=0)))
                                            / np.sqrt(np.mean(np.abs(self.T) ** 2)) + 1e-12))
        # equalise
        if self.eq == "pilots":
            Pm = P.copy()
            k = 5                                        # smooth over a few symbols
            cs = np.cumsum(np.vstack((np.zeros((1, Pm.shape[1])), Pm)), axis=0)
            lo = np.clip(np.arange(S) - k, 0, S)
            hi = np.clip(np.arange(S) + k + 1, 0, S)
            Pm = (cs[hi] - cs[lo]) / (hi - lo)[:, None]
            H = self._interp(Pm)
        elif self.eq == "taps":
            H = self._echo_fit(P, Pa)
            if self.adv:
                H = H * self._ramp(np.arange(self.mode.nfft), self.adv)[None, :]
        elif self.eq == "common":
            g = P.mean(axis=1, keepdims=True)
            H = np.repeat(g, self.mode.nfft, axis=1)
        elif self.eq == "level":
            H = self.pilot_level(Y)
        else:
            H = np.ones_like(Y)
        Z = Y / np.where(np.abs(H) > 1e-6, H, 1e-6)
        spread = getattr(self, "spread", "Off")
        bias = None
        if spread in ("Groups", "Whole band", "Hadamard"):   # (the picture carriers MMSE, then despread)
            Hv = H[:, m.video_bins]
            h2 = np.abs(Hv) ** 2
            snr_l = 10 ** (min(max(float(getattr(self, "snr_est", None) or 30.0), 0.0), 50.0) / 10.0)
            nv = h2.mean(axis=1, keepdims=True) / snr_l
            Z[:, m.video_bins] = Y[:, m.video_bins] * np.conj(Hv) / (h2 + nv)
            bias = h2 / (h2 + nv)
        if getattr(self, "scramble", True):
            ph = np.conj(scramble_phase(self.mode.nfft))
            Z[:, m.video_bins] *= ph[m.video_bins]
            Z[:, m.audio_bins] *= ph[m.audio_bins]
        if bias is not None:
            Z[:, m.video_bins] = despread_values(Z[:, m.video_bins], m, spread, bias)
        vid = Z[:, m.video_bins]
        aud = Z[:, m.audio_bins]
        if getattr(self, "test_rot_deg", 0.0):            # (tests only: a steady phase error left after the EQ)
            r = np.exp(1j * np.deg2rad(self.test_rot_deg))
            vid, aud = vid * r, aud * r
        if getattr(self, "fold", False):                   # (the sender's tone injection undone)
            vid = ti_fold(vid.real) + 1j * ti_fold(vid.imag)
            aud = ti_fold(aud.real) + 1j * ti_fold(aud.imag)
        fl = getattr(self, "iqflip", False)
        if fl:                                             # (odd lines' I and Q put back, and odd symbols' sound)
            vid = iq_swap(vid, iqflip_mask(m, self.interleave))
            aud = iq_swap(aud, iqflip_mask_audio(m))
        vm = np.empty((S, self.mode.vbps), np.uint8)
        vm[:, 0::2] = level_to_byte(vid.real)
        vm[:, 1::2] = level_to_byte(vid.imag)
        frame = vm.T.ravel()
        if self.interleave:
            f2 = np.empty_like(frame)
            f2[interleaver(m)] = frame
            frame = f2
        am = np.empty((S, self.mode.abps), np.uint8)
        am[:, 0::2] = level_to_byte(aud.real)
        am[:, 1::2] = level_to_byte(aud.imag)
        self.last_const = Z[:, m.video_bins[::3]].ravel()[::3]
        self.last_const_a = Z[:, m.audio_bins].ravel()[::2]          # (as many points as the video's)
        # (which of those points went out with I and Q swapped: the scopes show them in another colour - as
        # received, before the swap is undone)
        self.last_flip = iqflip_mask(m, self.interleave)[:, ::3].ravel()[::3] if fl else None
        self.last_flip_a = iqflip_mask_audio(m).ravel()[::2] if fl else None
        self.last_Z = Z
        # the receiver's own SNR estimate: the equalised pilots against what they should be
        Tk = self.T[(self.pat0 + np.arange(S)) % len(self.T)]
        # (each pilot's own steady error over the frame taken out first: a channel shape the equaliser's
        # model doesn't follow - the TX filter's roll-off at the band edges - is not noise, and counting
        # it made the decoders' noise filtering soften a good picture)
        # - and the typical pilot's noise (the median over the pilots), not their sum: one or two pilots at
        # the very band edges, where that filter smears the symbols together, would otherwise set the SNR
        # for the whole picture)
        Zp = Z[:, m.pilot_bins]
        gp = np.sum(Zp * np.conj(Tk), axis=0) / np.maximum(np.sum(np.abs(Tk) ** 2, axis=0), 1e-12)
        pe_p = np.sum(np.abs(Zp - gp * Tk) ** 2, axis=0) * S / max(S - 1.0, 1.0)
        pe = float(np.median(pe_p)) * len(m.pilot_bins)
        # (per data carrier: the pilots are stronger than the data's 2/3 mean power, so take that off)
        self.snr_est = 10 * math.log10(float(np.mean(np.abs(Tk) ** 2)) * S * len(m.pilot_bins) / max(pe, 1e-9)) \
            - 10 * math.log10(float(np.mean(np.abs(self.T) ** 2)) / (2.0 / 3.0))
        abs_start = int(round(self.start))
        self.start += S * (self.L + self.rate)
        self.pat0 = (self.pat0 + S) % len(self.T)
        # lost: pure noise, or a signal at another timing, reads coherence ~0.25-0.4 and the pilots
        # -18..-35 dB; a real one even at 3 dB SNR reads ~0.98 and +5 dB (both needed, so a deep fade
        # on a weak signal doesn't count)
        if coh < 0.3 or (coh < 0.5 and self.snr_est < -5.0):
            self.bad += 2 if coh < 0.3 else 1           # (lost: 2 frames of the first, 3 of the second)
            if self.bad >= 3:
                self.locked = False
                self.stats.update(state="lost")
        else:
            self.bad = 0
        self.stats.update(cfo=self.cfo, coherence=coh, offset=int(abs_start % self.L), ppm=self.rate / self.L * 1e6,
                          snr_est=self.snr_est)
        wd = word_unpack(self.word) if (self.word is not None and self.word_age == 0) else None
        return dict(video=frame, audio=am.ravel(), start=abs_start, coherence=coh, ok=frame_ok, snr_est=self.snr_est,
                    word=wd, word_raw=self.word if wd else None, word_frames=self.word_frames, word_soft=self.word_soft,
                    callsign=self.callsign(), side=self.side_data(), word_breaks=self.breaks,
                    word_page=getattr(self, "this_page", None))

    def pilot_level(self, Y):
        """Level only, from the pilots (as a receiver without an equaliser can do it - see
        pilot_level_agc.py for GNU Radio): each pilot's RMS over the frame against what the pilot
        sends (the sync pattern's RMS: over a frame it comes out exact for the sine tables and the PN),
        in between the pilots by straight lines, then smoothed from frame to frame.  The phase is left
        alone.  -> H (real), one gain per carrier."""
        m = self.mode
        rx = np.sqrt(np.mean(np.abs(Y[:, m.pilot_bins]) ** 2, axis=0))
        ref = np.sqrt(np.mean(np.abs(self.T) ** 2, axis=0))
        lev = rx / np.maximum(ref, 1e-9)
        prev = getattr(self, "lev_prev", None)
        if prev is not None and prev.shape == lev.shape:
            lev = 0.5 * prev + 0.5 * lev                 # a little smoothing (one frame back)
        self.lev_prev = lev
        kp = m.pilot_bins
        order = np.argsort(kp)
        g = np.interp(np.arange(self.mode.nfft), kp[order], lev[order])          # flat beyond the end pilots
        return np.repeat(g[None, :], len(Y), axis=0)

    def _echo_fit(self, P, Pa):
        """The channel as the main path (with a little timing error) plus one echo (with a little of
        its own timing error), fitted to the pilots.  The echo's delay is found over the whole frame;
        the paths' strengths and phases are then fitted symbol by symbol and smoothed over as many
        symbols as the fading allows (picked by how well each smoothing predicts the symbol it leaves
        out) - on HF sky wave the two paths fade on their own, a few times a second."""
        m = self.mode
        N = self.mode.nfft
        kp = m.pilot_bins - N / 2.0
        k = np.arange(N) - N / 2.0
        S = len(P)
        npil = len(kp)
        # (the phase of each symbol taken off for the search, so a frequency offset left over doesn't
        # count as a fit error)
        c = P.sum(axis=1)
        Pc = P * np.conj(c / (np.abs(c) + 1e-12))[:, None]

        three = npil >= 12                               # (enough pilots for each path's own fine timing)

        def main(p):
            return [p - 1, p, p + 1]

        def ech(p):
            return [p - 1, p, p + 1] if three else [p]

        def resid(t):
            A = np.exp(-2j * math.pi * np.outer(kp, t) / N)
            G = np.linalg.solve(A.conj().T @ A + 0.01 * np.eye(len(t)), A.conj().T)
            E = Pc - (Pc @ G.T) @ A.T
            return float(np.sum(np.abs(E) ** 2)) / max(npil - len(t), 1)     # per degree of freedom

        # (delays repeat every nfft samples: the range searched is under that, mostly after the timing)
        top = min(max(self.cp, 8) + 12, N - 24)
        bot = min(top, N - top - 1)
        rng_ = range(-bot, top + 1)
        pa, pb = getattr(self, "path_prev", (0, None))

        def pick(cands, f, prefer):
            best = None
            for x in cands:
                r = f(x) * (0.85 if (prefer is not None and abs(x - prefer) <= 1) else 1.0)
                if best is None or r < best[0]:
                    best = (r, x)
            return best[1]
        # every pair of single paths at once, from the pilots' covariance over the frame (each symbol's
        # pilots lie in the span of the two paths' patterns however the paths fade): the pair that
        # leaves least.  Then the stronger as the main path, with its own little timing error.
        xs = np.arange(-bot, top + 1)
        E = np.exp(-2j * math.pi * np.outer(kp, xs) / N)              # pilots x candidates
        R = Pc.T @ Pc.conj()                                          # pilots x pilots
        M = np.real(np.einsum("ki,kl,lj->ij", E.conj(), R, E))         # e_i^H R e_j (diag real)
        Mc = np.einsum("ki,kl,lj->ij", E.conj(), R, E)
        Gm = E.conj().T @ E
        n0 = float(npil) * 1.05                                         # (a little regularised: nearly
        g = Gm                                                         # alike patterns can't run away)                                                         # e_i^H e_j
        det = n0 * n0 - np.abs(g) ** 2
        # captured energy of the pair: [Mii Mij; Mji Mjj] with inverse Gram
        cap = (n0 * np.real(np.diag(Mc))[:, None] + n0 * np.real(np.diag(Mc))[None, :]
               - 2 * np.real(g.conj() * Mc)) / np.maximum(det, 1e-9)
        sep = np.abs(xs[:, None] - xs[None, :]) >= 3
        cap = np.where(sep, cap, -np.inf)
        if pb is not None:                                             # last frame's pair, unless clearly beaten
            near = (np.abs(xs[:, None] - pa) <= 1) & (np.abs(xs[None, :] - pb) <= 1)
            tot = float(np.real(np.trace(R)))
            cap = np.where((near | near.T) & sep, cap + 0.15 * (tot - np.where(sep, cap, 0.0)), cap)
        i, j = np.unravel_index(int(np.argmax(cap)), cap.shape)
        si, sj = np.real(Mc[i, i]), np.real(Mc[j, j])
        a1, b1 = (int(xs[i]), int(xs[j])) if si >= sj else (int(xs[j]), int(xs[i]))
        r00 = resid(main(0))
        a0 = pick(rng_, lambda x: resid(main(x)), 0)
        r1 = resid(main(a0))
        if r1 > 0.7 * r00:
            a0, r1 = 0, r00
        r2 = resid(main(a1) + ech(b1))
        if r2 < 0.5 * r1:                                # an echo only if it explains most of what is left
            taps = main(a1) + ech(b1)
            lo, hi = min(a1, b1), max(a1, b1)
            early, d = lo, hi - lo
            # Delays repeat every nfft samples: the pilots can't tell an echo d later from one N - d
            # earlier.  When the guard could hold either, the time signal can: each path's guard is a
            # copy of its symbol's end, so the signal matches itself N samples on over that path's
            # guard.  The later-echo reading puts that match also just after the first path's guard,
            # the earlier-echo reading just before it - whichever region matches more is the one.
            if self.cp > 0 and N - d <= top and d >= 3 and N - d >= 3:
                ra = self._guard_match(lo + self.cp, hi + self.cp)
                rb = self._guard_match(hi - N, lo)
                if ra is not None and rb is not None:
                    v = getattr(self, "alias_vote", 0.0)
                    v = 0.6 * v + 0.4 * (1.0 if rb > ra else -1.0)
                    self.alias_vote = v
                    if v > 0.0:                          # the "later" path is really the first
                        early, d = hi - N, N - d
            else:
                self.alias_vote = 0.0
            self.path_prev = (((a1 - early + bot) % N) - bot, ((b1 - early + bot) % N) - bot)
        else:
            taps = main(a0)
            early, d = a0, 0
            self.path_prev = (0, None)
        # the timing onto the earliest path from the next frame on (the echo then comes d samples later)
        # (two frames running must agree first: a fit that went wrong once doesn't move it)
        cand = getattr(self, "anchor_cand", None)
        if abs(early) >= 2 and r2 < 0.5 * r1 if d else abs(early) >= 2:
            if cand is not None and abs(cand - early) <= 2:
                self.start += early
                self.anchor_cand = None
            else:
                self.anchor_cand = early
        else:
            self.anchor_cand = None
        self.echo_est = d
        # where the window goes: both paths inside the guard (the window starts no earlier than the later
        # path, and ends no later than the earlier one's symbol), with the room left split either side.
        # An echo kept for a few frames after it fades (sky wave paths come and go)
        if d:
            self.echo_hold, self.echo_keep = 6, d
        elif getattr(self, "echo_hold", 0) > 0:
            self.echo_hold -= 1
            d = self.echo_keep
        # (no echo: still a little way into the guard - a delay that is not a whole sample, as on any real
        # path, makes each symbol's start ring on both sides, and the next symbol's pre-ringing landed in
        # the end of a window that ended right on it: ~27 dB at half a sample, on every carrier)
        target = int(round((self.cp - abs(d)) / 2.0 - min(0, d))) if d else min(GUARD_BACKOFF, self.cp // 8)
        target = min(max(target, 0), self.cp)
        if abs(target - self.adv) >= 2:
            self.next_adv = target
        A = np.exp(-2j * math.pi * np.outer(kp, taps) / N)
        B = np.exp(-2j * math.pi * np.outer(k, taps) / N)
        G = np.linalg.solve(A.conj().T @ A + 0.01 * np.eye(len(taps)), A.conj().T)
        hs = P @ G.T                                     # taps, symbol by symbol (S x taps)
        # smoothing over symbols: the length that best predicts each symbol's pilots from its neighbours
        cs = np.concatenate((np.zeros((1, hs.shape[1]), complex), np.cumsum(hs, axis=0)))
        best = None
        for w in (1, 2, 3, 5, 8, 12, 20, 40):
            lo = np.clip(np.arange(S) - w, 0, S)
            hi = np.clip(np.arange(S) + w + 1, 0, S)
            loo = (cs[hi] - cs[lo] - hs) / np.maximum(hi - lo - 1, 1)[:, None]
            e = float(np.sum(np.abs(P - loo @ A.T) ** 2))
            if best is None or e < best[0]:
                best = (e, w)
        w = best[1]
        lo = np.clip(np.arange(S) - w, 0, S)
        hi = np.clip(np.arange(S) + w + 1, 0, S)
        hsm = (cs[hi] - cs[lo]) / (hi - lo)[:, None]
        self.eq_span = w
        H = hsm @ B.T
        # what the echo model misses (filter roll off at the band edges): the pilots' steady ratio to it,
        # in between them by straight lines (kept to a modest correction)
        Hp = hsm @ A.T
        ratio = np.sum(P * np.conj(Hp), axis=0) / np.maximum(np.sum(np.abs(Hp) ** 2, axis=0), 1e-12)
        mag = np.abs(ratio)
        ratio = ratio / np.maximum(mag, 1e-12) * np.clip(mag, 0.7, 1.4)
        return H * self._interp(ratio[None, :])[0]

    def _taps(self, P):
        """Pilot estimates -> every carrier by fitting a short echo pattern (impulse response taps at
        -1 .. D samples) by least squares: exact for an echo shorter than the guard interval."""
        m = self.mode
        kp = m.pilot_bins - self.mode.nfft / 2.0
        D = max(2, min(len(kp) - 3, max(self.cp, 4)))
        d = np.arange(-1, D + 1)
        A = np.exp(-2j * math.pi * np.outer(kp, d) / self.mode.nfft)
        lam = 0.02 * np.eye(len(d))
        G = np.linalg.solve(A.conj().T @ A + lam, A.conj().T)           # taps from pilots
        k = np.arange(self.mode.nfft) - self.mode.nfft / 2.0
        B = np.exp(-2j * math.pi * np.outer(k, d) / self.mode.nfft)
        return (P @ G.T) @ B.T

    def _interp(self, P):
        """Pilot channel estimates -> every carrier: amplitude and (unwrapped) phase, linearly."""
        pb = self.mode.pilot_bins.astype(float)
        amp = np.abs(P)
        ph = np.unwrap(np.angle(P), axis=1)
        k = np.arange(self.mode.nfft, dtype=float)
        A = np.array([np.interp(k, pb, a) for a in amp])
        F = np.array([np.interp(k, pb, p) for p in ph])
        # outside the outer pilots: carry the slope on
        if len(pb) > 1:
            for side in (0, 1):
                if side == 0:
                    sl = (ph[:, 1] - ph[:, 0]) / (pb[1] - pb[0])
                    sel = k < pb[0]
                    F[:, sel] = ph[:, :1] + sl[:, None] * (k[sel] - pb[0])
                else:
                    sl = (ph[:, -1] - ph[:, -2]) / (pb[-1] - pb[-2])
                    sel = k > pb[-1]
                    F[:, sel] = ph[:, -1:] + sl[:, None] * (k[sel] - pb[-1])
        return A * np.exp(1j * F)


# ======================================================================= sync test
# ----------------------------------------------------------------------- Auto: what is on the air
AUTO_GUARDS = (0, 10, 25, 50, 100, 200, 300)
AUTO_NEED = 3 * 122 * 700 + 2000                     # samples: two of the longest frames, and some


def guard_scan(x):
    """Symbol length and guard from the guard itself: the guard is a copy of the symbol's end, so the
    signal matches itself one FFT length later, over the guard's length, once every symbol.
    -> [(score, nfft, cp)] best first (score: that match's peak, in noise standard deviations)."""
    x = np.asarray(x, np.complex64)
    out = []
    # (FFT length, guards): the normal layouts, then the fixed 12.5 fps ones (FFT = 200 or 400 less the guard)
    plan = [(N, AUTO_GUARDS[1:]) for N in (NFFT, 2 * NFFT)]
    # (and the video first and balanced ones: each format and pilot count may cut its own way)
    bal = sorted(set((layout(f, S == 2 * NFFT, cp, k, d).nfft, cp) for S in (NFFT, 2 * NFFT) for cp in AUTO_GUARDS[1:]
                     for f in AUTO_FORMATS for d in ((False, True) if S == NFFT else (False,)) for k in (1, 2)))
    plan += [(N, (cp,)) for N, cp in bal if N not in (NFFT, 2 * NFFT)]
    for N, guards in plan:
        if len(x) < 6 * N:
            continue
        c = x[:-N] * np.conj(x[N:])
        e = 0.5 * (np.abs(x[:-N]) ** 2 + np.abs(x[N:]) ** 2)
        for cp in guards:
            L = N + cp
            M = (len(c) - cp) // L - 1
            if M < 8:
                continue
            k = np.ones(cp, np.float32)
            cs = np.convolve(c[:M * L + cp], k, "valid")[:M * L].reshape(M, L).sum(axis=0)
            es = np.convolve(e[:M * L + cp], k, "valid")[:M * L].reshape(M, L).sum(axis=0)
            rho = np.abs(cs) / (es + 1e-12)
            # against the rest of the curve (the noise floor of this measure)
            pk = int(np.argmax(rho))
            # against noise's own spread (each sum is M x cp products of unrelated samples), above the
            # curve's middle (a wrong symbol length smears the match into a broad hump; echoes as long
            # as the guard broaden the true one, so the curve itself is no floor to measure against)
            out.append(((float(rho[pk]) - float(np.median(rho))) * math.sqrt(M * cp), N, cp))
    return sorted(out, reverse=True)


def auto_detect(x, log=None):
    """What is on the air, from about 1.3 s of it: 200 or 400 carriers, the guard, 120x96 or 180x96,
    and the sync scheme.  The guard (if there is one) gives the symbol length and itself; then the
    receiver tries each format's pilots with each sync scheme and keeps the one whose sequence it
    finds most clearly.  -> dict(fmt, long, cp, sync, score, guard_score) or None."""
    x = np.asarray(x, np.complex64)
    gs = guard_scan(x)
    if gs and gs[0][0] > 30.0:                     # a guard, clearly (real ones score 70+ at 0 dB)
        cands = [(gs[0][1], gs[0][2])]
        # (200 carriers with a 300 guard repeats like 400 with 100 - the same symbol length: try both)
        cands += [(g[1], g[2]) for g in gs[1:] if g[1] + g[2] == gs[0][1] + gs[0][2] and g[0] > 0.5 * gs[0][0]]
    elif gs and gs[0][0] > 10.0:                   # perhaps: try it, and no guard
        cands = [(gs[0][1], gs[0][2]), (NFFT, 0), (2 * NFFT, 0)]
    else:
        cands = [(NFFT, 0), (2 * NFFT, 0)]             # no guard: try both symbol lengths
    strong, weak = [], []
    for N, cp in cands:
        # the FFT length says which: 200 / 400 as they are; the guard taken off it: fixed 12.5 fps;
        # a little less than 200 / 400 otherwise: balanced
        if N in (NFFT, 2 * NFFT):
            kinds, lng = (0,), N == 2 * NFFT
        else:                                            # (video first or balanced: whichever cuts to N)
            kinds, lng = (1, 2), N > NFFT
        for fmt, dense, fixed in [(f, d, k) for f in AUTO_FORMATS for d in ((False, True) if not lng else (False,))
                                  for k in kinds]:
            m = layout(fmt, lng, cp, fixed, dense)
            if fixed and (m.nfft != N or m.fixed_kind != fixed):   # (this one doesn't cut that way)
                continue
            if fixed == 2 and layout(fmt, lng, cp, 1, dense).nfft == N:   # (the same layout twice: once is enough)
                continue
            for sync in SYNC_SCHEMES:
                d = Demodulator(m, cp, False, sync)
                d.eq = "common"
                try:
                    res = d.feed(x)
                except Exception:
                    res = []
                if not res:
                    continue
                q, q2 = float(getattr(d, "sync_q", 0.0)), float(getattr(d, "sync_q2", 1.0))
                ratio = q / max(q2, 1e-3)
                fit = float(np.median([r["snr_est"] for r in res]))
                coh = float(np.median([r["coherence"] for r in res]))
                if log:
                    log("auto: %s %d carriers%s%s guard %d %s: sequence %.2f / %.2f, pilot fit %.1f dB, coherence %.2f"
                        % (fmt, N, {0: "", 1: " (video first)", 2: " (balanced)"}[fixed], " 16 pilots" if dense else "", cp, sync, q, q2, fit, coh))
                c = dict(fmt=fmt, long=lng, fixed=fixed, dense=dense, cp=cp, sync=sync, ratio=ratio, fit=fit, coh=coh,
                         guard_score=gs[0][0] if gs else 0.0)
                # Lab and HxDX: their own sequence found clearly is proof enough (a wrong format or
                # scheme gives no clear peak).  Standard's sequence repeats and never stands out, so
                # it has to show by its pilots fitting.
                nc = float(getattr(d, "sync_nc", 0.0))      # (found a few symbols at a time: a fading channel)
                if sync != "std" and ratio >= 3.0:
                    c["score"] = ratio
                    strong.append(c)
                elif sync != "std" and nc >= 1.6:
                    c["score"] = 1.5 * nc
                    strong.append(c)
                elif coh >= 0.6 and fit >= -12.0:
                    c["score"] = fit + 10.0 * coh
                    weak.append(c)
    pool = strong or weak
    best = max(pool, key=lambda c: c["score"]) if pool else None
    return best


def sync_trial(mode, sync, snr, rng, frames=5, cfo_max=150.0, cp=0, eq="taps", channel=None):
    """One acquisition from cold: a random start delay (up to two frames), frequency offset and
    phase, noise at `snr`; `frames` data frames of random bytes sent.  -> dict:
      first_ok   the first frame out was right (start within 3 samples, frequency within 20 Hz)
      t_lock     seconds of signal (from its start) until the first right frame is out (None: never)
      good       right frames / frames out
      dt, df     timing error (samples) and frequency error (Hz) at the first lock
      q, q2      sync peak and the best rival more than 4 symbols away (0..1)."""
    S = mode.syms
    mod = Modulator(mode, cp, False, sync)
    mod.pat = int(rng.randint(0, len(mod.T) // S)) * S          # start anywhere in the pattern
    dem = Demodulator(mode, cp, False, sync)
    dem.eq = eq
    ch = Channel()
    if channel:
        for k, v in channel.items():
            if k == "fade":
                ch.set_fading(v)
                ch.fader = Fader(v, seed=int(rng.randint(0, 2 ** 31 - 1)))   # a different fade each trial
            else:
                setattr(ch, k, v)
    ch.snr_db, ch.noise_on = float(snr), True
    ch.delay = int(rng.randint(0, 2 * S * (mode.nfft + cp)))
    ch.cfo_hz = float(rng.uniform(-cfo_max, cfo_max))
    ch.phase = float(rng.uniform(0, 2 * np.pi))
    ch.rng = np.random.RandomState(int(rng.randint(0, 2 ** 31 - 1)))
    flen = S * (mode.nfft + cp)
    sent = []
    outs = []
    # the signal starts after the random delay: send enough that every trial gets `frames` frames of it
    for k in range(frames + int(math.ceil(ch.delay / float(flen)))):
        f = rng.randint(0, 256, mode.frame_bytes).astype(np.uint8)
        sent.append(f)
        y = ch.process(mod.modulate(f, np.full(S * mode.abps, 128, np.uint8)))
        for r in dem.feed(y):
            r["t"] = ((k + 1) * flen - ch.delay) / float(FS)     # seconds of signal so far
            r["cfo_err"] = dem.cfo - ch.cfo_hz
            outs.append(r)
    res = dict(first_ok=False, t_lock=None, good=0.0, dt=None, df=None,
               q=getattr(dem, "sync_q", 0.0), q2=getattr(dem, "sync_q2", 0.0), frames=len(outs))
    ok = []
    rr = 1.0 + ch.ppm * 1e-6                           # the clock offset stretches where frames land
    for r in outs:
        k = int(round((r["start"] * rr - ch.delay) / flen))
        dt = r["start"] - (ch.delay + k * flen) / rr
        # right: the frame start within 3 samples and the frequency within 20 Hz (the sync is judged,
        # not what the channel did to the picture bytes)
        good = abs(dt) <= 3 and abs(r["cfo_err"]) < 20.0
        ok.append(good)
        if good and res["t_lock"] is None:
            res["t_lock"] = r["t"]
            res["dt"], res["df"] = float(dt), float(r["cfo_err"])
    if outs:
        res["first_ok"] = bool(ok[0])
        res["good"] = sum(ok) / float(len(ok))
    return res


def sync_point(mode, sync, snr, trials=10, seed=1, **kw):
    """Several cold starts at one SNR -> summary dict."""
    rng = np.random.RandomState(seed)
    rs = [sync_trial(mode, sync, snr, rng, **kw) for _ in range(trials)]
    tl = [r["t_lock"] for r in rs if r["t_lock"] is not None]
    dts = [r["dt"] for r in rs if r["dt"] is not None]
    dfs = [r["df"] for r in rs if r["df"] is not None]
    return dict(snr=snr, first_ok=100.0 * np.mean([r["first_ok"] for r in rs]),
                locked=100.0 * len(tl) / len(rs), good=100.0 * np.mean([r["good"] for r in rs]),
                t_lock=float(np.mean(tl)) if tl else None,
                dt_rms=float(np.sqrt(np.mean(np.square(dts)))) if dts else None,
                df_rms=float(np.sqrt(np.mean(np.square(dfs)))) if dfs else None,
                q=float(np.mean([r["q"] for r in rs])), q2=float(np.mean([r["q2"] for r in rs])),
                margin=float(np.mean([r["q"] - r["q2"] for r in rs])))


# ======================================================================= multi-core workers
# The lab's two heavy stages run in their own processes, so they use their own CPU cores (Python
# threads share one core for Python code): the modem (modulator, 200 kHz output, channel,
# demodulator) and the decoder (pictures, clean-up filters, picture scores).  The window's engine
# feeds them in turn, so the modem works on one frame while the decoder works on the one before.
# Each worker keeps its own state (the demodulator's lock, the decoder's last frame) and answers
# every message.  If processes cannot be started, the same code runs in the engine's thread.

# ----------------------------------------------------------------------- hardware I/O (192 kHz sound device)
# For testing with real hardware: the modulated I/Q leaves through a 192 kHz stereo sound device
# (left = I, right = Q) and/or comes back in through one, in place of the lab's simulated channel.
# Loop: out and back in (a cable, or a transmitter/receiver pair between them).  TX out: the sound
# card drives the hardware while the lab still decodes its simulated channel.  RX in: the lab
# decodes what arrives at the input (an SDR's I/Q, a GNU Radio flowgraph's audio sink).
HW_FS = 192000
HW_MODES = ("Off", "Loop", "TX out", "RX in")
HW_MAX_OFFSET = 44000                     # +-50 kHz of signal + offset must stay inside +-96 kHz
HW_MAX_TRIM = 10000.0                                  # (Hz: the TX and RX frequency trims, +-)


def hw_devices():
    """The sound devices -> (list of dict(name, ins, outs, in192, out192), error or None)."""
    alsa = alsa_devices() + hackrf_devices()
    try:
        import sounddevice as sd
    except Exception as e:
        return alsa, None if alsa else "sounddevice not available: %s" % (str(e).splitlines()[0] if str(e) else type(e).__name__)
    out = list(alsa)
    try:
        apis = [a["name"] for a in sd.query_hostapis()]
        for i, d in enumerate(sd.query_devices()):
            e = dict(name=sd_name(d, apis), ins=int(d.get("max_input_channels", 0)), outs=int(d.get("max_output_channels", 0)),
                     in192=False, out192=False)
            for kind in ("in", "out"):
                if e[kind + "s"] >= 2:
                    try:
                        sd_settings(sd, i, kind, d, apis)
                        e[kind + "192"] = True
                    except Exception:
                        pass
            out.append(e)
    except Exception as e:
        return out, str(e)
    if IS_WIN:                                   # (Windows: WASAPI first - it gives the card's own 192 kHz)
        out.sort(key=lambda e: 0 if "WASAPI" in e["name"] else 1)
    return out, None


IS_WIN = sys.platform.startswith("win")


def sd_name(d, apis):
    """A sounddevice device's name as listed; on Windows with its host API ('... [Windows WASAPI]'), since every
    card shows up once under each (MME, DirectSound, WASAPI, WDM-KS) and only some of them run at 192 kHz."""
    if IS_WIN:
        try:
            return "%s [%s]" % (d["name"], apis[d["hostapi"]])
        except Exception:
            pass
    return d["name"]


def sd_settings(sd, i, kind, d=None, apis=None):
    """Check device i at 192 kHz stereo float; -> extra_settings to open it with (WASAPI: exclusive mode where the
    card allows it - the card's own rate, past the Windows mixer - else shared)."""
    check = sd.check_output_settings if kind == "out" else sd.check_input_settings
    d = d or sd.query_devices(i)
    try:
        api = (apis or [a["name"] for a in sd.query_hostapis()])[d["hostapi"]]
    except Exception:
        api = ""
    if "WASAPI" in api and hasattr(sd, "WasapiSettings"):
        try:
            ex = sd.WasapiSettings(exclusive=True)
            check(device=i, channels=2, samplerate=HW_FS, dtype="float32", extra_settings=ex)
            return ex
        except Exception:
            pass
    check(device=i, channels=2, samplerate=HW_FS, dtype="float32")
    return None


# ---- ALSA direct (Linux): the card itself (hw:C,D) through aplay / arecord, past PulseAudio / PipeWire
# and their mixers, so 192 kHz is the card's own rate and nothing is resampled or mixed on the way.
def alsa_devices():
    """The cards' own PCM devices from aplay -l / arecord -l -> list of dict(name, dev, ins, outs)."""
    import re
    import shutil
    import subprocess
    found = {}
    for tool, key in (("aplay", "outs"), ("arecord", "ins")):
        if shutil.which(tool) is None:
            continue
        try:
            txt = subprocess.run([tool, "-l"], capture_output=True, text=True, timeout=3).stdout
        except Exception:
            continue
        for m in re.finditer(r"card (\d+): (\S+) \[([^\]]*)\], device (\d+): ([^\[]*)\[([^\]]*)\]", txt):
            dev = "hw:%s,%s" % (m.group(1), m.group(4))
            e = found.setdefault(dev, dict(name="ALSA %s - %s - %s" % (dev, m.group(3).strip(), m.group(6).strip()),
                                           dev=dev, ins=0, outs=0, in192=True, out192=True, alsa=True))
            e[key] = 2
    return [found[k] for k in sorted(found)]


def alsa_dev(name):
    """'ALSA hw:0,0 - ...', 'hw:0,0' or 'plughw:1,0' -> the ALSA device (None if not an ALSA name)."""
    if not name:
        return None
    n = name.strip()
    if n.startswith("ALSA "):
        n = n[5:].split(" ")[0]
    return n if n.startswith(("hw:", "plughw:")) else None


def _alsa_err(dev, err):
    e = err.lower()
    if "busy" in e:
        return ("%s is busy: PulseAudio / PipeWire has this card.  Free it: 'Release card' in the 192k devices "
                "window (or pavucontrol > Configuration > the card's profile Off)" % dev)
    if "no such" in e or "cannot find card" in e:
        return "no ALSA device %s (aplay -l / arecord -l list them)" % dev
    if "rate" in e:
        return "%s will not run at 192 kHz: %s" % (dev, err.strip().splitlines()[-1][:120])
    return "%s: %s" % (dev, err.strip().splitlines()[-1][:160] if err.strip() else "would not start")


def alsa_capture_controls(alsa_name):
    """The capture side of the card's ALSA mixer (amixer -c N scontents) -> (card number, list of
    dict(name, kind, value, items)) - the input source, capture level and boosts."""
    import re
    import shutil
    import subprocess
    dev = alsa_dev(alsa_name)
    m = re.match(r"(?:plug)?hw:(\w+)", dev or "")
    if not m or shutil.which("amixer") is None:
        return None, []
    num = m.group(1)
    try:
        txt = subprocess.run(["amixer", "-c", num, "scontents"], capture_output=True, text=True, timeout=5,
                             env=dict(os.environ, LC_ALL="C")).stdout
    except Exception:
        return num, []
    out = []
    for blk in re.split(r"\n(?=Simple mixer control)", txt):
        nm = re.match(r"Simple mixer control '([^']*)',(\d+)", blk)
        if not nm:
            continue
        name = nm.group(1) + ("" if nm.group(2) == "0" else ",%s" % nm.group(2))
        caps = re.search(r"Capabilities:(.*)", blk)
        caps = caps.group(1) if caps else ""
        low = name.lower()
        if not (re.search(r"\bc(volume|switch|enum)\b", caps) or "input source" in low or "capture" in low
                or "boost" in low):
            continue
        items = re.findall(r"'([^']*)'", re.search(r"Items:(.*)", blk).group(1)) if "Items:" in blk else []
        cur = re.search(r"Item0: '([^']*)'", blk)
        if items:
            out.append(dict(name=name, kind="enum", value=cur.group(1) if cur else "?", items=items))
            continue
        v = re.search(r"(?:Front Left|Mono|Left)?:? ?Capture (\d+) \[(\d+)%\](?: \[(-?[\d.]+)dB\])?(?: \[(on|off)\])?", blk)
        if v is None:
            v = re.search(r": (?:Playback |Capture )?(\d+) \[(\d+)%\](?: \[(-?[\d.]+)dB\])?(?: \[(on|off)\])?", blk)
        if v:
            out.append(dict(name=name, kind="level", value="%s%%%s%s" % (v.group(2), (" (%s dB)" % v.group(3)) if v.group(3) else "",
                                                                      (" [%s]" % v.group(4)) if v.group(4) else ""), items=[]))
    return num, out


def alsa_playback_controls(alsa_name):
    """The playback side of the card's ALSA mixer that sets the line out (Master, PCM, Front, Line
    Out ...) and the codec's analogue Loopback Mixing -> list of dict(name, kind, value, db, pct, sw, items)."""
    import re
    import shutil
    import subprocess
    dev = alsa_dev(alsa_name)
    m = re.match(r"(?:plug)?hw:(\w+)", dev or "")
    if not m or shutil.which("amixer") is None:
        return []
    try:
        txt = subprocess.run(["amixer", "-c", m.group(1), "scontents"], capture_output=True, text=True, timeout=5,
                             env=dict(os.environ, LC_ALL="C")).stdout
    except Exception:
        return []
    out = []
    for blk in re.split(r"\n(?=Simple mixer control)", txt):
        nm = re.match(r"Simple mixer control '([^']*)',(\d+)", blk)
        if not nm or nm.group(2) != "0":
            continue
        name = nm.group(1)
        low = name.lower()
        if "loopback" in low and "Items:" in blk:
            items = re.findall(r"'([^']*)'", re.search(r"Items:(.*)", blk).group(1))
            cur = re.search(r"Item0: '([^']*)'", blk)
            out.append(dict(name=name, kind="enum", value=cur.group(1) if cur else "?", items=items, db=None, pct=None, sw=None))
            continue
        if low not in ("master", "pcm", "front", "line out", "speaker", "headphone"):
            continue
        v = re.search(r"Playback (\d+) \[(\d+)%\](?: \[(-?[\d.]+)dB\])?(?: \[(on|off)\])?", blk)
        if v:
            out.append(dict(name=name, kind="level", value="%s%%%s%s" % (v.group(2), (" (%s dB)" % v.group(3)) if v.group(3) else "",
                                                                      (" [%s]" % v.group(4)) if v.group(4) else ""),
                            db=float(v.group(3)) if v.group(3) else None, pct=int(v.group(2)), sw=v.group(4), items=[]))
    return out


def alsa_set_enum(num, name, item):
    import subprocess
    try:
        r = subprocess.run(["amixer", "-c", str(num), "sset", name, item], capture_output=True, text=True, timeout=5)
        return None if r.returncode == 0 else (r.stderr.strip() or "amixer failed")
    except Exception as e:
        return str(e)


def alsa_adjust(num, name, db_change=None, value=None):
    """amixer -c num sset name (by db_change dB, or to value) -> error text or None."""
    import subprocess
    arg = value if value is not None else ("%.0fdB%s" % (abs(db_change), "+" if db_change > 0 else "-"))
    try:
        r = subprocess.run(["amixer", "-c", str(num), "sset", name, arg], capture_output=True, text=True, timeout=5)
        return None if r.returncode == 0 else (r.stderr.strip() or "amixer failed")
    except Exception as e:
        return str(e)


def pulse_card(alsa_name):
    """The PulseAudio / PipeWire card behind an ALSA device ('hw:3,0', 'ALSA hw:3,0 - ...') ->
    (card name, active profile) or (None, reason)."""
    import re
    import shutil
    import subprocess
    dev = alsa_dev(alsa_name)
    if dev is None:
        return None, "not an ALSA hw: device"
    m = re.match(r"(?:plug)?hw:(\w+)", dev)
    num = m.group(1) if m else None
    if shutil.which("pactl") is None:
        return None, "pactl not found (sudo apt install pulseaudio-utils)"
    try:
        txt = subprocess.run(["pactl", "list", "cards"], capture_output=True, text=True, timeout=5,
                             env=dict(os.environ, LC_ALL="C")).stdout
    except Exception as e:
        return None, "pactl: %s" % e
    for blk in re.split(r"\n(?=Card #)", txt):
        nm = re.search(r"^\s*Name:\s*(\S+)", blk, re.M)
        cd = re.search(r'alsa\.card\s*=\s*"([^"]*)"', blk)
        ap = re.search(r"^\s*Active Profile:\s*(\S+)", blk, re.M)
        if nm and cd and cd.group(1) == num:
            return nm.group(1), (ap.group(1) if ap else "")
    return None, "no PulseAudio / PipeWire card for ALSA card %s (it may not be holding it)" % num


def pulse_set_profile(card, profile):
    """pactl set-card-profile -> error text or None."""
    import subprocess
    try:
        r = subprocess.run(["pactl", "set-card-profile", card, profile], capture_output=True, text=True, timeout=5)
        return None if r.returncode == 0 else (r.stderr.strip() or "pactl failed")
    except Exception as e:
        return str(e)


class AlsaStream:
    """A 192 kHz stereo stream on an ALSA device by way of aplay / arecord, with sounddevice's callback
    form (callback(data, frames, time, status), float32 frames x 2), so HwIO and the card check use
    it in the same way.  hw: devices give the card's own rate or refuse - never a resampled one."""

    class _Status:
        output_underflow = False
        input_overflow = False

    def __init__(self, kind, dev, callback, fs=HW_FS, blk=2048):
        self.kind, self.dev, self.cb, self.fs, self.blk = kind, dev, callback, fs, blk
        self.p = None
        self.run = False
        self.err = []

    def start(self):
        import shutil
        import subprocess
        import threading
        tool = "aplay" if self.kind == "out" else "arecord"
        if shutil.which(tool) is None:
            raise RuntimeError("%s not found (sudo apt install alsa-utils)" % tool)
        last = ""
        for fmt, dt in (("S32_LE", np.int32), ("S24_3LE", "s24"), ("S16_LE", np.int16)):
            cmd = [tool, "-q", "-D", self.dev, "-t", "raw", "-f", fmt, "-r", str(self.fs), "-c", "2",
                   "--buffer-time=200000", "--period-time=10000"]
            if self.kind == "in":
                cmd.append("-")
            self.p = subprocess.Popen(cmd, stdin=subprocess.PIPE if self.kind == "out" else subprocess.DEVNULL,
                                      stdout=subprocess.PIPE if self.kind == "in" else subprocess.DEVNULL,
                                      stderr=subprocess.PIPE, bufsize=0)
            self.err = []
            th = threading.Thread(target=self._stderr, daemon=True)
            th.start()
            nbytes = 3 if dt == "s24" else np.dtype(dt).itemsize
            if self.kind == "out":                       # (aplay opens the card on its first data)
                try:
                    self.p.stdin.write(bytes(self.blk * 2 * nbytes))
                except Exception:
                    pass
            t_end = time.time() + 0.6
            while time.time() < t_end and self.p.poll() is None and not self.err:
                time.sleep(0.02)
            if self.p.poll() is not None:
                th.join(0.5)                             # (it has gone: let its last words be read)
            msg = "\n".join(self.err)
            if self.p.poll() is None and "not accurate" not in msg.lower():
                self.dt, self.fmt = dt, fmt
                self.scale = float(2 ** 23 - 1) if dt == "s24" else float(np.iinfo(dt).max)
                break
            last = msg
            try:
                self.p.kill()
            except Exception:
                pass
            self.p = None
            if "format" not in msg.lower():
                break
        if self.p is None:
            raise RuntimeError(_alsa_err(self.dev, last or "would not start"))
        self.run = True
        threading.Thread(target=self._loop, daemon=True, name="nbtv-alsa-%s" % self.kind).start()

    def _stderr(self):
        try:
            for line in iter(self.p.stderr.readline, b""):
                self.err.append(line.decode("utf8", "ignore").strip())
        except Exception:
            pass

    def _loop(self):
        st = self._Status()
        s24 = self.dt == "s24"
        n, sz = self.blk, (3 if s24 else np.dtype(self.dt).itemsize) * 2
        try:
            while self.run:
                if self.kind == "out":
                    buf = np.zeros((n, 2), np.float32)
                    self.cb(buf, n, None, st)
                    # (in float64: float32 rounds 2^31-1 up to 2^31, which wrapped to the far end - a click)
                    v = np.clip(np.round(buf.astype(np.float64) * self.scale), -self.scale, self.scale)
                    if s24:                               # (packed 24 bit: three bytes a sample)
                        b = v.astype("<i4").reshape(-1, 1).view(np.uint8)[:, :3]
                        self.p.stdin.write(np.ascontiguousarray(b).tobytes())
                    else:
                        self.p.stdin.write(v.astype(self.dt).tobytes())
                else:
                    raw = b""
                    while len(raw) < n * sz and self.run:
                        part = self.p.stdout.read(n * sz - len(raw))
                        if not part:
                            raise EOFError
                        raw += part
                    if s24:
                        b = np.frombuffer(raw, np.uint8).reshape(-1, 3).astype(np.int32)
                        v = b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16)
                        v = np.where(v & 0x800000, v - 0x1000000, v)
                        x = (v.reshape(-1, 2).astype(np.float32) / self.scale)
                    else:
                        x = ((np.frombuffer(raw, self.dt).reshape(-1, 2).astype(np.float32) - getattr(self, "off", 0.0))
                             / self.scale)
                    self.cb(x, len(x), None, st)
        except Exception:
            if self.run:
                self.err.append("stream stopped")
        self.run = False

    def stop(self):
        self.run = False
        if self.p is not None:
            try:
                self.p.kill()
            except Exception:
                pass

    def close(self):
        pass


# ---- HackRF (hackrf-tools): I/Q at 2 Msps, 8 bit, half duplex - one unit sends or receives, so a loop
# takes two (TX out / RX in work with one).  20 x the modem's 100 kHz, by FFT both ways.
HACKRF_FS = 2000000


class StreamFFTResample:
    """100 kHz <-> R x 100 kHz for a stream, exactly band-limited at +-50 kHz (as the 2x IFFT: the
    edge carriers whole), by FFT over fixed blocks with ov samples (at 100 kHz) either side so the
    joins don't show.  up: 100 kHz in, R x out; down: R x in, 100 kHz out."""

    def __init__(self, R, up=True, ov=1024, block=16384):
        self.R, self.up, self.ov, self.n = int(R), bool(up), int(ov), int(block)   # n: 100 kHz samples a block
        self.buf = np.zeros(self.ov * (1 if up else self.R), np.complex64)

    def process(self, x):
        R, ov, n = self.R, self.ov, self.n
        b = np.concatenate([self.buf, np.asarray(x, np.complex64)])
        out = []
        if self.up:
            pos = 0
            while len(b) - pos >= n:
                X = np.fft.fft(b[pos:pos + n])
                Y = np.zeros(n * R, np.complex128)
                Y[:n // 2] = X[:n // 2]
                Y[-(n - n // 2):] = X[n // 2:]
                y = np.fft.ifft(Y) * R
                out.append(y[ov * R:(n - ov) * R].astype(np.complex64))
                pos += n - 2 * ov
            self.buf = b[pos:]
        else:
            L, oi, pos = n * R, ov * R, 0
            while len(b) - pos >= L:
                X = np.fft.fft(b[pos:pos + L])
                Y = np.concatenate([X[:n // 2], X[-(n - n // 2):]]) / R
                y = np.fft.ifft(Y)
                out.append(y[ov:n - ov].astype(np.complex64))
                pos += L - 2 * oi
            self.buf = b[pos:]
        return np.concatenate(out) if out else np.zeros(0, np.complex64)


def hackrf_devices():
    """HackRFs on USB (hackrf_info) -> list of dict(name, serial, ins, outs, hackrf=True)."""
    import re
    import shutil
    import subprocess
    if shutil.which("hackrf_info") is None:
        return []
    try:
        txt = subprocess.run(["hackrf_info"], capture_output=True, text=True, timeout=6).stdout
    except Exception:
        return []
    out = []
    for blk in re.split(r"\n(?=Index:)", txt):
        m = re.search(r"Serial number:\s*(?:0x)?([0-9a-fA-F]+)", blk)
        if not m:
            continue
        ser = m.group(1).lower()
        board = re.search(r"Board ID Number:\s*\d+\s*\(([^)]*)\)", blk)
        out.append(dict(name="HackRF %s - %s" % (ser.lstrip("0")[-16:] or "0", board.group(1) if board else "HackRF"),
                        serial=ser, ins=2, outs=2, in192=True, out192=True, hackrf=True))
    return out


def hackrf_dev(name):
    """'HackRF <serial> - ...' -> the serial (as hackrf_transfer -d takes it), or None.  Just 'HackRF':
    "" (the first one found - hackrf_transfer with no -d)."""
    if name and name.strip() == "HackRF":
        return ""
    if not name or not name.strip().startswith("HackRF "):
        return None
    tail = name.strip()[7:].split(" ")[0].lower()
    for d in hackrf_devices():
        if d["serial"].endswith(tail):
            return d["serial"]
    return tail


def _hackrf_err(ser, err):
    e = err.lower()
    if "not_found" in e or "not found" in e or "no hackrf" in e:
        return "HackRF %s not found (hackrf_info lists them)" % (ser or "")
    if "busy" in e or "access" in e:
        return ("HackRF %s is busy - another program has it (GNU Radio, SDR++, another hackrf_transfer), or it is "
                "the same unit for TX and RX (it is half duplex)" % (ser or ""))
    return "HackRF %s: %s" % (ser or "", err.strip().splitlines()[-1][:160] if err.strip() else "would not start")


class HackRFStream(AlsaStream):
    """A HackRF sending or receiving through hackrf_transfer (stdin / stdout, signed 8-bit I/Q) at
    2 Msps, with the same callback form as the sound card streams: frames x 2 float32 = I, Q."""

    def __init__(self, kind, serial, callback, rf):
        AlsaStream.__init__(self, kind, serial, callback, HACKRF_FS, 16384)
        self.rf = dict(rf)

    def start(self):
        import shutil
        import subprocess
        import threading
        if shutil.which("hackrf_transfer") is None:
            raise RuntimeError("hackrf_transfer not found (sudo apt install hackrf)")
        r = self.rf
        f = int(round(r["freq"] - r["lo_off"]))
        cmd = ["hackrf_transfer", "-f", str(f), "-s", str(HACKRF_FS), "-b", "1750000"]
        if self.kind == "out":
            cmd = cmd[:1] + ["-t", "-"] + cmd[1:] + ["-x", str(int(r["txvga"])), "-a", "1" if r["txamp"] else "0"]
        else:
            cmd = cmd[:1] + ["-r", "-"] + cmd[1:] + ["-l", str(int(r["lna"]) // 8 * 8), "-g", str(int(r["vga"]) // 2 * 2),
                                                     "-a", "1" if r["rxamp"] else "0"]
        if self.dev:
            cmd += ["-d", self.dev]
        self.p = subprocess.Popen(cmd, stdin=subprocess.PIPE if self.kind == "out" else subprocess.DEVNULL,
                                  stdout=subprocess.PIPE if self.kind == "in" else subprocess.DEVNULL,
                                  stderr=subprocess.PIPE, bufsize=0)
        self.err = []
        th = threading.Thread(target=self._stderr, daemon=True)
        th.start()
        if self.kind == "out":
            try:
                self.p.stdin.write(bytes(self.blk * 2))
            except Exception:
                pass
        t_end = time.time() + 1.2
        while time.time() < t_end and self.p.poll() is None:
            if any(("failed" in l.lower() or "error" in l.lower()) for l in self.err):
                break
            time.sleep(0.02)
        if self.p.poll() is not None or any(("failed" in l.lower()) for l in self.err):
            th.join(0.5)
            msg = "\n".join(self.err)
            try:
                self.p.kill()
            except Exception:
                pass
            self.p = None
            raise RuntimeError(_hackrf_err(self.dev, msg or "would not start"))
        self.dt, self.fmt, self.scale = np.int8, "IQ8", 127.0
        self.run = True
        threading.Thread(target=self._loop, daemon=True, name="nbtv-hackrf-%s" % self.kind).start()


def hackrf_rf(c):
    """The SDR's settings (HackRF and the other SDRs): frequency, LO offset, gains, amps, RX frequency trim."""
    return dict(freq=1e6 * float(c.get("hw_freq", 29.25)), lo_off=1e3 * float(c.get("hw_lo_off", 250.0)),
                txvga=int(c.get("hw_txvga", 20)), txamp=bool(c.get("hw_txamp", 0)), lna=int(c.get("hw_lna", 16)),
                vga=int(c.get("hw_vga", 20)), rxamp=bool(c.get("hw_rxamp", 0)), rx_trim=float(c.get("hw_rx_trim", 0.0)),
                rtl_gain=float(c.get("rtl_gain", 30.0)), rtl_ppm=int(c.get("rtl_ppm", 0)), rtl_hf=str(c.get("rtl_hf", "V4 / built-in HF")),
                airspy_lna=bool(c.get("airspy_lna", 0)), airspy_agc=bool(c.get("airspy_agc", 1)), airspy_att=int(c.get("airspy_att", 0)),
                soapy_gain=float(c.get("soapy_gain", 30.0)), soapy_ant=str(c.get("soapy_ant", "")))


# ---- the other SDRs (NBTV SDR): RTL-SDR and Airspy HF+ (receive only, through their own tools), and any radio with
# a SoapySDR driver (SDRplay, LimeSDR, ...) through SoapySDR's Python module.  2 Msps ones go the HackRF's way
# (20 x the modem's rate, the LO offset put back in software); the Airspy HF+ runs at 192 kHz, the sound card's way.
RTL_HF = ("V4 / built-in HF", "V3 direct sampling", "Upconverter 125 MHz")


def iq_kind(name):
    """'hackrf', 'rtl', 'airspy', 'soapy' - or None for a sound card."""
    n = (name or "").strip()
    if hackrf_dev(n) is not None:
        return "hackrf"
    if n.startswith("RTL-SDR"):
        return "rtl"
    if n.startswith("Airspy HF+"):
        return "airspy"
    if n.startswith("SoapySDR"):
        return "soapy"
    return None


def wide_dev(name):
    """A 2 Msps SDR (the HackRF's path)?"""
    return iq_kind(name) in ("hackrf", "rtl", "soapy")


class RtlStream(AlsaStream):
    """An RTL-SDR receiving through rtl_sdr (unsigned 8-bit I/Q) at 2 Msps.  HF: the V4 has it built in, a V3 uses
    direct sampling (-D 2), or an upconverter in front (+125 MHz)."""

    def __init__(self, kind, name, callback, rf):
        if kind != "in":
            raise RuntimeError("an RTL-SDR can only receive")
        AlsaStream.__init__(self, kind, name, callback, HACKRF_FS, 16384)
        self.rf = dict(rf)

    def start(self):
        import shutil
        import subprocess
        import threading
        if shutil.which("rtl_sdr") is None:
            raise RuntimeError("rtl_sdr not found (sudo apt install rtl-sdr)")
        r = self.rf
        f = int(round(r["freq"] - r["lo_off"]))
        cmd = ["rtl_sdr"]
        if r["rtl_hf"].startswith("Upconverter"):
            f += 125000000
        elif r["rtl_hf"].startswith("V3") and f < 28800000:
            cmd += ["-D", "2"]
        idx = (self.dev.split("#")[1].strip() if "#" in self.dev else "0") or "0"
        cmd += ["-f", str(f), "-s", str(HACKRF_FS), "-d", idx]
        if r["rtl_gain"] > 0:
            cmd += ["-g", "%.1f" % r["rtl_gain"]]
        if r["rtl_ppm"]:
            cmd += ["-p", str(r["rtl_ppm"])]
        cmd += ["-"]
        self.p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        self.err = []
        threading.Thread(target=self._stderr, daemon=True).start()
        time.sleep(0.8)
        if self.p.poll() is not None:
            msg = "\n".join(self.err)
            self.p = None
            raise RuntimeError("RTL-SDR: %s" % ((msg.strip().splitlines() or ["would not start"])[-1][:160]))
        self.dt, self.fmt, self.scale, self.off = np.uint8, "U8", 128.0, 127.5
        self.run = True
        threading.Thread(target=self._loop, daemon=True, name="nbtv-rtl").start()


class AirspyStream(AlsaStream):
    """An Airspy HF+ / HF+ Discovery receiving through airspyhf_rx (float I/Q) at 192 kHz - the sound card's rate."""

    def __init__(self, kind, name, callback, rf):
        if kind != "in":
            raise RuntimeError("an Airspy HF+ can only receive")
        AlsaStream.__init__(self, kind, name, callback, HW_FS, 4096)
        self.rf = dict(rf)

    def start(self):
        import shutil
        import subprocess
        import threading
        if shutil.which("airspyhf_rx") is None:
            raise RuntimeError("airspyhf_rx not found (sudo apt install airspyhf)")
        r = self.rf
        cmd = ["airspyhf_rx", "-f", "%.6f" % (r["freq"] / 1e6), "-a", str(HW_FS), "-r", "stdout",
               "-m", "on" if r["airspy_lna"] else "off", "-g", "on" if r["airspy_agc"] else "off"]
        if r["airspy_att"]:
            cmd += ["-t", str(int(r["airspy_att"]) // 6)]
        ser = self.dev[len("Airspy HF+"):].strip()
        if ser:
            cmd += ["-s", ser]
        self.p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        self.err = []
        threading.Thread(target=self._stderr, daemon=True).start()
        time.sleep(0.8)
        if self.p.poll() is not None:
            msg = "\n".join(self.err)
            self.p = None
            raise RuntimeError("Airspy HF+: %s" % ((msg.strip().splitlines() or ["would not start"])[-1][:160]))
        self.dt, self.fmt, self.scale, self.off = np.float32, "F32", 1.0, 0.0
        self.run = True
        threading.Thread(target=self._loop, daemon=True, name="nbtv-airspy").start()


class SoapyStream:
    """Any radio with a SoapySDR driver (SDRplay RSPs, LimeSDR, ...): 2 Msps complex float, receive or send, with
    the sound card streams' callback form.  Needs python3-soapysdr and the radio's module."""

    def __init__(self, kind, name, callback, rf):
        self.kind, self.cb, self.rf = kind, callback, dict(rf)
        self.args = name[len("SoapySDR"):].strip()
        self.run = False
        self.err = []
        self.p = None
        self.dev = self.st = None

    class _Status:
        input_overflow = output_underflow = False

    def start(self):
        import threading
        try:
            import SoapySDR
            from SoapySDR import SOAPY_SDR_RX, SOAPY_SDR_TX, SOAPY_SDR_CF32
        except ImportError:
            raise RuntimeError("SoapySDR's Python module not found (sudo apt install python3-soapysdr, and the radio's "
                               "module, e.g. SoapySDRPlay3 for an SDRplay)")
        try:
            self.dev = SoapySDR.Device(self.args)
        except Exception as e:
            raise RuntimeError("SoapySDR '%s': %s" % (self.args or "first radio", str(e)[:160] or "no radio found"))
        d = SOAPY_SDR_TX if self.kind == "out" else SOAPY_SDR_RX
        r = self.rf
        self.dev.setSampleRate(d, 0, float(HACKRF_FS))
        self.dev.setFrequency(d, 0, float(r["freq"] - r["lo_off"]))
        try:
            self.dev.setGain(d, 0, float(r["soapy_gain"]))
        except Exception:
            pass
        if r.get("soapy_ant"):
            try:
                self.dev.setAntenna(d, 0, r["soapy_ant"])
            except Exception as e:
                self.err.append("antenna: %s" % e)
        self.st = self.dev.setupStream(d, SOAPY_SDR_CF32)
        self.dev.activateStream(self.st)
        self.p = True                                       # (for HwIO.status: a stream that has stopped says why)
        self.run = True
        threading.Thread(target=self._loop, daemon=True, name="nbtv-soapy-%s" % self.kind).start()

    def _loop(self):
        st = self._Status()
        n = 16384
        buf = np.zeros(n, np.complex64)
        try:
            while self.run:
                if self.kind == "out":
                    x = np.zeros((n, 2), np.float32)
                    self.cb(x, n, None, st)
                    z = (x[:, 0] + 1j * x[:, 1]).astype(np.complex64)
                    k = 0
                    while k < n and self.run:
                        sr = self.dev.writeStream(self.st, [z[k:]], n - k, timeoutUs=1000000)
                        if sr.ret <= 0:
                            raise RuntimeError("writeStream %d" % sr.ret)
                        k += sr.ret
                else:
                    sr = self.dev.readStream(self.st, [buf], n, timeoutUs=1000000)
                    if sr.ret <= 0:
                        if sr.ret == -4:                    # (overflow: carry on)
                            continue
                        raise RuntimeError("readStream %d" % sr.ret)
                    z = buf[:sr.ret]
                    self.cb(np.stack([z.real, z.imag], 1).astype(np.float32), sr.ret, None, st)
        except Exception as e:
            if self.run:
                self.err.append("stream stopped: %s" % e)
        self.run = False

    def stop(self):
        self.run = False

    def close(self):
        self.run = False
        time.sleep(0.05)
        try:
            if self.st is not None:
                self.dev.deactivateStream(self.st)
                self.dev.closeStream(self.st)
        except Exception:
            pass
        self.st = self.dev = None


def open_stream(kind, name, callback, rf=None):
    """A stereo float (I, Q) stream on the named device: a HackRF ('HackRF <serial>', 2 Msps, rf =
    its settings), ALSA direct for 'ALSA hw:..' / 'hw:..' names, otherwise sounddevice (PortAudio, at
    192 kHz).  Not started."""
    ser = hackrf_dev(name)
    if ser is not None:
        return HackRFStream(kind, ser, callback, rf or hackrf_rf({}))
    kd = iq_kind(name)
    if kd == "rtl":
        return RtlStream(kind, name.strip(), callback, rf or hackrf_rf({}))
    if kd == "airspy":
        return AirspyStream(kind, name.strip(), callback, rf or hackrf_rf({}))
    if kd == "soapy":
        return SoapyStream(kind, name.strip(), callback, rf or hackrf_rf({}))
    dev = alsa_dev(name)
    if dev is not None:
        return AlsaStream(kind, dev, callback)
    import sounddevice as sd
    i = HwIO._dev(sd, name, "output" if kind == "out" else "input")
    ex = sd_settings(sd, i, kind) if i is not None else None
    kw = dict(extra_settings=ex) if ex is not None else {}
    if kind == "out":
        return sd.OutputStream(samplerate=HW_FS, channels=2, dtype="float32", device=i, latency="high", callback=callback, **kw)
    return sd.InputStream(samplerate=HW_FS, channels=2, dtype="float32", device=i, latency="high", callback=callback, **kw)


class IQResampler:
    """Rational L/M resampling of a complex stream, block by block with no joins (polyphase,
    Kaiser-windowed sinc; fc = the -6 dB point in Hz).  The card's TX side is 200 kHz -> 192 kHz
    (L=24, M=25), from the lab's 2x IFFT stream, so nothing is lost at the band edges; RX is
    192 kHz -> 100 kHz (L=25, M=48), flat to past +-50 kHz - what lies just beyond folds back
    onto the edge carriers exactly as it does in a 100 kHz receiver."""

    def __init__(self, L, M, fs_in, taps, fc, beta=6.0):
        g = math.gcd(L, M)
        self.L, self.M, self.K = L // g, M // g, taps
        L = self.L
        fs_up = fs_in * L
        n = np.arange(L * taps) - (L * taps - 1) / 2.0
        h = 2.0 * fc / fs_up * np.sinc(2.0 * fc / fs_up * n) * np.kaiser(L * taps, beta) * L
        # E[p, k] = h[p + k L]; reversed in k so a window x[i0-K+1 .. i0] multiplies straight across
        self.E = h.reshape(taps, L).T[:, ::-1].astype(np.float32).copy()
        self.reset()

    def reset(self):
        self.hist = np.zeros(self.K - 1, np.complex64)
        self.n_in = 0                       # inputs taken so far
        self.j = 0                          # next output sample

    def delay_out(self):
        """The filter's delay, in output samples."""
        return (self.L * self.K - 1) / 2.0 / self.M

    def process(self, x):
        x = np.asarray(x, np.complex64)
        if not len(x):
            return np.zeros(0, np.complex64)
        before = self.n_in
        xb = np.concatenate([self.hist, x])
        self.n_in += len(x)
        # outputs whose newest input is now here: j M // L <= n_in - 1, i.e. j M < n_in L
        j_end = -(-self.n_in * self.L // self.M)
        js = np.arange(self.j, j_end, dtype=np.int64)
        self.j = j_end
        self.hist = xb[len(xb) - (self.K - 1):].copy()
        if not len(js):
            return np.zeros(0, np.complex64)
        W = np.lib.stride_tricks.sliding_window_view(xb, self.K)
        u = js * self.M
        rows = u // self.L - before                 # = (i0 - g0) - (K - 1)
        ph = u % self.L
        y = np.empty(len(js), np.complex64)
        for a in range(0, len(js), 8192):
            b = a + 8192
            y[a:b] = np.einsum("ij,ij->i", W[rows[a:b]], self.E[ph[a:b]])
        return y


class StreamInterp2:
    """interp2 for a stream: 100 kHz -> 200 kHz band-limited exactly at +-50 kHz (the edge carriers
    kept whole), done over each block with 2048 samples either side so the joins don't show;
    the output comes 2048 input samples (20 ms) late."""

    def __init__(self, ov=2048):
        self.ov = ov
        self.buf = np.zeros(ov, np.complex64)

    def process(self, x):
        b = np.concatenate([self.buf, np.asarray(x, np.complex64)])
        o = self.ov
        if len(b) < 3 * o:
            self.buf = b
            return np.zeros(0, np.complex64)
        y = interp2(b)[2 * o:2 * (len(b) - o)]
        self.buf = b[len(b) - 2 * o:]
        return y


class IQTrim:
    """The card's left / right (I / Q) put back in step: the left input delayed by skew samples (a
    fraction of one: a Kaiser-windowed sinc), the right one scaled by -gain_db; both channels go
    through the same 15-sample delay, so nothing else moves.  Streams in blocks with no joins."""

    TAPS = 31

    def __init__(self, skew=0.0, gain_db=0.0):
        self.set(skew, gain_db)
        self.hist = np.zeros((self.TAPS - 1, 2), np.float64)

    def set(self, skew, gain_db):
        self.skew, self.gain_db = float(skew), float(gain_db)
        k = np.arange(self.TAPS) - (self.TAPS - 1) / 2.0
        w = np.kaiser(self.TAPS, 6.0)
        hl = np.sinc(k - self.skew) * w
        hr = np.sinc(k) * w
        self.h = np.stack([hl / hl.sum(), hr / hr.sum() * 10 ** (-self.gain_db / 20.0)], axis=1)

    def process(self, s):
        s = np.asarray(s, np.float64)
        if not len(s):
            return s.astype(np.float32)
        b = np.concatenate([self.hist, s])
        self.hist = b[len(b) - (self.TAPS - 1):]
        out = np.empty_like(s)
        for ch in (0, 1):
            out[:, ch] = np.convolve(b[:, ch], self.h[::-1, ch][::-1], mode="valid")[:len(s)]
        return out.astype(np.float32)


def iq_image_db(skew_s, gain_db, f):
    """How far below a carrier at f (Hz) its mirror image sits, for an I/Q timing difference
    skew_s (seconds) and gain difference gain_db: the image rejection."""
    th = 2 * np.pi * f * skew_s
    g = 10 ** (gain_db / 20.0)
    return 10 * np.log10((1 + 2 * g * np.cos(th) + g * g) / max(1 - 2 * g * np.cos(th) + g * g, 1e-15))


class HwIO:
    """The sound device(s): a jitter buffer feeding the output, a ring catching the input, and the
    conversions between the modem's 100 kHz complex samples and the card's 192 kHz stereo."""

    def __init__(self):
        self.key = None
        self.ostream = self.istream = None
        self.err = None
        self.mode = "Off"
        self.olen = 0
        self.lock = __import__("threading").Lock()
        self.reset_counts()

    def reset_counts(self):
        self.under = self.over = self.late = 0
        self.out_clip = self.in_clip = 0.0
        self.in_dbfs = self.out_dbfs = -120.0
        self.tx_rms = None
        self.rx_rms = None
        self.rx_gain = None

    # ---- set up
    def configure(self, c):
        mode = c.get("hw_mode", "Off")
        if mode not in HW_MODES:
            mode = "Off"
        self.level_db = float(c.get("hw_level", -18.0))
        self.swap = bool(c.get("hw_swap", 0))
        self.offset = max(-HW_MAX_OFFSET, min(HW_MAX_OFFSET, 1000.0 * float(c.get("hw_offset", 0.0))))
        # (NBTV SDR 1.17) frequency trims, any hardware, live: TX moved up by tx_trim; what comes in moved down
        # by rx_trim (Hz) - two pieces of hardware a little apart in frequency put back on the channel
        self.tx_trim = max(-HW_MAX_TRIM, min(HW_MAX_TRIM, float(c.get("hw_tx_trim", 0.0))))
        self.rx_trim = max(-HW_MAX_TRIM, min(HW_MAX_TRIM, float(c.get("hw_rx_trim", 0.0))))
        # (NBTV SDR 1.19) a swapped I/Q taken out on receive: 0 as it comes; 1 the RX's I/Q swapped (the input
        # mirrored as it comes); 2 the TX's swapped, at this station's TX offset (the signal mirrored on the
        # channel, then moved back by twice the TX's offset - a swapped TX puts it on its image); 3 the TX's
        # swapped with no offset (another station's); 4 both the RX's and the TX's (1 then 2: they cancel only
        # when the TX and RX offsets are the same)
        self.rx_inv = int(c.get("hw_rx_inv", 0)) if int(c.get("hw_rx_inv", 0)) in (0, 1, 2, 3, 4) else 0
        self.buf_s = max(0.05, float(c.get("hw_buf", 300)) / 1000.0)
        sk, gd = float(c.get("hw_skew", 0.0)), float(c.get("hw_qgain", 0.0))
        self.trim_on = bool(c.get("hw_trim", 1)) and (abs(sk) > 1e-4 or abs(gd) > 1e-3)
        if getattr(self, "trim", None) is None:
            self.trim = IQTrim(sk, gd)
        elif (self.trim.skew, self.trim.gain_db) != (sk, gd):
            self.trim.set(sk, gd)
        self.rf = hackrf_rf(c)
        self.lo_rm = bool(c.get("hw_lo_rm", 1))              # (1.32) the SDR's LO spike taken out on receive
        rfkey = tuple(sorted((k, v) for k, v in self.rf.items() if k != "rx_trim"))
        uses_rf = iq_kind(c.get("hw_out")) is not None or iq_kind(c.get("hw_in")) is not None
        key = (mode, c.get("hw_out", "Default"), c.get("hw_in", "Default"), rfkey if uses_rf else None)
        self.last_c = dict(c)
        self.t_try = time.time()
        if key == self.key and (mode == "Off" or self.err is None):
            return False
        self.close()
        self.key, self.mode = key, mode
        self.err = None
        if mode == "Off":
            return True
        try:
            self._open(mode, key[1], key[2])
        except Exception as e:
            self.close()
            self.mode = mode
            self.err = "%s: %s" % (type(e).__name__, str(e).splitlines()[0][:400] if str(e) else "")
        return True

    def retry(self):
        """A card that was busy (the sound server still letting go after Release card): try it
        again every 2 s.  -> True if it has just opened."""
        if self.err is None or "busy" not in self.err or self.mode == "Off" or time.time() - getattr(self, "t_try", 0) < 2.0:
            return False
        self.key = None
        self.configure(self.last_c)
        return self.err is None

    @staticmethod
    def _dev(sd, name, kind):
        if name in (None, "", "Default"):
            return None
        apis = [a["name"] for a in sd.query_hostapis()]
        for i, d in enumerate(sd.query_devices()):          # (the name as listed - on Windows with its host API)
            if sd_name(d, apis) == name and d.get("max_%s_channels" % kind, 0) >= 2:
                return i
        bare = [i for i, d in enumerate(sd.query_devices())  # (an older setting: the bare name - the one of
                if d["name"] == name and d.get("max_%s_channels" % kind, 0) >= 2]   # its entries that runs at 192 kHz)
        for i in bare:
            try:
                sd_settings(sd, i, "out" if kind == "output" else "in")
                return i
            except Exception:
                pass
        if bare:
            return bare[0]
        raise RuntimeError("%s device '%s' not found" % (kind, name))

    def _open(self, mode, out_name, in_name):
        self.tx_rf = wide_dev(out_name)
        self.rx_rf = wide_dev(in_name)
        self.rx_card = iq_kind(in_name) is None                # (the I/Q trim is a sound card's)
        self.tx_card = iq_kind(out_name) is None               # (and Swap I/Q: a card's, not an SDR's)
        if mode == "Loop" and self.tx_rf and self.rx_rf and hackrf_dev(out_name) == hackrf_dev(in_name):
            raise RuntimeError("one HackRF cannot send and receive at once (it is half duplex): a loop takes two "
                               "HackRFs (or a HackRF and another receiver), or use TX out / RX in")
        self.tx_fs = HACKRF_FS if self.tx_rf else HW_FS
        self.rx_fs = HACKRF_FS if self.rx_rf else HW_FS
        self.i2 = StreamInterp2()
        self.up = IQResampler(24, 25, 2 * FS, 32, 75000.0)
        self.down = IQResampler(25, 48, HW_FS, 96, 54500.0, 5.0)
        self.up_rf = StreamFFTResample(HACKRF_FS // FS, up=True)
        self.down_rf = StreamFFTResample(HACKRF_FS // FS, up=False)
        self.tx_ph = self.rx_ph = 0
        self.rx_dc = None                                 # (a new path: the LO spike estimated afresh)
        self.ofifo = collections.deque()
        self.olen = 0
        self.ohead = None
        self.playing = False
        self.ififo = collections.deque()
        self.ilen = 0
        self.rx100 = np.zeros(0, np.complex64)
        self.reset_counts()
        if mode in ("Loop", "TX out"):
            self.ostream = open_stream("out", out_name, self._out_cb, self.rf)
        if mode in ("Loop", "RX in"):
            self.istream = open_stream("in", in_name, self._in_cb, self.rf)
        for s in (self.istream, self.ostream):
            if s is not None:
                s.start()

    def close(self):
        for s in (self.ostream, self.istream):
            if s is not None:
                try:
                    s.stop()
                    s.close()
                except Exception:
                    pass
        self.ostream = self.istream = None
        self.key = None

    @property
    def tx_on(self):
        return self.ostream is not None

    @property
    def rx_on(self):
        return self.istream is not None

    # ---- the card's callbacks (PortAudio's thread)
    def _out_cb(self, outdata, frames, tinfo, status):
        with self.lock:
            if status.output_underflow:
                self.under += 1
            if not self.playing and self.olen >= int(self.buf_s * self.tx_fs * (0.5 if self.under else 1.0)):
                self.playing = True                    # the jitter buffer is full: go
            got = 0
            while self.playing and got < frames and self.ofifo:
                blk = self.ofifo[0]
                n = min(frames - got, len(blk))
                outdata[got:got + n] = blk[:n]
                got += n
                self.olen -= n
                if n == len(blk):
                    self.ofifo.popleft()
                else:
                    self.ofifo[0] = blk[n:]
            if got < frames:
                outdata[got:] = 0
                if self.playing:                      # ran dry: refill the buffer before going on
                    self.under += 1
                    self.playing = False

    def _in_cb(self, indata, frames, tinfo, status):
        with self.lock:
            if status.input_overflow:
                self.over += 1
            self.ififo.append(indata.copy())
            self.ilen += frames
            while self.ilen > 10 * self.rx_fs:            # nobody reading: keep the last 10 s
                self.ilen -= len(self.ififo.popleft())
                self.over += 1

    # ---- the modem's side
    def _shift(self, z, f, ph, fs=HW_FS):
        if not f:
            return z, ph
        n = np.arange(len(z))
        z = z * np.exp(1j * (ph + 2 * np.pi * f / fs * n)).astype(np.complex64)
        return z, (ph + 2 * np.pi * f / fs * len(z)) % (2 * np.pi)

    def send(self, tx):
        """The modem's 100 kHz samples out through the card at the set rms level (by way of
        200 kHz, so the edge carriers come out whole)."""
        tx = np.asarray(tx, np.complex64)
        r = float(np.sqrt(np.mean(np.abs(tx) ** 2))) if len(tx) else 0.0
        if r > 0:
            self.tx_rms = r if self.tx_rms is None else 0.7 * self.tx_rms + 0.3 * r
        if not self.tx_on:
            return
        if self.tx_rf:                                    # HackRF: 2 Msps, the LO offset put back
            rf = self.up_rf.process(tx)
            z = rf
        else:
            rf = self.i2.process(tx)
        r2 = float(np.sqrt(np.mean(np.abs(rf) ** 2))) if len(rf) else 0.0
        if r2 > 0:
            self.rf_rms = r2 if getattr(self, "rf_rms", None) is None else 0.7 * self.rf_rms + 0.3 * r2
        if self.tx_rf:
            z, self.tx_ph = self._shift(z, self.rf["lo_off"] + getattr(self, "tx_trim", 0.0), self.tx_ph, HACKRF_FS)
        else:
            z = self.up.process(rf)
            z, self.tx_ph = self._shift(z, self.offset + getattr(self, "tx_trim", 0.0), self.tx_ph)
        g = 10 ** (self.level_db / 20.0) / max(getattr(self, "rf_rms", None) or 1.0, 1e-9)
        z = z * g
        s = np.empty((len(z), 2), np.float32)
        s[:, 0], s[:, 1] = (z.imag, z.real) if (self.swap and getattr(self, "tx_card", True)) else (z.real, z.imag)
        clip = float(np.mean(np.abs(s) > 1.0)) if len(s) else 0.0
        self.out_clip = 0.8 * self.out_clip + 0.2 * clip
        self.out_dbfs = 10 * np.log10(max(float(np.mean(s ** 2)) * 2, 1e-12))
        np.clip(s, -1.0, 1.0, out=s)
        with self.lock:
            self.ofifo.append(s)
            self.olen += len(s)
            while self.olen > 20 * self.tx_fs:            # (nobody playing: keep it bounded)
                self.olen -= len(self.ofifo.popleft())
        if not self.rx_on:                                # TX out: go at the card's pace (in Loop
            t_end = time.time() + 5.0                     # the input does that)
            while self.olen > (self.buf_s + 0.5) * self.tx_fs and time.time() < t_end:
                time.sleep(0.005)

    LO_TAU = 0.5                                          # (s) how long the LO spike's estimate averages over

    def _lo_remove(self, z):
        """(NBTV SDR 1.32) The 2 Msps SDR's LO spike (its LO leakage / DC offset) taken out: a steady tone at
        0 Hz in its raw samples - the LO offset below the channel's centre.  A slow running average of the
        raw samples is the spike alone (the OFDM carriers, scrambled, average to nothing over LO_TAU), and
        is taken away before the channel is tuned: a notch well under 1 Hz wide."""
        fs = HACKRF_FS
        out = np.empty_like(z)
        dc = getattr(self, "rx_dc", None)
        blk = 8192
        for i in range(0, len(z), blk):
            b = z[i:i + blk]
            m = complex(b.mean())
            if dc is None:
                dc = m
            else:
                a = 1.0 - math.exp(-len(b) / (fs * self.LO_TAU))
                dc = (1.0 - a) * dc + a * m
            out[i:i + blk] = b - np.complex64(dc)
        self.rx_dc = dc
        self.lo_dbfs = 10 * np.log10(max(abs(dc) ** 2, 1e-12))   # (its level, for the hardware line)
        return out

    def _rx_tune(self, z):
        """What came in put on the channel: the SDR's LO offset or the card's channel offset off, the RX trim,
        and a swapped I/Q taken out (rx_inv, above)."""
        fs = HACKRF_FS if self.rx_rf else HW_FS                  # (as before: the card path at HW_FS)
        base = self.rf["lo_off"] if self.rx_rf else self.offset
        trim = getattr(self, "rx_trim", 0.0)
        inv = getattr(self, "rx_inv", 0)
        if inv in (1, 4):
            z = np.conj(z)
        if inv in (2, 3, 4):
            z, self.rx_ph = self._shift(z, -base, self.rx_ph, fs)
            z = np.conj(z)
            T = (self.offset if getattr(self, "tx_card", True) else self.rf["lo_off"]) if inv in (2, 4) else 0.0
            z, self.inv_ph = self._shift(z, -(2.0 * T + trim), getattr(self, "inv_ph", 0.0), fs)
            return z
        z, self.rx_ph = self._shift(z, -(base + trim), self.rx_ph, fs)
        return z

    def receive(self, n, timeout):
        """n samples at 100 kHz from the card's input (waits for them, up to timeout s; what does
        not come is zeros).  Scaled to the level the modem sent, as the channel would give."""
        t_end = time.time() + timeout
        while len(self.rx100) < n:
            with self.lock:
                blks = list(self.ififo)
                self.ififo.clear()
                self.ilen = 0
            if blks:
                s = np.concatenate(blks)
                self.in_clip = 0.8 * self.in_clip + 0.2 * float(np.mean(np.abs(s) >= 0.98))   # (an ADC can stop short of 1.0)
                ms = float(np.mean(s ** 2)) * 2
                self.in_dbfs = 10 * np.log10(max(ms, 1e-12))
                if self.trim_on and not self.rx_rf and getattr(self, "rx_card", True):                    # (the card's I / Q skew taken out)
                    s = self.trim.process(s)
                z = (s[:, 1] + 1j * s[:, 0]) if (self.swap and getattr(self, "rx_card", True)) else (s[:, 0] + 1j * s[:, 1])
                if self.rx_rf and getattr(self, "lo_rm", True):
                    z = self._lo_remove(z.astype(np.complex64))
                z = self._rx_tune(z.astype(np.complex64))
                if self.rx_rf:                                         # HackRF: the LO offset (and trim) off
                    self.rx100 = np.concatenate([self.rx100, self.down_rf.process(z)])
                else:
                    self.rx100 = np.concatenate([self.rx100, self.down.process(z)])
                # (NBTV SDR: the input as it came, centred on the channel, for its 200 kHz spectrum)
                self.wide = (z, self.rx_fs) if getattr(self, "wide", None) is None else \
                    (np.concatenate([self.wide[0], z])[-int(0.6 * self.rx_fs):], self.rx_fs)
                continue
            if time.time() >= t_end:
                self.late += 1
                self.rx100 = np.concatenate([self.rx100, np.zeros(n - len(self.rx100), np.complex64)])
                break
            time.sleep(0.005)
        y, self.rx100 = self.rx100[:n], self.rx100[n:]
        if len(y):                                        # the channel's own level (+-50 kHz), as it came in
            self.ch_dbfs = 10 * np.log10(max(float(np.mean(np.abs(y) ** 2)), 1e-12))
        if len(self.rx100) > 4 * FS:                      # behind by seconds: catch up
            self.rx100 = self.rx100[-FS // 2:]
            self.over += 1
        # an AGC to the level that was sent (what the lab's channel gives the receiver): up at once
        # when the signal arrives, then slowly; silence leaves it alone
        r = float(np.sqrt(np.mean(np.abs(y) ** 2))) if len(y) else 0.0
        if r > 1e-5:
            if self.rx_rms is None or r > 4 * self.rx_rms:
                self.rx_rms = r
            else:
                self.rx_rms = 0.6 * self.rx_rms + 0.4 * r
            self.rx_gain = (self.tx_rms or 1.0) / self.rx_rms
        return (y * (self.rx_gain or 1.0)).astype(np.complex64)

    def status(self):
        with self.lock:
            buf = self.olen / float(getattr(self, "tx_fs", HW_FS))
        for st_ in (self.ostream, self.istream):          # (a stream that has stopped by itself: say why)
            if st_ is not None and self.err is None and getattr(st_, "p", None) is not None and not st_.run \
                    and getattr(st_, "err", None):
                self.err = "stopped: %s" % " / ".join(l for l in st_.err[-3:] if l)[:300]
        return dict(mode=self.mode, err=self.err, tx=self.tx_on, rx=self.rx_on, in_dbfs=self.in_dbfs,
                    out_dbfs=self.out_dbfs, in_clip=self.in_clip, out_clip=self.out_clip, under=self.under,
                    over=self.over, late=self.late, buf_s=buf, playing=getattr(self, "playing", False),
                    ch_dbfs=getattr(self, "ch_dbfs", -120.0),
                    lo_dbfs=(getattr(self, "lo_dbfs", None) if self.rx_rf and getattr(self, "lo_rm", True) else None),
                    offset=self.offset, rf=bool(getattr(self, "tx_rf", False) or getattr(self, "rx_rf", False)),
                    freq=self.rf["freq"] if hasattr(self, "rf") else None)


def rf_check(out_name, in_name, c, level_db=-12.0):
    """The RF path out of one HackRF (or the card) and into another receiver, measured like the card
    check but on complex I/Q: a quiet lead-in (the noise floor), a tone 10 kHz up (the frequency offset
    between the two units, and the I/Q image), then noise across +-48 kHz (delay, gain, SNR by band).
    -> (dict of results, list of report lines)."""
    import threading
    lines = []
    rf = hackrf_rf(c)
    tx_rf, rx_rf = hackrf_dev(out_name) is not None, hackrf_dev(in_name) is not None
    if not (tx_rf or rx_rf):
        return dict(ok=False), ["RF check: neither device is a HackRF - use Card check for a sound card"]
    if tx_rf and rx_rf and hackrf_dev(out_name) == hackrf_dev(in_name):
        return dict(ok=False), ["RF check: one HackRF cannot send and receive at once (half duplex) - choose two"]
    lines.append("RF check: %.4f MHz, out '%s' (%s), in '%s' (%s)" % (
        rf["freq"] / 1e6, out_name, "TX VGA %d dB%s" % (rf["txvga"], ", amp" if rf["txamp"] else "") if tx_rf else "",
        in_name, "LNA %d, VGA %d dB%s" % (rf["lna"], rf["vga"], ", amp" if rf["rxamp"] else "") if rx_rf else ""))
    fs_t = HACKRF_FS if tx_rf else HW_FS
    fs_r = HACKRF_FS if rx_rf else HW_FS
    # the test at 100 kHz, complex
    F = FS
    rng = np.random.RandomState(11)
    lead, tone_n, gap, nb, tail = int(0.4 * F), int(0.4 * F), int(0.05 * F), int(0.8 * F), int(0.8 * F)
    a = 10 ** (level_db / 20.0)
    tone = a * np.exp(2j * np.pi * 10000.0 / F * np.arange(tone_n))
    X = np.fft.fft(rng.randn(nb) + 1j * rng.randn(nb))
    ff = np.fft.fftfreq(nb, 1.0 / F)
    X[np.abs(ff) > 48000] = 0
    noise = np.fft.ifft(X)
    noise = noise / np.sqrt(np.mean(np.abs(noise) ** 2)) * a
    t100 = np.concatenate([np.zeros(lead), tone, np.zeros(gap), noise, np.zeros(tail)]).astype(np.complex64)
    p_tone, p_noise = lead, lead + tone_n + gap
    # to the device's rate
    if tx_rf:
        up = StreamFFTResample(HACKRF_FS // F, up=True)
        z = np.concatenate([up.process(t100), up.process(np.zeros(4 * 16384, np.complex64))])
        n = np.arange(len(z))
        z = z * np.exp(2j * np.pi * rf["lo_off"] / HACKRF_FS * n)
    else:
        i2, upc = StreamInterp2(), IQResampler(24, 25, 2 * F, 32, 75000.0)
        z = upc.process(i2.process(np.concatenate([t100, np.zeros(8192, np.complex64)])))
    out = np.stack([z.real, z.imag], axis=1).astype(np.float32)
    N = len(out)
    rec, pos, done, lock = [], [0], threading.Event(), threading.Lock()

    def ocb(outdata, frames, tinfo, status):
        k = pos[0]
        m = max(0, min(frames, N - k))
        outdata[:m] = out[k:k + m]
        outdata[m:] = 0
        pos[0] = k + frames
        if pos[0] >= N + int(0.3 * fs_t):
            done.set()

    def icb(indata, frames, tinfo, status):
        with lock:
            rec.append(indata.copy())
    si = so = None
    try:
        si = open_stream("in", in_name, icb, rf)
        si.start()
        so = open_stream("out", out_name, ocb, rf)
        so.start()
        done.wait(N / float(fs_t) + 8.0)
        time.sleep(0.4)
        so.stop()
        si.stop()
    except Exception as e:
        for st_ in (si, so):
            try:
                if st_ is not None:
                    st_.stop()
            except Exception:
                pass
        lines.append("  could not run: %s" % (str(e).splitlines()[0] if str(e) else type(e).__name__))
        return dict(ok=False), lines
    with lock:
        x = np.concatenate(rec) if rec else np.zeros((0, 2), np.float32)
    if len(x) < 1000:
        lines.append("  nothing came in from the receiver")
        return dict(ok=False), lines
    clip = float(np.mean(np.abs(x) >= 0.99))
    zr = (x[:, 0] + 1j * x[:, 1]).astype(np.complex64)
    raw_dbfs = 10 * np.log10(max(float(np.mean(np.abs(zr) ** 2)), 1e-12))
    if rx_rf:
        nn = np.arange(len(zr))
        zr = zr * np.exp(-2j * np.pi * rf["lo_off"] / HACKRF_FS * nn).astype(np.complex64)
        dn = StreamFFTResample(HACKRF_FS // F, up=False)
        y = dn.process(zr)
    else:
        y = IQResampler(25, 48, HW_FS, 96, 54500.0, 5.0).process(zr)
    y = y.astype(np.complex128)
    db = lambda p: 10 * np.log10(max(float(p), 1e-20))
    res = dict(ok=True, clip=clip, raw_dbfs=raw_dbfs)
    def xc(ref, sig):
        L_ = 1 << int(np.ceil(np.log2(len(ref) + len(sig))))
        return np.fft.ifft(np.fft.fft(sig, L_) * np.conj(np.fft.fft(ref, L_)))[:len(sig)]
    q = y[int(0.05 * F):int(0.35 * F)]                # the lead-in, before anything arrives
    floor = db(np.mean(np.abs(q) ** 2))
    dcv = abs(np.mean(q))
    lines.append("  in: %.1f dBFS at the converter%s;  quiet: floor %.1f dBFS, DC %.1f dBFS (in the 100 kHz)" % (
        raw_dbfs, (", CLIPPING %.2f%%" % (100 * clip)) if clip > 1e-4 else "", floor, db(dcv * dcv)))
    # 1) the tone's start, from the power (a frequency offset doesn't matter to that): the delay, roughly
    pw = np.convolve(np.abs(y) ** 2, np.ones(100) / 100.0, mode="same")
    thr = 10 ** ((floor + 10) / 10.0)
    on = np.nonzero(pw[int(0.3 * F):] > thr)[0]
    if not len(on):
        res["path"] = "none"
        lines.append("  NOTHING of the test comes back (no tone 10 dB over the floor): check the cable / attenuator, the "
                     "frequency, the gains, and that the TX is really sending")
        return res, lines
    d0 = int(0.3 * F) + int(on[0]) + 50 - p_tone
    # 2) the tone: the frequency offset and the I/Q image
    ts = y[p_tone + d0 + int(0.05 * F):p_tone + d0 + tone_n - int(0.05 * F)]
    nf = 1 << 16
    S_ = np.abs(np.fft.fft(ts * np.hanning(len(ts)), nf)) ** 2
    fq = np.fft.fftfreq(nf, 1.0 / F)
    near = np.abs(fq - 10000.0) < 4000
    i = int(np.argmax(np.where(near, S_, 0)))
    y0, y1, y2 = S_[i - 1], S_[i], S_[(i + 1) % nf]
    di = 0.5 * (np.log(y0 + 1e-30) - np.log(y2 + 1e-30)) / (np.log(y0 + 1e-30) - 2 * np.log(y1 + 1e-30) + np.log(y2 + 1e-30))
    off = fq[i] + di * F / nf - 10000.0
    im = int(np.argmin(np.abs(fq - (-10000.0 - off))))
    img = db(np.sum(S_[max(0, im - 3):im + 4])) - db(np.sum(S_[i - 3:i + 4]))
    # 3) frequency corrected: the noise burst's exact delay
    yc = y * np.exp(-2j * np.pi * off / F * np.arange(len(y)))
    w0 = max(0, p_noise + d0 - 2000)
    c_ = np.abs(xc(noise[:int(0.2 * F)], yc[w0:w0 + int(0.2 * F) + 6000]))
    k = int(np.argmax(c_))
    d = w0 + k - p_noise
    e_ = np.sqrt(np.sum(np.abs(noise[:int(0.2 * F)]) ** 2) * np.sum(np.abs(yc[w0 + k:w0 + k + int(0.2 * F)]) ** 2))
    rho = c_[k] / max(e_, 1e-20)
    res.update(delay_ms=1000.0 * d / F, rho=float(rho), freq_off=off, image_db=img)
    if rho < 0.3:
        res["path"] = "none"
        lines.append("  something comes back (a tone %+.0f Hz off) but the test noise does not match (%.2f): a strong "
                     "interferer, or the receiver overloaded?" % (off, rho))
        return res, lines
    res["path"] = "rf"
    lines.append("  frequency: the receiver hears it %+.1f Hz off (%+.2f ppm at %.3f MHz)%s;  I/Q image %.1f dB" % (
        off, off / rf["freq"] * 1e6, rf["freq"] / 1e6,
        "  (RX trim was %+.1f Hz)" % rf["rx_trim"] if rf["rx_trim"] and rx_rf else "", img))
    y = yc
    # the noise burst, frequency corrected: gain and SNR by band
    ns = y[p_noise + d:p_noise + d + nb]
    if len(ns) < nb:
        lines.append("  the recording ended early")
        return res, lines
    B = 4096
    Sxy = Sxx = Syy = 0.0
    for j in range(nb // B):
        r_ = np.fft.fft(noise[j * B:(j + 1) * B])
        w_ = np.fft.fft(ns[j * B:(j + 1) * B])
        Sxy = Sxy + w_ * np.conj(r_)
        Sxx = Sxx + np.abs(r_) ** 2
        Syy = Syy + np.abs(w_) ** 2
    fb = np.fft.fftfreq(B, 1.0 / F)
    H = Sxy / np.maximum(Sxx, 1e-20)
    g = float(np.mean(np.abs(H[np.abs(fb) < 5000])))
    bands = []
    for lo, hi in ((0, 10000), (10000, 20000), (20000, 30000), (30000, 40000), (40000, 48000)):
        kk = (np.abs(fb) >= lo) & (np.abs(fb) < hi)
        sg = np.sum(np.abs(Sxy[kk]) ** 2 / np.maximum(Sxx[kk], 1e-20))
        bands.append(10 * np.log10(max(sg, 1e-30) / max(np.sum(Syy[kk]) - sg, 1e-30)))
    resp = [20 * np.log10(np.mean(np.abs(H[(np.abs(fb) >= lo) & (np.abs(fb) < hi)])) / max(g, 1e-12) + 1e-12)
            for lo, hi in ((0, 10000), (10000, 20000), (20000, 30000), (30000, 40000), (40000, 48000))]
    res.update(gain_db=20 * np.log10(g + 1e-12), snr_bands=bands, resp=resp)
    lines.append("  through it: delay %.1f ms, gain %+.1f dB (converter to converter)" % (res["delay_ms"], res["gain_db"]))
    lines.append("  SNR by band (|f| from the centre):  0-10k 10-20k 20-30k 30-40k 40-48k")
    lines.append("                                     " + " ".join("%6.1f" % v for v in bands))
    lines.append("  response (dB re the centre):        " + " ".join("%6.1f" % v for v in resp))
    if clip > 1e-3:
        lines.append("  !! the receiver's converter is CLIPPING: lower the RX gains (LNA / VGA / amp) or add attenuation")
    elif raw_dbfs < -40:
        lines.append("  !! the level into the receiver's converter is low (%.0f dBFS): raise the RX gains (aim -20..-10 dBFS)"
                     % raw_dbfs)
    if abs(off) > 150:
        lines.append("  !! %+.0f Hz between the two units: more than the receiver likes to pull in - the RX trim will "
                     "take it out" % off)
    if min(bands) < 25:
        lines.append("  !! the SNR is low: more TX gain / less attenuation, or more RX gain (without clipping)")
    return res, lines


def card_check(out_name="Default", in_name="Default", level_db=-20.0, trim=(0.0, 0.0)):
    """Measure the sound card's own loop (line out -> line in), in this process: noise on the left
    only, then on the right only, then a slow sweep; what comes back on each input says whether there
    is a real path through the DAC and ADC, a digital copy (a monitor / loopback device), or nothing.
    -> (dict of results, list of report lines)."""
    lines = []
    import threading
    fs = HW_FS
    nm = []
    for kind, name in (("output", out_name), ("input", in_name)):
        if alsa_dev(name) is not None:
            nm.append("%s (ALSA direct, no mixer)" % alsa_dev(name))
            continue
        try:
            import sounddevice as sd
            i = HwIO._dev(sd, name, kind)
            devs = sd.query_devices()
            nm.append(devs[i]["name"] if i is not None else
                      "default (%s)" % devs[sd.default.device[1 if kind == "output" else 0]]["name"])
        except Exception as e:
            return dict(ok=False), ["Card check: the %s '%s': %s" % (kind, name, str(e).splitlines()[0] if str(e) else e)]
    lines.append("Card check: out '%s', in '%s', 192 kHz" % tuple(nm))
    rng = np.random.RandomState(7)
    a = 10 ** (level_db / 20.0)
    q, b = int(0.05 * fs), int(0.4 * fs)                        # quiet gaps, noise bursts
    sweep_n = int(1.0 * fs)
    t = np.arange(sweep_n) / float(fs)
    f0, f1 = 200.0, 90000.0
    sweep = np.sin(2 * np.pi * f0 * sweep_n / fs / np.log(f1 / f0) * (np.exp(t / t[-1] * np.log(f1 / f0)) - 1))
    nl = rng.randn(b) * a
    nr = rng.randn(b) * a
    lead, tail = int(0.3 * fs), int(0.5 * fs)
    n = lead + b + q + b + q + sweep_n + tail
    out = np.zeros((n, 2), np.float32)
    p1 = lead
    p2 = p1 + b + q
    p3 = p2 + b + q
    out[p1:p1 + b, 0] = nl
    out[p2:p2 + b, 1] = nr
    out[p3:p3 + sweep_n, 0] = sweep * a * 1.41
    out[p3:p3 + sweep_n, 1] = sweep * a * 1.41
    rec = []
    pos = [0]
    done = threading.Event()
    lock = threading.Lock()

    def ocb(outdata, frames, tinfo, status):
        k = pos[0]
        m = max(0, min(frames, n - k))
        outdata[:m] = out[k:k + m]
        outdata[m:] = 0
        pos[0] = k + frames
        if pos[0] >= n + int(0.3 * fs):
            done.set()

    def icb(indata, frames, tinfo, status):
        with lock:
            rec.append(indata.copy())
    si = so = None
    try:
        si = open_stream("in", in_name, icb)
        si.start()
        so = open_stream("out", out_name, ocb)
        so.start()
        done.wait(n / float(fs) + 5.0)
        so.stop(); si.stop(); so.close(); si.close()
    except Exception as e:
        for st_ in (si, so):
            try:
                if st_ is not None:
                    st_.stop()
            except Exception:
                pass
        lines.append("  could not run: %s" % (str(e).splitlines()[0] if str(e) else type(e).__name__))
        return dict(ok=False), lines
    with lock:
        x = np.concatenate(rec) if rec else np.zeros((0, 2), np.float32)
    if len(x) < n:
        x = np.concatenate([x, np.zeros((n - len(x), 2), np.float32)])
    x = x.astype(np.float64)
    trim = (float(trim[0]), float(trim[1]))
    if abs(trim[0]) > 1e-4 or abs(trim[1]) > 1e-3:        # (measured with the loop's I / Q trim in place)
        x = IQTrim(*trim).process(x).astype(np.float64)
    db = lambda p: 10 * np.log10(max(float(p), 1e-20))
    # the input with nothing playing yet (the lead-in): what the ADC hears on its own
    q0 = x[int(0.02 * fs):int(0.25 * fs)]
    quiet_info = []
    loud = None
    if len(q0) > 4096:
        for ch, nm_ in ((0, "L"), (1, "R")):
            v = q0[:, ch]
            dc = float(np.mean(v))
            ac = v - dc
            F = np.abs(np.fft.rfft(ac * np.hanning(len(ac)))) ** 2
            f_ = np.fft.rfftfreq(len(ac), 1.0 / fs)
            tot = F.sum() + 1e-30
            pw = float(np.mean(ac ** 2))
            bands = [(F[(f_ >= lo) & (f_ < hi)].sum() / tot) * pw for lo, hi in ((20, 400), (400, 20000), (20000, 96000))]
            k20 = int(np.searchsorted(f_, 20.0))
            pk = f_[int(np.argmax(F[k20:])) + k20]
            quiet_info.append("%s: DC %+.3f (%.0f dBFS), hum/LF %.0f, audio %.0f, above 20k %.0f dBFS, strongest at %.0f Hz"
                              % (nm_, dc, db(dc * dc * 2), db(bands[0] * 2), db(bands[1] * 2), db(bands[2] * 2), pk))
            tot_db = db((dc * dc + pw) * 2)
            if tot_db > -40 and (loud is None or tot_db > loud[0]):
                kind = "DC" if dc * dc > pw else ("hum" if bands[0] > max(bands[1], bands[2]) else
                                                  ("noise above 20 kHz" if bands[2] > bands[1] else "audio-band noise"))
                loud = (tot_db, kind)
    res_quiet = dict(info=quiet_info, loud=loud)
    num, ctl = alsa_capture_controls(in_name)
    mix_line = None
    if ctl:
        mix_line = "  capture mixer (amixer -c %s): " % num + "; ".join(
            "%s = %s" % (c["name"], ("'%s'" % c["value"]) if c["kind"] == "enum" else c["value"]) for c in ctl[:8])

    def xcorr(ref, sig):
        L = 1 << int(np.ceil(np.log2(len(ref) + len(sig))))
        c = np.fft.irfft(np.fft.rfft(sig, L) * np.conj(np.fft.rfft(ref, L)), L)
        return c
    def find(ref, start, ch):
        """Where ref (sent at start) came back on input ch: (delay in samples, fractional; match 0..1)."""
        c = xcorr(ref, x[:, ch])[:len(x)]
        k = int(np.argmax(np.abs(c)))
        y0, y1, y2 = (abs(c[k - 1]) if k > 0 else 0.0), abs(c[k]), (abs(c[k + 1]) if k + 1 < len(c) else 0.0)
        fk = k + (0.5 * (y0 - y2) / (y0 - 2 * y1 + y2) if (y0 - 2 * y1 + y2) != 0 else 0.0)
        e = np.sqrt(np.sum(ref ** 2) * np.sum(x[k:k + len(ref), ch] ** 2))
        return fk - start, abs(c[k]) / max(e, 1e-20)
    res = dict(ok=True, path="?", quiet=res_quiet, mixer=(num, ctl))
    in_rms = db(np.mean(x ** 2) * 2)
    lines.append("  input with nothing playing - " + ";  ".join(quiet_info))
    if loud is not None:
        hint = {"DC": "a DC offset: the input is probably a MIC jack (its bias voltage) - set the capture source to Line",
                "hum": "mains hum: an open input at high gain (a mic input with boost?) - Line, boost 0, capture lower",
                "noise above 20 kHz": "noise above 20 kHz: high capture gain or a mic boost - turn them down",
                "audio-band noise": "noise: the capture gain is high, or a mic boost - Line input, boost 0, capture ~50%"}[loud[1]]
        lines.append("  !! the input is LOUD with nothing connected (%.1f dBFS): %s" % (loud[0], hint))
    if mix_line:
        lines.append(mix_line)
    fl = [find(nl, p1, ch) for ch in (0, 1)]
    chL = 0 if fl[0][1] >= fl[1][1] else 1
    other = 1 - chL
    d1, rho = fl[chL]
    res.update(in_dbfs=in_rms, rho=rho)
    if rho < 0.2:
        res["path"] = "none"
        lines.append("  NOTHING of the output comes back (match %.2f); the input reads %.1f dBFS." % (rho, in_rms))
        lines.append("  -> no path from line out to line in: right with no cable.  With a cable: check the"
                     " mixer (capture source = Line, capture not muted, gain up) and that 'in' is the line input.")
        return res, lines
    d2, rho2 = find(nr, p2, other)
    d3, _ = find(out[p3:p3 + sweep_n, 0].astype(np.float64), p3, chL)
    res["delay_ms"] = 1000.0 * d1 / fs
    di = int(round(d1))
    # the two cards' clocks: the right burst lands (p2 - p1) after the left one, give or take
    ppm = (d2 - d1) / float(p2 - p1) * 1e6 if rho2 > 0.2 else 0.0

    def fit(ch, s0, ref, dd):
        """ref against what came back on ch, a block at a time, each block at its own (fractional)
        delay as the clocks drift: -> (gain, residual power, signal power)."""
        B, m = 8192, 64
        G, E, P = [], 0.0, 0.0
        num = den = 0.0
        blocks = []
        for j in range(len(ref) // B):
            dj = dd + ppm * 1e-6 * (j * B + B / 2.0 - len(ref) / 2.0)
            k0 = int(np.floor(dj))
            fr_ = dj - k0
            w = x[s0 + k0 + j * B - m:s0 + k0 + (j + 1) * B + m, ch]
            if len(w) < B + 2 * m:
                break
            W = np.fft.rfft(w)
            f_ = np.fft.rfftfreq(len(w))
            w = np.fft.irfft(W * np.exp(2j * np.pi * f_ * fr_), len(w))[m:m + B]
            r = ref[j * B:(j + 1) * B]
            blocks.append((w, r))
            num += np.dot(w, r)
            den += np.dot(r, r)
        # per frequency: what came back against what was sent, over the blocks; the gain at 1 kHz,
        # and the SNR inside 0 - 50 kHz (each channel carries that much of the I/Q's +-50 kHz)
        Sxy = Sxx = Syy = 0.0
        for w, r in blocks:
            Wf, Rf = np.fft.rfft(w), np.fft.rfft(r)
            Sxy = Sxy + Wf * np.conj(Rf)
            Sxx = Sxx + np.abs(Rf) ** 2
            Syy = Syy + np.abs(Wf) ** 2
        fb = np.fft.rfftfreq(B, 1.0 / fs)
        H = Sxy / np.maximum(Sxx, 1e-20)
        band = (fb > 300) & (fb < 50000)
        sig = np.sum(np.abs(Sxy[band]) ** 2 / np.maximum(Sxx[band], 1e-20))
        noi = np.sum(Syy[band]) - sig
        k1 = (fb > 500) & (fb < 2000)
        g = float(np.real(np.mean(H[k1])))
        bands = []
        for lo, hi in ((300, 10000), (10000, 20000), (20000, 30000), (30000, 40000), (40000, 50000)):
            k = (fb >= lo) & (fb < hi)
            sg = np.sum(np.abs(Sxy[k]) ** 2 / np.maximum(Sxx[k], 1e-20))
            bands.append(10 * np.log10(max(sg, 1e-30) / max(np.sum(Syy[k]) - sg, 1e-30)))
        fit.bands = bands
        return g, max(noi, 1e-30), sig
    gl, E, P = fit(chL, p1, nl, d1)
    bands_l = list(fit.bands)
    gx, _, _ = fit(other, p1, nl, d1)
    gr, _, _ = fit(other, p2, nr, d2)
    bands_r = list(fit.bands)
    snr = db(P) - db(E)
    quiet = x[max(0, p1 + di - q):p1 + di - int(0.005 * fs), :]   # just before the burst arrives
    floor = db(np.mean(quiet ** 2) * 2) if len(quiet) > 100 else -200.0
    burst = x[p1 + di:p1 + di + b]
    res["in_peak"] = float(np.max(np.abs(burst))) if len(burst) else 0.0
    res["in_clip"] = float(np.mean(np.abs(burst) >= 0.98)) if len(burst) else 0.0
    res.update(gain_db=20 * np.log10(abs(gl) + 1e-12), snr_db=snr, floor_dbfs=floor,
               cross_db=20 * np.log10(abs(gx) / max(abs(gl), 1e-12) + 1e-12),
               right_gain_db=20 * np.log10(abs(gr) + 1e-12), swapped=chL == 1, inverted=bool(gl < 0))
    digital = snr > 90 and abs(res["gain_db"]) < 0.01 and floor < -110
    res["path"] = "digital" if digital else "analogue"
    lines.append("  the output comes back after %.1f ms, gain %+.2f dB%s%s" % (
        res["delay_ms"], res["gain_db"], ", L and R SWAPPED" if res["swapped"] else "",
        ", polarity INVERTED" if res["inverted"] else ""))
    if digital:
        lines.append("  -> it is a DIGITAL COPY (SNR %.0f dB, noise floor %.0f dBFS): the input is a monitor /"
                     " loopback of the output, not the ADC.  Pick the card's own line input (hw:) and turn off"
                     " 'Monitor of', 'Stereo Mix', 'Loopback' or PipeWire/Pulse routing." % (snr, floor))
        return res, lines
    lines.append("  through the DAC and ADC: SNR %.1f dB (noise + distortion), noise floor %.1f dBFS, L->R crosstalk"
                 " %.1f dB, right channel gain %+.2f dB" % (snr, floor, res["cross_db"], res["right_gain_db"]))
    if res["in_clip"] > 1e-3:
        lines.append("  !! the INPUT IS CLIPPING (%.1f%% of samples at full scale, peak %.3f): the capture gain is far too high"
                     " - the loop gain should be about 0 dB, it reads %+.1f dB (and more, as clipping hides it)"
                     % (100 * res["in_clip"], res["in_peak"], res["gain_db"]))
    elif res["gain_db"] > 6:
        lines.append("  !! the loop gain is %+.1f dB: the capture gain is too high (aim for about 0 dB)" % res["gain_db"])
    elif res["gain_db"] < -12:
        lines.append("  !! the loop gain is %+.1f dB: the capture gain is low (aim for about 0 dB)" % res["gain_db"])
    res["snr_bands"] = (bands_l, bands_r)
    lines.append("  SNR by band (each channel's 0-50 kHz = the I/Q's carriers from the middle out):")
    lines.append("                            0-10k 10-20k 20-30k 30-40k 40-50k")
    lines.append("    left  (I)               " + " ".join("%6.1f" % v for v in bands_l))
    lines.append("    right (Q)               " + " ".join("%6.1f" % v for v in bands_r))
    lo_b, hi_b = min(bands_l[0], bands_r[0]), min(bands_l[-1], bands_r[-1])
    if lo_b < 35:
        lines.append("  !! the SNR is low across the band (%.0f dB even at the bottom): LEVELS - the line out is weak and"
                     " the capture gain makes up for it, or the input is clipping" % lo_b)
    elif lo_b - hi_b > 10:
        lines.append("  !! the SNR falls %.0f dB towards 50 kHz: the CARD - its noise rises above 20 kHz (noise shaping)"
                     " or it rolls off; the outer carriers get the worst of it" % (lo_b - hi_b))
    play = alsa_playback_controls(out_name)
    res["playback"] = play
    if play:
        lines.append("  playback mixer: " + "; ".join("%s = %s" % (c["name"], ("'%s'" % c["value"]) if c["kind"] == "enum"
                                                                   else c["value"]) for c in play))
    if snr < 30:
        lines.append("     (SNR under 30 dB: the level is low, or the input is clipping - aim for about -20 dBFS in)")
    # frequency response from the sweep (aligned where it came back), both channels
    o3 = int(round(d3))
    s_in = x[p3 + o3:p3 + o3 + sweep_n]
    s_ref = out[p3:p3 + sweep_n, 0].astype(np.float64)
    nf = 4096
    seg_n = min(sweep_n, len(s_in)) // nf * nf
    R = np.fft.rfft(s_ref[:seg_n].reshape(-1, nf) * np.hanning(nf), axis=1)
    fr = np.fft.rfftfreq(nf, 1.0 / fs)
    resp = []
    for ch in (chL, other):
        X = np.fft.rfft(s_in[:seg_n, ch].reshape(-1, nf) * np.hanning(nf), axis=1)
        H = np.sum(X * np.conj(R), axis=0) / np.maximum(np.sum(np.abs(R) ** 2, axis=0), 1e-20)
        resp.append(H)
    pts = (1000, 10000, 20000, 30000, 40000, 45000, 50000, 60000, 70000, 80000)
    idx = [int(np.argmin(np.abs(fr - f))) for f in pts]
    ref1k = abs(resp[0][idx[0]]) + 1e-12
    hl = [20 * np.log10(abs(resp[0][i]) / ref1k + 1e-12) for i in idx]
    hr = [20 * np.log10(abs(resp[1][i]) / ref1k + 1e-12) for i in idx]
    res.update(resp_f=list(pts), resp_l=hl, resp_r=hr)
    lines.append("  response (dB re 1 kHz)   " + " ".join("%5s" % ("%dk" % (f // 1000)) for f in pts))
    lines.append("    left  (I)              " + " ".join("%5.1f" % v for v in hl))
    lines.append("    right (Q)              " + " ".join("%5.1f" % v for v in hr))
    ph = [np.degrees(np.angle(resp[1][i] / (resp[0][i] + 1e-20))) for i in idx]
    res["iq_phase"] = ph
    lines.append("    R-L phase (deg)        " + " ".join("%5.1f" % v for v in ph))
    # the I / Q timing and gain difference: the R-L phase is a straight line in f for a pure delay
    k = (fr > 1000) & (fr < 60000)
    rt = resp[1][k] / (resp[0][k] + 1e-20)
    wgt = np.abs(resp[0][k]) ** 2
    phi = np.unwrap(np.angle(rt))
    tau = -float(np.sum(wgt * phi * fr[k]) / max(np.sum(wgt * fr[k] ** 2), 1e-20)) / (2 * np.pi)   # s, R later
    gdb = float(10 * np.log10(np.sum(wgt * np.abs(rt) ** 2) / max(np.sum(wgt), 1e-20)))
    if res.get("swapped"):
        tau, gdb = -tau, -gdb
    skew_res = tau * fs                                  # samples still to take out
    res["iq"] = dict(trim=trim, skew_res=skew_res, gain_res=gdb,
                     skew=trim[0] + skew_res, gain=trim[1] + gdb)
    tot_s, tot_g = res["iq"]["skew"], res["iq"]["gain"]
    lines.append("  I/Q (R against L): timing %+.1f ns (%+.3f samples), gain %+.2f dB%s" % (
        1e9 * tot_s / fs, tot_s, tot_g, ("  - with the trim in: %+.1f ns, %+.2f dB left" % (1e9 * skew_res / fs, gdb))
        if trim != (0.0, 0.0) else ""))
    irr = [iq_image_db(skew_res / fs, gdb, f) for f in (10000, 30000, 50000)]
    irr0 = [iq_image_db(tot_s / fs, tot_g, f) for f in (10000, 30000, 50000)]
    lines.append("    mirror carrier below each carrier (10 / 30 / 50 kHz): %s dB untrimmed%s" % (
        " / ".join("%.0f" % v for v in irr0), (", %s dB as tested" % " / ".join("%.0f" % v for v in irr))
        if trim != (0.0, 0.0) else ""))
    if rho2 > 0.2:
        res["ppm"] = ppm
        lines.append("  ADC vs DAC clock: %+.0f ppm%s" % (ppm, "  (one card, one clock: about 0 expected)"
                                                          if abs(ppm) < 3 else ""))
    worst = min(hl[:7] + hr[:7])
    lines.append("  -> a real path.  Inside +-50 kHz (what the I/Q uses) the response is within %.1f dB%s." % (
        -worst, "" if worst > -3 else " - the card's own filter cuts into the band: the outer carriers will come out weak"))
    return res, lines


WIDE_W = 640                              # NBTV SDR: points across its 200 kHz spectrum
WIDE_SPAN = 200000.0


def wide_rows(z, fs, nrows=None, W=WIDE_W, span=WIDE_SPAN):
    """Spectrum rows (dB) of complex samples centred on the channel, on W points across +-span/2
    (where the samples' own band stops short of that: -150 dB).  nrows None: a row every 50 ms."""
    z = np.asarray(z, np.complex64)
    if nrows is None:
        nrows = max(1, int(round(len(z) / float(fs) / 0.05)))
    nf = 1024 if fs < 400000 else 16384
    f = np.fft.fftshift(np.fft.fftfreq(nf, 1.0 / fs))
    grid = np.linspace(-span / 2, span / 2, W)
    keep = np.abs(f) <= span / 2 + fs / nf
    win = np.hanning(nf).astype(np.float32)
    g = float(np.sum(win)) ** 2
    out = []
    for part in np.array_split(z, max(1, nrows)):
        seg = part[:len(part) // nf * nf].reshape(-1, nf)
        if not len(seg):
            continue
        p = np.mean(np.abs(np.fft.fftshift(np.fft.fft(seg * win, axis=1), axes=1)) ** 2, axis=0) / g
        db = 10 * np.log10(p[keep] + 1e-15)
        fk = f[keep]
        if len(fk) > 2 * W:                               # (many bins a point: the strongest)
            idx = np.clip(np.searchsorted(grid, fk), 0, W - 1)
            row = np.full(W, -150.0)
            np.maximum.at(row, idx, db)
            empty = row <= -149.9
            if empty.any():
                row[empty] = np.interp(grid[empty], fk, db)
        else:
            row = np.interp(grid, fk, db, left=-150.0, right=-150.0)
        out.append(row.astype(np.float32))
    return out


class ModemHandler:
    """Modulator -> 200 kHz upsampler -> channel -> demodulator, and the spectra the window shows."""

    def __init__(self):
        self.ok = False
        self.auto = False
        self.rx_set = dict(eq="pilots", timing="auto", manual=0)
        self.auto_reset()

    def auto_reset(self):
        self.adem = None                                 # Auto: the receiver built from what was found
        self.abuf = []
        self.alen = 0
        self.ainfo = None
        self.abad = 0
        self.atries = 0
        self.ajob = None                                 # (a search still running is forgotten)

    def handle(self, msg):
        cmd = msg[0]
        if cmd == "build":
            _, mname, cp, ilv, sync = msg[:5]
            self.mode = layout(mname, bool(msg[5]) if len(msg) > 5 else False, cp, int(msg[6]) if len(msg) > 6 else 0,
                               len(msg) > 7 and bool(msg[7]))
            self.mod = Modulator(self.mode, cp, ilv, sync)
            self.dem = Demodulator(self.mode, cp, ilv, sync)
            self._set_rx(self.dem)
            self.chan = Channel()
            self.up = Upsampler()
            self.ok = True
            self.ilv = bool(ilv)
            self.auto_reset()
            return True
        if cmd == "apply":
            c = msg[1]
            ch, d = self.chan, self.dem
            ch.snr_db, ch.noise_on, ch.cfo_hz = float(c["snr"]), bool(c["noise"]), float(c["cfo"])
            ch.delay, ch.echo_delay, ch.echo_db, ch.ppm = int(c["delay"]), int(c["echo_delay"]), float(c["echo_db"]), float(c["ppm"])
            d.eq, d.timing, d.manual_offset = c["eq"], c["timing"], int(c["manual"])
            self.rx_set = dict(eq=c["eq"], timing=c["timing"], manual=int(c["manual"]),
                               mirror=bool(c.get("rx_iq_auto", 0)))
            d.auto_mirror = self.rx_set["mirror"]
            if not d.auto_mirror:
                d.mirror = False
            if self.adem is not None:
                self._set_rx(self.adem)
            auto = bool(c.get("auto_rx", 0))
            if auto != self.auto:
                self.auto = auto
                self.auto_reset()
            ch.set_fading(c["fade"])
            ch.doppler, ch.imp_rate, ch.imp_db = float(c["doppler"]), float(c["imp_rate"]), float(c["imp_db"])
            ch.pn_hz, ch.iq_gain_db, ch.iq_phase_deg, ch.dc_db = (float(c["pn_hz"]), float(c["iq_gain"]),
                                                                  float(c["iq_phase"]), float(c["dc_db"]))
            apply_front_end(ch, c)
            self.mod.clip_db = clip_value(c.get("clip", "Off"))
            self.mod.scramble = bool(c.get("scramble", 1))
            self.mod.spread = c.get("spread", "Off") if c.get("spread", "Off") in SPREADS else "Off"
            self.mod.ti = bool(c.get("ti", 0))
            self.mod.iqflip = bool(c.get("iqflip", 0))
            if self.dem.word is None:                   # (until the sender's word says)
                self.dem.scramble = self.mod.scramble
                self.dem.spread = self.mod.spread
                self.dem.fold = self.mod.ti and self.mod.scramble and self.mod.spread == "Off"
                self.dem.iqflip = self.mod.iqflip
            self.tx200 = c.get("tx_path", "2x IFFT")       # (the lab's channel as before 5.2 unless asked)
            self.peak_tx = bool(c.get("peak_tx", 0))
            self.tx_on = bool(c.get("tx_on", 1))
            self.snr_set = float(c["snr"])
            self.hw_sim = bool(c.get("hw_sim", 0))
            self.sdr = bool(c.get("sdr", 0))
            if c.get("hw_mode", "Off") != "Off" or getattr(self, "hw", None) is not None:
                if getattr(self, "hw", None) is None:
                    self.hw = HwIO()
                if self.hw.configure(c):                  # a new signal path: find the signal again
                    self.dem.reset()
                    if self.adem is not None:
                        self.adem.reset()
            return True
        if cmd == "reset":
            self.dem.reset()
            if self.adem is not None:
                self.adem.reset()
            return True
        if cmd == "frame":
            _, frame, aud, rf_speed = msg[:4]
            self.mod.word = msg[4] if len(msg) > 4 else None
            wu = word_unpack(self.mod.word) if self.mod.word is not None else None
            if wu is not None:                           # (where the peak limiting may put its error)
                self.mod.enc = wu["enc"]
            t0 = time.time()
            tx = self.mod.modulate(frame, aud)
            if np.any(tx):                               # (the level a received signal would have:
                self.snow_ref = float(np.sqrt(np.mean(np.abs(tx) ** 2)))   # the RX's video noise is scaled to it)
            elif getattr(self, "snow_ref", None) is None:
                self.snow_ref = 1.0
            if not getattr(self, "tx_on", True):         # transmitter off: silence, the same length
                tx = np.zeros_like(tx)
                self.tx_was_off = True
            elif getattr(self, "tx_was_off", False):     # back on: at a time of its own, as a real
                self.tx_was_off = False                  # transmitter starting up would be
                gap = int(np.random.randint(1, max(2, len(tx) // 2)))
                tx = np.concatenate([np.zeros(gap, tx.dtype), tx])
            if getattr(self, "tx200", "2x IFFT") == "2x IFFT":
                rf = interp2(tx)
            else:
                rf = self.up.process(tx)
                if getattr(self, "droop", None) is None:
                    self.droop = TxDroop()
                tx = self.droop.process(tx)                 # what the air gets: the outer carriers rolled off
            # the PAPR going out (2x oversampled, as the SDR is sent); with a peak-limited TX the
            # average - and so the C/N - goes up by what the clipping saved
            if np.any(rf):                                 # (transmitter off: the readings held)
                pp = papr_db(rf)
                pin = getattr(self.mod, "clip_stats", {}).get("papr_in", pp) if self.mod.clip_db is not None else pp
                self.papr = pp if getattr(self, "papr", None) is None else 0.8 * self.papr + 0.2 * pp
                self.papr_in = pin if getattr(self, "papr_in", None) is None else 0.8 * self.papr_in + 0.2 * pin
            self.papr = getattr(self, "papr", 0.0)
            self.papr_in = getattr(self, "papr_in", 0.0)
            self.peak_gain = max(0.0, self.papr_in - self.papr) if self.mod.clip_db is not None else 0.0
            if getattr(self, "peak_tx", False):
                self.chan.snr_db = getattr(self, "snr_set", self.chan.snr_db) + self.peak_gain
            rf_rows = []
            nf = 1024
            for part in np.array_split(rf, max(1, int(rf_speed))):
                seg = part[:len(part) // nf * nf].reshape(-1, nf)
                if len(seg):
                    pw = np.mean(np.abs(np.fft.fftshift(np.fft.fft(seg * np.hanning(nf), axis=1), axes=1)) ** 2, axis=0)
                    rf_rows.append(10 * np.log10(pw + 1e-12))
            if rf_rows:
                P = 10 ** (np.mean(rf_rows, axis=0) / 10.0)
                f = (np.arange(nf) - nf / 2) * (2.0 * FS) / nf
                cs = np.cumsum(P) / P.sum()
                obw = (f[np.searchsorted(cs, 0.995)] - f[np.searchsorted(cs, 0.005)]) / 1e3
                oob = 10 * np.log10(P[np.abs(f) > 50000].sum() / max(P[np.abs(f) <= 50000].sum(), 1e-20))
            else:
                obw = oob = 0.0
            hw = getattr(self, "hw", None)
            if hw is not None and hw.retry():               # (busy before: open now)
                self.dem.reset()
                if self.adem is not None:
                    self.adem.reset()
            if hw is not None and hw.mode in ("Loop", "RX in") and hw.err is not None:
                rx = np.zeros(len(tx), np.complex64)     # the card asked for but not open: nothing comes in
                                                         # (never the simulated channel in its place)
            elif hw is not None and hw.mode != "Off" and hw.err is None:
                hw.send(tx)                              # (TX out, Loop: to the card)
                if hw.rx_on:                             # (Loop, RX in: what came back)
                    rx = hw.receive(len(tx), timeout=len(tx) / float(FS) + 1.0)
                    if self.hw_sim:
                        rx = self.chan.process(rx)
                else:
                    rx = self.chan.process(tx)
            else:
                rx = self.chan.process(tx)
            if self.auto:
                res = self._auto_feed(rx)
            else:
                res = self.dem.feed(rx)
            rows = []
            nf = 512
            for part in np.array_split(rx, 5):
                seg = part[:len(part) // nf * nf].reshape(-1, nf)
                if len(seg):
                    p = np.mean(np.abs(np.fft.fftshift(np.fft.fft(seg * np.hanning(nf), axis=1), axes=1)) ** 2, axis=0)
                    rows.append(10 * np.log10(p + 1e-12))
            d = self.adem if (self.auto and self.adem is not None) else self.dem
            wide, wide_tx = None, False
            if getattr(self, "sdr", False):               # NBTV SDR: its 200 kHz spectrum - what comes in, or what goes out
                if hw is not None and hw.err is None and hw.rx_on:
                    # only what came in from the hardware - never the received channel after its AGC (which lifts
                    # bare noise to the transmitter's level: the bursts of noise seen after TX or loop back)
                    if getattr(hw, "wide", None) is not None:
                        wide, hw.wide = wide_rows(*hw.wide), None
                elif np.any(rf):
                    wide_tx = True                        # (what is going out - shown as such, whenever it arrives)
                    wide = wide_rows(rf * np.sqrt(0.5) / max(float(np.sqrt(np.mean(np.abs(rf) ** 2))), 1e-9)
                                     * 10 ** (-18 / 20.0), 2.0 * FS)
                else:
                    wide = wide_rows(rx, float(FS))
            out = dict(rf_rows=rf_rows, wide=wide, wide_tx=wide_tx, wide_mode=hw.mode if hw is not None else "Off", obw=obw, oob=oob, rows=rows, res=res, stats=dict(d.stats),
                       const=None if d.last_const is None else d.last_const.copy(),
                       const_a=None if getattr(d, "last_const_a", None) is None else d.last_const_a.copy(),
                       const_flip=getattr(d, "last_flip", None), const_flip_a=getattr(d, "last_flip_a", None),
                       timing_curve=d.timing_curve,
                       timing_err=getattr(d, "timing_err", 0.0), echo_est=getattr(d, "echo_est", 0),
                       fade_gain=getattr(self.chan, "fade_gain", 1.0), time=time.time() - t0,
                       papr=self.papr, papr_in=self.papr_in, peak_gain=self.peak_gain if getattr(self, "peak_tx", False) else None,
                       front=dict(agc_db=self.chan.agc_db, rms_dbfs=self.chan.adc_rms_dbfs, clip=self.chan.adc_clip,
                                  level=getattr(d, "level_db", None)),
                       auto=self._auto_state() if self.auto else None,
                       hw=hw.status() if hw is not None and hw.mode != "Off" else None,
                       snow=None if d.locked else np.asarray(rx[:120 * 96 * 3], np.complex64).copy(),
                       snow_ref=self.snow_ref)
            d.timing_curve = None
            return out
        return None


    def _set_rx(self, d):
        d.eq, d.timing, d.manual_offset = self.rx_set["eq"], self.rx_set["timing"], self.rx_set["manual"]
        d.auto_mirror = bool(self.rx_set.get("mirror", False))
        if not d.auto_mirror:
            d.mirror = False

    def _auto_feed(self, rx):
        """Auto: listen until there is enough to tell what is on the air, then receive with that -
        and start again if it is lost for good (the transmitter changed, or went)."""
        if self.adem is not None:
            res = self.adem.feed(rx)
            st = self.adem.stats.get("state")
            d = self.adem
            # a mode word that has been coming and stops is the surest sign the transmission changed
            word_gone = getattr(self, "aword_seen", False) and d.word_age >= 2
            if d.word is not None and d.word_age == 0:
                self.aword_seen = True
            bad = st != "locked" or not res or word_gone
            self.abad = self.abad + 1 if bad else 0
            self.arecent = (getattr(self, "arecent", []) + [np.asarray(rx, np.complex64)]) if bad else []
            if self.abad >= (2 if word_gone else 4):     # gone: find out again, from what came since
                keep = self.arecent
                self.auto_reset()
                self.aword_seen = False
                self.abuf, self.alen = keep, sum(len(k) for k in keep)
                res = []
            return [r for r in res if not word_gone]
        self.abuf.append(np.asarray(rx, np.complex64))
        self.alen += len(rx)
        # the search (seconds on noise) runs beside the frames, not in their way: a transmitter that
        # goes off used to stall the whole lab while Auto searched the silence frame after frame
        job = getattr(self, "ajob", None)
        if job is not None:
            if job["thread"].is_alive():
                while self.alen > 20 * FS and len(self.abuf) > 1:     # (what came since: kept, to a limit)
                    self.alen -= len(self.abuf.pop(0))
                return []
            self.ajob = None
            r = job["result"]
            if r is not None:
                self.ainfo = r
                d = Demodulator(layout(r["fmt"], r["long"], r["cp"], r.get("fixed", False), r.get("dense", False)),
                                r["cp"], self.ilv, r["sync"])
                self._set_rx(d)
                d.auto_word = True
                self.adem = d
                x = np.concatenate([job["x"]] + self.abuf)     # the window searched, and all since
                self.abuf, self.alen = [], 0
                return d.feed(x)
            self.abuf.insert(0, job["x"])                       # nothing: try again on the newest
            self.alen += len(job["x"])
        while self.alen - len(self.abuf[0]) >= AUTO_NEED and len(self.abuf) > 1:
            self.alen -= len(self.abuf[0])
            self.abuf.pop(0)
        if self.alen < AUTO_NEED:
            return []
        job = dict(x=np.concatenate(self.abuf), result=None)
        self.atries += 1

        def work(job=job):
            try:
                job["result"] = auto_detect(job["x"])
            except Exception:
                job["result"] = None
        import threading
        job["thread"] = threading.Thread(target=work, daemon=True, name="nbtv-auto")
        job["thread"].start()
        self.ajob = job
        self.abuf, self.alen = [], 0
        return []

    def _auto_state(self):
        r = self.ainfo
        if self.adem is None or r is None:
            return dict(state="detecting", tries=self.atries, need_s=AUTO_NEED / float(FS), have_s=self.alen / float(FS))
        return dict(state="found", fmt=r["fmt"], long=r["long"], fixed=r.get("fixed", False), cp=r["cp"], sync=r["sync"],
                    word=word_unpack(self.adem.word) if self.adem.word is not None else None,
                    word_age=self.adem.word_age, word_frames=self.adem.word_frames,
                    callsign=self.adem.callsign(), side=self.adem.side_data(), breaks=self.adem.breaks)


class DecodeHandler:
    """Data frame -> pictures (Decoder), the clean-up filters, and the scores against what was sent."""

    def __init__(self):
        self.dec = Decoder()
        self.pf = PictureFilter()
        self.ups = Upscaler()
        self.fi = FrameInterp()

    def handle(self, msg):
        cmd = msg[0]
        if cmd == "reset":
            self.dec.reset()
            self.pf.reset()
            self.ups.reset()
            self.fi.reset()
            return True
        if cmd == "upscale":
            _, yccs, key_idx, next_key, method, snr, F = msg[:7]
            soft_colour = bool(msg[7]) if len(msg) > 7 else False
            use_gpu(len(msg) > 8 and msg[8])
            t0 = time.time()
            out = self.ups.process(yccs, key_idx, next_key, method, snr, soft_colour)
            out = self.fi.process([y[0] for y in yccs], out, next_key, F)       # in-between pictures
            return dict(yccs=out, time=time.time() - t0, gpu=gpu_status())
        if cmd == "decode":
            _, v, mname, c, snr, ref = msg
            t0 = time.time()
            set_colour_coding(c.get("colour_coding", "1/4"))
            set_ww_split(c.get("ww_split", "8+4+4"))
            use_gpu(c.get("gpu", 0))
            mode = MODES[mname]
            self.dec.rx_est = c.get("rx_est", 0)
            yccs = self.dec.push(v, mode, int(c["enc"]), kmx=int(c["kmx"]), key_only=bool(c["key_only"]),
                                 wl=float(c["wl"]), snap=bool(c["snap"]), soft=bool(c["soft"]), snr=snr,
                                 detail=c["detail"], msearch=bool(c["msearch"]), ctrack=bool(c.get("ctrack", 1)),
                                 vemph=bool(c.get("vemph", VEMPH_ON)))
            yccs = self.pf.apply(yccs, int(c["fuzzy_c"]), int(c["fuzzy_p"]), bool(c["median_c"]), float(c["cavg"]),
                                 bool(c["auto_f"]), snr, c.get("tnr", "Off"), eff_enc(mode, int(c["enc"])))
            pic_db = None
            if yccs and ref is not None and len(ref) == len(yccs) and ref[0].shape[:2] == yccs[0][0].shape:
                pic_db = [10 * np.log10(255.0 ** 2 / max(float(np.mean((finish_picture(o).astype(np.float32)
                                                                           - p.astype(np.float32)) ** 2)), 1e-3))
                          for o, p in zip(yccs, ref)]
            enc = eff_enc(mode, int(c["enc"]))
            keys = [0, 1] if enc == 5 else ([0, 1, 2] if enc == WIDE else [0])
            return dict(yccs=yccs, pic_db=pic_db, filt=self.pf.used, time=time.time() - t0,
                        keys=keys if yccs else [], next_key=getattr(self.dec, "next_key", None),
                        gpu=gpu_status())
        return None


# ----------------------------------------------------------------------- GPU (optional)
# The receiver's heavy picture work - the Super-res enlarging, the in-between pictures and the motion
# search - can run on an NVIDIA card through CuPy (pip install cupy-cuda12x; an RTX 50 card needs
# CUDA 12.8 or later and driver 570+).  The same code is used: the functions are run again with
# CuPy standing in for numpy, so the GPU gives the same pictures (to float rounding).  If CuPy is
# missing, or anything fails on the card, the work is done on the CPU as before and the reason shown.
import types as _types
_HOSTNP = np
_GPU = {"want": False, "user": False, "failed": False, "cp": None, "name": None, "err": None, "tried": False, "G": None, "fn": set(),
        "calls": 0, "time": 0.0}
GPU_RUN = ("_upscale_one", "_fi_pair", "_motion_pair")


def gpu_init():
    """Load CuPy and try the card once (in this process).  -> (name or None, error or None)."""
    if _GPU["tried"]:
        return _GPU["name"], _GPU["err"]
    _GPU["tried"] = True
    try:
        _GPU["shadow"] = cuda_namespace_fix()
        import cupy as cp
        if cp.cuda.runtime.getDeviceCount() < 1:
            raise RuntimeError("no CUDA device")
        props = cp.cuda.runtime.getDeviceProperties(0)
        name = props["name"]
        name = name.decode() if isinstance(name, bytes) else str(name)
        x = cp.arange(1024, dtype=cp.float32)           # a real kernel: fails here if CuPy has no
        if abs(float((x * 2.0).sum()) - 1047552.0) > 1:  # code for this card's architecture
            raise RuntimeError("test sum wrong")
        _GPU["cp"], _GPU["name"], _GPU["err"] = cp, name, None
    except ImportError as e:
        import sys as _sys
        py = _sys.executable or "python3"
        if getattr(e, "name", None) == "cupy":
            # (not in this Python: often it went into another one - pip and python3 not the same
            # install, or a virtual environment)
            _GPU["err"] = ("CuPy not installed for %s (Python %d.%d) - install it into that one: "
                           "%s -m pip install cupy-cuda12x" % (py, _sys.version_info[0], _sys.version_info[1], py))
        else:
            # installed, but it couldn't load (a CUDA library it needs, a wheel for another Python - or, most often
            # with "initialization failed", a CuPy built for NumPy 1.x under NumPy 2.x)
            _GPU["err"] = "CuPy found but would not load in %s: %s" % (py, gpu_why(e))
    except Exception as e:
        _GPU["err"] = "%s: %s" % (type(e).__name__, str(e).splitlines()[0][:120] if str(e) else "")
    return _GPU["name"], _GPU["err"]


CUDA_SHIM = """# NBTV SDR: 'cuda' here means NVIDIA's package (cuda.pathfinder, cuda.bindings, cuda.core) - not another
# package of that name (a GNU Radio block, say) that would otherwise be found first.  Only for NBTV SDR and
# the processes it starts (CuPy's own probes included): nothing is moved or changed.
import os as _os
import sys as _sys
__path__ = []
for _d in _sys.path:
    _c = _os.path.join(_d or ".", "cuda")
    if _os.path.abspath(_c) != _os.path.abspath(_os.path.dirname(__file__)) and _c not in __path__ and \\
            any(_os.path.isdir(_os.path.join(_c, _k)) for _k in ("pathfinder", "bindings", "core")):
        __path__.append(_c)
"""


def cuda_namespace_fix():
    """CuPy 13+ imports NVIDIA's 'cuda' package (cuda.pathfinder, cuda.bindings - a namespace package, no
    __init__.py).  Another package called just 'cuda' with an __init__.py - a GNU Radio block in
    /usr/local/lib/python3.x/dist-packages/cuda, say - wins over it wherever it sits on the path, and CuPy then
    loads that (and GNU Radio, and its NumPy 1.x build) instead.  Here a small 'cuda' of NBTV SDR's own goes first
    on the path - in this process, and through PYTHONPATH in the ones it starts (CuPy checks libraries in a child
    "canary" process) - and points 'cuda' at NVIDIA's folders.  -> the package set aside, or None."""
    import importlib.util
    import sys as _sys
    nv = []
    for d in _sys.path:
        c = os.path.join(d or ".", "cuda")
        if os.path.isdir(c) and any(os.path.isdir(os.path.join(c, k)) for k in ("pathfinder", "bindings", "core")) \
                and c not in nv:
            nv.append(c)
    if not nv:
        return None
    try:
        spec = importlib.util.find_spec("cuda") if "cuda" not in _sys.modules else _sys.modules["cuda"].__spec__
    except Exception:
        spec = None
    other = None
    if spec is not None and spec.origin not in (None, "namespace") and str(spec.origin).endswith("__init__.py"):
        other = os.path.dirname(spec.origin)
    if other is None or os.path.normpath(other) in [os.path.normpath(n) for n in nv]:
        return None
    if "nbtv_cuda_shim" in other:                       # (ours already)
        return getattr(_sys.modules.get("nbtv_core"), "_CUDA_OTHER", None)
    base = os.path.join(os.path.expanduser("~"), ".cache", "nbtv_cuda_shim")
    try:
        os.makedirs(os.path.join(base, "cuda"), exist_ok=True)
        with open(os.path.join(base, "cuda", "__init__.py"), "w") as f:
            f.write(CUDA_SHIM)
    except OSError:
        import tempfile
        base = os.path.join(tempfile.gettempdir(), "nbtv_cuda_shim")
        os.makedirs(os.path.join(base, "cuda"), exist_ok=True)
        with open(os.path.join(base, "cuda", "__init__.py"), "w") as f:
            f.write(CUDA_SHIM)
    if base in _sys.path:
        _sys.path.remove(base)
    _sys.path.insert(0, base)
    pp = [x for x in os.environ.get("PYTHONPATH", "").split(os.pathsep) if x and x != base]
    os.environ["PYTHONPATH"] = os.pathsep.join([base] + pp)    # (the child processes too)
    for k in [k for k in _sys.modules if k == "cuda" or k.startswith("cuda.")]:
        del _sys.modules[k]
    importlib.invalidate_caches()
    global _CUDA_OTHER
    _CUDA_OTHER = other
    return other


_CUDA_OTHER = None


def gpu_why(e):
    """Why CuPy would not load, in a line, with what to do: its own words (the line that says why, not CuPy's
    banner), the versions in play, and the likely fix."""
    import sys as _sys
    import traceback as _tb
    try:
        full = "".join(_tb.format_exception(type(e), e, e.__traceback__))
    except Exception:
        full = ""
    if "gnuradio" in full and "cuda" in full:
        import re as _re
        mm = _re.search(r'File "([^"]*?[/\\]cuda)[/\\]__init__\.py"', full)
        where = mm.group(1) if mm else "a package called 'cuda'"
        return ("CuPy was handed %s (a GNU Radio block, not NVIDIA's cuda package), which loads GNU Radio built for "
                "NumPy 1.x under NumPy %s - rename or remove that package, or run NBTV SDR in its own venv" % (where, np.__version__))
    txt = str(e) or type(e).__name__
    lines = [l.strip() for l in txt.splitlines() if l.strip() and not set(l.strip()) <= set("=-")]
    why = next((l for l in lines if l.lower().startswith(("importerror", "oserror", "original error"))), None)
    if why and why.lower().startswith("original error"):
        k = lines.index(why)
        why = lines[k + 1] if k + 1 < len(lines) else why
    why = why or (lines[-1] if lines else txt)
    try:
        from importlib import metadata as md
        cps = [(d, md.version(d)) for d in ("cupy-cuda12x", "cupy-cuda11x", "cupy-cuda13x", "cupy") if _has_dist(md, d)]
    except Exception:
        cps = []
    cpv = ", ".join("%s %s" % c for c in cps) or "CuPy ?"
    npv = np.__version__
    hint = ""
    low = txt.lower()
    if "initialization failed" in low or "numpy" in low or "multiarray" in low:
        if int(npv.split(".")[0]) >= 2:
            hint = (" - this CuPy was built for NumPy 1.x and NumPy here is %s: update CuPy  (%s -m pip install -U %s)"
                    % (npv, _sys.executable or "python3", cps[0][0] if cps else "cupy-cuda12x"))
    elif "libcudart" in low or "libnvrtc" in low or "libcublas" in low or "cuda" in low and "version" in low:
        hint = " - the CUDA libraries don't match this CuPy: install the cupy-cudaXXx that matches nvidia-smi's CUDA version"
    return "%s  [%s, NumPy %s, Python %d.%d]%s" % (why[:160], cpv, npv, _sys.version_info[0], _sys.version_info[1], hint)


def _has_dist(md, d):
    try:
        md.version(d)
        return True
    except Exception:
        return False


def use_gpu(on):
    """Turn the GPU on or off for this process (each message says; ticking it again after a
    failure gives the card another go)."""
    on = bool(on)
    if on and not _GPU["user"]:
        _GPU["failed"] = False
        if _GPU["cp"] is None and _GPU["err"]:          # (another go: CuPy may have been installed since)
            _GPU["tried"] = False
            import importlib
            importlib.invalidate_caches()
    _GPU["user"] = on
    _GPU["want"] = on and not _GPU["failed"]
    if _GPU["want"]:
        gpu_init()


def gpu_status():
    """-> dict(on, name, err, ms): on = the work is really going to the card."""
    on = bool(_GPU["want"] and _GPU["cp"] is not None)
    ms = 1000.0 * _GPU["time"] / _GPU["calls"] if _GPU["calls"] else None
    return dict(on=on, want=_GPU["user"], name=_GPU["name"], err=_GPU["err"], ms=ms)


class _XpNS:
    """numpy's names as the GPU code sees them: CuPy's, plus what CuPy lacks."""

    def __init__(self, cp):
        self._cp = cp
        ast = cp.lib.stride_tricks.as_strided

        def sliding_window_view(x, window_shape, axis):
            n = int(window_shape)
            shp = list(x.shape)
            shp[axis] = x.shape[axis] - n + 1
            return ast(x, tuple(shp) + (n,), tuple(x.strides) + (x.strides[axis],))
        self.lib = _types.SimpleNamespace(stride_tricks=_types.SimpleNamespace(
            sliding_window_view=sliding_window_view, as_strided=ast))

    def __getattr__(self, k):
        return getattr(self._cp, k)


def _host(x):
    cp = _GPU["cp"]
    return cp.asnumpy(x) if cp is not None and isinstance(x, cp.ndarray) else x


def _est_shift_dev(A, B, ry=3, rx=6, iters=6):
    """est_shift for the card: the same search, with the few small sums brought back at once
    rather than one by one."""
    A = _box(np.asarray(A, np.float32), 1)
    B = _box(np.asarray(B, np.float32), 1)
    h, w = A.shape
    my, mx = ry + 2, rx + 2
    Bc = B[my:h - my, mx:w - mx]
    errs = _host(np.stack([np.mean(np.abs(A[my + dy:h - my + dy, mx + dx:w - mx + dx] - Bc))
                           for dy in range(-ry, ry + 1) for dx in range(-rx, rx + 1)]))
    k = int(_HOSTNP.argmin(errs))
    d = _HOSTNP.array([k // (2 * rx + 1) - ry, k % (2 * rx + 1) - rx], float)
    for _ in range(iters):
        As = fshift(A, float(d[0]), float(d[1]))
        gy = np.gradient(As, axis=0)[my:h - my, mx:w - mx]
        gx = np.gradient(As, axis=1)[my:h - my, mx:w - mx]
        e = Bc - As[my:h - my, mx:w - mx]
        sm = _HOSTNP.asarray(_host(np.stack([np.sum(gy * gy), np.sum(gy * gx), np.sum(gx * gx),
                                             np.sum(gy * e), np.sum(gx * e)])), float)
        M = _HOSTNP.array([[sm[0], sm[1]], [sm[1], sm[2]]]) + 1e-3 * _HOSTNP.eye(2)   # (a flat picture: no singular matrix)
        st = _HOSTNP.clip(_HOSTNP.linalg.solve(M, sm[3:5]), -1, 1)
        d += st
        if _HOSTNP.abs(st).max() < 0.01:
            break
    d = _HOSTNP.clip(d, [-ry, -rx], [ry, rx])
    err = float(np.mean(np.abs(Bc - fshift(A, float(d[0]), float(d[1]))[my:h - my, mx:w - mx])))
    return d, err


_CUB = {}


def _cubic_1d_dev(a, f, n_out, axis):
    """_cubic_1d for the card: the taps and weights worked out once per size and kept there, then
    one gather - a few kernels instead of some twenty-five."""
    a = np.moveaxis(np.asarray(a, np.float32), axis, 0)
    n = a.shape[0]
    tw = _CUB.get((n, f, n_out))
    if tw is None:
        hn = _HOSTNP
        x = (hn.arange(n_out) + 0.5) / f - 0.5
        i0 = hn.floor(x).astype(int)
        t = (x - i0).astype(hn.float32)
        w = hn.stack([((-0.5 * t + 1.0) * t - 0.5) * t, (1.5 * t - 2.5) * t * t + 1.0,
                      ((-1.5 * t + 2.0) * t + 0.5) * t, (0.5 * t - 0.5) * t * t]).astype(hn.float32)
        idx = hn.stack([hn.clip(i0 - 1 + k, 0, n - 1) for k in range(4)])
        tw = _CUB[(n, f, n_out)] = (np.asarray(idx), np.asarray(w))
    idx, w = tw
    out = (w.reshape((4, n_out) + (1,) * (a.ndim - 1)) * a[idx]).sum(axis=0)
    return np.moveaxis(out, 0, axis)


def _gpu_world():
    """This module's functions again, with numpy -> CuPy."""
    G = _GPU["G"]
    mod = globals()
    if G is None:
        G = dict(mod)
        fn = set()
        for k, v in list(mod.items()):
            if isinstance(v, _types.FunctionType) and v.__module__ == __name__:
                f = _types.FunctionType(v.__code__, G, v.__name__, v.__defaults__, v.__closure__)
                f.__kwdefaults__ = v.__kwdefaults__
                G[k] = f
                fn.add(k)
        G["est_shift"] = G["_est_shift_dev"]
        G["_cubic_1d"] = G["_cubic_1d_dev"]
        G["np"] = _XpNS(_GPU["cp"])
        _GPU["G"], _GPU["fn"] = G, fn
    else:                                              # settings changed since (colour coding ...)
        for k, v in mod.items():
            if k not in _GPU["fn"] and k not in ("np", "est_shift", "_cubic_1d"):
                G[k] = v
    return G


def _to_dev(x, cp):
    if isinstance(x, _HOSTNP.ndarray):
        return cp.asarray(x)
    if isinstance(x, (list, tuple)):
        return type(x)(_to_dev(v, cp) for v in x)
    return x


def _to_host(x):
    cp = _GPU["cp"]
    if isinstance(x, cp.ndarray):
        return cp.asnumpy(x)
    if isinstance(x, (list, tuple)):
        return type(x)(_to_host(v) for v in x)
    return x


def gpu_run(name, *args, **kw):
    """Run one of GPU_RUN on the card if it is on, else (or if that fails) on the CPU."""
    if _GPU["want"] and _GPU["cp"] is not None:
        t0 = time.time()
        try:
            cp = _GPU["cp"]
            G = _gpu_world()
            r = _to_host(G[name](*_to_dev(args, cp), **{k: _to_dev(v, cp) for k, v in kw.items()}))
            _GPU["calls"] += 1
            _GPU["time"] += time.time() - t0
            return r
        except Exception as e:                         # off for now; the reason is shown
            _GPU["want"], _GPU["failed"] = False, True
            _GPU["err"] = "%s in %s: %s" % (type(e).__name__, name, (str(e).splitlines() or [""])[0][:120])
    return globals()[name](*args, **kw)


HANDLERS = {"modem": ModemHandler, "decode": DecodeHandler, "upscale": DecodeHandler}


def _worker_main(kind, conn):
    """A worker process: answer messages until told to stop (or the window goes away)."""
    try:
        import os
        os.nice(2)                                       # the window stays the snappiest
    except Exception:
        pass
    h = HANDLERS[kind]()
    while True:
        try:
            msg = conn.recv()
        except (EOFError, OSError):
            break
        if msg[0] == "quit":
            break
        try:
            conn.send(("ok", h.handle(msg)))
        except Exception as e:
            import traceback
            tb = traceback.extract_tb(e.__traceback__)[-1]
            conn.send(("error", "%s (line %d, %s)" % (e, tb.lineno, tb.name)))


class _NoMain:
    """While worker processes start: hide the program that started them, so a fresh process
    imports only this module (spawn would otherwise run the main script again in each worker)."""

    def __enter__(self):
        import sys
        import types
        self.main = sys.modules.get("__main__")
        sys.modules["__main__"] = types.ModuleType("__main__")
        return self

    def __exit__(self, *a):
        import sys
        sys.modules["__main__"] = self.main
        return False


def mp_context():
    import multiprocessing as mp
    return mp.get_context("spawn")


class Worker:
    """One stage, in its own process (multi-core) or, if that cannot start, in the caller's thread.
    send() then recv(): a worker answers every message, in order."""

    def __init__(self, kind, use_process=True):
        self.kind = kind
        self.proc = None
        self.local = None
        self.pending = []
        if use_process:
            try:
                import multiprocessing as mp
                ctx = mp.get_context("spawn")        # a clean process: no copy of the window
                a, b = ctx.Pipe()
                self.proc = ctx.Process(target=_worker_main, args=(kind, b), daemon=True,
                                        name="nbtv-%s" % kind)
                with _NoMain():
                    self.proc.start()
                self.conn = a
            except Exception as e:
                self.proc = None
                self.error = str(e)
        if self.proc is None:
            self.local = HANDLERS[kind]()

    @property
    def multi(self):
        return self.proc is not None

    def send(self, msg):
        if self.proc is not None:
            self.conn.send(msg)
        else:
            try:
                self.pending.append(("ok", self.local.handle(msg)))
            except Exception as e:
                self.pending.append(("error", str(e)))

    def recv(self, timeout=None):
        """The answer to the oldest message sent (None if it does not come within timeout)."""
        if self.proc is not None:
            if timeout is not None and not self.conn.poll(timeout):
                return None
            st, val = self.conn.recv()
        else:
            st, val = self.pending.pop(0)
        if st == "error":
            raise RuntimeError("%s worker: %s" % (self.kind, val))
        return val

    def ready(self):
        """True if the answer to the oldest message is waiting (recv() won't wait)."""
        if self.proc is not None:
            return self.conn.poll(0)
        return bool(self.pending)

    def call(self, msg):
        self.send(msg)
        return self.recv()

    def close(self):
        if self.proc is not None:
            try:
                self.conn.send(("quit",))
            except Exception:
                pass
            self.proc.join(0.5)
            if self.proc.is_alive():
                self.proc.terminate()
            self.proc = None


def pool_size():
    """Worker processes for the off-line tests: every core but one (the window keeps one)."""
    import os
    return max(1, (os.cpu_count() or 1) - 1)


def run_parallel(fn, jobs, on_result, stopped=lambda: False, workers=None, log=None):
    """fn(*job) for every job, spread over the cores; on_result(job, result) as each finishes
    (in the caller's thread, in whatever order they finish).  fn must be a module-level function.
    With one core, or if the processes cannot start, the jobs run here one after another."""
    jobs = list(jobs)
    n = min(workers or pool_size(), len(jobs))
    ex = None
    if n > 1:
        try:
            from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
            ex = ProcessPoolExecutor(max_workers=n, mp_context=mp_context())
            with _NoMain():
                futs = {ex.submit(fn, *j): j for j in jobs}
        except Exception as e:
            if log:
                log("Multi-core: process pool would not start (%s) - one core" % e)
            if ex is not None:
                ex.shutdown(wait=False, cancel_futures=True)
            ex = None
    if ex is None:
        for j in jobs:
            if stopped():
                return False
            on_result(j, fn(*j))
        return True
    try:
        left = set(futs)
        while left:
            done, left = wait(left, timeout=0.2, return_when=FIRST_COMPLETED)
            for f in done:
                on_result(futs[f], f.result())
            if stopped():
                for p in list(getattr(ex, "_processes", {}).values()):   # stop now, not after the points in hand
                    try:
                        p.terminate()
                    except Exception:
                        pass
                return False
        return True
    finally:
        try:
            ex.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass


def sync_point_job(mode, sync, snr, trials, seed, frames, cfo_max, cp, eq, channel):
    """sync_point with plain arguments (for the process pool)."""
    return sync_point(mode, sync, snr, trials=trials, seed=seed, frames=frames, cfo_max=cfo_max, cp=cp, eq=eq,
                      channel=channel)
