# -*- coding: utf-8 -*-
"""NBTV SDR - the languages of its windows (labels, buttons, tick boxes, titles).

English is the program's own text; each other language is looked up here as a widget is drawn
or its text changed, so the program's code stays in English and its settings keep their English
values.  install() hooks tkinter once; set_language() redraws every open window in the new one.
A text with no entry here stays in English.  Grant Taylor VE3XTV.
"""
import re
import weakref
import tkinter as tk
from tkinter import ttk

LANGS = [("en", "English"), ("de", "Deutsch"), ("nl", "Nederlands"), ("fr", "Français"), ("it", "Italiano"),
         ("es", "Español")]
_COL = {"de": 0, "nl": 1, "fr": 2, "it": 3, "es": 4}

# English -> (German, Dutch, French, Italian, Spanish)
TR = {
    '   Format':
        ('   Format', '   Formaat', '   Format', '   Formato', '   Formato'),
    '  Callsign':
        ('  Rufzeichen', '  Roepnaam', '  Indicatif', '  Nominativo', '  Indicativo'),
    '  Frequency correction ppm':
        ('  Frequenzkorrektur ppm', '  Frequentiecorrectie ppm', '  Correction de fréquence ppm', '  Correzione di frequenza ppm', '  Corrección de frecuencia ppm'),
    '  Locator':
        ('  Locator', '  Locator', '  Locator', '  Locatore', '  Locator'),
    '  Title':
        ('  Titel', '  Titel', '  Titre', '  Titolo', '  Título'),
    '  e.g. driver=lime, or serial=... (SDRplay adds driver=sdrplay)':
        ('  z. B. driver=lime oder serial=... (SDRplay ergänzt driver=sdrplay)', '  bijv. driver=lime of serial=... (SDRplay voegt driver=sdrplay toe)', '  p. ex. driver=lime ou serial=... (SDRplay ajoute driver=sdrplay)', '  es. driver=lime o serial=... (SDRplay aggiunge driver=sdrplay)', '  p. ej. driver=lime o serial=... (SDRplay añade driver=sdrplay)'),
    ' Common':
        (' Gemeinsam', ' Gemeenschappelijk', ' Commun', ' Comune', ' Común'),
    ' Listen':
        (' Hören', ' Luisteren', ' Écoute', ' Ascolto', ' Escuchar'),
    '%s   10 dB/div, kHz':
        ('%s   10 dB/Teil, kHz', '%s   10 dB/div, kHz', '%s   10 dB/div, kHz', '%s   10 dB/div, kHz', '%s   10 dB/div, kHz'),
    '%s  mode %s  %.1f fps  %.2f s per data frame  %d carriers':
        ('%s  Modus %s  %.1f fps  %.2f s pro Datenrahmen  %d Träger', '%s  modus %s  %.1f fps  %.2f s per dataframe  %d draaggolven', '%s  mode %s  %.1f i/s  %.2f s par trame  %d porteuses', '%s  modo %s  %.1f fps  %.2f s per trama  %d portanti', '%s  modo %s  %.1f fps  %.2f s por trama  %d portadoras'),
    '%s %s - Help':
        ('%s %s - Hilfe', '%s %s - Help', '%s %s - Aide', '%s %s - Guida', '%s %s - Ayuda'),
    '%s - hardware setup':
        ('%s - Hardware-Einrichtung', '%s - hardware-instellingen', '%s - configuration matérielle', '%s - configurazione hardware', '%s - configuración del hardware'),
    '%s received, shown %dx%d (x%.1f)   upscale: %s   - drag the edges, 1-4: size, F11 / double click: full screen':
        ('%s empfangen, angezeigt %dx%d (x%.1f)   Hochskalierung: %s   - Ränder ziehen, 1-4: Größe, F11 / Doppelklick: Vollbild', '%s ontvangen, getoond %dx%d (x%.1f)   opschalen: %s   - sleep aan de randen, 1-4: grootte, F11 / dubbelklik: volledig scherm', '%s reçu, affiché %dx%d (x%.1f)   agrandissement : %s   - tirez les bords, 1-4 : taille, F11 / double-clic : plein écran', '%s ricevuto, mostrato %dx%d (x%.1f)   ingrandimento: %s   - trascina i bordi, 1-4: dimensione, F11 / doppio clic: schermo intero', '%s recibido, mostrado %dx%d (x%.1f)   escalado: %s   - arrastre los bordes, 1-4: tamaño, F11 / doble clic: pantalla completa'),
    '10 m channels':
        ('10-m-Kanäle', '10 m-kanalen', 'Canaux 10 m', 'Canali 10 m', 'Canales de 10 m'),
    '100 kHz each, 29.0 - 29.5 MHz':
        ('je 100 kHz, 29,0 - 29,5 MHz', 'elk 100 kHz, 29,0 - 29,5 MHz', '100 kHz chacun, 29,0 - 29,5 MHz', '100 kHz ciascuno, 29,0 - 29,5 MHz', '100 kHz cada uno, 29,0 - 29,5 MHz'),
    '100 kHz each, 51.0 - 52.0 MHz':
        ('je 100 kHz, 51,0 - 52,0 MHz', 'elk 100 kHz, 51,0 - 52,0 MHz', '100 kHz chacun, 51,0 - 52,0 MHz', '100 kHz ciascuno, 51,0 - 52,0 MHz', '100 kHz cada uno, 51,0 - 52,0 MHz'),
    '16 pilots (HF)':
        ('16 Piloten (KW)', '16 piloten (HF)', '16 pilotes (HF)', '16 piloti (HF)', '16 pilotos (HF)'),
    '25 fps':
        ('25 fps', '25 fps', '25 i/s', '25 fps', '25 fps'),
    '6 m channels':
        ('6-m-Kanäle', '6 m-kanalen', 'Canaux 6 m', 'Canali 6 m', 'Canales de 6 m'),
    "9600 baud 8N1, no terminator; F (kHz), TX, RX, P1/P0 (pre-amp), A1/A0 (attenuator) - the window follows the radio's replies.  Permission: sudo usermod -aG dialout $USER":
        ('9600 Baud 8N1, ohne Endzeichen; F (kHz), TX, RX, P1/P0 (Vorverstärker), A1/A0 (Abschwächer) - das Fenster folgt den Antworten des Funkgeräts.  Berechtigung: sudo usermod -aG dialout $USER', '9600 baud 8N1, geen afsluitteken; F (kHz), TX, RX, P1/P0 (voorversterker), A1/A0 (verzwakker) - het venster volgt de antwoorden van de radio.  Rechten: sudo usermod -aG dialout $USER', '9600 bauds 8N1, sans terminaison ; F (kHz), TX, RX, P1/P0 (préampli), A1/A0 (atténuateur) - la fenêtre suit les réponses de la radio.  Droits : sudo usermod -aG dialout $USER', '9600 baud 8N1, senza terminatore; F (kHz), TX, RX, P1/P0 (preamplificatore), A1/A0 (attenuatore) - la finestra segue le risposte della radio.  Permessi: sudo usermod -aG dialout $USER', '9600 baudios 8N1, sin terminador; F (kHz), TX, RX, P1/P0 (preamplificador), A1/A0 (atenuador) - la ventana sigue las respuestas de la radio.  Permisos: sudo usermod -aG dialout $USER'),
    'ALSA hw:C,D = the card itself, past PulseAudio / PipeWire (nothing resampled or mixed).  You can type one\nin, e.g. hw:1,0.  If it says busy: Release card (below), or start with  pasuspender -- python3 nbtv_sdr.py':
        ('ALSA hw:C,D = die Karte selbst, an PulseAudio / PipeWire vorbei (nichts umgetastet oder gemischt).  Sie können eine\neingeben, z. B. hw:1,0.  Bei „belegt“: Karte freigeben (unten), oder starten mit  pasuspender -- python3 nbtv_sdr.py', 'ALSA hw:C,D = de kaart zelf, buiten PulseAudio / PipeWire om (niets herbemonsterd of gemengd).  U kunt er een\nintypen, bijv. hw:1,0.  Bij ‘bezet’: Kaart vrijgeven (hieronder), of start met  pasuspender -- python3 nbtv_sdr.py', 'ALSA hw:C,D = la carte elle-même, sans PulseAudio / PipeWire (rien de rééchantillonné ni mixé).  Vous pouvez en\nsaisir une, p. ex. hw:1,0.  Si elle est occupée : Libérer la carte (ci-dessous), ou lancez  pasuspender -- python3 nbtv_sdr.py', 'ALSA hw:C,D = la scheda stessa, senza PulseAudio / PipeWire (niente ricampionato o mixato).  Se ne può\nscrivere una, es. hw:1,0.  Se risulta occupata: Rilascia scheda (sotto), o avviare con  pasuspender -- python3 nbtv_sdr.py', 'ALSA hw:C,D = la propia tarjeta, sin pasar por PulseAudio / PipeWire (nada remuestreado ni mezclado).  Puede\nescribir una, p. ej. hw:1,0.  Si dice ocupada: Liberar tarjeta (abajo), o inicie con  pasuspender -- python3 nbtv_sdr.py'),
    'Airspy HF+ / HF+ Discovery - receive only (airspyhf_rx, 192 kHz)':
        ('Airspy HF+ / HF+ Discovery - nur Empfang (airspyhf_rx, 192 kHz)', 'Airspy HF+ / HF+ Discovery - alleen ontvangst (airspyhf_rx, 192 kHz)', 'Airspy HF+ / HF+ Discovery - réception seule (airspyhf_rx, 192 kHz)', 'Airspy HF+ / HF+ Discovery - solo ricezione (airspyhf_rx, 192 kHz)', 'Airspy HF+ / HF+ Discovery - solo recepción (airspyhf_rx, 192 kHz)'),
    'Antenna (blank: default)':
        ('Antenne (leer: Standard)', 'Antenne (leeg: standaard)', 'Antenne (vide : par défaut)', 'Antenna (vuoto: predefinita)', 'Antena (vacío: predeterminada)'),
    'Attenuator':
        ('Abschwächer', 'Verzwakker', 'Atténuateur', 'Attenuatore', 'Atenuador'),
    'Attenuator dB':
        ('Abschwächer dB', 'Verzwakker dB', 'Atténuateur dB', 'Attenuatore dB', 'Atenuador dB'),
    'Audio in (L / R)':
        ('Audio ein (L / R)', 'Audio in (L / R)', 'Audio entrée (G / D)', 'Audio ingresso (S / D)', 'Audio entrada (I / D)'),
    'Audio out (L / R)':
        ('Audio aus (L / R)', 'Audio uit (L / R)', 'Audio sortie (G / D)', 'Audio uscita (S / D)', 'Audio salida (I / D)'),
    'Auto (by SNR)':
        ('Auto (nach SNR)', 'Auto (op SNR)', 'Auto (selon SNR)', 'Auto (secondo SNR)', 'Auto (según SNR)'),
    'Auto I/Q swap':
        ('Auto-I/Q-Tausch', 'Auto I/Q-wissel', 'Inversion I/Q auto', 'Scambio I/Q automatico', 'Intercambio I/Q automático'),
    'Auto mode (RX)':
        ('Auto-Modus (RX)', 'Automodus (RX)', 'Mode auto (RX)', 'Modo automatico (RX)', 'Modo automático (RX)'),
    'Balance L/R':
        ('Balance L/R', 'Balans L/R', 'Balance G/D', 'Bilanciamento S/D', 'Balance I/D'),
    'Brightness':
        ('Helligkeit', 'Helderheid', 'Luminosité', 'Luminosità', 'Brillo'),
    'Buffer ms':
        ('Puffer ms', 'Buffer ms', 'Tampon ms', 'Buffer ms', 'Búfer ms'),
    'Card check':
        ('Kartenprüfung', 'Kaarttest', 'Test de carte', 'Verifica scheda', 'Prueba de tarjeta'),
    'Card check: line out -> line in on its own, with no modem; it measures the path and sets the I/Q trim.\nThe I/Q path is closed for it (receive).':
        ('Kartenprüfung: Line-Ausgang -> Line-Eingang allein, ohne Modem; sie misst den Pfad und stellt den I/Q-Abgleich ein.\nDer I/Q-Pfad ist dafür geschlossen (Empfang).', 'Kaarttest: lijnuitgang -> lijningang op zichzelf, zonder modem; meet het pad en stelt de I/Q-correctie in.\nHet I/Q-pad is daarvoor gesloten (ontvangst).', 'Test de carte : sortie ligne -> entrée ligne seule, sans modem ; il mesure le trajet et règle la correction I/Q.\nLe trajet I/Q est fermé pendant ce test (réception).', 'Verifica scheda: uscita linea -> ingresso linea da sola, senza modem; misura il percorso e imposta la correzione I/Q.\nIl percorso I/Q è chiuso durante la verifica (ricezione).', 'Prueba de tarjeta: salida de línea -> entrada de línea sola, sin módem; mide el trayecto y ajusta la corrección I/Q.\nEl trayecto I/Q se cierra durante la prueba (recepción).'),
    'Channel in card kHz':
        ('Kanal in der Karte kHz', 'Kanaal in kaart kHz', 'Canal dans la carte kHz', 'Canale nella scheda kHz', 'Canal en la tarjeta kHz'),
    'Clean-up for poor signals':
        ('Aufbereitung für schwache Signale', 'Opschonen bij zwakke signalen', 'Nettoyage pour signaux faibles', 'Pulizia per segnali deboli', 'Limpieza para señales débiles'),
    'Close':
        ('Schließen', 'Sluiten', 'Fermer', 'Chiudi', 'Cerrar'),
    'Colour':
        ('Farbe', 'Kleur', 'Couleur', 'Colore', 'Color'),
    'Colour median':
        ('Farbmedian', 'Kleurmediaan', 'Médiane couleur', 'Mediana colore', 'Mediana de color'),
    'Colour over frames':
        ('Farbe über Rahmen', 'Kleur over frames', 'Couleur sur trames', 'Colore su più quadri', 'Color entre cuadros'),
    'Common':
        ('Gemeinsam', 'Gemeenschappelijk', 'Commun', 'Comune', 'Común'),
    'Connect':
        ('Verbinden', 'Verbinden', 'Connecter', 'Connetti', 'Conectar'),
    'Contrast':
        ('Kontrast', 'Contrast', 'Contraste', 'Contrasto', 'Contraste'),
    'Copy report':
        ('Bericht kopieren', 'Rapport kopiëren', 'Copier le rapport', 'Copia rapporto', 'Copiar informe'),
    'Decoder and RX':
        ('Decoder und RX', 'Decoder en RX', 'Décodeur et RX', 'Decodificatore e RX', 'Decodificador y RX'),
    'Defaults':
        ('Standardwerte', 'Standaardwaarden', 'Par défaut', 'Predefiniti', 'Valores predeterminados'),
    'Device':
        ('Gerät', 'Apparaat', 'Périphérique', 'Dispositivo', 'Dispositivo'),
    'Device arguments':
        ('Geräteargumente', 'Apparaatargumenten', 'Arguments du périphérique', 'Argomenti dispositivo', 'Argumentos del dispositivo'),
    'Device index':
        ('Geräteindex', 'Apparaatindex', 'Index du périphérique', 'Indice dispositivo', 'Índice del dispositivo'),
    'Display (Linux :0.0 - blank for this one; Windows desktop; macOS Capture screen 0)':
        ('Bildschirm (Linux :0.0 - leer für diesen; Windows desktop; macOS Capture screen 0)', 'Scherm (Linux :0.0 - leeg voor dit scherm; Windows desktop; macOS Capture screen 0)', 'Écran (Linux :0.0 - vide pour celui-ci ; Windows desktop ; macOS Capture screen 0)', 'Schermo (Linux :0.0 - vuoto per questo; Windows desktop; macOS Capture screen 0)', 'Pantalla (Linux :0.0 - vacío para esta; Windows desktop; macOS Capture screen 0)'),
    'Displayed text':
        ('Angezeigter Text', 'Getoonde tekst', 'Texte affiché', 'Testo visualizzato', 'Texto mostrado'),
    'Double-click a folder to open it,\na picture to use it.':
        ('Doppelklick auf einen Ordner öffnet ihn,\nauf ein Bild verwendet es.', 'Dubbelklik op een map om die te openen,\nop een afbeelding om die te gebruiken.', "Double-cliquez sur un dossier pour l'ouvrir,\nsur une image pour l'utiliser.", "Doppio clic su una cartella per aprirla,\nsu un'immagine per usarla.", 'Doble clic en una carpeta para abrirla,\nen una imagen para usarla.'),
    'Echo fit':
        ('Echo-Anpassung', 'Echo-aanpassing', "Ajustement d'écho", 'Adattamento eco', 'Ajuste de eco'),
    'Encode and TX':
        ('Kodierung und TX', 'Coderen en TX', 'Codage et TX', 'Codifica e TX', 'Codificación y TX'),
    'Encoder mode':
        ('Encoder-Modus', 'Encodermodus', 'Mode du codeur', 'Modo codificatore', 'Modo del codificador'),
    'Equaliser':
        ('Entzerrer', 'Equalizer', 'Égaliseur', 'Equalizzatore', 'Ecualizador'),
    "ExSDR radio: VE3XTV's homebrew HF SDR - serial control, I/Q through a 192 kHz sound card":
        ('ExSDR-Funkgerät: VE3XTVs selbstgebautes KW-SDR - serielle Steuerung, I/Q über eine 192-kHz-Soundkarte', 'ExSDR-radio: de zelfbouw-HF-SDR van VE3XTV - seriële besturing, I/Q via een 192 kHz-geluidskaart', 'Radio ExSDR : le SDR HF fait maison de VE3XTV - commande série, I/Q par une carte son 192 kHz', "Radio ExSDR: l'SDR HF autocostruito di VE3XTV - controllo seriale, I/Q tramite una scheda audio a 192 kHz", 'Radio ExSDR: el SDR de HF casero de VE3XTV - control serie, I/Q mediante una tarjeta de sonido de 192 kHz'),
    'Fixed: interleave on, emphasis 75 µs, colour BT.601, 240x192 detail DCT':
        ('Fest: Interleave ein, Preemphasis 75 µs, Farbe BT.601, 240x192-Detail DCT', 'Vast: interleave aan, pre-emfase 75 µs, kleur BT.601, 240x192-detail DCT', 'Fixe : entrelacement actif, préaccentuation 75 µs, couleur BT.601, détail 240x192 DCT', 'Fisso: interleave attivo, preenfasi 75 µs, colore BT.601, dettaglio 240x192 DCT', 'Fijo: entrelazado activo, preénfasis 75 µs, color BT.601, detalle 240x192 DCT'),
    'Fold peaks (TI)':
        ('Spitzen falten (TI)', 'Pieken vouwen (TI)', 'Replier les crêtes (TI)', 'Ripiega picchi (TI)', 'Plegar picos (TI)'),
    'Font':
        ('Schrift', 'Lettertype', 'Police', 'Carattere', 'Fuente'),
    'Font size':
        ('Schriftgröße', 'Lettergrootte', 'Taille de police', 'Dimensione carattere', 'Tamaño de fuente'),
    'Frame rate':
        ('Bildrate', 'Beeldsnelheid', "Fréquence d'images", 'Frequenza quadri', 'Velocidad de cuadros'),
    'Frequency (channel centre)':
        ('Frequenz (Kanalmitte)', 'Frequentie (kanaalmidden)', 'Fréquence (centre du canal)', 'Frequenza (centro canale)', 'Frecuencia (centro del canal)'),
    'From RX':
        ('Von RX', 'Van RX', 'Depuis RX', 'Da RX', 'Desde RX'),
    'Fuzzy colour':
        ('Fuzzy-Farbe', 'Fuzzy kleur', 'Couleur floue', 'Colore fuzzy', 'Color difuso'),
    'Fuzzy picture':
        ('Fuzzy-Bild', 'Fuzzy beeld', 'Image floue', 'Immagine fuzzy', 'Imagen difusa'),
    'Gain dB':
        ('Verstärkung dB', 'Versterking dB', 'Gain dB', 'Guadagno dB', 'Ganancia dB'),
    'Gain dB (0 = auto)':
        ('Verstärkung dB (0 = auto)', 'Versterking dB (0 = auto)', 'Gain dB (0 = auto)', 'Guadagno dB (0 = auto)', 'Ganancia dB (0 = auto)'),
    'Give card back':
        ('Karte zurückgeben', 'Kaart teruggeven', 'Rendre la carte', 'Restituisci scheda', 'Devolver tarjeta'),
    'Guard':
        ('Schutzintervall', 'Bewakingsinterval', 'Intervalle de garde', 'Intervallo di guardia', 'Intervalo de guarda'),
    'HF by':
        ('KW durch', 'HF via', 'HF par', 'HF tramite', 'HF por'),
    'HackRF One - TX and RX, 1 MHz to 6 GHz (hackrf_transfer, 2 Msps; half duplex: TX and RX take turns)':
        ('HackRF One - TX und RX, 1 MHz bis 6 GHz (hackrf_transfer, 2 Msps; Halbduplex: TX und RX abwechselnd)', 'HackRF One - TX en RX, 1 MHz tot 6 GHz (hackrf_transfer, 2 Msps; halfduplex: TX en RX om beurten)', 'HackRF One - TX et RX, 1 MHz à 6 GHz (hackrf_transfer, 2 Méch/s ; semi-duplex : TX et RX à tour de rôle)', 'HackRF One - TX e RX, da 1 MHz a 6 GHz (hackrf_transfer, 2 Msps; half duplex: TX e RX a turno)', 'HackRF One - TX y RX, de 1 MHz a 6 GHz (hackrf_transfer, 2 Msps; semidúplex: TX y RX por turnos)'),
    'Hardware off':
        ('Hardware aus', 'Hardware uit', 'Matériel arrêté', 'Hardware spento', 'Hardware apagado'),
    'Help':
        ('Hilfe', 'Help', 'Aide', 'Guida', 'Ayuda'),
    'I/Q flip':
        ('I/Q umkehren', 'I/Q omkeren', 'Inverser I/Q', 'Inverti I/Q', 'Invertir I/Q'),
    'I/Q trim':
        ('I/Q-Abgleich', 'I/Q-correctie', 'Correction I/Q', 'Correzione I/Q', 'Corrección I/Q'),
    'Key mix':
        ('Key-Mischung', 'Key-menging', 'Mélange de clé', 'Miscela chiave', 'Mezcla de clave'),
    'Key only (Ave)':
        ('Nur Key (Mittel)', 'Alleen key (gem.)', 'Clé seule (moy.)', 'Solo chiave (media)', 'Solo clave (media)'),
    'LNA (+6 dB)':
        ('LNA (+6 dB)', 'LNA (+6 dB)', 'LNA (+6 dB)', 'LNA (+6 dB)', 'LNA (+6 dB)'),
    'LO offset kHz':
        ('LO-Versatz kHz', 'LO-offset kHz', 'Décalage LO kHz', 'Offset LO kHz', 'Desplazamiento LO kHz'),
    'LOOP TEST':
        ('SCHLEIFENTEST', 'LUSTEST', 'TEST EN BOUCLE', 'TEST AD ANELLO', 'PRUEBA EN BUCLE'),
    'Large view':
        ('Große Ansicht', 'Grote weergave', 'Grande vue', 'Vista grande', 'Vista grande'),
    'Lip sync ms':
        ('Lippensynchron ms', 'Lipsynchronisatie ms', 'Synchro labiale ms', 'Sincronia labiale ms', 'Sincronía labial ms'),
    'Load...':
        ('Laden...', 'Laden...', 'Charger...', 'Carica...', 'Cargar...'),
    'Long symbols (400)':
        ('Lange Symbole (400)', 'Lange symbolen (400)', 'Symboles longs (400)', 'Simboli lunghi (400)', 'Símbolos largos (400)'),
    'Loop back test (cable: card out -> card in)':
        ('Schleifentest (Kabel: Karte aus -> Karte ein)', 'Lustest (kabel: kaart uit -> kaart in)', 'Test en boucle (câble : sortie carte -> entrée carte)', 'Test ad anello (cavo: uscita scheda -> ingresso scheda)', 'Prueba en bucle (cable: salida tarjeta -> entrada tarjeta)'),
    'Modem (TX and RX)':
        ('Modem (TX und RX)', 'Modem (TX en RX)', 'Modem (TX et RX)', 'Modem (TX e RX)', 'Módem (TX y RX)'),
    'More...':
        ('Mehr...', 'Meer...', 'Plus...', 'Altro...', 'Más...'),
    'Motion search':
        ('Bewegungssuche', 'Bewegingszoeken', 'Recherche de mouvement', 'Ricerca movimento', 'Búsqueda de movimiento'),
    'Multi-core (%d CPUs)':
        ('Mehrkern (%d CPUs)', "Multicore (%d CPU's)", 'Multicœur (%d processeurs)', 'Multi-core (%d CPU)', 'Multinúcleo (%d CPU)'),
    'NO SIGNAL':
        ('KEIN SIGNAL', 'GEEN SIGNAAL', 'PAS DE SIGNAL', 'NESSUN SEGNALE', 'SIN SEÑAL'),
    'No signal: nothing decoded':
        ('Kein Signal: nichts dekodiert', 'Geen signaal: niets gedecodeerd', 'Pas de signal : rien de décodé', 'Nessun segnale: niente decodificato', 'Sin señal: nada decodificado'),
    'Off':
        ('Aus', 'Uit', 'Arrêt', 'Spento', 'Apagado'),
    'On the air':
        ('Auf Sendung', 'In de lucht', "À l'antenne", 'In onda', 'En el aire'),
    'Paste':
        ('Einfügen', 'Plakken', 'Coller', 'Incolla', 'Pegar'),
    'Paste an IPTV / stream link: http(s), .m3u8 (HLS), rtsp, rtmp, udp ... (Ctrl+V)':
        ('IPTV- / Stream-Link einfügen: http(s), .m3u8 (HLS), rtsp, rtmp, udp ... (Strg+V)', 'Plak een IPTV- / streamlink: http(s), .m3u8 (HLS), rtsp, rtmp, udp ... (Ctrl+V)', 'Collez un lien IPTV / flux : http(s), .m3u8 (HLS), rtsp, rtmp, udp ... (Ctrl+V)', 'Incolla un link IPTV / stream: http(s), .m3u8 (HLS), rtsp, rtmp, udp ... (Ctrl+V)', 'Pegue un enlace IPTV / de flujo: http(s), .m3u8 (HLS), rtsp, rtmp, udp ... (Ctrl+V)'),
    'Pause':
        ('Pause', 'Pauze', 'Pause', 'Pausa', 'Pausa'),
    'Peak-limited TX':
        ('Spitzenbegrenztes TX', 'Piekbegrensde TX', 'TX limité en crête', 'TX con limitazione picchi', 'TX con limitación de picos'),
    'Picture':
        ('Bild', 'Beeld', 'Image', 'Immagine', 'Imagen'),
    'Pilot level':
        ('Pilotpegel', 'Pilootniveau', 'Niveau des pilotes', 'Livello piloti', 'Nivel de pilotos'),
    'Pilots':
        ('Piloten', 'Piloten', 'Pilotes', 'Piloti', 'Pilotos'),
    'Play':
        ('Abspielen', 'Afspelen', 'Lecture', 'Riproduci', 'Reproducir'),
    'Pre-amp':
        ('Vorverstärker', 'Voorversterker', 'Préampli', 'Preamplificatore', 'Preamplificador'),
    'RECEIVE':
        ('EMPFANG', 'ONTVANGST', 'RÉCEPTION', 'RICEZIONE', 'RECEPCIÓN'),
    'RTL-SDR (Blog V3 / V4, NooElec ...) - receive only (rtl_sdr, 2 Msps)':
        ('RTL-SDR (Blog V3 / V4, NooElec ...) - nur Empfang (rtl_sdr, 2 Msps)', 'RTL-SDR (Blog V3 / V4, NooElec ...) - alleen ontvangst (rtl_sdr, 2 Msps)', 'RTL-SDR (Blog V3 / V4, NooElec ...) - réception seule (rtl_sdr, 2 Méch/s)', 'RTL-SDR (Blog V3 / V4, NooElec ...) - solo ricezione (rtl_sdr, 2 Msps)', 'RTL-SDR (Blog V3 / V4, NooElec ...) - solo recepción (rtl_sdr, 2 Msps)'),
    'RX LNA dB':
        ('RX LNA dB', 'RX LNA dB', 'RX LNA dB', 'RX LNA dB', 'RX LNA dB'),
    'RX VGA dB':
        ('RX VGA dB', 'RX VGA dB', 'RX VGA dB', 'RX VGA dB', 'RX VGA dB'),
    'RX amp (+11 dB)':
        ('RX-Verst. (+11 dB)', 'RX-versterker (+11 dB)', 'Ampli RX (+11 dB)', 'Ampli RX (+11 dB)', 'Amplificador RX (+11 dB)'),
    'RX during TX (TX and RX on different hardware - mind the RX input)':
        ('RX während TX (TX und RX auf verschiedener Hardware - auf den RX-Eingang achten)', 'RX tijdens TX (TX en RX op verschillende hardware - let op de RX-ingang)', "RX pendant TX (TX et RX sur matériels différents - attention à l'entrée RX)", "RX durante TX (TX e RX su hardware diversi - attenzione all'ingresso RX)", 'RX durante TX (TX y RX en hardware distinto - cuidado con la entrada RX)'),
    'RX estimate':
        ('RX-Schätzung', 'RX-schatting', 'Estimation RX', 'Stima RX', 'Estimación RX'),
    'RX input: -':
        ('RX-Eingang: -', 'RX-ingang: -', 'Entrée RX : -', 'Ingresso RX: -', 'Entrada RX: -'),
    'RX mute (no signal)':
        ('RX stumm (kein Signal)', 'RX dempen (geen signaal)', 'RX muet (pas de signal)', 'RX muto (nessun segnale)', 'RX silencio (sin señal)'),
    'RX on':
        ('RX ein', 'RX aan', 'RX actif', 'RX attivo', 'RX activo'),
    'RX trim %+.0f Hz':
        ('RX-Abgleich %+.0f Hz', 'RX-correctie %+.0f Hz', 'Correction RX %+.0f Hz', 'Correzione RX %+.0f Hz', 'Corrección RX %+.0f Hz'),
    'Radio':
        ('Funkgerät', 'Radio', 'Radio', 'Radio', 'Radio'),
    'Radio / I/Q setup...':
        ('Funkgerät / I/Q-Einrichtung...', 'Radio / I/Q-instellingen...', 'Radio / configuration I/Q...', 'Radio / configurazione I/Q...', 'Radio / configuración I/Q...'),
    'Read back':
        ('Zurücklesen', 'Teruglezen', 'Relire', 'Rileggi', 'Releer'),
    'Received picture - large (drag the edges; 1-4: size, F11: full screen)':
        ('Empfangenes Bild - groß (Ränder ziehen; 1-4: Größe, F11: Vollbild)', 'Ontvangen beeld - groot (sleep aan de randen; 1-4: grootte, F11: volledig scherm)', 'Image reçue - grande (tirez les bords ; 1-4 : taille, F11 : plein écran)', 'Immagine ricevuta - grande (trascina i bordi; 1-4: dimensione, F11: schermo intero)', 'Imagen recibida - grande (arrastre los bordes; 1-4: tamaño, F11: pantalla completa)'),
    'Record':
        ('Aufnehmen', 'Opnemen', 'Enregistrer', 'Registra', 'Grabar'),
    'Refresh':
        ('Aktualisieren', 'Vernieuwen', 'Actualiser', 'Aggiorna', 'Actualizar'),
    'Release card':
        ('Karte freigeben', 'Kaart vrijgeven', 'Libérer la carte', 'Rilascia scheda', 'Liberar tarjeta'),
    'Resync':
        ('Neu synchronisieren', 'Opnieuw synchroniseren', 'Resynchroniser', 'Risincronizza', 'Resincronizar'),
    'S9 at dBFS':
        ('S9 bei dBFS', 'S9 bij dBFS', 'S9 à dBFS', 'S9 a dBFS', 'S9 a dBFS'),
    'SDRplay RSP (receive only) and any other radio with a SoapySDR driver (TX and RX where it can, e.g. LimeSDR)':
        ('SDRplay RSP (nur Empfang) und jedes andere Funkgerät mit SoapySDR-Treiber (TX und RX, wo möglich, z. B. LimeSDR)', 'SDRplay RSP (alleen ontvangst) en elke andere radio met een SoapySDR-driver (TX en RX waar mogelijk, bijv. LimeSDR)', 'SDRplay RSP (réception seule) et toute autre radio avec un pilote SoapySDR (TX et RX si possible, p. ex. LimeSDR)', 'SDRplay RSP (solo ricezione) e qualsiasi altra radio con driver SoapySDR (TX e RX dove possibile, es. LimeSDR)', 'SDRplay RSP (solo recepción) y cualquier otra radio con controlador SoapySDR (TX y RX donde se pueda, p. ej. LimeSDR)'),
    'SNR per carrier: video green, audio blue, pilots yellow':
        ('SNR pro Träger: Video grün, Audio blau, Piloten gelb', 'SNR per draaggolf: video groen, audio blauw, piloten geel', 'SNR par porteuse : vidéo vert, audio bleu, pilotes jaune', 'SNR per portante: video verde, audio blu, piloti giallo', 'SNR por portadora: vídeo verde, audio azul, pilotos amarillo'),
    'SOFTWARE LOOP':
        ('SOFTWARE-SCHLEIFE', 'SOFTWARELUS', 'BOUCLE LOGICIELLE', 'ANELLO SOFTWARE', 'BUCLE DE SOFTWARE'),
    'Save picture':
        ('Bild speichern', 'Beeld opslaan', "Enregistrer l'image", 'Salva immagine', 'Guardar imagen'),
    'Saved in %s  -  or press Copy report and paste it':
        ('Gespeichert in %s  -  oder Bericht kopieren drücken und einfügen', 'Opgeslagen in %s  -  of druk op Rapport kopiëren en plak het', 'Enregistré dans %s  -  ou cliquez sur Copier le rapport et collez-le', 'Salvato in %s  -  oppure premi Copia rapporto e incollalo', 'Guardado en %s  -  o pulse Copiar informe y péguelo'),
    'Screen':
        ('Bildschirm', 'Scherm', 'Écran', 'Schermo', 'Pantalla'),
    'Screen X':
        ('Bildschirm X', 'Scherm X', 'Écran X', 'Schermo X', 'Pantalla X'),
    'Screen Y':
        ('Bildschirm Y', 'Scherm Y', 'Écran Y', 'Schermo Y', 'Pantalla Y'),
    'Send mode word (TX)':
        ('Moduswort senden (TX)', 'Moduswoord zenden (TX)', 'Envoyer le mot de mode (TX)', 'Invia parola di modo (TX)', 'Enviar palabra de modo (TX)'),
    'Sending (one of the three pictures in each data frame)':
        ('Gesendet (eines der drei Bilder jedes Datenrahmens)', 'Verzonden (een van de drie beelden in elk dataframe)', 'Envoi (une des trois images de chaque trame)', 'Invio (una delle tre immagini di ogni trama)', 'Enviando (una de las tres imágenes de cada trama)'),
    'Serial (blank: the first)':
        ('Seriennummer (leer: das erste)', 'Serienummer (leeg: de eerste)', 'N° de série (vide : le premier)', 'Numero di serie (vuoto: il primo)', 'Número de serie (vacío: el primero)'),
    'Serial port':
        ('Serielle Schnittstelle', 'Seriële poort', 'Port série', 'Porta seriale', 'Puerto serie'),
    'Set + Save':
        ('Setzen + Speichern', 'Instellen + opslaan', 'Régler + enregistrer', 'Imposta + salva', 'Ajustar + guardar'),
    'Sharpness':
        ('Schärfe', 'Scherpte', 'Netteté', 'Nitidezza', 'Nitidez'),
    'Software loop back':
        ('Software-Schleife', 'Softwarelus', 'Boucle logicielle', 'Anello software', 'Bucle de software'),
    'Sound':
        ('Ton', 'Geluid', 'Son', 'Audio', 'Sonido'),
    'Sound NR':
        ('Ton-Rauschminderung', 'Geluidsruisonderdrukking', 'Réduction de bruit du son', 'Riduzione rumore audio', 'Reducción de ruido de sonido'),
    'Sound devices':
        ('Tongeräte', 'Geluidsapparaten', 'Périphériques son', 'Dispositivi audio', 'Dispositivos de sonido'),
    'Sound devices...':
        ('Tongeräte...', 'Geluidsapparaten...', 'Périphériques son...', 'Dispositivi audio...', 'Dispositivos de sonido...'),
    'Sound in':
        ('Ton ein', 'Geluid in', 'Entrée son', 'Ingresso audio', 'Entrada de sonido'),
    'Sound in (Sound card / Loopback)':
        ('Ton ein (Soundkarte / Loopback)', 'Geluid in (geluidskaart / loopback)', 'Entrée son (carte son / boucle)', 'Ingresso audio (scheda audio / loopback)', 'Entrada de sonido (tarjeta de sonido / loopback)'),
    'Sound in dB':
        ('Ton ein dB', 'Geluid in dB', 'Entrée son dB', 'Ingresso audio dB', 'Entrada de sonido dB'),
    'Sound out (the received sound)':
        ('Ton aus (der empfangene Ton)', 'Geluid uit (het ontvangen geluid)', 'Sortie son (le son reçu)', "Uscita audio (l'audio ricevuto)", 'Salida de sonido (el sonido recibido)'),
    'Spectrum and waterfall, 200 kHz (click to tune, drag to centre the signal: RX trim; Shift: fine)':
        ('Spektrum und Wasserfall, 200 kHz (klicken zum Abstimmen, ziehen zum Zentrieren: RX-Abgleich; Umschalt: fein)', 'Spectrum en waterval, 200 kHz (klik om af te stemmen, sleep om het signaal te centreren: RX-correctie; Shift: fijn)', 'Spectre et cascade, 200 kHz (cliquez pour accorder, glissez pour centrer le signal : correction RX ; Maj : fin)', 'Spettro e cascata, 200 kHz (clic per sintonizzare, trascina per centrare il segnale: correzione RX; Maiusc: fine)', 'Espectro y cascada, 200 kHz (clic para sintonizar, arrastre para centrar la señal: corrección RX; Mayús: fino)'),
    'Spread':
        ('Spreizung', 'Spreiding', 'Étalement', 'Spargimento', 'Dispersión'),
    'Stereo as R+L / R-L:  M share':
        ('Stereo als R+L / R-L:  M-Anteil', 'Stereo als R+L / R-L:  M-aandeel', 'Stéréo en R+L / R-L :  part M', 'Stereo come R+L / R-L:  quota M', 'Estéreo como R+L / R-L:  parte M'),
    'Stereo compander R+L, R-L 2:1 (TX+RX)':
        ('Stereo-Kompander R+L, R-L 2:1 (TX+RX)', 'Stereocompander R+L, R-L 2:1 (TX+RX)', 'Compresseur-expanseur stéréo R+L, R-L 2:1 (TX+RX)', 'Compander stereo R+L, R-L 2:1 (TX+RX)', 'Compansor estéreo R+L, R-L 2:1 (TX+RX)'),
    'Stop rec':
        ('Aufn. stoppen', 'Opname stoppen', "Arrêter l'enr.", 'Ferma reg.', 'Parar grab.'),
    'Stream URL':
        ('Stream-URL', 'Stream-URL', 'URL du flux', 'URL dello stream', 'URL del flujo'),
    'Swap I/Q':
        ('I/Q tauschen', 'I/Q wisselen', 'Permuter I/Q', 'Scambia I/Q', 'Intercambiar I/Q'),
    'Sync':
        ('Sync', 'Sync', 'Synchro', 'Sincro', 'Sincronía'),
    'TX VGA dB':
        ('TX VGA dB', 'TX VGA dB', 'TX VGA dB', 'TX VGA dB', 'TX VGA dB'),
    'TX amp (+11 dB)':
        ('TX-Verst. (+11 dB)', 'TX-versterker (+11 dB)', 'Ampli TX (+11 dB)', 'Ampli TX (+11 dB)', 'Amplificador TX (+11 dB)'),
    'TX level dBFS':
        ('TX-Pegel dBFS', 'TX-niveau dBFS', 'Niveau TX dBFS', 'Livello TX dBFS', 'Nivel TX dBFS'),
    'TX on':
        ('TX ein', 'TX aan', 'TX actif', 'TX attivo', 'TX activo'),
    'TX peaks':
        ('TX-Spitzen', 'TX-pieken', 'Crêtes TX', 'Picchi TX', 'Picos TX'),
    'Temporal NR':
        ('Zeitliche Rauschminderung', 'Tijdelijke ruisonderdrukking', 'Réduction de bruit temporelle', 'Riduzione rumore temporale', 'Reducción de ruido temporal'),
    'Test Card Editor - NBTV Lab':
        ('Testbild-Editor - NBTV Lab', 'Testbeeld-editor - NBTV Lab', 'Éditeur de mire - NBTV Lab', 'Editor monoscopio - NBTV Lab', 'Editor de carta de ajuste - NBTV Lab'),
    'Test card':
        ('Testbild', 'Testbeeld', 'Mire', 'Monoscopio', 'Carta de ajuste'),
    'Test card editor...':
        ('Testbild-Editor...', 'Testbeeld-editor...', 'Éditeur de mire...', 'Editor monoscopio...', 'Editor de carta de ajuste...'),
    'Test sound in':
        ('Toneingang testen', 'Geluidsingang testen', "Tester l'entrée son", 'Prova ingresso audio', 'Probar entrada de sonido'),
    'Testing %s ...':
        ('Teste %s ...', '%s testen ...', 'Test de %s ...', 'Prova di %s ...', 'Probando %s ...'),
    'Text colour':
        ('Textfarbe', 'Tekstkleur', 'Couleur du texte', 'Colore del testo', 'Color del texto'),
    'The area is 240 x 192 (4:3) or 342 x 192 (16:9) near the top left of the screen;\nmove it with the Screen X and Y sliders.':
        ('Der Bereich ist 240 x 192 (4:3) oder 342 x 192 (16:9) nahe der oberen linken Bildschirmecke;\nverschieben mit den Reglern Bildschirm X und Y.', 'Het gebied is 240 x 192 (4:3) of 342 x 192 (16:9) linksboven op het scherm;\nverplaats het met de schuifregelaars Scherm X en Y.', "La zone fait 240 x 192 (4:3) ou 342 x 192 (16:9) près du coin supérieur gauche de l'écran ;\ndéplacez-la avec les curseurs Écran X et Y.", "L'area è 240 x 192 (4:3) o 342 x 192 (16:9) vicino all'angolo in alto a sinistra dello schermo;\nspostala con i cursori Schermo X e Y.", 'El área es de 240 x 192 (4:3) o 342 x 192 (16:9) cerca de la esquina superior izquierda de la pantalla;\nmuévala con los controles Pantalla X e Y.'),
    "The picture is cropped to 4:3 or 16:9 from its middle; the stream's sound goes with it\n(Sound in: Source).  A stream that drops is opened again by itself.  Earlier links are in the list.":
        ('Das Bild wird aus der Mitte auf 4:3 oder 16:9 zugeschnitten; der Ton des Streams geht mit\n(Ton ein: Quelle).  Ein abbrechender Stream wird von selbst neu geöffnet.  Frühere Links stehen in der Liste.', 'Het beeld wordt vanuit het midden bijgesneden tot 4:3 of 16:9; het geluid van de stream gaat mee\n(Geluid in: bron).  Een stream die wegvalt wordt vanzelf opnieuw geopend.  Eerdere links staan in de lijst.', "L'image est recadrée en 4:3 ou 16:9 depuis son centre ; le son du flux l'accompagne\n(Entrée son : source).  Un flux interrompu est rouvert automatiquement.  Les liens précédents sont dans la liste.", "L'immagine è ritagliata a 4:3 o 16:9 dal centro; l'audio dello stream la accompagna\n(Ingresso audio: sorgente).  Uno stream che cade viene riaperto da solo.  I link precedenti sono nell'elenco.", 'La imagen se recorta a 4:3 o 16:9 desde su centro; el sonido del flujo la acompaña\n(Entrada de sonido: fuente).  Un flujo que se corta se vuelve a abrir solo.  Los enlaces anteriores están en la lista.'),
    "These are the SOUND the encoder sends and the received sound you hear - not the radio's I/Q.\nThe 192 kHz I/Q card, the serial (COM) port and the hardware loop back test are in Radio / I/Q setup.\n(Loopback under Sound in records this computer's own sound output as the programme sound.)":
        ('Dies ist der TON, den der Encoder sendet, und der empfangene Ton, den Sie hören - nicht das I/Q des Funkgeräts.\nDie 192-kHz-I/Q-Karte, die serielle (COM-)Schnittstelle und der Hardware-Schleifentest sind unter Funkgerät / I/Q-Einrichtung.\n(Loopback unter Ton ein nimmt die eigene Tonausgabe dieses Computers als Programmton auf.)', 'Dit is het GELUID dat de encoder zendt en het ontvangen geluid dat u hoort - niet de I/Q van de radio.\nDe 192 kHz-I/Q-kaart, de seriële (COM-)poort en de hardware-lustest staan onder Radio / I/Q-instellingen.\n(Loopback onder Geluid in neemt de eigen geluidsuitvoer van deze computer op als programmageluid.)', "Il s'agit du SON envoyé par le codeur et du son reçu que vous entendez - pas de l'I/Q de la radio.\nLa carte I/Q 192 kHz, le port série (COM) et le test en boucle matériel sont dans Radio / configuration I/Q.\n(Loopback dans Entrée son enregistre la sortie son de cet ordinateur comme son du programme.)", "Questo è l'AUDIO che il codificatore invia e l'audio ricevuto che si ascolta - non l'I/Q della radio.\nLa scheda I/Q a 192 kHz, la porta seriale (COM) e il test ad anello hardware sono in Radio / configurazione I/Q.\n(Loopback in Ingresso audio registra l'uscita audio di questo computer come audio del programma.)", 'Este es el SONIDO que envía el codificador y el sonido recibido que oye - no el I/Q de la radio.\nLa tarjeta I/Q de 192 kHz, el puerto serie (COM) y la prueba en bucle del hardware están en Radio / configuración I/Q.\n(Loopback en Entrada de sonido graba la salida de sonido de este ordenador como sonido del programa.)'),
    'Time stamp (UTC)':
        ('Zeitstempel (UTC)', 'Tijdstempel (UTC)', 'Horodatage (UTC)', 'Marca temporale (UTC)', 'Marca de tiempo (UTC)'),
    'To 200 kHz':
        ('Auf 200 kHz', 'Naar 200 kHz', 'Vers 200 kHz', 'A 200 kHz', 'A 200 kHz'),
    'Track colour':
        ('Farbe verfolgen', 'Kleur volgen', 'Suivre la couleur', 'Segui colore', 'Seguir color'),
    'Upscale':
        ('Hochskalierung', 'Opschalen', 'Agrandissement', 'Ingrandimento', 'Escalado'),
    'Use it':
        ('Verwenden', 'Gebruiken', 'Utiliser', 'Usa', 'Usar'),
    'User file':
        ('Benutzerdatei', 'Gebruikersbestand', 'Fichier utilisateur', 'File utente', 'Archivo de usuario'),
    'Video file':
        ('Videodatei', 'Videobestand', 'Fichier vidéo', 'File video', 'Archivo de vídeo'),
    'Volume dB':
        ('Lautstärke dB', 'Volume dB', 'Volume dB', 'Volume dB', 'Volumen dB'),
    'Waterfall range dB':
        ('Wasserfallbereich dB', 'Watervalbereik dB', 'Plage de la cascade dB', 'Gamma cascata dB', 'Rango de cascada dB'),
    'Webcam':
        ('Webcam', 'Webcam', 'Webcam', 'Webcam', 'Webcam'),
    'Webcam device (Linux /dev/videoN, Windows video=Name, macOS 0)':
        ('Webcam-Gerät (Linux /dev/videoN, Windows video=Name, macOS 0)', 'Webcamapparaat (Linux /dev/videoN, Windows video=Naam, macOS 0)', 'Webcam (Linux /dev/videoN, Windows video=Nom, macOS 0)', 'Dispositivo webcam (Linux /dev/videoN, Windows video=Nome, macOS 0)', 'Dispositivo de webcam (Linux /dev/videoN, Windows video=Nombre, macOS 0)'),
    "Windows: use the card's [Windows WASAPI] entries (listed first) - they run at the card's own 192 kHz.\nIn Windows Sound settings set the card to 2 channel, 24 bit, 192000 Hz, and turn its audio enhancements off.":
        ('Windows: die Einträge [Windows WASAPI] der Karte verwenden (zuerst aufgeführt) - sie laufen mit den eigenen 192 kHz der Karte.\nIn den Windows-Soundeinstellungen die Karte auf 2 Kanäle, 24 Bit, 192000 Hz stellen und ihre Audioverbesserungen ausschalten.', 'Windows: gebruik de vermeldingen [Windows WASAPI] van de kaart (als eerste vermeld) - die lopen op de eigen 192 kHz van de kaart.\nZet in de Windows-geluidsinstellingen de kaart op 2 kanalen, 24 bit, 192000 Hz en schakel de geluidsverbeteringen uit.', 'Windows : utilisez les entrées [Windows WASAPI] de la carte (listées en premier) - elles tournent aux 192 kHz propres de la carte.\nDans les paramètres son de Windows, réglez la carte sur 2 canaux, 24 bits, 192000 Hz et désactivez ses améliorations audio.', 'Windows: usare le voci [Windows WASAPI] della scheda (elencate per prime) - funzionano ai 192 kHz propri della scheda.\nNelle impostazioni audio di Windows impostare la scheda su 2 canali, 24 bit, 192000 Hz e disattivarne i miglioramenti audio.', 'Windows: use las entradas [Windows WASAPI] de la tarjeta (listadas primero) - funcionan a los 192 kHz propios de la tarjeta.\nEn la configuración de sonido de Windows ponga la tarjeta en 2 canales, 24 bits, 192000 Hz y desactive sus mejoras de audio.'),
    'Y+C (colour)':
        ('Y+C (Farbe)', 'Y+C (kleur)', 'Y+C (couleur)', 'Y+C (colore)', 'Y+C (color)'),
    'drag a text to move it   click: upper text here   right-click: lower text here':
        ('Text ziehen zum Verschieben   Klick: oberer Text hierher   Rechtsklick: unterer Text hierher', 'sleep een tekst om die te verplaatsen   klik: bovenste tekst hier   rechtsklik: onderste tekst hier', 'glissez un texte pour le déplacer   clic : texte du haut ici   clic droit : texte du bas ici', 'trascina un testo per spostarlo   clic: testo superiore qui   clic destro: testo inferiore qui', 'arrastre un texto para moverlo   clic: texto superior aquí   clic derecho: texto inferior aquí'),
    'sudo apt install airspyhf.  Tuned straight to the channel (no DC spike to keep away from).':
        ('sudo apt install airspyhf.  Direkt auf den Kanal abgestimmt (keine DC-Spitze zu meiden).', 'sudo apt install airspyhf.  Direct op het kanaal afgestemd (geen DC-piek om te vermijden).', 'sudo apt install airspyhf.  Accordé directement sur le canal (pas de pic DC à éviter).', 'sudo apt install airspyhf.  Sintonizzato direttamente sul canale (nessun picco DC da evitare).', 'sudo apt install airspyhf.  Sintonizado directamente en el canal (sin pico de CC que evitar).'),
    "sudo apt install hackrf.  A gain change starts hackrf_transfer again.  Below 30 MHz a low-pass filter on\nTX is a must (the HackRF's harmonics are strong).":
        ('sudo apt install hackrf.  Eine Verstärkungsänderung startet hackrf_transfer neu.  Unter 30 MHz ist ein Tiefpassfilter am\nTX ein Muss (die Oberwellen des HackRF sind stark).', 'sudo apt install hackrf.  Een versterkingswijziging start hackrf_transfer opnieuw.  Onder 30 MHz is een laagdoorlaatfilter op\nTX een must (de harmonischen van de HackRF zijn sterk).', 'sudo apt install hackrf.  Un changement de gain relance hackrf_transfer.  Sous 30 MHz, un filtre passe-bas en\nTX est indispensable (les harmoniques du HackRF sont fortes).', "sudo apt install hackrf.  Un cambio di guadagno riavvia hackrf_transfer.  Sotto i 30 MHz un filtro passa-basso in\nTX è indispensabile (le armoniche dell'HackRF sono forti).", 'sudo apt install hackrf.  Un cambio de ganancia reinicia hackrf_transfer.  Por debajo de 30 MHz un filtro paso bajo en\nTX es imprescindible (los armónicos del HackRF son fuertes).'),
    "sudo apt install python3-soapysdr soapysdr-tools, plus the radio's module (SDRplay: the SDRplay API\nand SoapySDRPlay3; LimeSDR: soapysdr-module-lms7).  SoapySDRUtil --find lists what it sees.  2 Msps.":
        ('sudo apt install python3-soapysdr soapysdr-tools, dazu das Modul des Funkgeräts (SDRplay: die SDRplay-API\nund SoapySDRPlay3; LimeSDR: soapysdr-module-lms7).  SoapySDRUtil --find zeigt, was es findet.  2 Msps.', 'sudo apt install python3-soapysdr soapysdr-tools, plus de module van de radio (SDRplay: de SDRplay-API\nen SoapySDRPlay3; LimeSDR: soapysdr-module-lms7).  SoapySDRUtil --find toont wat het ziet.  2 Msps.', "sudo apt install python3-soapysdr soapysdr-tools, plus le module de la radio (SDRplay : l'API SDRplay\net SoapySDRPlay3 ; LimeSDR : soapysdr-module-lms7).  SoapySDRUtil --find liste ce qu'il voit.  2 Méch/s.", "sudo apt install python3-soapysdr soapysdr-tools, più il modulo della radio (SDRplay: l'API SDRplay\ne SoapySDRPlay3; LimeSDR: soapysdr-module-lms7).  SoapySDRUtil --find elenca ciò che vede.  2 Msps.", 'sudo apt install python3-soapysdr soapysdr-tools, más el módulo de la radio (SDRplay: la API de SDRplay\ny SoapySDRPlay3; LimeSDR: soapysdr-module-lms7).  SoapySDRUtil --find lista lo que ve.  2 Msps.'),
    'sudo apt install rtl-sdr.  V4: HF is built in.  V3: direct sampling below 28.8 MHz (RTL-SDR Blog\ndrivers).  Upconverter: a 125 MHz upconverter (Ham-it-up etc.) in front.':
        ('sudo apt install rtl-sdr.  V4: KW ist eingebaut.  V3: Direktabtastung unter 28,8 MHz (RTL-SDR-Blog-\nTreiber).  Aufwärtsmischer: ein 125-MHz-Upconverter (Ham-it-up usw.) davor.', 'sudo apt install rtl-sdr.  V4: HF is ingebouwd.  V3: directe bemonstering onder 28,8 MHz (RTL-SDR Blog-\ndrivers).  Upconverter: een 125 MHz-upconverter (Ham-it-up enz.) ervoor.', 'sudo apt install rtl-sdr.  V4 : la HF est intégrée.  V3 : échantillonnage direct sous 28,8 MHz (pilotes\nRTL-SDR Blog).  Convertisseur : un convertisseur 125 MHz (Ham-it-up, etc.) en amont.', "sudo apt install rtl-sdr.  V4: l'HF è integrata.  V3: campionamento diretto sotto 28,8 MHz (driver\nRTL-SDR Blog).  Upconverter: un upconverter a 125 MHz (Ham-it-up ecc.) davanti.", 'sudo apt install rtl-sdr.  V4: la HF viene integrada.  V3: muestreo directo por debajo de 28,8 MHz (controladores\nRTL-SDR Blog).  Conversor: un conversor de 125 MHz (Ham-it-up, etc.) delante.'),
    'sync: timing +-4 smp (blue), pilots (green)':
        ('Sync: Timing +-4 Abt. (blau), Piloten (grün)', 'sync: timing +-4 smp (blauw), piloten (groen)', 'synchro : temps +-4 éch. (bleu), pilotes (vert)', 'sincro: tempo +-4 camp. (blu), piloti (verde)', 'sincronía: tiempo +-4 mues. (azul), pilotos (verde)'),
    'the SDR is tuned the LO offset below the channel and the signal moved up in software, so its DC\nspike stays out of the 100 kHz.  (TX trim / RX trim, under TX on / RX on, correct a\nfrequency difference between two pieces of hardware or two stations.)':
        ('das SDR wird um den LO-Versatz unter den Kanal abgestimmt und das Signal in Software nach oben geschoben, damit seine DC-\nSpitze außerhalb der 100 kHz bleibt.  (TX-Abgleich / RX-Abgleich, unter TX ein / RX ein, gleichen einen\nFrequenzunterschied zwischen zwei Geräten oder zwei Stationen aus.)', 'de SDR wordt de LO-offset onder het kanaal afgestemd en het signaal in software omhoog geschoven, zodat de DC-\npiek buiten de 100 kHz blijft.  (TX-correctie / RX-correctie, onder TX aan / RX aan, corrigeren een\nfrequentieverschil tussen twee apparaten of twee stations.)', 'le SDR est accordé du décalage LO sous le canal et le signal remonté par logiciel, pour que son pic\nDC reste hors des 100 kHz.  (Correction TX / correction RX, sous TX actif / RX actif, compensent un\nécart de fréquence entre deux matériels ou deux stations.)', "l'SDR è sintonizzato dell'offset LO sotto il canale e il segnale spostato in su via software, così il suo picco\nDC resta fuori dai 100 kHz.  (Correzione TX / correzione RX, sotto TX attivo / RX attivo, compensano una\ndifferenza di frequenza tra due apparati o due stazioni.)", 'el SDR se sintoniza el desplazamiento LO por debajo del canal y la señal se sube por software, para que su pico\nde CC quede fuera de los 100 kHz.  (Corrección TX / corrección RX, bajo TX activo / RX activo, corrigen una\ndiferencia de frecuencia entre dos equipos o dos estaciones.)'),
    "where the 100 kHz channel sits in the card's +-96 kHz (away from its DC / LO leak); the radio's LO is set\nthat far below the frequency.  Past +-30 kHz the card's own filter edge may show.":
        ('wo der 100-kHz-Kanal in den +-96 kHz der Karte liegt (weg von ihrem DC- / LO-Durchschlag); der LO des Funkgeräts wird\nso weit unter die Frequenz gesetzt.  Jenseits von +-30 kHz kann sich die Filterflanke der Karte zeigen.', 'waar het 100 kHz-kanaal in de +-96 kHz van de kaart ligt (weg van de DC- / LO-lekkage); de LO van de radio wordt\nzo ver onder de frequentie gezet.  Voorbij +-30 kHz kan de filterflank van de kaart zichtbaar worden.', "où se situe le canal de 100 kHz dans les +-96 kHz de la carte (loin de sa fuite DC / LO) ; le LO de la radio est réglé\nd'autant sous la fréquence.  Au-delà de +-30 kHz, le flanc du filtre de la carte peut apparaître.", 'dove si trova il canale da 100 kHz nei +-96 kHz della scheda (lontano dalla sua dispersione DC / LO); il LO della radio è\nimpostato altrettanto sotto la frequenza.  Oltre +-30 kHz può comparire il fianco del filtro della scheda.', 'dónde se sitúa el canal de 100 kHz en los +-96 kHz de la tarjeta (lejos de su fuga de CC / LO); el LO de la radio se pone\nesa distancia por debajo de la frecuencia.  Más allá de +-30 kHz puede notarse el flanco del filtro de la tarjeta.'),
    'Display colour':
        ('Anzeigefarbe', 'Displaykleur', "Couleur de l'affichage", 'Colore del display', 'Color de la pantalla'),
    'Language':
        ('Sprache', 'Taal', 'Langue', 'Lingua', 'Idioma'),
    '%s, mode %s: pictures %d x %d, %.1f a second (%d per data frame)\ndata frame %d bytes every %.2f s (%d OFDM symbols)\n%d carriers: 144 video, 48 audio, %d pilots, 500 Hz apart, 100 kHz wide':
        ('%s, Modus %s: Bilder %d x %d, %.1f pro Sekunde (%d pro Datenrahmen)\nDatenrahmen %d Bytes alle %.2f s (%d OFDM-Symbole)\n%d Träger: 144 Video, 48 Audio, %d Piloten, 500 Hz Abstand, 100 kHz breit', '%s, modus %s: beelden %d x %d, %.1f per seconde (%d per dataframe)\ndataframe %d bytes elke %.2f s (%d OFDM-symbolen)\n%d draaggolven: 144 video, 48 audio, %d piloten, 500 Hz uit elkaar, 100 kHz breed', '%s, mode %s : images %d x %d, %.1f par seconde (%d par trame)\ntrame de %d octets toutes les %.2f s (%d symboles OFDM)\n%d porteuses : 144 vidéo, 48 audio, %d pilotes, espacées de 500 Hz, 100 kHz de large', "%s, modo %s: immagini %d x %d, %.1f al secondo (%d per trama)\ntrama di %d byte ogni %.2f s (%d simboli OFDM)\n%d portanti: 144 video, 48 audio, %d piloti, a 500 Hz l'una dall'altra, larghe 100 kHz", '%s, modo %s: imágenes %d x %d, %.1f por segundo (%d por trama)\ntrama de %d bytes cada %.2f s (%d símbolos OFDM)\n%d portadoras: 144 vídeo, 48 audio, %d pilotos, separadas 500 Hz, 100 kHz de ancho'),
    '%s   %s sync %s   freq %s Hz   clock %s ppm   timing %s   frame %s   %s':
        ('%s   %s-Sync %s   Frequenz %s Hz   Takt %s ppm   Timing %s   Rahmen %s   %s', '%s   %s-sync %s   frequentie %s Hz   klok %s ppm   timing %s   frame %s   %s', '%s   synchro %s %s   fréquence %s Hz   horloge %s ppm   temps %s   trame %s   %s', '%s   sincro %s %s   frequenza %s Hz   clock %s ppm   tempo %s   trama %s   %s', '%s   sincronía %s %s   frecuencia %s Hz   reloj %s ppm   tiempo %s   trama %s   %s'),
    'modem %s + decode %s + upscale %s ms (%s cores)   PAPR %s dB':
        ('Modem %s + Dekodierung %s + Hochskalierung %s ms (%s Kerne)   PAPR %s dB', 'modem %s + decoderen %s + opschalen %s ms (%s kernen)   PAPR %s dB', 'modem %s + décodage %s + agrandissement %s ms (%s cœurs)   PAPR %s dB', 'modem %s + decodifica %s + ingrandimento %s ms (%s core)   PAPR %s dB', 'módem %s + decodificación %s + escalado %s ms (%s núcleos)   PAPR %s dB'),
    '%s   C/N %s   %s':
        ('%s   C/N %s   %s', '%s   C/N %s   %s', '%s   C/N %s   %s', '%s   C/N %s   %s', '%s   C/N %s   %s'),
    'freq %s Hz':
        ('Frequenz %s Hz', 'frequentie %s Hz', 'fréquence %s Hz', 'frequenza %s Hz', 'frecuencia %s Hz'),
    'Hardware %s @ %s: %s':
        ('Hardware %s @ %s: %s', 'Hardware %s @ %s: %s', 'Matériel %s @ %s : %s', 'Hardware %s @ %s: %s', 'Hardware %s @ %s: %s'),
    'out %s dBFS; buffer %s ms; in %s dBFS':
        ('aus %s dBFS; Puffer %s ms; ein %s dBFS', 'uit %s dBFS; buffer %s ms; in %s dBFS', 'sortie %s dBFS ; tampon %s ms ; entrée %s dBFS', 'uscita %s dBFS; buffer %s ms; ingresso %s dBFS', 'salida %s dBFS; búfer %s ms; entrada %s dBFS'),
    'out %s dBFS; buffer %s ms (filling); in %s dBFS':
        ('aus %s dBFS; Puffer %s ms (füllt sich); ein %s dBFS', 'uit %s dBFS; buffer %s ms (vult zich); in %s dBFS', 'sortie %s dBFS ; tampon %s ms (remplissage) ; entrée %s dBFS', 'uscita %s dBFS; buffer %s ms (in riempimento); ingresso %s dBFS', 'salida %s dBFS; búfer %s ms (llenándose); entrada %s dBFS'),
    'RX input: %s (%s), in %s dBFS':
        ('RX-Eingang: %s (%s), ein %s dBFS', 'RX-ingang: %s (%s), in %s dBFS', 'Entrée RX : %s (%s), entrée %s dBFS', 'Ingresso RX: %s (%s), ingresso %s dBFS', 'Entrada RX: %s (%s), entrada %s dBFS'),
    'LO %s kHz, channel %s kHz in the card\n%s':
        ('LO %s kHz, Kanal %s kHz in der Karte\n%s', 'LO %s kHz, kanaal %s kHz in de kaart\n%s', 'LO %s kHz, canal %s kHz dans la carte\n%s', 'LO %s kHz, canale %s kHz nella scheda\n%s', 'LO %s kHz, canal %s kHz en la tarjeta\n%s'),
    'pre-amp %s, att %s':
        ('Vorverst. %s, Abschw. %s', 'voorversterker %s, verzwakker %s', 'préampli %s, atténuateur %s', 'preamplificatore %s, attenuatore %s', 'preamplificador %s, atenuador %s'),
    'LOCKED':
        ('EINGERASTET', 'VERGRENDELD', 'VERROUILLÉ', 'AGGANCIATO', 'ENGANCHADO'),
    'SEARCHING':
        ('SUCHE', 'ZOEKEN', 'RECHERCHE', 'RICERCA', 'BUSCANDO'),
    'LOST':
        ('VERLOREN', 'VERLOREN', 'PERDU', 'PERSO', 'PERDIDO'),
    'receiving':
        ('Empfang', 'ontvangst', 'réception', 'ricezione', 'recepción'),
    'transmitting':
        ('Senden', 'zenden', 'émission', 'trasmissione', 'transmisión'),
    'sound card':
        ('Soundkarte', 'geluidskaart', 'carte son', 'scheda audio', 'tarjeta de sonido'),
    'radio NOT connected':
        ('Funkgerät NICHT verbunden', 'radio NIET verbonden', 'radio NON connectée', 'radio NON collegata', 'radio NO conectada'),
    'on':
        ('ein', 'aan', 'actif', 'attivo', 'activo'),
    'off':
        ('aus', 'uit', 'arrêt', 'spento', 'apagado'),
    'RX input: none (no hardware)':
        ('RX-Eingang: keiner (keine Hardware)', 'RX-ingang: geen (geen hardware)', 'Entrée RX : aucune (pas de matériel)', 'Ingresso RX: nessuno (nessun hardware)', 'Entrada RX: ninguna (sin hardware)'),
    'Hardware: none - choose one under Encode and TX (Radio / I/Q setup...)':
        ('Hardware: keine - eine unter Kodierung und TX wählen (Funkgerät / I/Q-Einrichtung...)', 'Hardware: geen - kies er een onder Coderen en TX (Radio / I/Q-instellingen...)', 'Matériel : aucun - choisissez-en un sous Codage et TX (Radio / configuration I/Q...)', 'Hardware: nessuno - sceglierne uno in Codifica e TX (Radio / configurazione I/Q...)', 'Hardware: ninguno - elija uno en Codificación y TX (Radio / configuración I/Q...)'),
    'off (CPU)':
        ('aus (CPU)', 'uit (CPU)', 'arrêt (CPU)', 'spento (CPU)', 'apagado (CPU)'),
    'not measured yet: Card check sets it':
        ('noch nicht gemessen: die Kartenprüfung stellt es ein', 'nog niet gemeten: de kaarttest stelt het in', 'pas encore mesuré : le test de carte le règle', 'non ancora misurato: lo imposta la verifica scheda', 'aún sin medir: la prueba de tarjeta lo ajusta'),
    'I/Q as sent':
        ('I/Q wie gesendet', 'I/Q zoals verzonden', "I/Q tel qu'envoyé", 'I/Q come inviato', 'I/Q como se envió'),
    'I/Q swapped - flipped on receive':
        ('I/Q vertauscht - beim Empfang gedreht', 'I/Q verwisseld - bij ontvangst omgedraaid', 'I/Q inversé - retourné à la réception', 'I/Q scambiato - ribaltato in ricezione', 'I/Q intercambiado - invertido al recibir'),
    'No hardware: the receiver hears nothing;\nTX is shown and monitored here only':
        ('Keine Hardware: der Empfänger hört nichts;\nTX wird nur hier gezeigt und überwacht', 'Geen hardware: de ontvanger hoort niets;\nTX wordt alleen hier getoond en bewaakt', "Pas de matériel : le récepteur n'entend rien ;\nla TX est seulement affichée et surveillée ici", 'Nessun hardware: il ricevitore non sente nulla;\nla TX è solo mostrata e monitorata qui', 'Sin hardware: el receptor no oye nada;\nla TX solo se muestra y supervisa aquí'),
    'Card output':
        ('Kartenausgang', 'Kaartuitgang', 'Sortie de la carte', 'Uscita scheda', 'Salida de la tarjeta'),
    'Card input':
        ('Karteneingang', 'Kaartingang', 'Entrée de la carte', 'Ingresso scheda', 'Entrada de la tarjeta'),
    'V4 / built-in HF':
        ('V4 / eingebautes KW', 'V4 / ingebouwde HF', 'V4 / HF intégrée', 'V4 / HF integrata', 'V4 / HF integrada'),
    'V3 direct sampling':
        ('V3 Direktabtastung', 'V3 directe bemonstering', 'V3 échantillonnage direct', 'V3 campionamento diretto', 'V3 muestreo directo'),
    'Upconverter 125 MHz':
        ('Aufwärtsmischer 125 MHz', 'Upconverter 125 MHz', 'Convertisseur 125 MHz', 'Upconverter 125 MHz', 'Conversor 125 MHz'),
    'Upper':
        ('Oben', 'Boven', 'Haut', 'Sopra', 'Arriba'),
    'Lower':
        ('Unten', 'Onder', 'Bas', 'Sotto', 'Abajo'),
    'Upper text':
        ('Oberer Text', 'Bovenste tekst', 'Texte du haut', 'Testo superiore', 'Texto superior'),
    'Lower text':
        ('Unterer Text', 'Onderste tekst', 'Texte du bas', 'Testo inferiore', 'Texto inferior'),
    'Bold':
        ('Fett', 'Vet', 'Gras', 'Grassetto', 'Negrita'),
    'Black box':
        ('Schwarzer Kasten', 'Zwart vak', 'Cadre noir', 'Riquadro nero', 'Recuadro negro'),
    "Blank: the default input, or for Loopback the default output's monitor.\ndefault (PulseAudio mixer) (or pulse / pipewire): through the sound server - pick the input in the\nmixer (pavucontrol, Recording tab, while the lab is taking sound in): a microphone, or\n'Monitor of ...' for loopback.  plughw:... uses a card directly; a .monitor name is a loopback.":
        ("Leer: der Standardeingang, oder bei Loopback der Monitor des Standardausgangs.\ndefault (PulseAudio mixer) (oder pulse / pipewire): über den Soundserver - den Eingang im\nMixer wählen (pavucontrol, Reiter Aufnahme, während Ton aufgenommen wird): ein Mikrofon, oder\n'Monitor of ...' für Loopback.  plughw:... nutzt eine Karte direkt; ein .monitor-Name ist ein Loopback.", "Leeg: de standaardingang, of bij Loopback de monitor van de standaarduitgang.\ndefault (PulseAudio mixer) (of pulse / pipewire): via de geluidsserver - kies de ingang in de\nmixer (pavucontrol, tabblad Opnemen, terwijl er geluid binnenkomt): een microfoon, of\n'Monitor of ...' voor loopback.  plughw:... gebruikt een kaart direct; een .monitor-naam is een loopback.", "Vide : l'entrée par défaut, ou pour Loopback le moniteur de la sortie par défaut.\ndefault (PulseAudio mixer) (ou pulse / pipewire) : par le serveur de son - choisissez l'entrée dans le\nmixeur (pavucontrol, onglet Enregistrement, pendant la prise de son) : un micro, ou\n'Monitor of ...' pour la boucle.  plughw:... utilise une carte directement ; un nom .monitor est une boucle.", "Vuoto: l'ingresso predefinito, o per Loopback il monitor dell'uscita predefinita.\ndefault (PulseAudio mixer) (o pulse / pipewire): tramite il server audio - scegliere l'ingresso nel\nmixer (pavucontrol, scheda Registrazione, mentre entra l'audio): un microfono, o\n'Monitor of ...' per il loopback.  plughw:... usa una scheda direttamente; un nome .monitor è un loopback.", "Vacío: la entrada predeterminada, o para Loopback el monitor de la salida predeterminada.\ndefault (PulseAudio mixer) (o pulse / pipewire): a través del servidor de sonido - elija la entrada en el\nmezclador (pavucontrol, pestaña Grabación, mientras entra sonido): un micrófono, o\n'Monitor of ...' para loopback.  plughw:... usa una tarjeta directamente; un nombre .monitor es un loopback."),
    "Linux: names ending in .monitor are loopbacks of an output; alsa:hw:Loopback,1 uses ALSA's snd-aloop.":
        ('Linux: Namen mit .monitor am Ende sind Loopbacks eines Ausgangs; alsa:hw:Loopback,1 nutzt ALSAs snd-aloop.', "Linux: namen die eindigen op .monitor zijn loopbacks van een uitgang; alsa:hw:Loopback,1 gebruikt ALSA's snd-aloop.", "Linux : les noms finissant par .monitor sont des boucles d'une sortie ; alsa:hw:Loopback,1 utilise snd-aloop d'ALSA.", "Linux: i nomi che finiscono in .monitor sono loopback di un'uscita; alsa:hw:Loopback,1 usa snd-aloop di ALSA.", 'Linux: los nombres que terminan en .monitor son loopbacks de una salida; alsa:hw:Loopback,1 usa snd-aloop de ALSA.'),
    "Blank: the system default.  pulse: through PulseAudio, so the mixer (Playback tab,\n'NBTV OFDM Lab') says where it goes.  Or a sound card by name.":
        ("Leer: der Systemstandard.  pulse: über PulseAudio, dann bestimmt der Mixer (Reiter Wiedergabe,\n'NBTV OFDM Lab'), wohin es geht.  Oder eine Soundkarte nach Namen.", "Leeg: de systeemstandaard.  pulse: via PulseAudio, dan bepaalt de mixer (tabblad Afspelen,\n'NBTV OFDM Lab') waar het heen gaat.  Of een geluidskaart op naam.", "Vide : la valeur par défaut du système.  pulse : par PulseAudio, le mixeur (onglet Lecture,\n'NBTV OFDM Lab') indique alors où il va.  Ou une carte son par son nom.", "Vuoto: il predefinito di sistema.  pulse: tramite PulseAudio, così il mixer (scheda Riproduzione,\n'NBTV OFDM Lab') dice dove va.  Oppure una scheda audio per nome.", "Vacío: el predeterminado del sistema.  pulse: a través de PulseAudio, así el mezclador (pestaña Reproducción,\n'NBTV OFDM Lab') indica adónde va.  O una tarjeta de sonido por su nombre."),
    'Remove the LO spike (RX: HackRF, RTL-SDR, SoapySDR)':
        ('LO-Spitze entfernen (RX: HackRF, RTL-SDR, SoapySDR)', 'LO-piek verwijderen (RX: HackRF, RTL-SDR, SoapySDR)', 'Supprimer le pic du LO (RX : HackRF, RTL-SDR, SoapySDR)', 'Rimuovi il picco del LO (RX: HackRF, RTL-SDR, SoapySDR)', 'Quitar el pico del LO (RX: HackRF, RTL-SDR, SoapySDR)'),
    'LO spike %s dBFS, removed':
        ('LO-Spitze %s dBFS, entfernt', 'LO-piek %s dBFS, verwijderd', 'pic du LO %s dBFS, supprimé', 'picco del LO %s dBFS, rimosso', 'pico del LO %s dBFS, quitado'),
}


_SPEC = re.compile(r"%[-+ #0]*\d*(?:\.\d+)?[sdfgxi]")
_PAT = []                                       # (regex, translations) for the texts with numbers in them
for _k, _v in TR.items():
    if _SPEC.search(_k):
        _parts = _SPEC.split(_k)
        _PAT.append((re.compile("(.*?)".join(re.escape(p) for p in _parts) + r"\Z", re.S), _v))
cur = "en"
_REG = weakref.WeakSet()                        # widgets with text, and windows with a title


def tr(s, _depth=0):
    """The text in the language now in use (English if there is no translation).  A text with numbers
    in it is matched to its pattern, and its parts are looked up too (status lines are built from parts)."""
    if cur == "en" or not isinstance(s, str) or not s:
        return s
    col = _COL[cur]
    t = TR.get(s)
    if t is not None:
        return t[col]
    for rx, t in _PAT:
        m = rx.match(s)
        if m:
            g = m.groups() if _depth > 2 else tuple(tr(x, _depth + 1) for x in m.groups())
            try:
                return _SPEC.sub("%s", t[col]) % g
            except (TypeError, ValueError):
                return s
    return s


def _hook_init(cls, has_cnf):
    orig = cls.__init__
    if getattr(orig, "_nbtv_lang", False):
        return

    def __init__(self, master=None, cnf=None, **kw):
        if not has_cnf and cnf is not None:
            kw.update(cnf)
            cnf = None
        cnf = dict(cnf) if cnf else {}
        en = kw.get("text", cnf.get("text"))
        if isinstance(en, str):
            if "text" in kw:
                kw["text"] = tr(en)
            else:
                cnf["text"] = tr(en)
        if has_cnf:
            orig(self, master, cnf, **kw)
        else:
            orig(self, master, **kw)
        if isinstance(en, str):
            self._nbtv_en = en
            _REG.add(self)
    __init__._nbtv_lang = True
    cls.__init__ = __init__


def install():
    """Hook tkinter (once): every label, button, tick box and window title goes through tr()."""
    Misc = getattr(tk, "Misc", None)
    if Misc is None or getattr(Misc.configure, "_nbtv_lang", False):
        return
    for name in ("Label", "Button", "Checkbutton", "Radiobutton", "LabelFrame", "Message"):
        if hasattr(tk, name):
            _hook_init(getattr(tk, name), True)
    for name in ("Label", "Button", "Checkbutton", "Radiobutton", "LabelFrame"):
        if hasattr(ttk, name):
            _hook_init(getattr(ttk, name), False)
    conf = Misc.configure

    def configure(self, cnf=None, **kw):
        if cnf is not None and isinstance(cnf, dict) and isinstance(cnf.get("text"), str):
            cnf = dict(cnf)
            self._nbtv_en = cnf["text"]
            cnf["text"] = tr(cnf["text"])
            _REG.add(self)
        if isinstance(kw.get("text"), str):
            self._nbtv_en = kw["text"]
            kw["text"] = tr(kw["text"])
            _REG.add(self)
        return conf(self, cnf, **kw)
    configure._nbtv_lang = True
    configure._nbtv_orig = conf
    Misc.configure = Misc.config = configure
    if not hasattr(tk, "Wm"):
        return
    title = tk.Wm.title

    def wm_title(self, string=None):
        if string is None:
            return title(self)
        self._nbtv_title = string
        _REG.add(self)
        return title(self, tr(string))
    tk.Wm.title = tk.Wm.wm_title = wm_title
    if not hasattr(tk, "Menu"):
        return
    add = tk.Menu.add_command

    def add_command(self, cnf=None, **kw):
        if isinstance(kw.get("label"), str):
            kw["label"] = tr(kw["label"])
        return add(self, cnf or {}, **kw)
    tk.Menu.add_command = add_command


def set_language(code):
    """Use this language from now on, and redraw every open window's texts in it."""
    global cur
    cur = code if code in _COL or code == "en" else "en"
    Misc = getattr(tk, "Misc", None)
    if Misc is None:
        return
    conf = getattr(Misc.configure, "_nbtv_orig", Misc.configure)
    for w in list(_REG):
        try:
            if hasattr(w, "_nbtv_en"):
                conf(w, text=tr(w._nbtv_en))
            if hasattr(w, "_nbtv_title"):
                tk.Wm.title(w, w._nbtv_title)
        except tk.TclError:                     # (a window since closed)
            pass


def code_of(name):
    for c, n in LANGS:
        if n == name or c == name:
            return c
    return "en"


def name_of(code):
    return dict(LANGS).get(code, "English")
