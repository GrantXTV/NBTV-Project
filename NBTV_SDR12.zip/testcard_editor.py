"""Test card editor for the NBTV OFDM Lab - brought over from ExSDR (Grant Taylor VE3XTV).

A test card (PM5544, Colourful, Dish, IDTV, TestF, Bars, ATV, ATV basic, the lab's own) or any picture of
yours, with two lines of text on it (font, size, colour, bold, black box), placed by dragging.  Set + Save
writes it to Pictures/NBTV Lab and makes it the lab's Picture source.

The cards are in the "testcards" folder next to this file; put your own in Pictures/NBTV Lab test cards
(any of PNG, GIF, JPEG, BMP, WebP, TIFF, PPM).  Text needs Pillow (python3-pil) for real fonts; without it
a built-in dot font is used."""
import os
import glob
import time
import subprocess
import numpy as np
import tkinter as tk
from tkinter import ttk
try:
    from tkinter import filedialog
except ImportError:
    filedialog = None
try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    Image = ImageDraw = ImageFont = None


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def pictures_dir():
    """The user's Pictures folder (XDG on Linux, ~/Pictures elsewhere)."""
    home = os.path.expanduser("~")
    try:
        cfgp = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config"), "user-dirs.dirs")
        with open(cfgp) as f:
            for line in f:
                if line.startswith("XDG_PICTURES_DIR"):
                    v = line.split("=", 1)[1].strip().strip('"').replace("$HOME", home)
                    if os.path.isdir(v):
                        return v
    except OSError:
        pass
    d = os.path.join(home, "Pictures")
    return d if os.path.isdir(d) else home


# The test cards: (button, file name without extension), in the "testcards" folder next to this file or in
# Pictures/NBTV Lab test cards.  "NBTV Lab" is the lab's own test card, drawn by the program.
TESTCARDS = (("PM5544", "PM5544"), ("Colourful", "COLFUL"), ("Dish", "DISH"), ("IDTV", "IDCARD"),
             ("TestF", "TestF"), ("TestX", "TestX"), ("Bars", "Bars"), ("ATV", "ATV"), ("ATVBasic", "ATVB"),
             ("NBTV Lab", None))
TC_EXTS = (".gif", ".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff", ".ppm")
TC_WORK_W = 862                                   # big pictures are worked on at this width
IMG_TYPES = [("Images", "*.png *.jpg *.jpeg *.bmp *.gif *.ppm *.pgm *.webp *.tif *.tiff"), ("All files", "*")]


def testcard_dirs():
    return [os.path.join(os.path.dirname(os.path.abspath(__file__)), "testcards"),
            os.path.join(pictures_dir(), "NBTV Lab test cards")]


def testcard_path(stem):
    """The file for a test card button, or None."""
    if not stem:
        return None
    for d in testcard_dirs():
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for n in sorted(names):
            b, e = os.path.splitext(n)
            if b.lower() == stem.lower() and e.lower() in TC_EXTS:
                return os.path.join(d, n)
    return None


_FONTS = None


class Host:
    """What the editor needs from the window that opens it (ExSDR's names, the lab's look).
    app: the lab's window - cfg, root, log(), and use_picture(path, img) / builtin_card(w, h)."""

    def __init__(self, app, colours, fonts):
        self.lab = app
        self.root, self.cfg, self.log = app.root, app.cfg, app.log
        self.ui = app.cfg.setdefault("tc", {})          # (the editor's settings, kept with the lab's)
        (self.BG, self.CARD, self.FG, self.MUTED, self.ACC, self.FIELD, self.BORDER, self.DISPLAY) = colours
        self.SEL, self.HOVER = "#2d5f91", "#3d4651"
        self.F, self.F_SMALL, self.F_HEAD = fonts
        self.IMG_TYPES = IMG_TYPES
        self.tc_editor = None

    def use_picture(self, path, img):
        self.lab.tc_use_picture(path, img)

    def builtin_card(self, w, h):
        return self.lab.tc_builtin_card(w, h)

    @staticmethod
    def _bg(widget):
        try:
            return widget["bg"]
        except Exception:
            return "#262b31"

    def frame(self, parent):
        return tk.Frame(parent, bg=self._bg(parent))

    def group(self, parent, title):
        f = tk.Frame(parent, bg=self.CARD, highlightthickness=1, highlightbackground=self.BORDER)
        if title:
            tk.Label(f, text=title, bg=self.CARD, fg=self.ACC, font=self.F_HEAD).pack(anchor="w", padx=6, pady=(3, 1))
        return f

    def lbl(self, parent, text, muted=False, **kw):
        return tk.Label(parent, text=text, bg=self._bg(parent), fg=self.MUTED if muted else self.FG,
                        font=kw.pop("font", self.F), **kw)

    def btn(self, parent, text, cmd, **kw):
        return tk.Button(parent, text=text, command=cmd, bg="#323942", fg=self.FG, activebackground=self.HOVER,
                         activeforeground=self.FG, relief=tk.FLAT, font=self.F, padx=6, pady=1,
                         highlightthickness=0, **kw)

    def toggle(self, parent, text, variable, value=None, cmd=None, width=None, color=None):
        """Flat push button that stays pressed (radio button when value is given)."""
        common = dict(text=text, variable=variable, command=cmd, indicatoron=False, width=width,
                      bg="#323942", fg=self.FG, selectcolor=color or self.SEL, activebackground=self.HOVER,
                      activeforeground=self.FG, relief=tk.FLAT, bd=0, offrelief=tk.FLAT, highlightthickness=0,
                      font=self.F, padx=6, pady=2, cursor="hand2")
        if value is None:
            return tk.Checkbutton(parent, **common)
        return tk.Radiobutton(parent, value=value, **common)


def open_editor(host):
    """Open the editor (or bring the open one forward)."""
    ed = host.tc_editor
    if ed is not None:
        try:
            ed.win.deiconify()
            ed.win.lift()
            return ed
        except Exception:
            host.tc_editor = None
    host.tc_editor = TestCardEditor(host, "nbtv")
    return host.tc_editor


WFID_FONT = {
    "A": "01110 10001 10001 11111 10001 10001 10001", "B": "11110 10001 10001 11110 10001 10001 11110",
    "C": "01110 10001 10000 10000 10000 10001 01110", "D": "11100 10010 10001 10001 10001 10010 11100",
    "E": "11111 10000 10000 11110 10000 10000 11111", "F": "11111 10000 10000 11110 10000 10000 10000",
    "G": "01110 10001 10000 10111 10001 10001 01111", "H": "10001 10001 10001 11111 10001 10001 10001",
    "I": "01110 00100 00100 00100 00100 00100 01110", "J": "00111 00010 00010 00010 00010 10010 01100",
    "K": "10001 10010 10100 11000 10100 10010 10001", "L": "10000 10000 10000 10000 10000 10000 11111",
    "M": "10001 11011 10101 10101 10001 10001 10001", "N": "10001 10001 11001 10101 10011 10001 10001",
    "O": "01110 10001 10001 10001 10001 10001 01110", "P": "11110 10001 10001 11110 10000 10000 10000",
    "Q": "01110 10001 10001 10001 10101 10010 01101", "R": "11110 10001 10001 11110 10100 10010 10001",
    "S": "01111 10000 10000 01110 00001 00001 11110", "T": "11111 00100 00100 00100 00100 00100 00100",
    "U": "10001 10001 10001 10001 10001 10001 01110", "V": "10001 10001 10001 10001 10001 01010 00100",
    "W": "10001 10001 10001 10101 10101 10101 01010", "X": "10001 10001 01010 00100 01010 10001 10001",
    "Y": "10001 10001 10001 01010 00100 00100 00100", "Z": "11111 00001 00010 00100 01000 10000 11111",
    "0": "01110 10001 10011 10101 11001 10001 01110", "1": "00100 01100 00100 00100 00100 00100 01110",
    "2": "01110 10001 00001 00010 00100 01000 11111", "3": "11111 00010 00100 00010 00001 10001 01110",
    "4": "00010 00110 01010 10010 11111 00010 00010", "5": "11111 10000 11110 00001 00001 10001 01110",
    "6": "00110 01000 10000 11110 10001 10001 01110", "7": "11111 00001 00010 00100 01000 01000 01000",
    "8": "01110 10001 10001 01110 10001 10001 01110", "9": "01110 10001 10001 01111 00001 00010 01100",
    "/": "00001 00010 00010 00100 01000 01000 10000", "-": "00000 00000 00000 11111 00000 00000 00000",
    ".": "00000 00000 00000 00000 00000 01100 01100", " ": "00000 00000 00000 00000 00000 00000 00000",
}


def fit_image(img, w, h):
    """Scale an RGB array to w x h, filling the frame (centre crop), area-averaged."""
    H, W = img.shape[:2]
    s = max(w / float(W), h / float(H))
    cw, ch = min(W, int(round(w / s))), min(H, int(round(h / s)))
    x0, y0 = (W - cw) // 2, (H - ch) // 2
    crop = img[y0:y0 + ch, x0:x0 + cw].astype(np.float64)
    # area average with cumulative sums (works for up- and down-scaling)
    def axis_resample(a, n, ax):
        m = a.shape[ax]
        edges = np.linspace(0, m, n + 1)
        cs = np.concatenate([np.zeros_like(np.take(a, [0], axis=ax)), np.cumsum(a, axis=ax)], axis=ax)
        idx = np.arange(m + 1)
        lo = edges[:-1]
        hi = np.maximum(edges[1:], lo + 1e-6)
        def at(x):
            i = np.clip(np.floor(x).astype(int), 0, m - 1)
            fr = (x - i).reshape([-1 if k == ax else 1 for k in range(a.ndim)])
            return np.take(cs, i, axis=ax) + fr * (np.take(cs, i + 1, axis=ax) - np.take(cs, i, axis=ax))
        shape = [-1 if k == ax else 1 for k in range(a.ndim)]
        return (at(hi) - at(lo)) / (hi - lo).reshape(shape)
    out = axis_resample(axis_resample(crop, h, 0), w, 1)
    return np.clip(out, 0, 255).astype(np.uint8)


def parse_ppm(data):
    """Binary PPM (P6) / PGM (P5) bytes -> RGB array."""
    toks, i = [], 0
    while len(toks) < 4:
        while data[i:i + 1].isspace():
            i += 1
        if data[i:i + 1] == b"#":
            while data[i:i + 1] not in (b"\n", b""):
                i += 1
            continue
        j = i
        while not data[j:j + 1].isspace():
            j += 1
        toks.append(data[i:j])
        i = j
    i += 1
    kind, w, h, mx = toks[0], int(toks[1]), int(toks[2]), int(toks[3])
    ch = 3 if kind == b"P6" else 1
    dt = np.uint8 if mx < 256 else ">u2"
    a = np.frombuffer(data, dtype=dt, count=w * h * ch, offset=i).reshape(h, w, ch).astype(np.float64)
    a = np.clip(a * 255.0 / mx, 0, 255).astype(np.uint8)
    return np.repeat(a, 3, axis=2) if ch == 1 else a


def read_image(path):
    """Any picture file -> RGB array (Pillow if installed, else Tk: PNG, GIF, PPM, PGM)."""
    if Image is not None:
        with Image.open(path) as im:
            return np.asarray(im.convert("RGB")).copy()
    if path.lower().endswith((".ppm", ".pgm", ".pnm")):
        with open(path, "rb") as f:
            return parse_ppm(f.read())
    ph = tk.PhotoImage(file=path)
    import tempfile
    fd, tmp = tempfile.mkstemp(suffix=".ppm")
    os.close(fd)
    try:
        ph.write(tmp, format="ppm")
        with open(tmp, "rb") as f:
            return parse_ppm(f.read())
    finally:
        os.unlink(tmp)


def save_image(img, path):
    if Image is not None:
        Image.fromarray(np.ascontiguousarray(img)).save(path)
        return
    ppm = b"P6 %d %d 255\n" % (img.shape[1], img.shape[0]) + np.ascontiguousarray(img).tobytes()
    if path.lower().endswith(".ppm"):
        with open(path, "wb") as f:
            f.write(ppm)
        return
    tk.PhotoImage(data=ppm, format="PPM").write(path, format="png")



def list_fonts():
    """{family: {style: font file}} of the fonts Pillow can draw with ({} without Pillow)."""
    global _FONTS
    if _FONTS is not None:
        return _FONTS
    fonts = {}
    if ImageFont is None:
        _FONTS = fonts
        return fonts
    try:                                          # Linux: fontconfig knows them all
        out = subprocess.run(["fc-list", "--format", "%{family[0]}|%{style[0]}|%{file}\n"],
                             capture_output=True, text=True, timeout=10).stdout
        for line in out.splitlines():
            p = line.split("|")
            if len(p) == 3 and p[2].lower().endswith((".ttf", ".otf", ".ttc")):
                fonts.setdefault(p[0].strip(), {}).setdefault(p[1].strip() or "Regular", p[2])
    except Exception:
        pass
    if not fonts:                                 # Windows / macOS / no fc-list: look in the font folders
        dirs = [os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Fonts"),
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
                "/Library/Fonts", "/System/Library/Fonts", os.path.expanduser("~/Library/Fonts"),
                "/usr/share/fonts", os.path.expanduser("~/.fonts")]
        for d in dirs:
            for path in glob.glob(os.path.join(d, "**", "*.*"), recursive=True)[:1500]:
                if not path.lower().endswith((".ttf", ".otf", ".ttc")):
                    continue
                try:
                    fam, sty = ImageFont.truetype(path, 12).getname()
                except Exception:
                    continue
                fonts.setdefault(fam, {}).setdefault(sty or "Regular", path)
    _FONTS = fonts
    return fonts


def font_file(family, bold):
    """Font file for a family, the bold style when asked (and there is one).  -> (path, real bold)"""
    styles = list_fonts().get(family) or {}
    if not styles:
        return None, False
    def pick(words, avoid=("italic", "oblique")):
        for s, p in styles.items():
            sl = s.lower()
            if all(w in sl for w in words) and not any(a in sl for a in avoid):
                return p
        return None
    exact = {s.lower(): p for s, p in styles.items()}
    odd = ("italic", "oblique", "semi", "demi", "extra", "ultra", "condensed", "narrow", "light", "thin",
           "black", "medium", "heavy")
    if bold:
        p = exact.get("bold") or pick(("bold",), odd) or pick(("bold",))
        if p:
            return p, True
    p = next((exact[k] for k in ("regular", "book", "normal", "roman", "medium") if k in exact), None) or \
        pick(("regular",), odd) or pick(("book",), odd) or pick((), odd) or pick(())
    return (p or list(styles.values())[0]), False


def _dots_text(img, text, cx, y, size, colour):
    """Without Pillow: the waterfall ID 5 x 7 dot font, scaled (capitals and digits only)."""
    d = max(1, int(round(size / 7.0)))
    chars = [c for c in text.upper() if c in WFID_FONT or c == " "]
    w = len(chars) * 6 * d
    x = int(cx - w / 2)
    H, W = img.shape[:2]
    for c in chars:
        if c != " ":
            for r, row in enumerate(WFID_FONT[c].split()):
                for k, b in enumerate(row):
                    if b == "1":
                        y0, x0 = y + r * d, x + k * d
                        img[max(0, y0):max(0, min(H, y0 + d)), max(0, x0):max(0, min(W, x0 + d))] = colour
        x += 6 * d
    return img


def testcard_draw(base, texts, family, size, colour, bold=True, box=False, boxes=None):
    """The test card with text on it.  texts: [(text, centre x, top y)], colour (r, g, b).
    boxes (a list) gets the (x0, y0, x1, y1) of each text, None for an empty one."""
    img = np.ascontiguousarray(base[..., :3]).copy()
    path, real_bold = font_file(family, bold)
    if boxes is not None:
        del boxes[:]
    if ImageDraw is None or path is None:
        for t, x, y in texts:
            if boxes is not None:
                d = max(1, int(round(size / 7.0)))
                w = len(t) * 6 * d
                boxes.append((x - w / 2.0, y, x + w / 2.0, y + 7 * d) if t.strip() else None)
            if t.strip():
                if box:
                    d = max(1, int(round(size / 7.0)))
                    w = len(t) * 6 * d
                    img[max(0, y - d):y + 8 * d, max(0, int(x - w / 2 - d)):int(x + w / 2 + d)] = 0
                _dots_text(img, t, x, y, size, colour)
        return img
    im = Image.fromarray(img)
    dr = ImageDraw.Draw(im)
    try:
        font = ImageFont.truetype(path, max(4, int(size)))
    except Exception:
        font = ImageFont.load_default()
    sw = 0 if real_bold or not bold else max(1, int(size / 30))       # no bold face: thicken it
    for t, x, y in texts:
        if not t.strip():
            if boxes is not None:
                boxes.append(None)
            continue
        l, tp, r, b = dr.textbbox((0, 0), t, font=font, stroke_width=sw)
        x0 = x - (r - l) / 2.0 - l
        if boxes is not None:
            boxes.append((x0 + l, y + tp, x0 + r, y + b))
        if box:
            pad = max(2, int(size / 8))
            dr.rectangle((x0 + l - pad, y + tp - pad, x0 + r + pad, y + b + pad), fill=(0, 0, 0))
        dr.text((x0, y), t, font=font, fill=tuple(colour), stroke_width=sw, stroke_fill=tuple(colour))
    return np.asarray(im).copy()


class TestCardEditor:
    """Test card editor (from ExSDR): a test card (or your own picture) with two lines of text on it,
    saved to Pictures/NBTV Lab and used as the lab's picture source, ready to send."""
    SWATCHES = ("#ffffff", "#000000", "#ffff00", "#00ffff", "#00ff00", "#ff00ff", "#ff0000", "#0000ff",
                "#ff8000", "#808080", "#c0c0c0", "#800000", "#008000", "#000080", "#804000", "#ff80c0")

    def __init__(self, app, target):
        self.app, self.target = app, target
        a, ui = app, app.ui
        self.win = w = tk.Toplevel(app.root)
        w.title("Test Card Editor - NBTV Lab")
        w.configure(bg=a.BG)
        w.geometry("1060x760")
        w.protocol("WM_DELETE_WINDOW", self.close)
        self.base = None                                  # the card without text (RGB array)
        self.card = ui.get("tc_card", "PM5544")
        self.img = None
        self.pending = None
        self.fx = [ui.get("tc_ux", 0.5), ui.get("tc_lx", 0.5)]      # text centre, fraction of the width
        self.fy = [ui.get("tc_uy", 0.084), ui.get("tc_ly", 0.775)]  # text top, fraction of the height
        # ---- top: test cards, text position, the text itself
        top = a.frame(w)
        top.configure(bg=a.BG)
        top.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(6, 2))
        right_t = a.frame(top)
        right_t.pack(side=tk.RIGHT, padx=(8, 0))
        a.lbl(right_t, "Displayed text", muted=True, font=a.F_SMALL).grid(row=0, column=0, columnspan=2, sticky="w")
        self.v_text = []
        call = (app.cfg.get("callsign", "") or "").strip().upper()
        for r, (name, key, dflt) in enumerate((("Upper", "tc_upper", call or "NBTV"),
                                               ("Lower", "tc_lower", "Test TX"))):
            a.lbl(right_t, name, muted=True, font=a.F_SMALL).grid(row=r + 1, column=0, sticky="e", padx=(0, 3))
            v = tk.StringVar(value=ui.get(key, dflt))
            v.trace_add("write", lambda *_: self.redraw_soon())
            e = tk.Entry(right_t, textvariable=v, width=24, bg=a.FIELD, fg=a.FG, insertbackground=a.FG,
                         relief=tk.FLAT, highlightthickness=1, highlightbackground=a.BORDER)
            e.grid(row=r + 1, column=1, pady=1)
            self.v_text.append(v)
        left_t = a.frame(top)
        left_t.pack(side=tk.LEFT, fill=tk.X, expand=True)
        cards = a.frame(left_t)
        cards.pack(fill=tk.X)
        self.v_card = tk.StringVar(value=self.card)
        self.card_btns = {}
        for name, stem in TESTCARDS:
            b = a.toggle(cards, name, self.v_card, value=name, cmd=lambda n=name: self.load_card(n), width=8)
            b.pack(side=tk.LEFT, padx=1)
            self.card_btns[name] = b
            if stem and testcard_path(stem) is None:
                b.config(state=tk.DISABLED)               # file not there
        pos = a.frame(left_t)
        pos.pack(fill=tk.X, pady=(4, 0))
        self.scales, self.vals = [], []
        for i, name in enumerate(("Upper text", "Lower text")):
            g = a.group(pos, name)
            g.pack(side=tk.LEFT, padx=(0, 6), fill=tk.X, expand=True)
            row = a.frame(g)
            row.pack(fill=tk.X)
            for j, ax in enumerate(("X", "Y")):
                a.lbl(row, ax, muted=True, font=a.F_SMALL).pack(side=tk.LEFT, padx=(6 if j else 0, 2))
                v = tk.DoubleVar(value=0)
                sc = ttk.Scale(row, from_=0, to=100, orient=tk.HORIZONTAL, length=120, variable=v,
                               command=lambda _x, i=i, j=j: self.slid(i, j))
                sc.pack(side=tk.LEFT, fill=tk.X, expand=True)
                vl = tk.Label(row, text="", width=4, bg=a._bg(row), fg=a.FG, font=a.F_SMALL)
                vl.pack(side=tk.LEFT)
                self.scales.append((sc, v, vl))
        # ---- right column: colour, font, save, your own pictures
        side = a.group(w, "")
        side.pack(side=tk.RIGHT, fill=tk.Y, padx=(2, 6), pady=(2, 6))
        a.lbl(side, "Text colour", muted=True, font=a.F_SMALL).pack(anchor="w")
        sw = a.frame(side)
        sw.pack(anchor="w", pady=(2, 2))
        for k, c in enumerate(self.SWATCHES):
            b = tk.Label(sw, bg=c, width=3, height=1, relief=tk.FLAT, highlightthickness=1,
                         highlightbackground=a.BORDER, cursor="hand2")
            b.grid(row=k // 8, column=k % 8, padx=1, pady=1)
            b.bind("<Button-1>", lambda e, c=c: self.set_colour(c))
        cr = a.frame(side)
        cr.pack(fill=tk.X, pady=(2, 6))
        self.colour = ui.get("tc_colour", "#ffffff")
        self.col_show = tk.Label(cr, bg=self.colour, width=6, highlightthickness=1, highlightbackground=a.BORDER)
        self.col_show.pack(side=tk.LEFT)
        a.btn(cr, "More...", self.pick_colour).pack(side=tk.LEFT, padx=4)
        a.lbl(side, "Font", muted=True, font=a.F_SMALL).pack(anchor="w")
        fams = sorted(list_fonts(), key=str.lower) or ["Built-in dots"]
        want = ui.get("tc_font")
        if want not in fams:
            want = next((f for f in ("DejaVu Sans", "Arial", "Liberation Sans", "FreeSans", "Helvetica")
                         if f in fams), fams[0])
        self.v_font = tk.StringVar(value=want)
        fc = ttk.Combobox(side, textvariable=self.v_font, values=fams, width=24, state="readonly")
        fc.pack(fill=tk.X)
        fc.bind("<<ComboboxSelected>>", lambda e: self.redraw_soon())
        fs = a.frame(side)
        fs.pack(fill=tk.X, pady=(4, 0))
        a.lbl(fs, "Font size", muted=True, font=a.F_SMALL).pack(side=tk.LEFT)
        self.v_size = tk.IntVar(value=int(ui.get("tc_size", 38)))
        sp = tk.Spinbox(fs, from_=8, to=300, width=5, textvariable=self.v_size, command=self.redraw_soon,
                        bg=a.FIELD, fg=a.FG, buttonbackground=a.CARD, relief=tk.FLAT, highlightthickness=1,
                        highlightbackground=a.BORDER)
        sp.pack(side=tk.RIGHT)
        sp.bind("<KeyRelease>", lambda e: self.redraw_soon())
        ob = a.frame(side)
        ob.pack(fill=tk.X, pady=(4, 0))
        self.v_bold = tk.IntVar(value=int(ui.get("tc_bold", 1)))
        self.v_box = tk.IntVar(value=int(ui.get("tc_box", 0)))
        a.toggle(ob, "Bold", self.v_bold, cmd=self.redraw_soon).pack(side=tk.LEFT)
        a.toggle(ob, "Black box", self.v_box, cmd=self.redraw_soon).pack(side=tk.LEFT, padx=4)
        a.btn(side, "Set + Save", self.save).pack(fill=tk.X, pady=(10, 2))
        a.btn(side, "User file", self.user_file).pack(fill=tk.X, pady=(2, 4))
        self.dir = ui.get("tc_dir") or pictures_dir()
        self.dir_lbl = tk.Label(side, text="", bg=a._bg(side), fg=a.MUTED, font=a.F_SMALL, anchor="w",
                                width=30)
        self.dir_lbl.pack(fill=tk.X)
        lf = a.frame(side)
        lf.pack(fill=tk.BOTH, expand=True)
        self.files = tk.Listbox(lf, bg=a.FIELD, fg=a.FG, selectbackground=a.SEL, relief=tk.FLAT,
                                highlightthickness=1, highlightbackground=a.BORDER, activestyle="none",
                                exportselection=False, width=30)
        sb = ttk.Scrollbar(lf, orient=tk.VERTICAL, command=self.files.yview)
        self.files.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.files.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.files.bind("<Double-Button-1>", lambda e: self.user_file())
        self.files.bind("<Return>", lambda e: self.user_file())
        a.lbl(side, "Double-click a folder to open it,\na picture to use it.", muted=True,
              font=a.F_SMALL).pack(anchor="w", pady=(2, 0))
        # ---- the picture
        self.cv = tk.Canvas(w, bg=a.DISPLAY, highlightthickness=1, highlightbackground=a.BORDER)
        self.cv.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(6, 2), pady=(2, 6))
        self.cv.bind("<Configure>", lambda e: self.show())
        self.boxes = []
        self.drag = None
        self.cv.bind("<Button-1>", self.press)          # on a text: drag it; elsewhere: the upper text goes there
        self.cv.bind("<B1-Motion>", self.motion)
        self.cv.bind("<ButtonRelease-1>", self.release)
        self.cv.bind("<Button-3>", lambda e: self.click(e, 1))          # right click: the lower text
        self.cv.bind("<Motion>", self.hover)
        self.status = tk.Label(w, text="", bg=a.BG, fg=a.MUTED, font=a.F_SMALL)
        self.fill_files()
        last = ui.get("tc_userfile")
        if self.card == "User file" and last and os.path.isfile(last):
            self.load_file(last)
        else:
            if self.card not in dict(TESTCARDS) or (dict(TESTCARDS)[self.card] and
                                                     testcard_path(dict(TESTCARDS)[self.card]) is None):
                self.card = next((n for n, s in TESTCARDS if s and testcard_path(s)), "NBTV Lab")
            self.load_card(self.card)

    # ------------------------------------------------------------ pictures
    @staticmethod
    def work_size(img):
        """Big or small pictures are worked on about 862 wide, so the font sizes mean the same."""
        h, w = img.shape[:2]
        if 640 <= w <= 1024:
            return img
        nw = TC_WORK_W
        nh = max(1, int(round(h * nw / float(w))))
        return fit_image(img, nw, nh)

    def load_card(self, name):
        stem = dict(TESTCARDS).get(name)
        try:
            img = self.app.builtin_card(864, 648) if stem is None else read_image(testcard_path(stem))
        except Exception as e:
            self.app.log("Test card: cannot read %s: %s" % (name, e))
            return
        self.card = name
        self.v_card.set(name)
        self.set_base(img)

    def load_file(self, path):
        try:
            img = read_image(path)
        except Exception as e:
            self.app.log("Test card: cannot read %s: %s" % (path, e))
            return False
        self.card = "User file"
        self.v_card.set("")
        self.app.ui["tc_userfile"] = path
        self.set_base(img)
        return True

    def set_base(self, img):
        self.base = self.work_size(img)
        h, w = self.base.shape[:2]
        for k, (sc, v, vl) in enumerate(self.scales):
            i, j = divmod(k, 2)
            n = w if j == 0 else h
            sc.configure(to=n)
            v.set(round((self.fx[i] if j == 0 else self.fy[i]) * n))
            vl.config(text="%d" % v.get())
        self.redraw()

    # ------------------------------------------------------------ controls
    def slid(self, i, j):
        if self.base is None:
            return
        h, w = self.base.shape[:2]
        sc, v, vl = self.scales[2 * i + j]
        x = float(v.get())
        vl.config(text="%d" % x)
        if j == 0:
            self.fx[i] = x / w
        else:
            self.fy[i] = x / h
        self.redraw_soon()

    def to_pic(self, e):
        x0, y0, s = self.geo
        return (e.x - x0) / s, (e.y - y0) / s

    def hit(self, e):
        """Which text (0 upper, 1 lower) is under the mouse, or None."""
        if self.base is None or not getattr(self, "geo", None):
            return None
        px, py = self.to_pic(e)
        m = 6 / self.geo[2]                               # a few screen pixels of slack
        for i in (1, 0):                                  # the one drawn last is on top
            b = self.boxes[i] if i < len(self.boxes) else None
            if b and b[0] - m <= px <= b[2] + m and b[1] - m <= py <= b[3] + m:
                return i
        return None

    def press(self, e):
        i = self.hit(e)
        if i is None:
            self.drag = None
            self.click(e, 0)
            return
        px, py = self.to_pic(e)
        h, w = self.base.shape[:2]
        self.drag = (i, self.fx[i] * w - px, self.fy[i] * h - py)    # keep the grab point under the mouse
        self.cv.config(cursor="fleur")

    def motion(self, e):
        if self.drag is None or self.base is None:
            return
        i, ox, oy = self.drag
        h, w = self.base.shape[:2]
        px, py = self.to_pic(e)
        self.place(i, clamp(px + ox, 0, w), clamp(py + oy, 0, h), soon=25)

    def release(self, e):
        if self.drag is not None:
            self.drag = None
            self.redraw()
        self.hover(e)

    def hover(self, e):
        try:
            self.cv.config(cursor="fleur" if self.hit(e) is not None else "crosshair")
        except Exception:
            pass

    def place(self, i, px, py, soon=60):
        h, w = self.base.shape[:2]
        self.fx[i], self.fy[i] = px / w, py / h
        for j, val in ((0, px), (1, py)):
            sc, v, vl = self.scales[2 * i + j]
            v.set(round(val))
            vl.config(text="%d" % val)
        self.redraw_soon(ms=soon)

    def click(self, e, i):
        """Click on the picture: that text goes there (centred across, top at the click)."""
        if self.base is None or not getattr(self, "geo", None):
            return
        h, w = self.base.shape[:2]
        px, py = self.to_pic(e)
        self.place(i, clamp(px, 0, w), clamp(py, 0, h))

    def set_colour(self, c):
        self.colour = c
        self.col_show.config(bg=c)
        self.redraw_soon()

    def pick_colour(self):
        try:
            from tkinter import colorchooser
            c = colorchooser.askcolor(color=self.colour, parent=self.win, title="Text colour")[1]
        except Exception:
            c = None
        if c:
            self.set_colour(c)

    def size(self):
        try:
            return clamp(int(self.v_size.get()), 4, 400)
        except (ValueError, tk.TclError):
            return 38

    def texts(self):
        h, w = self.base.shape[:2]
        return [(self.v_text[i].get(), int(round(self.fx[i] * w)), int(round(self.fy[i] * h))) for i in (0, 1)]

    def redraw_soon(self, *_, ms=60):
        if self.pending is not None:
            try:
                self.win.after_cancel(self.pending)
            except Exception:
                pass
        self.pending = self.win.after(ms, self.redraw)

    def redraw(self):
        self.pending = None
        if self.base is None:
            return
        c = self.colour.lstrip("#")
        rgb = tuple(int(c[k:k + 2], 16) for k in (0, 2, 4)) if len(c) == 6 else (255, 255, 255)
        self.img = testcard_draw(self.base, self.texts(), self.v_font.get(), self.size(), rgb,
                                 bold=bool(self.v_bold.get()), box=bool(self.v_box.get()), boxes=self.boxes)
        self.show()

    def show(self):
        if self.img is None:
            return
        cv = self.cv
        W, H = max(50, int(cv.winfo_width() or 0)), max(50, int(cv.winfo_height() or 0))
        h, w = self.img.shape[:2]
        s = min((W - 8) / float(w), (H - 8) / float(h))
        dw, dh = max(1, int(w * s)), max(1, int(h * s))
        if Image is not None:
            a = np.asarray(Image.fromarray(self.img).resize((dw, dh), Image.LANCZOS))
        else:
            ys = np.minimum((np.arange(dh) / s).astype(int), h - 1)
            xs = np.minimum((np.arange(dw) / s).astype(int), w - 1)
            a = self.img[ys][:, xs]
        self.photo = tk.PhotoImage(data=b"P6 %d %d 255\n" % (dw, dh) + np.ascontiguousarray(a).tobytes(),
                                   format="PPM")
        x0, y0 = (W - dw) // 2, (H - dh) // 2
        self.geo = (x0, y0, s)
        cv.delete("all")
        cv.create_image(x0, y0, image=self.photo, anchor="nw")
        cv.create_text(W - 6, H - 4, anchor="se", fill="#8a93a0", font=self.app.F_SMALL,
                       text="drag a text to move it   click: upper text here   right-click: lower text here")

    # ------------------------------------------------------------ your own pictures
    def fill_files(self):
        lb = self.files
        lb.delete(0, tk.END)
        self.entries = []
        d = self.dir
        self.dir_lbl.config(text=d if len(d) < 34 else "..." + d[-31:])
        try:
            names = sorted(os.listdir(d), key=str.lower)
        except OSError:
            names = []
        if os.path.dirname(d) != d:
            self.entries.append(os.path.dirname(d))
            lb.insert(tk.END, "[..]")
        for n in names:
            if n.startswith("."):
                continue
            p = os.path.join(d, n)
            if os.path.isdir(p):
                self.entries.append(p)
                lb.insert(tk.END, "[%s]" % n)
        for n in names:
            p = os.path.join(d, n)
            if os.path.isfile(p) and os.path.splitext(n)[1].lower() in TC_EXTS:
                self.entries.append(p)
                lb.insert(tk.END, n)

    def user_file(self):
        """User file: the picture chosen in the list (a folder opens), or ask for one."""
        sel = self.files.curselection()
        path = self.entries[sel[0]] if sel and sel[0] < len(self.entries) else None
        if path and os.path.isdir(path):
            self.dir = path
            self.app.ui["tc_dir"] = path
            self.fill_files()
            return
        if not path:
            if filedialog is None:
                return
            path = filedialog.askopenfilename(parent=self.win, title="Picture for the test card",
                                              filetypes=self.app.IMG_TYPES, initialdir=self.dir)
            if not path:
                return
            self.dir = os.path.dirname(path)
            self.app.ui["tc_dir"] = self.dir
            self.fill_files()
        self.load_file(path)

    # ------------------------------------------------------------ save and use
    def remember(self):
        ui = self.app.ui
        ui.update(tc_card=self.card, tc_upper=self.v_text[0].get(), tc_lower=self.v_text[1].get(),
                  tc_ux=self.fx[0], tc_uy=self.fy[0], tc_lx=self.fx[1], tc_ly=self.fy[1],
                  tc_font=self.v_font.get(), tc_size=self.size(), tc_colour=self.colour,
                  tc_bold=int(self.v_bold.get()), tc_box=int(self.v_box.get()), tc_dir=self.dir)

    def save(self):
        """Set + Save: save the picture to Pictures/NBTV Lab and send it (the lab's Picture source)."""
        if self.img is None:
            return
        if self.pending is not None:
            self.redraw()
        d = os.path.join(pictures_dir(), "NBTV Lab")
        try:
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, "testcard-%s.png" % time.strftime("%Y%m%d-%H%M%S"))
            k = 2
            while os.path.exists(path):
                path = os.path.join(d, "testcard-%s-%d.png" % (time.strftime("%Y%m%d-%H%M%S"), k))
                k += 1
            save_image(self.img, path)
        except Exception as e:
            self.app.log("Test card: cannot save: %s" % e)
            return
        self.remember()
        self.app.log("Test card: saved %s" % path)
        self.app.use_picture(path, self.img.copy())
        self.last_saved = path
        self.close()

    def close(self):
        if self.pending is not None:
            try:
                self.win.after_cancel(self.pending)
            except Exception:
                pass
            self.pending = None
        self.remember()
        if getattr(self.app, "tc_editor", None) is self:
            self.app.tc_editor = None
        try:
            self.win.destroy()
        except Exception:
            pass
