"""NBTV SDR - radio control: VE3XTV's homebrew HF SDR over its serial port (as in ExSDR).

    9600 baud 8N1, no line terminator, about 100 ms between commands (600 ms around a frequency
    command - the PIC locks up when they come quickly).
        F03650 -> "Frequency Set to 3650 kHz"     ?F -> "Frequency = 7100 kHz"
        TX -> "Tx Set"    RX -> "Rx Set"          power-on banner "HF SDR v1"
    The window follows what the radio reports back.
"""
import os
import queue
import re
import select
import threading
import time

try:
    import termios
except ImportError:          # not Linux
    termios = None
try:
    import serial as pyserial
except Exception:
    pyserial = None

FMIN_KHZ, FMAX_KHZ = 300, 65000                  # the homebrew SDR: 300 kHz to just over 65 MHz

RADIO_DEFAULTS = {
    "serial_port": "/dev/ttyUSB0",
    "baud": 9600,
    "terminator": "",             # appended to every command ("" = none)
    "reply_timeout": 1.50,        # seconds to wait for the hardware's reply to a command
    "idle_gap": 0.06,             # seconds of silence that end a reply
    "cmd_gap": 0.10,              # minimum time between two commands
    "freq_gap": 0.60,             # minimum time before and after a frequency (Fnnnnn) command
    "txrx_gap": 0.40,             # minimum time after TX / RX (relays + LEDs)
    "banner_wait": 0.40,          # listen this long after opening the port for "HF SDR v1"
    "open_delay": 0.0,            # wait after opening the port (boards that reset on open)
}


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


class SerialLink:
    """Serial control of the homebrew hardware (termios only, no pyserial).

    The hardware does NOT echo. It answers every command with a text message:
        F03650 -> "Frequency Set to 3650 kHz"      ?F -> "Frequency = 7100 kHz"
        TX     -> "Tx Set"                         RX -> "Rx Set"
        ?P     -> "Pre Amp = off" / "Pre Amp = on"
        ?A     -> "Attenuator = off" / "Attenuator = on"
        power-on banner: "HF SDR v1"
    Two commands must be at least cmd_gap (100 ms) apart.  Everything the hardware
    reports (also unsolicited text such as the banner) is parsed and pushed to
    `self.events`, so the GUI always shows what the hardware says, not what was asked.
    """
    FREQ_RE = re.compile(r"Frequency\D*(\d+)\s*kHz", re.I)
    PRE_RE = re.compile(r"Pre\s*-?\s*Amp\b.*?\b(on|off)\b", re.I)
    ATT_RE = re.compile(r"Attenuator\b.*?\b(on|off)\b", re.I)
    TX_RE = re.compile(r"\bTx\s+Set\b", re.I)
    RX_RE = re.compile(r"\bRx\s+Set\b", re.I)
    HELLO_RE = re.compile(r"HF\s*SDR\b.*", re.I)

    def __init__(self, cfg, log):
        self.cfg = cfg
        self.log = log
        self.fd = None
        self.ser = None
        self.q = queue.Queue()
        self.events = queue.Queue()
        self.stop_evt = threading.Event()
        self.thread = None
        self.lock = threading.Lock()
        self.pend_freq = None
        self.t_last = 0.0
        self.last_kind = ""
        self.hw ={"freq": None, "pre": None, "att": None, "tx": None, "version": None}
        self.connected = False

    # ------------------------------------------------------------ open / close
    def open(self):
        self.ser = None
        if termios is None:                              # Windows: pyserial (COM3 ...)
            return self._open_pyserial()
        port = self.cfg["serial_port"]
        try:
            fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        except OSError as e:
            hint = ""
            if e.errno == 13:
                hint = "  (permission: sudo usermod -aG dialout $USER, then log out and in)"
            raise RuntimeError("cannot open %s: %s%s" % (port, e.strerror, hint))
        attrs = termios.tcgetattr(fd)
        speed = getattr(termios, "B%d" % int(self.cfg["baud"]), None)
        if speed is None:
            os.close(fd)
            raise RuntimeError("unsupported baud rate %s" % self.cfg["baud"])
        attrs[0] = 0
        attrs[1] = 0
        attrs[2] = termios.CS8 | termios.CREAD | termios.CLOCAL       # 8 data, no parity, 1 stop
        attrs[3] = 0
        attrs[4] = speed
        attrs[5] = speed
        attrs[6][termios.VMIN] = 0
        attrs[6][termios.VTIME] = 0
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
        self.fd = fd
        if self.cfg["open_delay"]:
            time.sleep(self.cfg["open_delay"])
        self.t_last = time.time()
        self.stop_evt.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.connected = True
        self.log("serial: %s open at %s baud 8N1" % (port, self.cfg["baud"]))

    def _open_pyserial(self):
        if pyserial is None:
            raise RuntimeError("serial control needs pyserial: py -m pip install pyserial")
        port = self.cfg["serial_port"]
        try:
            self.ser = pyserial.Serial(port, int(self.cfg["baud"]), bytesize=8, parity="N", stopbits=1,
                                       timeout=0, write_timeout=1.0)
        except Exception as e:
            raise RuntimeError("cannot open %s: %s" % (port, e))
        if self.cfg["open_delay"]:
            time.sleep(self.cfg["open_delay"])
        self.t_last = time.time()
        self.stop_evt.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.connected = True
        self.log("serial: %s open at %s baud 8N1" % (port, self.cfg["baud"]))

    def _wait_data(self, to):
        """True when bytes are waiting (within to seconds)."""
        if getattr(self, "ser", None) is not None:
            t_end = time.time() + to
            while True:
                try:
                    if self.ser.in_waiting:
                        return True
                except Exception as e:
                    raise OSError(str(e))
                if time.time() >= t_end:
                    return False
                time.sleep(0.003)
        r, _, _ = select.select([self.fd], [], [], to)
        return bool(r)

    def _read_some(self):
        if getattr(self, "ser", None) is not None:
            try:
                return self.ser.read(self.ser.in_waiting or 1)
            except Exception as e:
                raise OSError(str(e))
        return os.read(self.fd, 256)

    def _write(self, b):
        if getattr(self, "ser", None) is not None:
            try:
                self.ser.reset_input_buffer()
                self.ser.write(b)
                self.ser.flush()
            except Exception as e:
                raise OSError(str(e))
            return
        try:
            termios.tcflush(self.fd, termios.TCIFLUSH)
        except Exception:
            pass
        os.write(self.fd, b)

    def close(self):
        self.stop_evt.set()
        if self.thread is not None:
            self.thread.join(2.0)
            self.thread = None
        if getattr(self, "ser", None) is not None:
            try:
                self.ser.close()
            except Exception:
                pass
            self.ser = None
        if self.fd is not None:
            try:
                os.close(self.fd)
            except OSError:
                pass
        self.fd = None
        self.connected = False

    # ------------------------------------------- public (thread safe, non blocking)
    def set_freq_khz(self, khz):
        with self.lock:
            self.pend_freq = int(clamp(khz, FMIN_KHZ, FMAX_KHZ))
        self.q.put(("freq",))

    def set_flag(self, letter, on):
        key = {"P": "pre", "A": "att"}[letter]
        self.q.put(("cmd", "%s%d" % (letter, 1 if on else 0), "?" + letter, key))

    def submit_txrx(self, cmd, delay=0.0, done=None):
        self.q.put(("txrx", cmd, delay, done))

    def send_raw(self, text):
        self.q.put(("raw", text))

    def query_all(self):
        for letter, key in (("F", "freq"), ("P", "pre"), ("A", "att")):
            self.q.put(("query", "?" + letter))

    # ------------------------------------------------------------------ parsing
    def parse(self, text):
        """Turn hardware text into events, update self.hw, return [(kind, value)]."""
        evs = []
        for line in re.split(r"[\r\n]+", text):
            line = line.strip()
            if not line:
                continue
            m = self.FREQ_RE.search(line)
            if m:
                evs.append(("freq", int(m.group(1))))
                continue
            m = self.PRE_RE.search(line)
            if m:
                evs.append(("pre", m.group(1).lower() == "on"))
                continue
            m = self.ATT_RE.search(line)
            if m:
                evs.append(("att", m.group(1).lower() == "on"))
                continue
            if self.TX_RE.search(line):
                evs.append(("tx", True))
                continue
            if self.RX_RE.search(line):
                evs.append(("tx", False))
                continue
            m = self.HELLO_RE.search(line)
            if m:
                evs.append(("hello", m.group(0).strip()))
                continue
            evs.append(("text", line))
        for kind, val in evs:
            if kind == "hello":
                self.hw["version"] = val
            elif kind in self.hw:
                self.hw[kind] = val
            if kind == "freq":
                with self.lock:
                    latest = self.pend_freq is None      # False: a newer request is already waiting
                self.events.put(("freq", val, latest))
            else:
                self.events.put((kind, val))
        return evs

    # ------------------------------------------------------------------- worker
    def _run(self):
        try:
            self._listen(self.cfg["banner_wait"])        # power-on banner "HF SDR v1"
        except Exception as e:
            self.log("serial error: %s" % e)
        while not self.stop_evt.is_set():
            try:
                try:
                    item = self.q.get(timeout=0.1)
                except queue.Empty:
                    self._drain()                         # unsolicited text, e.g. hardware power-cycled
                    continue
                self._handle(item)
            except OSError as e:
                self.log("serial link lost: %s" % e)
                self.connected = False
                return
            except Exception as e:
                self.log("serial error: %s" % e)

    def _read_idle(self, first_wait):
        data = b""
        while True:
            to = self.cfg["idle_gap"] if data else first_wait
            if not self._wait_data(to):
                break
            chunk = self._read_some()
            if not chunk:
                break
            data += chunk
        return data

    def _listen(self, secs):
        text = self._read_idle(secs).decode("ascii", "ignore")
        if text.strip():
            self.log("hw< " + " | ".join(l.strip() for l in re.split(r"[\r\n]+", text) if l.strip()))
            self.parse(text)

    def _drain(self):
        if self._wait_data(0):
            self._listen(0.0)

    def xfer(self, cmd):
        """Send one command, wait for the reply. Returns (reply_text, events)."""
        self._drain()
        is_freq = re.match(r"F\d+$", cmd) is not None
        gap = self.cfg["cmd_gap"]
        # The PIC is busy after some commands (PLL, band relays, LED update: PAUSE 200,
        # PAUSE 100, 16 x PAUSE 10).  A byte that arrives while it is busy overruns its
        # USART, and the old firmware then stops receiving altogether - the "lock up".
        if is_freq or self.last_kind == "F":
            gap = max(gap, float(self.cfg.get("freq_gap", 0.6)))
        if self.last_kind == "TXRX":
            gap = max(gap, float(self.cfg.get("txrx_gap", 0.4)))
        wait = gap - (time.time() - self.t_last)
        if wait > 0:
            time.sleep(wait)
        self.last_kind = "F" if is_freq else "TXRX" if cmd in ("TX", "RX") else ""
        self._write((cmd + self.cfg["terminator"]).encode("ascii"))
        text = self._read_idle(self.cfg["reply_timeout"]).decode("ascii", "ignore")
        self.t_last = time.time()
        shown = " | ".join(l.strip() for l in re.split(r"[\r\n]+", text) if l.strip())
        self.log("hw> %-7s < %s" % (cmd, shown or "(no reply)"))
        return text, self.parse(text)

    def _handle(self, item):
        kind = item[0]
        if kind == "freq":
            with self.lock:
                k, self.pend_freq = self.pend_freq, None
            if k is None:
                return                                    # already sent (requests were merged)
            text, evs = self.xfer("F%05d" % k)
            if not any(e[0] == "freq" for e in evs):
                self.log("warning: no 'Frequency Set' reply for F%05d" % k)
        elif kind == "cmd":
            text, evs = self.xfer(item[1])
            if not any(e[0] == item[3] for e in evs):     # reply did not say on/off: ask
                self.xfer(item[2])
        elif kind == "query":
            self.xfer(item[1])
        elif kind == "txrx":
            if item[2]:
                time.sleep(item[2])
            text, evs = self.xfer(item[1])
            ok = ("tx", item[1] == "TX") in evs
            if not ok:
                self.log("warning: no '%s Set' reply from hardware" % item[1].capitalize())
            if item[3]:
                item[3](ok)
        elif kind == "raw":
            self.xfer(item[1])




class NullRadio:
    """No radio control (HackRF, or no hardware): the same calls, nothing sent."""

    def __init__(self, cfg=None, log=None):
        self.events = queue.Queue()
        self.connected = False
        self.hw = {"freq": None, "pre": None, "att": None, "tx": None, "version": None}

    def open(self):
        pass

    def close(self):
        pass

    def set_freq_khz(self, khz):
        pass

    def set_flag(self, letter, on):
        pass

    def submit_txrx(self, cmd, delay=0.0, done=None):
        if done:
            done(True)

    def send_raw(self, text):
        pass

    def query_all(self):
        pass
