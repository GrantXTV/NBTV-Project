# NBTV SDR 1.13 — VE3XTV

NBTV SDR puts VE3XTV's NBTV system on the air. Encode and transmit, receive and decode, all in one window.

It is made from NBTV OFDM Lab 5.31 and uses the same codec and modem (`nbtv_core.py`), so its signal is the lab's signal. The lab's test parts have been taken out:

- the simulated channel (Noise / SNR dB and its sliders)
- the data frame monitor
- the RF out display
- Real world, Clean channel, the SNR sweep and the Sync test
- the Fast speed (NBTV SDR always runs in real time)

## New in 1.13 — video emphasis in every mode (from NBTV OFDM Lab 5.38)

- **Video emph** (next to I/Q flip), on by default: the transmitter lifts the fine detail of each
  picture's brightness (soft knee, the colour untouched), the receiver takes it back down with the
  channel's fine-grain noise.  About +0.5 to +1.5 dB at 0-10 dB C/N in every mode, little or nothing
  above 20 dB.  Not sent in the mode word: both stations must have it set the same.
- The codec is the lab's 5.38, so the 120x96 encoder modes now include 5 KWMD-MC (mode 1's signal,
  the 240x192 detail carried along the motion at the receiver) and 6 L KMM-MS (mode 3 with a 192 line
  key as line sums and differences).
- The Auto line names the mode by the format the sync found (the mode word's codes now mean different
  modes in 120x96 and 180x96).

## New in 1.12

- **The lines under the frequency readout now wrap at the readout's width.** These are the LO / radio line and the lock / C/N line, and each now runs to two short lines. Before, they could widen the frequency block and push the 10 m and 6 m channel buttons past the right edge of the centre panel.

## New in 1.11 — ExSDR pre-amp and attenuator, 6 m channels

- **Pre-amp and Attenuator for the ExSDR radio.** These are in Radio / I/Q setup, on the ExSDR radio tab.
  - Ticking one sends `P1` / `P0` or `A1` / `A0`, then reads the setting back with `?P` / `?A`.
  - The tick boxes follow what the radio reports. On connecting, the window takes the radio's own settings.
  - **Read back** asks the radio again.
  - The radio line under the frequency shows "pre-amp on/off, attenuator on/off".
- **6 m channels.** Ten channels of 100 kHz fill 51.0 to 52.0 MHz. Their centres run from 51.050 to 51.950 MHz. They sit to the right of the 10 m channels, in two columns of five.
  - A button jumps to that channel's centre.
  - The lit button is the channel you are on. A dimmer one means you are inside it but off its centre.

## New in 1.10 — the "cuda" fix carried to CuPy's own probe

**What went wrong in 1.9.** "Canary probe child process exited with code 1": CuPy 14 checks its libraries by starting a small Python process of its own, the "canary" probe. 1.9's fix only applied inside NBTV SDR itself. The probe process still found the GNU Radio `cuda` package first and failed in the same way.

**The fix.** NBTV SDR now puts a small `cuda` package of its own first on the path, in `~/.cache/nbtv_cuda_shim`. That package points `cuda` at NVIDIA's folders. It does this for NBTV SDR and, through PYTHONPATH, for every process NBTV SDR starts, so CuPy's probe gets it too. Nothing of yours is moved or changed.

**Checking it.** `--gpu-check` now also shows where a child process finds `cuda`. It should be the NVIDIA folder, not the GNU Radio one.

## New in 1.9 — the GPU and a GNU Radio package called "cuda"

**What `--gpu-check` showed.** CuPy (cupy-cuda12x 14.2) is fine. CuPy 14 imports NVIDIA's `cuda` package (`cuda.pathfinder`), but there is another package called `cuda` in `/usr/local/lib/python3.12/dist-packages/cuda`. It is a GNU Radio block (`gpu_kernel`), and Python picks it over NVIDIA's wherever it sits.

That block imports GNU Radio, which Ubuntu builds for NumPy 1.x. NumPy 2.5.4 in `~/.local` then stops GNU Radio from loading, so CuPy failed with "initialization failed".

**The fix.** Before NBTV SDR loads CuPy, it now makes `cuda` mean NVIDIA's package, for this program only. The other package is left where it is, and it is only set aside inside NBTV SDR. `--gpu-check` says when it has done this.

If CuPy still stops, the GPU line and `--gpu-check` give the next reason. Now that the error names the GNU Radio package, the message says that rather than suggesting a CuPy update.

## New in 1.8 — finding out why the GPU won't load

- **A clearer reason when CuPy won't load.** The GPU line used to show only CuPy's last words (for example just "initialization failed"). Now it gives:
  - the line that actually says why
  - the CuPy, NumPy and Python versions in use
  - the likely fix

  The usual cause of "initialization failed" is a CuPy built for NumPy 1.x running under NumPy 2.x. The fix for that is to update CuPy for that same Python: `/usr/bin/python3 -m pip install -U cupy-cuda12x`, or `cupy-cuda11x` to match your CUDA.
- **`python3 nbtv_sdr.py --gpu-check`** prints everything in one go:
  - Python and where it is
  - the NumPy version
  - the CuPy package and version
  - the card and driver, and the CUDA version from `nvidia-smi`
  - a test on the card, or CuPy's full error

## New in 1.7 — no more bursts of noise on the RX spectrum

**The cause.** After TX or a loop back test, with nothing coming in, the receiver could fall behind what the card or HackRF was delivering, and stay behind.

- While behind, it was working from samples already read in. In those frames no new hardware input reached the spectrum, so the spectrum and waterfall drew the received channel *after its AGC* instead.
- The AGC lifts bare noise up to the transmitter's level, so those frames showed as bursts of noise about 60–77 dB over the noise floor.

It was reproduced here, with a stand-in sound card looped back: 10–13 bursts in the 15 s after TX or after the loop back test, and none before.

**The fixes:**

- The 200 kHz spectrum and waterfall now draw only what comes in from the hardware, never the AGC'd channel.
- On receive, the hardware's input now sets the pace, as it already did for TX. A receiver that falls behind catches up at once instead of staying behind.
- Frames still in the pipeline from before a TX / RX / loop back switch are not drawn after it. TX rows are marked by their own frame, so they are never drawn as RX.

Same test after the fixes: no bursts after TX or after the loop back test.

## New in 1.6 — Windows version

NBTV SDR is now one program for Linux and Windows. **NBTV_SDR_Windows.zip** has the same files, plus `run_nbtv_sdr.bat`, `build_windows.bat` (makes `NBTV_SDR.exe` with the NBTV logo as its icon), `requirements.txt` and `README_Windows.txt`.

- **Windows sound devices.** Every card shows up once for each Windows sound system, so the I/Q devices are now listed with theirs, e.g. "Line (Realtek) [Windows WASAPI]". WASAPI is listed first; it opens in exclusive mode where the card allows, which gives the card's own 192 kHz. An older setting with a bare name picks whichever of its entries runs at 192 kHz.
- **Tools next to the program are found.** ffmpeg, hackrf_transfer, rtl_sdr and airspyhf_rx can sit in the program's folder, on Linux too.
- **`--list-devices`** prints the sound devices (and which can run at 192 kHz), the SDRs and the serial ports.
- **Windows fonts and display.** It uses Segoe UI and Consolas, and stays sharp on high-DPI screens.
- **The Windows version has not been tried on a real Windows PC yet.** The way the sound devices are named and picked was tested here, against stand-in Windows sound devices.

## New in 1.5

- **Software loop back:** a new tick box to the right of the cable Loop back test (Encode and TX).
  - The transmitter goes straight into the receiver inside the program. No sound card, SDR or radio is used, and the radio stays on RX.
  - Use it to check the codec and modem on their own, with any Hardware setting.
  - The status reads SOFTWARE LOOP, and the RX input line says "software loop back".
  - TX is locked out while it is on. Only one loop runs at a time, so ticking either loop box clears the other.

## New in 1.4

- **More SDR hardware for HF.** The Hardware list is now a drop-down with seven choices:

  | Hardware | TX | Tunes | Through |
  |---|---|---|---|
  | None | – | – | – |
  | ExSDR radio | yes | 0.36 – 65 MHz | serial port + 192 kHz sound card |
  | HackRF | yes | 1 MHz – 6 GHz | hackrf_transfer, 2 Msps |
  | RTL-SDR (V3 / V4) | receive only | 0.5 MHz – 1.7 GHz | rtl_sdr, 2 Msps (V4 built-in HF, V3 direct sampling, or a 125 MHz upconverter) |
  | Airspy HF+ / Discovery | receive only | 0.5 – 260 MHz | airspyhf_rx, 192 kHz |
  | SDRplay RSP | receive only | 1 MHz – 2 GHz | SoapySDR (SoapySDRPlay3), 2 Msps |
  | SoapySDR (other, e.g. LimeSDR) | yes, where the radio can | 1 MHz – 6 GHz | SoapySDR, 2 Msps |

  - Radio / I/Q setup now has one tab for each kind of hardware, with its own settings. The 2 Msps SDRs are set the LO offset below the channel, so their DC spike stays out of it.
  - With a receive-only SDR, the TX button says so and stays on receive.
  - Tested here: the RTL-SDR and Airspy HF+ input paths, against stand-in tools giving a known tone; it came out at the right frequency and level. The SoapySDR path could not be tested here (no SoapySDR module).
- **TX drop-outs in the hardware loop back test.** Three changes:
  - While it is going out of real hardware (TX, or the loop back test), the program now works at the hardware's pace instead of the computer clock's. A frame that is late is made up at once, instead of the card running dry.
  - If the picture source isn't ready for a frame (a video file or stream falling behind), the last pictures go out again rather than leaving a gap.
  - If the output buffer does run dry, it starts again half full, not after a whole buffer of silence. The buffer is now 500 ms to start with.
  - Tested with a stand-in sound card looped back for 60 s: locked all the way, 50 dB C/N, no underruns.
- **RX information** under the audio meters now has one item per line (C/N and pilots, sound, clean-up, A/V, station) and room for eight lines, so it no longer gets cut off.
- **A rare upscaler error fixed:** on a completely flat picture (blank or black), the Super-res motion step could fail with "Singular matrix".
- **120x96 mode 2** is now named **240x192x12.5 KWMM** (it was "KWMM L"). The NBTV OFDM Lab gets the same name.

## New in 1.3

- **10 m channels:** buttons for Ch 1 to Ch 5 sit to the right of the frequency readout, as ExSDR has its band buttons. Each channel is 100 kHz wide, and together they fill 29.0 to 29.5 MHz:

  | Channel | Centre | Covers |
  |---|---|---|
  | Ch 1 | 29.050 MHz | 29.0 – 29.1 MHz |
  | Ch 2 | 29.150 MHz | 29.1 – 29.2 MHz |
  | Ch 3 | 29.250 MHz | 29.2 – 29.3 MHz |
  | Ch 4 | 29.350 MHz | 29.3 – 29.4 MHz |
  | Ch 5 | 29.450 MHz | 29.4 – 29.5 MHz |

  - A button jumps to that channel's centre and updates the frequency display. The ExSDR radio's LO is set there too.
  - The button for the channel you are on is lit. A dimmer light means you are inside that channel but off its centre.
- **Top bar and window title** show just the name and version.

## New in 1.2

- **Spectrum and waterfall in real time.** They used to jump once a data frame (about 4 times a second, 3 lines at a time). Now there is a spectrum line for every 50 ms of signal, and the window plays them out over the frame's own time: about 20 lines a second, the same in Loop back, receive and transmit.
- **Receiver's information line moved.** The RX information (C/N, pilots, sound, clean-up, callsign) is now under the Audio out (L / R) meters, at the bottom of Decoder and RX.
- **Frequency readout and signal meter line up on the left** with the Modem (TX and RX) settings.
- **NBTV logo** as the window's icon and in the top bar (`nbtv_logo.png`).
- **Help:** the Help button (top right) opens `NBTV_SDR_Help.txt`, a guide to every part of the window, the hardware setup, and what to check when something is wrong.

## New in 1.1

- **Centre layout:** the frequency readout and signal meter now sit centred under the spectrum, with the **Modem** settings full width below them, so they're no longer pushed off to the right.
- **Loop back test** (Encode and TX, under the TX button): checks the ExSDR radio's 192 kHz sound card with a cable from line out to line in.
  - The transmitter goes out of the card and back in, and the receiver decodes what comes back, as in the lab's Loop.
  - The radio is left on RX (no TX command), and TX is locked out while the test runs.
  - The HackRF can't do it, because it is half duplex.
- **Serial port:** Radio / I/Q setup has a drop-down of the serial ports it finds (`/dev/ttyUSB*`, `ttyACM*`, `/dev/serial/by-id/*`, `ttyS*`). **Refresh** looks again, and choosing one connects.
- **Setup button:** "Setup..." is now **Radio / I/Q setup...**.
  - The Sound devices window says these are the programme sound only, not the radio's I/Q, and has a button to Radio / I/Q setup.
  - **Loopback** under Sound in records the computer's own sound output as the programme sound. It is not the I/Q loop test.
- **GPU** has moved to the top bar, to the right of Multi-core.

## Running it

    python3 nbtv_sdr.py

Keep `nbtv_core.py`, `nbtv_radio.py`, `testcard_editor.py`, `testcards/`, `nbtv_logo.png` and `NBTV_SDR_Help.txt` in the same folder. It needs the same packages as the lab: python3, numpy and tkinter, and ideally Pillow and ffmpeg. For the sound card it needs sounddevice or ALSA `hw:` devices; for the HackRF it needs `hackrf_transfer` (`sudo apt install hackrf`).

Settings are kept in `~/.config/nbtv_sdr.json`, separate from the lab's own.

## The window

- **Encode and TX** (left)
  - **TX** goes on the air. Press it again to come back to receive. NBTV SDR is half duplex and always starts on receive.
  - **Hardware**: None, ExSDR radio or HackRF. **Setup...** opens the hardware window.
  - **TX level dBFS** sets the output level.
  - Below that are the picture source, sound and encoder mode, as in the lab.
- **On the air** (centre), the settings shared by TX and RX:
  - **Spectrum and waterfall, 200 kHz** across the top, laid out like ExSDR's.
    - On receive it shows what comes in from the hardware: the sound card's ±96 kHz, or 200 kHz out of the HackRF's 2 Msps.
    - On transmit it shows what goes out, in orange.
    - The channel's 100 kHz is shaded, and the yellow line marks its centre.
    - The kHz scale is the real frequency.
    - Click the spectrum to tune there. The mouse wheel over it tunes 1 kHz a click.
  - **Frequency** is the channel's centre, in Hz, like ExSDR's readout.
    - Use the wheel on a digit, or click its top half to go up and its bottom half to go down.
    - You can also type kHz into the box, or use the −1k / +1k buttons.
    - Right-click the readout to change its colour.
    - The line under it shows the radio's LO and where the channel sits.
  - **Signal meter** sits under the frequency.
    - It reads the channel's level coming in, in S units. S9 is set in Setup (−60 dBFS to start with).
    - Under it you get the lock state, C/N and the frequency error.
    - On transmit it shows TX and the output level.
  - **Modem**: guard, equaliser, long symbols, 16 pilots, frame rate, TX peaks, spread, Fold peaks, I/Q flip, Auto mode, mode word, callsign, sync, Resync and RX mute, all as in the lab.
  - The hardware status line, the vector scopes, the carriers and the sync display are also here.
- **Decoder and RX** (right) works as in the lab. Sound out is on to start with.
  - On transmit, the receiver monitors your own signal and is labelled MONITOR.

## Hardware

**ExSDR radio** is the homebrew HF SDR, the same one ExSDR uses.

- **Control** goes over its serial port, written the same way as ExSDR's:
  - 9600 baud 8N1, no terminator.
  - `F` (kHz), `TX` and `RX`, with the same gaps between commands (600 ms around a frequency command).
  - The window follows the radio's replies.
- **I/Q** goes through its 192 kHz sound card. Set Card output and Card input in Setup; ALSA `hw:C,D` goes past the mixers.
- **Tuning**: the radio's LO is in kHz.
  - The channel sits **Channel in card kHz** from it (0 to start with).
  - Tuning within ±20 kHz of that is done in the card's I/Q, so no command goes to the radio.
  - Past that, the LO is moved with one `F` command.
- **TX** sends `TX` to the radio, then the I/Q. Coming back, the I/Q stops first, then `RX` is sent.
- Card check, Release card and I/Q trim are as in the lab.

**HackRF** runs through `hackrf_transfer` at 2 Msps.

- It tunes 1 MHz to 6 GHz, with a 10-digit readout.
- The LO sits *LO offset* (250 kHz) below the frequency, so its DC spike stays out of the channel.
- Each new frequency restarts `hackrf_transfer`. That happens once you stop tuning for 0.4 s, not on every wheel click.
- TX and RX take turns, and each turn restarts it too.
- Gains and amps are set in Setup.

**None** gives no I/Q at all. The receiver hears nothing. On TX the signal is drawn and monitored here only.

## Not tested on real hardware yet

All of this was tested here with no sound card, HackRF or radio attached:

- **Radio control**: against a stand-in radio on a pseudo serial port. It got `?F ?P ?A`, `F29250`, `F29290`, `TX` and `RX` and its replies came back correctly.
- **Card input path**: a modem signal 12 kHz off centre was fed into the receive path at 192 kHz. It locked at 32 dB C/N, and the 200 kHz spectrum showed the channel centred.

First tries on the air should start with a low TX level.
