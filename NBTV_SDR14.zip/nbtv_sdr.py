#!/usr/bin/env python3
"""NBTV SDR - VE3XTV's NBTV system on the air: encode and transmit, receive and decode, in one window.
Made from the NBTV OFDM Lab (the same codec and modem, nbtv_core.py), with the lab's test parts taken out:
the simulated channel, the data frame monitor, real world path, clean channel, SNR sweep and sync test.

Hardware: VE3XTV's homebrew HF SDR (I/Q through a 192 kHz sound card, control over its serial port, as in
ExSDR), a HackRF (hackrf_transfer, 2 Msps), or none.  Half duplex: RX, and TX while TX is pressed.
By Grant Taylor VE3XTV.   Needs: python3, numpy, tkinter.  Better with: Pillow, ffmpeg (video, webcam).
"""
import re
import collections
import io
import glob
import json
import math
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, ttk

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nbtv_core as C  # noqa: E402
import nbtv_radio as R  # noqa: E402

try:
    from PIL import Image
except ImportError:                                       # pictures need Pillow; the test card does not
    Image = None

APP = "NBTV SDR"
VERSION = "1.14"
IS_WIN = sys.platform.startswith("win")
CFG_PATH = os.path.join(os.path.expanduser("~"), ".config", "nbtv_sdr.json")
HERE = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))   # (Windows .exe: its own folder)
HELP_FILE = os.path.join(HERE, "NBTV_SDR_Help.txt")
BG, CARD, FG, MUTED, ACC, FIELD, BORDER = "#1e2227", "#262b31", "#d7dde3", "#8a93a0", "#4fa3ff", "#14181c", "#3a414a"
DISPLAY = "#0b0f13"
SCOPE = 128                                                    # the vector scopes (pixels square)
CC_NAMES = {"1/4": "1/4 range (CPU1)", "3/4": "3/4 range", "BT.601": "BT.601"}
MON_W = 720                       # the data frame monitor: 720 columns x 48 rows, column by column
SANS = "Segoe UI" if sys.platform.startswith("win") else "DejaVu Sans"           # (Windows: its own fonts)
MONO = "Consolas" if sys.platform.startswith("win") else "DejaVu Sans Mono"
F = (SANS, 9)
F_SMALL = (SANS, 8)
F_HEAD = (SANS, 10, "bold")

DEFAULTS = dict(mode="120x96", source="Test card", picture="", video="", webcam="/dev/video0" if not IS_WIN else "video=",
                screen="", screen_x=12, screen_y=80, stream_url="", stream_urls=[], sound_in="Source", sound_dev="", sound_gain=0.0, sound_out_dev="", volume=0.0,
                aspect="4:3", snr=30.0, noise=1, cfo=0.0, delay=0, echo_delay=0, echo_db=-20.0, ppm=0.0,
                cp=0, eq="taps", timing="auto", manual=0, interleave=1, realtime=1, multicore=1, long_sym=0, pilots16=0, upscale="Super-res", lip_ms=0, audio_nr="Auto", fps25=1, ctrack=1, tnr="Auto", clip="Off", peak_tx=0, scramble=1, tx_path="2x IFFT", emph="75 us", compander="Off", audio16=1, gpu=0, fixed_fps=0, stereo="Sum/diff", ms_split="Auto", auto_rx=0, tx_word=1, tx_on=1, ti=0, iqflip=0, vemph=1, audio_mode="Stereo", common="Auto", listen="Both", rx_mute=1, spread="Off", hw_freq=29.25, hw_lo_off=250, hw_txvga=20, hw_txamp=0, hw_lna=16, hw_vga=20, hw_rxamp=0, hw_rx_trim=0.0, hw_trim=1, hw_skew=0.0, hw_qgain=0.0, hw_mode="Off", hw_out="Default", hw_in="Default", hw_level=-18, hw_buf=300, hw_offset=0, hw_swap=0, hw_sim=0, callsign="", tx_stamp=0, grid="", title="", colour_coding="BT.601",
                bright=0.0, contrast=1.0, colour=1.0, sharp=0.0, ycol=1, key_only=0, kmx=3, wl=16.0, audio_out=0, enc=4, rf_speed=4, mon="Received", mon_scale=1,
                soft=1, msearch=1, detail="dct", fuzzy_c=1, fuzzy_p=1, median_c=0, cavg=0.0, auto_f=0, snap=1, fade="Off", doppler=1.0, imp_rate=0.0, imp_db=10.0, pn_hz=0.0, iq_gain=0.0, iq_phase=0.0, dc_db=-60.0,
                sync="lab", qsb_db=0.0, qsb_hz=0.2, rf_db=0.0, rx_agc="Fixed", rx_gain=0.0, adc=0)
DEFAULTS.update(R.RADIO_DEFAULTS)
DEFAULTS.update(hardware="None", hackrf_dev="", card_out="Default", card_in="Default", tune_hz=29250000,
                lo_khz=29250, card_off_khz=0.0, s9_dbfs=-60.0, digit_colour="Amber", wf_rng=70.0, ptt=0, sdr=1,
                audio_out=1, loop_test=0, sw_loop=0, radio_pre=0, radio_att=0, hw_buf=500, rtl_index=0, rtl_gain=30.0, rtl_ppm=0, rtl_hf="V4 / built-in HF",
                airspy_lna=0, airspy_agc=1, airspy_att=0, airspy_serial="", sdr_args="", soapy_gain=30.0, soapy_ant="")
HARDWARE = ("None", "ExSDR radio", "HackRF", "RTL-SDR", "Airspy HF+", "SDRplay", "SoapySDR")
RX_ONLY = ("RTL-SDR", "Airspy HF+", "SDRplay")         # (receive only: no TX)
SDRS = ("HackRF", "RTL-SDR", "Airspy HF+", "SDRplay", "SoapySDR")   # (tuned in the SDR itself, not by a radio)
# what each can tune (Hz)
HW_RANGE = {"ExSDR radio": (R.FMIN_KHZ * 1000 + 60000, R.FMAX_KHZ * 1000), "HackRF": (1000000, 6000000000),
            "RTL-SDR": (500000, 1766000000), "Airspy HF+": (500000, 260000000), "SDRplay": (1000000, 2000000000),
            "SoapySDR": (1000000, 6000000000), "None": (100000, 99999999)}
# the 10 m NBTV channels: five of 100 kHz between 29.0 and 29.5 MHz (their centres)
CHANNELS_10M = tuple(("Ch %d" % (k + 1), 29000000 + 50000 + 100000 * k) for k in range(5))
# the 6 m NBTV channels: ten of 100 kHz between 51.0 and 52.0 MHz (their centres)
CHANNELS_6M = tuple(("Ch %d" % (k + 1), 51000000 + 50000 + 100000 * k) for k in range(10))
DIGIT_COLOURS = {"Amber": "#f4c96b", "Green": "#72e08a", "Cyan": "#6fd6ff", "White": "#e8e8e8"}
REAL_WORLD = (("doppler", 1.0), ("imp_rate", 0.0), ("imp_db", 10.0), ("pn_hz", 0.0), ("iq_gain", 0.0), ("iq_phase", 0.0),
              ("dc_db", -60.0), ("qsb_db", 0.0), ("rf_db", 0.0))


def pictures_dir():
    for d in (os.path.join(os.path.expanduser("~"), "Pictures"), os.path.expanduser("~")):
        if os.path.isdir(d):
            return d
    return os.getcwd()


def videos_dir():
    d = os.path.join(os.path.expanduser("~"), "Videos")
    return d if os.path.isdir(d) else pictures_dir()


# Always so in VE3XTV's system, so fixed here (and not sent in the mode word): interleave on, 75 us
# emphasis, BT.601 colour, the 240x192 detail as DCT.  The compander is Off or Syllabic.
FIXED = dict(interleave=1, emph="75 us", colour_coding="BT.601", detail="dct",
             scramble=1, timing="auto", manual=0)          # (5.30: Scramble always on, timing always Auto)
# NBTV SDR: no simulated channel (what goes out is what the receiver monitors while transmitting), real time
SDR_FIXED = dict(noise=0, snr=40.0, cfo=0.0, delay=0, echo_delay=0, echo_db=-40.0, ppm=0.0, fade="Off", hw_sim=0,
                 adc=0, rx_agc="Fixed", rx_gain=0.0, realtime=1, sdr=1, doppler=1.0, imp_rate=0.0, imp_db=10.0,
                 pn_hz=0.0, iq_gain=0.0, iq_phase=0.0, dc_db=-60.0, qsb_db=0.0, rf_db=0.0,
                 vemph=1)                                  # (video emphasis: always on in NBTV SDR, 1.14)
SDR_NOT = {C.KWDM: C.KWD, C.KMS: 4}                         # lab-only 120x96 modes 5, 6 -> what NBTV SDR sends instead


def sdr_enc_list(m):
    """The encoder modes NBTV SDR offers (the lab's experimental 120x96 modes 5 and 6 left out; a signal in
    them is still decoded)."""
    return [e for e in C.enc_list(m) if e not in SDR_NOT]


def load_cfg():
    c = dict(DEFAULTS)
    try:
        with open(CFG_PATH) as f:
            c.update(json.load(f))
    except Exception:
        pass
    c.update(FIXED)
    c.update(SDR_FIXED)
    if c.get("mode") not in C.MODES:                      # (a format that is gone: back to 120x96)
        c["mode"] = "120x96"
    c["compander"] = C.compander_name(c.get("compander", "Off"))
    c["pilots16"] = 1 if c.get("pilots16", 0) else 0     # (5.13's Scattered (2) is gone: 16 pilots kept)
    c["ptt"] = 0                                          # (always starts on receive)
    c["loop_test"] = 0
    c["sw_loop"] = 0
    c["tx_on"] = 0
    c["hw_mode"] = "Off"                                  # (set from the hardware once the window is up)
    return c


def save_cfg(c):
    try:
        os.makedirs(os.path.dirname(CFG_PATH), exist_ok=True)
        with open(CFG_PATH, "w") as f:
            json.dump(c, f, indent=1)
    except Exception:
        pass


def list_ports():
    """Serial ports for the radio: USB ones first, then the built-in, then by-id names."""
    if IS_WIN or R.termios is None:
        try:
            from serial.tools import list_ports as lp
            return [p.device for p in sorted(lp.comports(), key=lambda p: p.device)]
        except Exception:
            return ["COM%d" % i for i in range(1, 10)]
    ports = []
    for pat in ("/dev/ttyUSB*", "/dev/ttyACM*", "/dev/serial/by-id/*", "/dev/ttyS[0-9]*"):
        ports += sorted(glob.glob(pat))
    return ports


def _mix(a, b, t):
    """Colour a, a share t of the way to colour b."""
    ca = [int(a[i:i + 2], 16) for i in (1, 3, 5)]
    cb = [int(b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(round(x + (y - x) * t)) for x, y in zip(ca, cb))


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


# ======================================================================= pictures and sound in
FONT5 = {  # 5 x 7 dots for the test card caption
    "0": "01110100011001110101110011000101110", "1": "00100011000010000100001000010001110",
    "2": "01110100010000100010001000100011111", "3": "11111000100010000010000011000101110",
    "4": "00010001100101010010111110001000010", "5": "11111100001111000001000011000101110",
    "6": "00110010001000011110100011000101110", "7": "11111000010001000100010000100001000",
    "8": "01110100011000101110100011000101110", "9": "01110100011000101111000010001001100",
    ":": "00000011000110000000011000110000000", " ": "0" * 35,
    "N": "10001110011010110011100011000110001", "B": "11110100011000111110100011000111110",
    "T": "11111001000010000100001000010000100", "V": "10001100011000110001100010101000100",
    "L": "10000100001000010000100001000011111", "A": "01110100011000111111100011000110001",
    "E": "11111100001000011110100001000011111", "X": "10001100010101000100010101000110001",
    "O": "01110100011000110001100011000101110", "F": "11111100001000011110100001000010000",
    "D": "11110100011000110001100011000111110", "M": "10001110111010110101100011000110001",
}


def draw_text(img, text, x, y, scale, col):
    for ch in text:
        pat = FONT5.get(ch)
        if pat:
            for i, b in enumerate(pat):
                if b == "1":
                    r, c = divmod(i, 5)
                    img[y + r * scale:y + (r + 1) * scale, x + c * scale:x + (c + 1) * scale] = col
        x += 6 * scale
    return img


def test_card(w, h, t):
    """A moving test card: colour bars, a grey scale, a sweeping bar and a clock (w x h RGB)."""
    img = np.zeros((h, w, 3), np.uint8)
    bars = [(255, 255, 255), (255, 255, 0), (0, 255, 255), (0, 255, 0), (255, 0, 255), (255, 0, 0), (0, 0, 255), (0, 0, 0)]
    bh = h * 3 // 8
    for i, c in enumerate(bars):
        img[:bh, i * w // 8:(i + 1) * w // 8] = c
    for i in range(8):                                    # grey scale
        img[bh:bh + h // 8, i * w // 8:(i + 1) * w // 8] = int(i * 255 / 7)
    y0 = bh + h // 8
    yy, xx = np.mgrid[y0:h, 0:w]
    img[y0:h] = np.stack((40 + 30 * np.sin(xx / 7.0), 50 + 0 * xx, 90 + 0 * xx), -1).astype(np.uint8)
    px = int((t * 40) % (w + 20)) - 10                     # a bar moving across: shows the motion frames
    img[y0:h, max(0, px):max(0, min(w, px + 6))] = (255, 220, 60)
    r = max(3, min((h - y0) // 2 - 3, w // 8))
    cx, cy = w - r - 4, y0 + (h - y0) // 2
    a = t * 2 * math.pi / 4.0                             # a hand going round every 4 s
    for k in range(r):
        img[int(cy - k * math.cos(a)), int(cx + k * math.sin(a))] = (255, 255, 255)
    if (t % 1.0) < 0.1:                                  # a flash each second, with the sound's click
        fs = max(4, r // 2)
        img[cy - fs:cy + fs, max(0, cx - r - 2 * fs - 2):max(0, cx - r - 2)] = (255, 255, 255)
    s = time.strftime("%H:%M:%S")
    sc = max(1, w // 60)
    draw_text(img, "NBTV", 4, y0 + 4, sc, (255, 255, 255))
    draw_text(img, s, 4, h - 2 - 8 * max(1, sc // 2), max(1, sc // 2), (230, 230, 230))
    return img


def crop_aspect(img, aspect):
    """Crop a picture to 4:3 or 16:9 (the shape the NBTV picture shows)."""
    A = 4 / 3.0 if aspect == "4:3" else 16 / 9.0
    h, w = img.shape[:2]
    if w > h * A:
        nw = int(h * A)
        x = (w - nw) // 2
        return img[:, x:x + nw]
    nh = int(w / A)
    y = (h - nh) // 2
    return img[y:y + nh]


def resize(img, w, h, smooth=True):
    if Image is not None:
        return np.asarray(Image.fromarray(img).resize((w, h), Image.BILINEAR if smooth else Image.NEAREST))
    ys = (np.arange(h) * img.shape[0] / h).astype(int)
    xs = (np.arange(w) * img.shape[1] / w).astype(int)
    return img[ys][:, xs]


SOUND_INS = ("Source", "Sound card", "Loopback")
APP_NAME = "NBTV OFDM Lab"                               # what the sound mixer calls our streams
MIXER_DEFAULT = "default (PulseAudio mixer)"
# Screen, as VE3XTV's TX: a 240x192 (4:3) or 342x192 (16:9) area one-to-one from near the top left of
# the screen, its corner set by X (0-200) and Y (0-160) sliders.  The whole block the sliders can
# reach is grabbed, and the area cut from it, so the sliders move it at once.
SCREEN_X_MAX, SCREEN_Y_MAX = 200, 160
SCREEN_AREA = {"4:3": (240, 192), "16:9": (342, 192)}
SCREEN_GRAB = (SCREEN_X_MAX + 342, SCREEN_Y_MAX + 192)


def screen_input(display, area):
    """ffmpeg's input for the screen (and a crop, where the platform cannot grab an area itself).
    display: Linux ':0.0' (blank: $DISPLAY), Windows 'desktop', macOS 'Capture screen 0' or its number;
    area: 'x,y,w,h' or blank for the whole screen."""
    box = None
    try:
        if area.strip():
            box = [int(float(v)) for v in area.replace(" ", "").split(",")][:4]
            if len(box) != 4 or box[2] < 16 or box[3] < 16:
                box = None
    except Exception:
        box = None
    if IS_WIN:
        a = ["-f", "gdigrab", "-framerate", "25"]
        if box:
            a += ["-offset_x", str(box[0]), "-offset_y", str(box[1]), "-video_size", "%dx%d" % (box[2], box[3])]
        return a + ["-i", display or "desktop"], None
    if sys.platform == "darwin":
        dev = display or "Capture screen 0"
        return (["-f", "avfoundation", "-framerate", "25", "-capture_cursor", "1", "-i", dev + ":none"],
                ("crop=%d:%d:%d:%d" % (box[2], box[3], box[0], box[1])) if box else None)
    disp = display or os.environ.get("DISPLAY", ":0.0")
    a = ["-f", "x11grab", "-framerate", "25", "-draw_mouse", "1"]
    if box:
        a += ["-video_size", "%dx%d" % (box[2], box[3])]
        disp += "+%d,%d" % (box[0], box[1])
    return a + ["-i", disp], None


def default_monitor():
    """PulseAudio / PipeWire: the default output's monitor - what the PC is playing."""
    try:
        out = subprocess.run(["pactl", "get-default-sink"], capture_output=True, text=True, timeout=3).stdout.strip()
        if out:
            return out + ".monitor"
    except Exception:
        pass
    try:                                                 # older pactl
        info = subprocess.run(["pactl", "info"], capture_output=True, text=True, timeout=3).stdout
        for line in info.splitlines():
            if line.startswith("Default Sink:"):
                return line.split(":", 1)[1].strip() + ".monitor"
    except Exception:
        pass
    return "default.monitor"


def sound_input(kind, dev):
    """ffmpeg's input for live sound: the sound card's input, or a loopback of what the PC plays.
    Linux: PulseAudio / PipeWire (a source name, or blank: the default, or the default output's monitor);
    'alsa:hw:Loopback,1' for ALSA.  Windows: a DirectShow audio device ('Stereo Mix' for loopback).
    macOS: an AVFoundation audio device (BlackHole or similar for loopback)."""
    dev = (dev or "").strip()
    if IS_WIN:
        if not dev:
            dev = "Stereo Mix" if kind == "Loopback" else ""
        return ["-f", "dshow", "-i", "audio=" + dev] if dev else None
    if sys.platform == "darwin":
        return ["-f", "avfoundation", "-i", ":" + (dev or "0")]
    if dev.startswith("alsa:"):
        return ["-f", "alsa", "-i", dev[5:] or "default"]
    name = ["-f", "pulse", "-name", APP_NAME, "-stream_name", "Sound in"]   # (so the mixer shows it by name)
    if dev == "default":                                 # PulseAudio's default: the mixer (pavucontrol,
        return name + ["-i", "default"]                  #  Recording tab) says which input it is
    if kind == "Loopback":
        return name + ["-i", dev or default_monitor()]
    return name + ["-i", dev or "default"]


_SHARED = None


def shared_alsa_device():
    """The ALSA device that goes through the desktop sound server, as ExSDR offers them: 'pipewire',
    else 'pulse' (whichever arecord -L lists), else 'default'."""
    global _SHARED
    if _SHARED is None:
        _SHARED = "default"
        try:
            big = subprocess.run(["arecord", "-L"], capture_output=True, text=True, timeout=3).stdout
            top = set(l.strip() for l in big.splitlines() if l and not l[0].isspace())
            for v in ("pipewire", "pulse"):
                if v in top:
                    _SHARED = v
                    break
        except Exception:
            pass
    return _SHARED


def live_sound_cmd(kind, dev, rate):
    """The command that gives live sound as 16 bit stereo at 'rate' on its stdout, its environment,
    and a description.  Linux:
      - through the desktop sound server, so the mixer (pavucontrol, Recording tab) shows the stream as
        'NBTV OFDM Lab' and can route it: parec (PulseAudio's own recorder, also on PipeWire) where it
        is installed, else arecord on ALSA's 'pipewire' / 'pulse' device, as ExSDR does;
      - Loopback (blank): the default output's monitor; a '.monitor' name: that monitor;
      - hw: / plughw: names: arecord straight from the card (not through the mixer).
    Windows / macOS: ffmpeg."""
    dev = (dev or "").strip()
    if dev == MIXER_DEFAULT:
        dev = "default"
    env = dict(os.environ)
    env["PULSE_PROP"] = "application.name='%s' media.name='Sound in'" % APP_NAME
    if not IS_WIN and sys.platform != "darwin" and not dev.startswith("ffmpeg:"):
        if dev.startswith("alsa:"):
            dev = dev[5:]
        direct = dev.startswith(("hw:", "plughw:", "sysdefault", "dsnoop"))
        if not direct:
            # through the sound server
            src = None                                   # None: the server's default input
            if dev.endswith(".monitor") or (dev and dev not in ("default", "pulse", "pipewire")):
                src = dev
            elif kind == "Loopback" and dev == "":
                src = default_monitor()
            if shutil.which("parec"):
                cmd = ["parec", "--format=s16le", "--rate=%d" % rate, "--channels=2", "--latency-msec=50",
                       "--client-name=%s" % APP_NAME, "--stream-name=Sound in"] + (["--device=" + src] if src else [])
                return cmd, env, "parec" + (" --device=%s" % src if src else " (the mixer's input)")
            if shutil.which("arecord"):
                adev = "pulse" if src else (dev if dev in ("pulse", "pipewire") else shared_alsa_device())
                if src:
                    env["PULSE_SOURCE"] = src
                cmd = ["arecord", "-q", "-D", adev, "-t", "raw", "-f", "S16_LE", "-c", "2", "-r", str(rate),
                       "--buffer-time=100000"]
                return cmd, env, "arecord -D %s" % adev + (" (PULSE_SOURCE %s)" % src if src else "")
        elif shutil.which("arecord"):                     # a card, directly
            cmd = ["arecord", "-q", "-D", dev, "-t", "raw", "-f", "S16_LE", "-c", "2", "-r", str(rate),
                   "--buffer-time=100000"]
            return cmd, env, "arecord -D %s (the card itself, not through the mixer)" % dev
    ff = shutil.which("ffmpeg")
    ain = sound_input(kind, dev[7:] if dev.startswith("ffmpeg:") else dev)
    if not ff or ain is None:
        return None, env, ""
    return ([ff, "-hide_banner", "-loglevel", "error", "-nostdin"] + ain +
            ["-vn", "-f", "s16le", "-ac", "2", "-ar", str(rate), "-"], env, "ffmpeg " + " ".join(ain[1:]))


def sound_in_test(kind, dev, rate=24000):
    """Record 1 s the way the lab will, and say what came (or the error), as ExSDR's device test."""
    cmd, env, what = live_sound_cmd(kind, dev, rate)
    if cmd is None:
        return "FAILED: no way to record (needs parec or arecord, or ffmpeg)"
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        b = b""
        t0 = time.time()
        while len(b) < rate * 4 and time.time() - t0 < 3.0:
            d = p.stdout.read(4800)
            if not d:
                break
            b += d
        p.kill()
        try:
            err = (p.communicate(timeout=1.5)[1] or b"").decode("utf8", "ignore").strip()
        except Exception:
            err = ""
    except Exception as e:
        return "FAILED: %s (%s)" % (e, what)
    if len(b) < rate:
        return "FAILED: %s (%s)" % (err.splitlines()[-1] if err else "no sound came", what)
    a = np.frombuffer(b[:len(b) // 4 * 4], "<i2").astype(float) / 32768.0
    a = a - a.mean()
    pk = float(np.max(np.abs(a)))
    rms = 20 * math.log10(math.sqrt(float(np.mean(a * a))) + 1e-9)
    return "OK - %s: 1 s, peak %d %%, %.1f dBFS%s" % (what, round(100 * pk), rms,
                                                    "  (silence: is anything playing / is the input right?)" if pk < 0.002 else "")


def list_sound_inputs():
    """Names of the sound inputs ffmpeg can open (best effort)."""
    names = []
    try:
        if IS_WIN or sys.platform == "darwin":
            ff = shutil.which("ffmpeg")
            args = ([ff, "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"] if IS_WIN else
                    [ff, "-hide_banner", "-f", "avfoundation", "-list_devices", "true", "-i", ""])
            err = subprocess.run(args, capture_output=True, text=True, timeout=8).stderr
            audio = False
            for line in err.splitlines():
                if "audio devices" in line.lower():
                    audio = True
                    continue
                if IS_WIN and '"' in line and "(audio)" in line:
                    names.append(line.split('"')[1])
                elif not IS_WIN and audio and "] [" in line:
                    names.append(line.split("] [", 1)[1].split("]", 1)[0])
        else:
            names = [MIXER_DEFAULT]
            try:
                big = subprocess.run(["arecord", "-L"], capture_output=True, text=True, timeout=3).stdout
                top = [l.strip() for l in big.splitlines() if l and not l[0].isspace()]
                names += [v for v in ("pulse", "pipewire") if v in top]
                txt = subprocess.run(["arecord", "-l"], capture_output=True, text=True, timeout=3).stdout
                import re
                for m in re.finditer(r"card (\d+): (\S+) \[(.*?)\], device (\d+):", txt):
                    names.append("plughw:CARD=%s,DEV=%s" % (m.group(2), m.group(4)))
            except Exception:
                pass
            try:                                         # the server's sources: monitors are loopbacks
                out = subprocess.run(["pactl", "list", "short", "sources"], capture_output=True, text=True, timeout=3).stdout
                names += [l.split("\t")[1] for l in out.splitlines() if "\t" in l]
            except Exception:
                pass
    except Exception:
        pass
    return names


def list_sound_outputs():
    """Names of the sound outputs (sounddevice, where installed)."""
    try:
        import sounddevice as sd
        return [d["name"] for d in sd.query_devices() if d.get("max_output_channels", 0) >= 2]
    except Exception:
        return []


class _PipeProc:
    """A sound pipe with the stdout / stderr a process has (for _live_reader)."""

    def __init__(self, f):
        self.stdout = f
        self.stderr = io.BytesIO()


def fmt_time(t):
    """Seconds as m:ss (or h:mm:ss)."""
    t = int(max(0, t))
    return "%d:%02d:%02d" % (t // 3600, t // 60 % 60, t % 60) if t >= 3600 else "%d:%02d" % (t // 60, t % 60)


class Source:
    """Pictures (three per data frame) and sound (24 kHz U8 stereo) for the encoder."""

    def __init__(self, log):
        self.log = log
        self.kind = "Test card"
        self.mode = C.MODES["120x96"]
        self.aspect = "4:3"
        self.still = None
        self.vproc = self.aproc = None
        self.path = ""
        self.paused = False
        self.t = 0.0
        self.latest = None                                # webcam, screen: the newest picture
        self.liveq = collections.deque()                  # ... and the ones not yet sent, in order
        self.lock = threading.Lock()
        self.last = None
        self.gen = 0
        self.sound_in, self.sound_dev = "Source", ""      # live sound: "Sound card" or "Loopback"
        self.sound_gain = 1.0
        self.scr_x, self.scr_y = 12, 80                    # Screen: the area's top left corner
        self.lproc = None
        self.lbuf = bytearray()
        self.lunder = 0

    def ffmpeg(self):
        return shutil.which("ffmpeg")

    def close(self):
        self.gen += 1
        for p in (self.vproc, self.aproc, self.lproc):
            if p is not None:
                try:
                    p.kill()
                except Exception:
                    pass
        self.vproc = self.aproc = self.lproc = None
        with self.lock:
            self.lbuf = bytearray()
            self.liveq.clear()
            self.latest = None

    def set(self, kind, path, mode, aspect, enc=2, frame_time=None):
        self.close()
        self.kind, self.path, self.mode, self.aspect = kind, path, mode, aspect
        self.enc = enc
        self.w, self.h = C.pic_size(mode, enc)
        self.n = C.pics_per_frame(enc)
        self.frame_time = frame_time or mode.period
        self.fps = self.n / self.frame_time
        self.aclk = C.AudioClock(self.frame_time)          # sound samples per frame, by air time
        self.t, self.ak = 0.0, 0                           # the test card's picture and sound together
        self.arsm = None                                   # (the guard's rate change, made on first use)
        self.a_taken = 0                                   # sound and pictures taken so far (for the
        self.p_taken = 0                                   #  TX's own sync check)
        self.still = None
        self.paused = False
        self.seek_base, self.pos_n = 0.0, 0              # position: where it started + pictures since
        self.duration, self.live = None, None            # (from ffprobe, in the background)
        self.src_id = getattr(self, "src_id", 0) + 1     # (this source: a probe's answer for an older one is dropped)
        if kind in ("Video file", "Stream URL") and path:
            threading.Thread(target=self._probe, args=(self.src_id, path), daemon=True).start()
        if kind == "Picture" and path:
            if Image is None:
                self.log("Pictures need Pillow (pip install pillow) - showing the test card")
                self.kind = "Test card"
            else:
                try:
                    im = np.asarray(Image.open(path).convert("RGB"))
                    self.still = resize(crop_aspect(im, aspect), self.w, self.h)
                except Exception as e:
                    self.log("Cannot read %s: %s" % (path, e))
                    self.kind = "Test card"
        elif kind == "Stream URL":
            if not self.ffmpeg():
                self.log("Stream URLs need ffmpeg - showing the test card")
                self.kind = "Test card"
            elif not path:
                self.log("Stream URL: paste a link first (Load...)")
                self.kind = "Test card"
            else:
                self.start_stream()
        elif kind in ("Video file", "Webcam", "Screen"):
            if not self.ffmpeg():
                self.log("Video, webcam and screen need ffmpeg - showing the test card")
                self.kind = "Test card"
            else:
                self.start_ffmpeg()
        if self.sound_in != "Source":
            self.start_live_sound()

    def start_stream(self):
        """An IPTV / network stream (http(s), .m3u8 HLS, rtsp, rtmp, udp, ...): one ffmpeg reads it,
        paced at its own rate (-re), the pictures to its stdout and, on Linux / macOS, the sound to a
        second pipe from the same connection (many IPTV servers allow only one) so the two stay
        together.  A stream that stops is opened again after a few seconds."""
        ff = self.ffmpeg()
        self.gen += 1
        gen = self.gen
        url = self.path.strip()
        pre = ["-hide_banner", "-loglevel", "error", "-nostdin"]
        if url.lower().startswith(("http://", "https://")):
            pre += ["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "5",
                    "-user_agent", "Mozilla/5.0 (X11; Linux x86_64) NBTV-OFDM-Lab"]
        elif url.lower().startswith("rtsp://"):
            pre += ["-rtsp_transport", "tcp"]
        if getattr(self, "seek_base", 0.0) > 0:          # (a recording / VOD stream: from where it was put)
            pre += ["-ss", "%.3f" % self.seek_base]
        pre += ["-re", "-i", url]
        vout = ["-map", "0:v:0", "-vf", self.vf(), "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"]
        want_sound = self.sound_in == "Source"
        rfd = wfd = None
        try:
            if want_sound and not IS_WIN:
                rfd, wfd = os.pipe()
                aout = ["-map", "0:a:0?", "-f", "s16le", "-ac", "2", "-ar", str(C.AUDIO_FS), "pipe:%d" % wfd]
                self.vproc = subprocess.Popen([ff] + pre + vout + aout, stdout=subprocess.PIPE,
                                              stderr=subprocess.PIPE, pass_fds=(wfd,))
                os.close(wfd)
                apipe = os.fdopen(rfd, "rb", buffering=0)
            else:
                self.vproc = subprocess.Popen([ff] + pre + vout, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                apipe = None
                if want_sound:                           # Windows: a second connection for the sound
                    self.aproc = subprocess.Popen([ff] + pre + ["-map", "0:a:0?", "-f", "s16le", "-ac", "2",
                                                               "-ar", str(C.AUDIO_FS), "-"],
                                                  stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                    apipe = self.aproc.stdout
        except Exception as e:
            self.log("Stream URL: %s" % e)
            for fd in (rfd, wfd):
                try:
                    if fd is not None:
                        os.close(fd)
                except Exception:
                    pass
            return
        self.stream_sound = apipe is not None
        self.live_bytes = 0
        self.log("Stream: %s" % url)
        if not want_sound:
            self.log("Stream: Sound in is %s, so the stream's own sound is not used - set Sound in to "
                     "Source to send it" % self.sound_in)
        threading.Thread(target=self._cam_reader, args=(gen,), daemon=True).start()
        if apipe is not None:
            threading.Thread(target=self._live_reader, args=(gen, _PipeProc(apipe)), daemon=True).start()
            threading.Thread(target=self._stream_sound_check, args=(gen, ff, pre), daemon=True).start()

    def _probe(self, sid, path):
        """The length of the file / stream (ffprobe, else ffmpeg -i): none = live, not seekable."""
        dur = None
        try:
            fp = shutil.which("ffprobe")
            if path.strip().lower().startswith(("udp://", "rtp://", "srt://", "tcp://")):
                fp = None                                 # (always live - and a second listener on the
                path = None                               #  same port would take the stream's packets)
            if path is None:
                pass
            elif fp:
                cmd = [fp, "-v", "error"] + (["-rw_timeout", "8000000"] if path.lower().startswith("http") else []) + \
                      ["-show_entries", "format=duration", "-of", "default=nw=1:nk=1", path]
                out = subprocess.run(cmd, capture_output=True, text=True, timeout=15).stdout.strip()
                try:
                    dur = float(out.splitlines()[0])
                except (ValueError, IndexError):
                    dur = None
            elif self.ffmpeg() and path:
                err = subprocess.run([self.ffmpeg(), "-hide_banner", "-i", path], capture_output=True, text=True,
                                     timeout=15).stderr
                m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", err)
                if m:
                    dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
        except Exception:
            dur = None
        if dur is not None and not (dur > 0.5 and dur < 1e7):
            dur = None
        if sid == self.src_id:
            self.duration = dur
            self.live = dur is None
            if self.kind == "Stream URL":
                self.log("Stream: %s" % ("live (no length) - the position bar shows the time running" if dur is None
                                         else "a recording, %s long - the position bar can move it" % fmt_time(dur)))

    def position(self):
        """-> (seconds, length or None, seekable) for a video file / stream; None for other sources."""
        if self.kind not in ("Video file", "Stream URL") or not self.fps:
            return None
        n = getattr(self, "pos_n", 0)
        if self.kind == "Stream URL":                     # (read but not sent yet: not counted)
            n -= len(self.liveq)
        t = self.seek_base + max(0, n) / float(self.fps)
        dur = self.duration
        if dur and self.kind == "Video file":
            t = t % dur                                   # (the file loops)
        elif dur:
            t = min(t, dur)
        return t, dur, bool(dur)

    def seek(self, t):
        """Play from t seconds (a video file, or a stream that has a length): the pictures and the
        sound start again there together."""
        if self.kind not in ("Video file", "Stream URL") or not self.duration:
            return
        t = max(0.0, min(float(t), self.duration - 0.5))
        self.gen += 1                                     # (the old readers stop, and don't 'try again')
        for p in (self.vproc, self.aproc):
            try:
                if p is not None:
                    p.kill()
            except Exception:
                pass
        self.vproc = self.aproc = None
        with self.lock:
            self.liveq.clear()
            self.lbuf = bytearray()
        self.seek_base, self.pos_n = t, 0
        if self.kind == "Video file":
            self.start_ffmpeg()
        else:
            self.start_stream()
        self.log("%s: from %s" % ("Video" if self.kind == "Video file" else "Stream", fmt_time(t)))

    def vf(self):
        A = "4/3" if self.aspect == "4:3" else "16/9"
        return ("crop='min(iw,ih*%s)':'min(ih,iw/(%s))',scale=%d:%d:flags=area,fps=%.6f"
                % (A, A, self.w, self.h, self.fps))

    def start_ffmpeg(self):
        ff = self.ffmpeg()
        self.gen += 1
        gen = self.gen
        pre = None
        if self.kind == "Webcam":
            dev = self.path or ("/dev/video0" if not IS_WIN else "video=")
            fmt = ["-f", "dshow"] if IS_WIN else ["-f", "avfoundation"] if sys.platform == "darwin" else ["-f", "v4l2"]
            vin = fmt + ["-i", dev]
        elif self.kind == "Screen":
            vin, pre = screen_input(self.path, "0,0,%d,%d" % SCREEN_GRAB)
            if (not IS_WIN and sys.platform != "darwin" and os.environ.get("XDG_SESSION_TYPE", "") == "wayland"):
                self.log("Screen: this is a Wayland desktop - x11grab sees only X11 (XWayland) windows; "
                         "log in to an X11 (Xorg) session to capture everything")
        else:
            ss = ["-ss", "%.3f" % self.seek_base] if getattr(self, "seek_base", 0.0) > 0 else []
            vin = ["-stream_loop", "-1"] + ss + ["-i", self.path]
        try:
            self.vproc = subprocess.Popen([ff, "-hide_banner", "-loglevel", "error", "-nostdin"] + vin +
                                          ["-an", "-vf", (pre + "," if pre else "") + (self.vf() if self.kind != "Screen" else
                                                                                    "fps=%.6f" % self.fps),
                                           "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                                          stdout=subprocess.PIPE, stderr=subprocess.PIPE if self.kind == "Screen" else subprocess.DEVNULL)
        except Exception as e:
            self.log("ffmpeg: %s" % e)
            self.kind = "Test card"
            return
        if self.kind == "Video file" and self.sound_in == "Source":
            try:
                self.aproc = subprocess.Popen([ff, "-hide_banner", "-loglevel", "error", "-nostdin", "-stream_loop", "-1"] + ss +
                                              ["-i", self.path, "-vn", "-f", "s16le", "-ac", "2", "-ar", str(C.AUDIO_FS), "-"],
                                              stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            except Exception:
                self.aproc = None
        elif self.kind != "Video file":                  # webcam, screen: keep only the newest picture
            threading.Thread(target=self._cam_reader, args=(gen,), daemon=True).start()

    def _stream_sound_check(self, gen, ff, pre):
        """If no sound has come on the shared connection a few seconds after the pictures did, open
        the sound on a connection of its own (some systems will not hand ffmpeg the second pipe);
        if that brings none either, say the stream has no sound."""
        t0 = time.time()
        while gen == self.gen and time.time() - t0 < 12:
            time.sleep(0.5)
            if getattr(self, "live_bytes", 0) > 0:
                return
            if self.latest is not None and time.time() - t0 > 5:
                break
        if gen != self.gen or getattr(self, "live_bytes", 0) > 0:
            return
        self.log("Stream: no sound on the shared connection - opening the sound on its own connection")
        try:
            self.aproc = subprocess.Popen([ff] + pre + ["-vn", "-map", "0:a:0?", "-f", "s16le", "-ac", "2",
                                                       "-ar", str(C.AUDIO_FS), "-"],
                                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception as e:
            self.log("Stream sound: %s" % e)
            return
        threading.Thread(target=self._live_reader, args=(gen, self.aproc), daemon=True).start()
        t1 = time.time()
        while gen == self.gen and time.time() - t1 < 8:
            time.sleep(0.5)
            if getattr(self, "live_bytes", 0) > 0:
                self.log("Stream: sound coming on its own connection")
                return
        if gen == self.gen:
            self.log("Stream: this stream has no sound (or ffmpeg cannot read it)")

    def _stream_again(self, gen):
        # a recording (it has a length) that came to its end: from the start again, as a video file
        # loops; a live stream that dropped, or a recording cut short: again from where it was
        pos = self.position()
        at_end = bool(self.duration) and pos is not None and pos[0] >= self.duration - 2.0
        time.sleep(1.0 if at_end else 4.0)
        if gen == self.gen and self.kind == "Stream URL":
            for p in (self.vproc, self.aproc):
                try:
                    if p is not None:
                        p.kill()
                except Exception:
                    pass
            if at_end:
                self.seek_base, self.pos_n = 0.0, 0
                self.log("Stream: the recording ended - from the start again")
            else:
                if self.duration and pos is not None:     # (cut short: carry on from there)
                    self.seek_base, self.pos_n = pos[0], 0
                self.log("Stream: trying again")
            self.start_stream()

    def start_live_sound(self):
        """Live sound from the sound card's input, or a loopback of what the PC plays, for any picture
        source: read as it comes (16 bit, 24 kHz stereo) into a short buffer the frames take from."""
        cmd, env, what = live_sound_cmd(self.sound_in, self.sound_dev, C.AUDIO_FS)
        if cmd is None:
            self.log("Sound in: needs arecord (Linux) or ffmpeg, and on Windows a device (Sound devices...)")
            return
        try:
            self.lproc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        except Exception as e:
            self.log("Sound in: %s" % e)
            return
        self.log("Sound in: %s (%s)" % (self.sound_in, what))
        threading.Thread(target=self._live_reader, args=(self.gen, self.lproc), daemon=True).start()

    def _live_reader(self, gen, p):
        cap = C.AUDIO_FS * 4 * 2                         # keep at most 2 s
        while gen == self.gen:
            d = p.stdout.read(4800)
            if not d:
                err = b""
                try:
                    err = p.stderr.read() or b""
                except Exception:
                    pass
                if gen == self.gen and self.kind != "Stream URL":    # (a stream says so itself)
                    self.log("Sound in stopped" + (": " + err.decode("utf-8", "replace").strip().splitlines()[-1]
                                                  if err.strip() else ""))
                break
            with self.lock:
                self.lbuf += d
                self.live_bytes = getattr(self, "live_bytes", 0) + len(d)
                if len(self.lbuf) > cap:
                    del self.lbuf[:len(self.lbuf) - cap]

    def _live_take(self, k):
        """k stereo samples of live sound; short of it, the rest is silence.  Kept within about half a
        second of the input, so the sound does not fall behind the pictures."""
        n = k * 4
        with self.lock:
            over = len(self.lbuf) - n - C.AUDIO_FS * 4 // 2
            if over > 0:
                del self.lbuf[:over - over % 4]
            b = bytes(self.lbuf[:n])
            del self.lbuf[:len(b)]
        if len(b) < n:
            self.lunder += 1
            b = b + b"\x00" * (n - len(b))
        x = np.frombuffer(b, "<i2").astype(np.float32) / 256.0
        if self.sound_gain != 1.0:
            x = np.clip(x * self.sound_gain, -128.0, 127.99)
        return x + 128.0

    def _read(self, proc, n):
        buf = b""
        while len(buf) < n:
            d = proc.stdout.read(n - len(buf))
            if not d:
                return None
            buf += d
        return buf

    def _cam_reader(self, gen):
        gw, gh = SCREEN_GRAB if self.kind == "Screen" else (self.w, self.h)
        n = gw * gh * 3
        p = self.vproc
        while gen == self.gen and p is not None:
            b = self._read(p, n)
            if b is None:
                if gen == self.gen:
                    msg = ""
                    if self.kind == "Screen":
                        try:
                            msg = (p.stderr.read() or b"").decode("utf-8", "replace").strip()
                        except Exception:
                            pass
                    if self.kind == "Stream URL":
                        try:
                            msg = (p.stderr.read() or b"").decode("utf-8", "replace").strip()
                        except Exception:
                            pass
                    self.log("%s stopped%s" % (self.kind, (": " + msg.splitlines()[-1]) if msg else ""))
                    if self.kind == "Stream URL":         # live streams drop: try again
                        threading.Thread(target=self._stream_again, args=(gen,), daemon=True).start()
                break
            with self.lock:
                self.latest = np.frombuffer(b, np.uint8).reshape(gh, gw, 3)
                self.liveq.append(self.latest)
                self.pos_n = getattr(self, "pos_n", 0) + 1
                while len(self.liveq) > 4 * max(self.n, 1):  # (never more than ~2 frames behind)
                    self.liveq.popleft()

    def pictures(self):
        """The pictures for the next data frame (two or three, as the encoder mode wants)."""
        w, h = self.w, self.h
        dt = 1.0 / self.fps
        out = []
        live = []
        if self.kind in ("Webcam", "Screen", "Stream URL") and not self.paused:
            # the camera / screen gives pictures at the source's rate (ffmpeg's fps filter): take the
            # next ones in order - every picture once - rather than the newest one n times over
            with self.lock:
                while self.liveq and len(live) < self.n:
                    live.append(self.liveq.popleft())
                while len(self.liveq) > 2 * self.n:      # running behind: catch up
                    self.liveq.popleft()
                newest = self.latest
            while live and len(live) < self.n:          # short (the start, a stall): repeat the last
                live.append(live[-1])
            if not live and newest is not None:
                live = [newest] * self.n
        for i in range(self.n):
            if self.paused and self.last is not None:
                out.append(self.last)
                continue
            if self.kind == "Picture" and self.still is not None:
                p = self.still
            elif self.kind == "Video file" and self.vproc is not None:
                b = self._read(self.vproc, w * h * 3)
                if b:
                    self.pos_n = getattr(self, "pos_n", 0) + 1
                p = np.frombuffer(b, np.uint8).reshape(h, w, 3) if b else (self.last if self.last is not None
                                                                         else test_card(w, h, self.t))
            elif self.kind == "Screen":
                g = live[i] if live else None
                if g is None:
                    p = test_card(w, h, self.t)
                else:                                    # the area, one-to-one, then to the picture size
                    aw, ah = SCREEN_AREA.get(self.aspect, (240, 192))
                    x = int(min(max(self.scr_x, 0), SCREEN_X_MAX))
                    y = int(min(max(self.scr_y, 0), SCREEN_Y_MAX))
                    p = resize(crop_aspect(np.ascontiguousarray(g[y:y + ah, x:x + aw]), self.aspect), w, h)
            elif self.kind in ("Webcam", "Stream URL"):
                p = live[i] if live else test_card(w, h, self.t)
            else:
                p = test_card(w, h, self.t)
            if p.shape[:2] != (h, w):
                p = resize(p, w, h)
            self.t += dt
            self.last = p
            out.append(p)
        self.p_taken += len(out)
        return out

    def audio(self, n_samples):
        """The sound for the next data frame: the frame's air time of sound (as the pictures are its
        air time of video), fitted into the n stereo samples the frame carries.  Interleaved, on the
        U8 scale (128 = silence): rounded to U8, or with bits16 kept to 1/256 of a step (16 bit)."""
        k = self.aclk.next() if hasattr(self, "aclk") else n_samples
        self.a_taken += k
        a = None
        if self.sound_in != "Source" or (self.kind == "Stream URL" and getattr(self, "stream_sound", False)):
            if (self.lproc is not None or self.kind == "Stream URL") and not self.paused:
                a = self._live_take(k)
        elif self.kind == "Video file" and self.aproc is not None and not self.paused:
            b = self._read(self.aproc, k * 4)
            if b and len(b) == k * 4:
                a = np.frombuffer(b, "<i2").astype(np.float32) / 256.0 + 128.0      # 16 bit, on the U8 scale
        elif self.kind == "Test card" and not self.paused:   # 1 kHz left, 400 Hz right, gently
            t = getattr(self, "ak", 0) + np.arange(k)
            self.ak = int(t[-1] + 1)
            a = np.empty(k * 2, np.float32)
            a[0::2] = 128 + 60 * np.sin(2 * np.pi * 1000 * t / C.AUDIO_FS)
            a[1::2] = 128 + 60 * np.sin(2 * np.pi * 400 * t / C.AUDIO_FS)
            # a click every second on both channels, for checking lip sync by ear against the
            # test card's clock (its second hand jumps at the same moment)
            ph = (t % C.AUDIO_FS) < 240
            a[0::2][ph] = 128 + 110 * np.sin(2 * np.pi * 3000 * t[ph] / C.AUDIO_FS)
            a[1::2][ph] = a[0::2][ph]
        if a is None:
            return np.full(n_samples * 2, 128, np.uint8)
        step = self.aclk.per / float(n_samples)
        if getattr(self, "arsm", None) is not None and abs(self.arsm.step - step) > 1e-9:
            self.arsm = None                              # the frame carries a different number now
        if k == n_samples and getattr(self, "arsm", None) is None:
            return self._out(np.asarray(a, np.float32))
        # with a guard: a steady, seamless rate change (16 tap sinc) - no seams between frames
        if getattr(self, "arsm", None) is None:
            self.arsm = C.StreamResampler(step)
        return self._out(self.arsm.process(np.asarray(a, np.float32), n_samples))

    def _out(self, a):
        a = np.asarray(a, np.float32).ravel()
        if getattr(self, "bits16", False):
            return np.clip(np.round(a * 256.0) / 256.0, 0.0, 255.99609375).astype(np.float32)
        return np.clip(np.round(a), 0, 255).astype(np.uint8)

    @property
    def av_skew(self):
        """TX: sound taken minus pictures taken, in seconds (should stay 0)."""
        return self.a_taken / float(C.AUDIO_FS) - self.p_taken / float(self.fps)


class AudioOut:
    """The sound card: sounddevice where installed (it reports its own delay), else aplay (Linux)."""

    def __init__(self, log):
        self.log, self.proc, self.sd = log, None, None
        self.latency = 0.0
        self.device = ""                                 # "": the system default; "pulse": through the
                                                         # PulseAudio mixer; or a device's name

    def start(self):
        if self.proc or self.sd:
            return True
        # the PulseAudio mixer shows our stream by this name (pavucontrol's Playback tab)
        os.environ["PULSE_PROP"] = "application.name='%s' media.name='Sound out'" % APP_NAME
        dev = self.device.strip() or None
        try:
            import sounddevice as sd
            try:
                self.sd = sd.RawOutputStream(samplerate=C.AUDIO_FS, channels=2, dtype="int16", latency="low", device=dev)
            except Exception as e:
                if dev is None:
                    raise
                self.log("Sound out: cannot open %s (%s) - using the system default" % (dev, e))
                self.sd = sd.RawOutputStream(samplerate=C.AUDIO_FS, channels=2, dtype="int16", latency="low")
            self.sd.start()
            self.latency = float(self.sd.latency)
            return True
        except Exception:
            self.sd = None
        if shutil.which("aplay") and not IS_WIN:
            # a small buffer, so its delay is known (0.1 s); we feed it at its own pace
            self.proc = subprocess.Popen(["aplay", "-q"] + (["-D", dev] if dev else []) +
                                         ["-f", "S16_LE", "-c", "2", "-r", str(C.AUDIO_FS), "--buffer-time=100000"],
                                         stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
            self.latency = 0.1
            return True
        self.log("No sound output: needs 'pip install sounddevice' (or aplay on Linux)")
        return False

    @property
    def blocking(self):
        """True if write() waits for the card (the card's own clock sets the pace)."""
        return self.sd is not None

    def write(self, b):
        try:
            if self.proc:
                self.proc.stdin.write(b.tobytes())
                self.proc.stdin.flush()
            elif self.sd:
                self.sd.write(b.tobytes())
            return True
        except Exception:
            self.stop()
            return False

    def stop(self):
        try:
            if self.proc:
                self.proc.kill()
            if self.sd:
                self.sd.stop()
                self.sd.close()
        except Exception:
            pass
        self.proc = self.sd = None


class AVPlayer:
    """Plays the received sound and times the received pictures to it (C.AVSync keeps the
    timeline and the clock; this adds the sound card and a thread to feed it)."""

    CHUNK = 480                                          # 20 ms of sound at a time

    def __init__(self, log):
        self.log = log
        self.lock = threading.Lock()
        self.sig = None
        self.sync = None
        self.out = AudioOut(log)
        self.sound = False
        self.running = False
        self.w_end = None                                # when the sound written so far will have played
        self.m_end = None                                # its media time

    def configure(self, period, n, lag):
        sig = (round(period, 6), n, lag)
        if sig != self.sig:
            with self.lock:
                self.sig = sig
                lip = self.sync.lip if self.sync is not None else 0.0
                self.sync = C.AVSync(period, n, lag)
                self.sync.lip = lip
                self.w_end = self.m_end = None

    def reset(self):
        with self.lock:
            if self.sync is not None:
                self.sync.reset()
            self.w_end = self.m_end = None

    def push(self, audio, start, pics=()):
        with self.lock:
            if self.sync is not None:
                self.sync.push(audio, start, pics)

    def push_pics(self, start, pics, part=0, nparts=1):
        with self.lock:
            if self.sync is not None and start is not None:
                self.sync.push_pics(start, pics, part, nparts)

    def set_device(self, dev):
        """Change the sound card (or go through the PulseAudio mixer): reopened if playing."""
        self.out.device = dev or ""
        if self.running:
            self.running = False
            time.sleep(0.1)                              # the feeder sees it and leaves
            self.out.stop()
            self.set_sound(True)

    def set_sound(self, on):
        if on and not self.running:
            if not self.out.start():
                return
            self.running = True
            with self.lock:
                self.w_end = self.m_end = None
            threading.Thread(target=self._feed, daemon=True).start()
        elif not on and self.running:
            self.running = False

    def _feed(self):
        dur = self.CHUNK / float(C.AUDIO_FS)
        while self.running:
            with self.lock:
                sy = self.sync
                if sy is None:
                    chunk = np.full((self.CHUNK, 2), 128.0, np.float32)
                else:
                    chunk = sy.audio(self.CHUNK)
                    now = time.time()
                    self.w_end = max(now, self.w_end or now) + dur
                    self.m_end = sy.clock()
            # 16 bit to the card: 8 bit sound as it was (x 256), 16 bit sound with all of its detail;
            # the volume here (it changes nothing else: the meters and the sound SNR are before it)
            g = getattr(self, "gain", 1.0) * 256.0
            if not self.out.write(np.clip(np.round((np.asarray(chunk, np.float64) - 128.0) * g), -32768, 32767).astype("<i2")):
                break
            if not self.out.blocking:                    # aplay: keep no more than ~60 ms ahead of it
                ahead = (self.w_end or 0) - time.time() - 0.06
                if ahead > 0:
                    time.sleep(ahead)
            else:                                        # the card waited: it sets the pace
                with self.lock:
                    self.w_end = time.time() + self.out.latency
        self.out.stop()
        self.running = False

    def clock(self, dt):
        """The media time to show now; dt: seconds since the last call (used with the sound off)."""
        with self.lock:
            sy = self.sync
            if sy is None:
                return None
            if not self.running:
                sy.advance(dt)
                return sy.clock()
            if self.m_end is None:
                return None
            # what is coming out of the speaker now: the end of what was written, less what is
            # still waiting to play, less the card's own delay
            return self.m_end - max(0.0, self.w_end - time.time()) - (self.out.latency if not self.out.blocking else 0.0)

    def pick(self, c):
        with self.lock:
            return None if self.sync is None else self.sync.pick(c)

    def report(self):
        with self.lock:
            return None if self.sync is None else self.sync.report()

    def close(self):
        self.running = False
        time.sleep(0.05)
        self.out.stop()


# ======================================================================= the engine
def pic_psnr(a, b):
    return 10 * np.log10(255.0 ** 2 / max(float(np.mean((a.astype(np.float32) - b.astype(np.float32)) ** 2)), 1e-3))


class Engine:
    """Encoder -> modulator -> channel -> demodulator -> decoder, one data frame at a time.
    The modem and the decoder run in their own processes (cores) when Multi-core is on: while the
    modem works on frame k, the decoder works on frame k-1 and the window draws k-2."""

    def __init__(self, app):
        self.app = app
        self.running = False
        self.q = queue.Queue(maxsize=40)
        self.sent = collections.deque(maxlen=10)          # (video bytes, audio bytes sent, pictures, sound before emphasis)
        self.lock = threading.Lock()
        self.source = Source(app.log)
        self.rebuild_needed = True
        self.frames = 0
        self.modem = self.decw = None
        self.pending = None
        self.dec_busy = self.up_busy = None              # what the decoder / upscaler are working on
        self.up_hist = collections.deque(maxlen=12)      # 1 = a frame the upscaler was too busy for
        self.up_wait = None                              # a frame waiting for the upscaler
        self.apply_needed = False

    def start_workers(self):
        multi = bool(self.app.cfg.get("multicore", 1))
        if self.modem is not None and self.modem.multi == multi:
            return
        self.close_workers()
        self.modem = C.Worker("modem", multi)
        self.decw = C.Worker("decode", multi)
        self.upw = C.Worker("upscale", multi)
        if multi and not self.modem.multi:
            self.app.log("Multi-core: worker processes would not start (%s) - running in one"
                         % getattr(self.modem, "error", "?"))

    def close_workers(self):
        for w in (self.modem, self.decw, getattr(self, "upw", None)):
            if w is not None:
                w.close()
        self.modem = self.decw = self.upw = None
        self.pending = None
        self.dec_busy = self.up_busy = self.up_wait = None

    @property
    def cores(self):
        return 4 if self.modem is not None and self.modem.multi else 1

    def rebuild(self):
        c = self.app.cfg
        gen0 = getattr(self, "rebuild_gen", 0)           # (a change asked for while this runs: again)
        self.start_workers()
        self.finish_pending()
        self.mode = C.MODES[c["mode"]]
        self.lay = C.layout(self.mode, bool(c.get("long_sym", 0)), int(c["cp"]), int(c.get("fixed_fps", 0)), bool(c.get("pilots16", 0)))           # 200 or 400 carriers
        self.mod = C.Modulator(self.lay, c["cp"], bool(c["interleave"]), c["sync"])   # (for the byte order)
        self.modem.call(("build", c["mode"], int(c["cp"]), bool(c["interleave"]), c["sync"], self.lay.long,
                         int(self.lay.fixed_kind), bool(self.lay.dense)))
        self.decw.call(("reset",))
        self.upw.call(("reset",))
        self.sent.clear()
        self.prev_pics = None
        self.rebuild_needed = getattr(self, "rebuild_gen", 0) != gen0
        self.apply()

    def apply(self):
        """Channel and receiver settings that change on the fly (sent to the modem with the next frame)."""
        self.apply_needed = True

    def resync(self):
        self.resync_needed = True

    def reset_decoder(self):
        self.reset_dec_needed = True

    def start(self):
        if self.running:
            return
        self.running = True
        threading.Thread(target=self.run, daemon=True).start()

    def stop(self):
        self.running = False
        with self.lock:                                  # (waits for the frame in hand)
            self.close_workers()

    def run(self):
        t_next = time.time()
        while self.running:
            if getattr(self, "hold", False):            # (held)
                self.finish_pending()
                time.sleep(0.1)
                t_next = time.time()
                continue
            try:
                with self.lock:
                    if self.rebuild_needed or self.modem is None or \
                            self.modem.multi != bool(self.app.cfg.get("multicore", 1)):
                        self.rebuild()
                    self.step()
            except Exception as e:
                import traceback
                tb = traceback.extract_tb(e.__traceback__)[-1]
                self.app.log("Engine: %s (line %d, %s)" % (e, tb.lineno, tb.name))
                self.rebuild_needed = True
                time.sleep(0.5)
            hw = getattr(self.app, "hw_last", None) or {}
            if (hw.get("tx") or hw.get("rx")) and not hw.get("err") and \
                    self.app.cfg.get("hw_mode") in ("TX out", "Loop", "RX in"):
                # real hardware: its output buffer (TX out), or the input coming in (RX in, Loop) sets the pace - a
                # late frame is made up at once, rather than leaving the card to run dry (a drop-out) or the
                # receiver running behind what comes in
                t_next = time.time()
                time.sleep(0.001)
            elif self.app.cfg["realtime"]:
                t_next += C.frame_seconds(self.lay, self.mod.cp)                    # one data frame of air time
                d = t_next - time.time()
                if d > 0:
                    time.sleep(d)
                elif d < -1.0:
                    t_next = time.time()
            else:
                time.sleep(0.005)

    def step(self):
        m = self.mode
        c = self.app.cfg
        t0 = time.time()
        enc = int(c["enc"])
        lay = self.lay
        H = lay.halves
        C.set_colour_coding(c.get("colour_coding", "3/4"))
        fs, auds, pics = [], [], []
        for h in range(H):                                # long symbols: two codec frames a data frame
            p = self.source.pictures()
            if len(p) != C.pics_per_frame(enc) or p[0].shape[:2] != C.pic_size(m, enc)[::-1]:
                lp = getattr(self, "last_pics", None)     # the source being changed over, or late: on the air, the
                if lp is None or len(lp) != C.pics_per_frame(enc) or lp[0].shape[:2] != C.pic_size(m, enc)[::-1]:
                    return                                # last pictures again rather than a gap in the signal
                p = lp
            self.last_pics = p
            self.source.bits16 = True                     # (16 bit sound always, since 5.7)
            ms_tx = True                                  # (always sum and difference, since 5.11)
            auds.append(self.source.audio(C.MS_FULL if ms_tx else C.audio_capacity(lay) // H))
            fs.append(C.encode_frame(p, m, enc, detail=c["detail"], vemph=bool(c.get("vemph", 1))))
            pics += p
        frame = np.concatenate(fs) if H > 1 else fs[0]
        aud = np.concatenate(auds) if H > 1 else auds[0]
        # TX sound emphasis (the treble lifted before the air; the RX takes it back off)
        em = c.get("emph", "Off")
        if em != getattr(self, "tx_emph_name", "Off"):
            self.tx_emph_name = em
            self.tx_emph = C.Emphasis(C.emph_tau(em), True) if C.emph_tau(em) else None
        # TX stereo compander: R+L and R-L, each 2:1 (before the emphasis; the RX undoes it after)
        cmp_name = C.compander_name(c.get("compander", "Off"))
        if cmp_name != getattr(self, "tx_comp_name", "Off"):
            self.tx_comp_name = cmp_name
            self.tx_comp = C.make_compander(cmp_name, True)
        aud_orig = aud
        dual = c.get("audio_mode", "Stereo") == "Dual mono"
        cm = c.get("common", "Auto")
        same = C.is_common(np.asarray(aud, np.float64).reshape(-1, 2))
        self.same_run = (getattr(self, "same_run", 0) + 1) if same else 0     # (Auto: on after 4 frames the same, off at once)
        self.tx_common = dual and (cm == "On" or (cm == "Auto" and self.same_run >= 4))
        if self.tx_common:                                # (common mode: Ch 1 on both, before the compander)
            aud = np.asarray(aud).reshape(-1, 2).copy()
            aud[:, 1] = aud[:, 0]
            aud = aud.ravel()
        if ms_tx:
            # Sum/diff: the compander and emphasis on L, R as always, then M and S at their own rates
            xa = aud.reshape(-1, 2).astype(np.float64) - 128.0
            if getattr(self, "tx_comp", None) is not None:
                xa = self.tx_comp.process(xa)
            if getattr(self, "tx_emph", None) is not None:
                xa = self.tx_emph.process(xa)
            nb = C.audio_capacity(lay) * 2 // H
            sp = "Dual" if dual else c.get("ms_split", "Auto")
            if getattr(self, "ms_tx", None) is None or self.ms_tx.nbytes != nb or self.ms_tx.split != sp \
                    or getattr(self, "ms_reset", False):
                self.ms_tx, self.ms_reset = C.sound_coder(nb, sp), False
                self.ms_rx = None
            if dual:
                aud = np.concatenate([self.ms_tx.encode(xa[h * C.MS_FULL:(h + 1) * C.MS_FULL], self.tx_common) for h in range(H)])
            else:
                aud = np.concatenate([self.ms_tx.encode(xa[h * C.MS_FULL:(h + 1) * C.MS_FULL]) for h in range(H)])
        elif getattr(self, "tx_emph", None) is not None or getattr(self, "tx_comp", None) is not None:
            xa = aud.reshape(-1, 2).astype(np.float64) - 128.0
            if getattr(self, "tx_comp", None) is not None:
                xa = self.tx_comp.process(xa)
            if getattr(self, "tx_emph", None) is not None:
                xa = self.tx_emph.process(xa)
            aud = np.clip(np.round(xa + 128.0), 0, 255).astype(np.uint8).ravel()
        elif aud.dtype != np.uint8:                       # 16 bit sound, sent plain: 8 bits on the air
            aud = np.clip(np.round(aud), 0, 255).astype(np.uint8).ravel()
        self.sent.append((frame, aud, pics, aud_orig))
        if self.apply_needed:
            self.apply_needed = False
            self.modem.send(("apply", dict(c)))
            self.modem.recv()
        if getattr(self, "resync_needed", False):
            self.resync_needed = False
            self.modem.call(("reset",))
        if getattr(self, "reset_dec_needed", False):
            self.reset_dec_needed = False
            self.finish_pending()
            self.decw.call(("reset",))
            self.upw.call(("reset",))
            self.prev_pics = None
        # the modem works on this frame while the decoder and the upscaler finish earlier ones
        word = None
        if c.get("tx_word", 1):
            settings = C.word_pack(enc, C.compander_name(c.get("compander", "Off")), bool(c.get("scramble", 1)),
                                   c.get("ms_split", "Auto"), c.get("spread", "Off"),
                                   bool(c.get("ti", 0)) and bool(c.get("scramble", 1)) and c.get("spread", "Off") == "Off",
                                   bool(c.get("iqflip", 0)), c.get("audio_mode", "Stereo"), bool(getattr(self, "tx_common", False)))
            self.word_seq = getattr(self, "word_seq", -1) + 1      # (the 32-frame round of pages)
            word = C.tx_word(self.word_seq, settings, c.get("callsign", ""), bool(c.get("tx_stamp", 0)),
                             c.get("grid", ""), c.get("title", ""))
        self.modem.send(("frame", frame, aud, int(c["rf_speed"]), word))
        self.poll_stages()
        r = self.modem.recv()
        out = dict(kind="frame", sent=pics, rows=r["rows"], rf_rows=r["rf_rows"], obw=r["obw"], oob=r["oob"],
                   stats=r["stats"], const=r["const"], const_a=r.get("const_a"),
                   const_flip=r.get("const_flip"), const_flip_a=r.get("const_flip_a"), timing_curve=r["timing_curve"],
                   timing_err=r["timing_err"],
                   echo_est=r["echo_est"], fade_gain=r["fade_gain"], front=r.get("front"), hw=r.get("hw"), snow=r.get("snow"), snow_ref=r.get("snow_ref"), tx_time=time.time() - t0,
                   modem_time=r["time"], cores=self.cores, auto=r.get("auto"), papr=r.get("papr"), papr_in=r.get("papr_in"),
                   peak_gain=r.get("peak_gain"), wide=r.get("wide"), wide_tx=r.get("wide_tx", False),
                   wide_mode=r.get("wide_mode"))
        res = r["res"]
        if c.get("auto_rx", 0):                          # Auto: only frames of the layout this engine runs
            res = [x for x in res if len(x["video"]) == lay.frame_bytes]
        rx = [self.analyse(x) for x in res]
        out["rx"] = rx
        # the sound (and the frame's figures) go to the window now - the pictures follow when ready,
        # so a slow decoder or upscaler can never hold up the sound
        self.post(out)
        enc_e = C.eff_enc(m, enc)
        n = C.pics_per_frame(enc_e)
        for x in rx:
            v, sp = x["frame"], x.pop("sent_pics")
            for h in range(H):
                # the decoder gives the pictures of the codec frame before (it waits for the next key) -
                # mode 5 its own; a codec frame's place: (its data frame's start, which half)
                here = (x["start_s"], h)
                pos = here if enc_e == 5 else getattr(self, "last_pos", None)
                ref = sp[h * n:(h + 1) * n] if enc_e == 5 else getattr(self, "prev_pics", None)
                self.last_pos = here
                self.prev_pics = sp[h * n:(h + 1) * n]
                if self.dec_busy is not None:          # one frame at a time in the decoder
                    self.handle_dec(self.decw.recv())
                self.decode(v[h * m.frame_bytes:(h + 1) * m.frame_bytes], pos, ref, x.get("snr_est"))
                self.poll_stages()

    def post(self, out):
        try:
            self.q.put_nowait(out)
        except queue.Full:
            pass
        if out.get("kind") == "frame":
            self.frames += 1

    def decode(self, v, pos, ref, snr_est):
        c = self.app.cfg
        keys = ("enc", "kmx", "key_only", "wl", "snap", "soft", "detail", "msearch", "fuzzy_c", "fuzzy_p",
                "median_c", "cavg", "auto_f", "ctrack", "colour_coding", "tnr", "vemph")
        dc = {k: c[k] for k in keys}
        for k in ("enc", "colour_coding", "detail"):       # Auto: as the mode word says
            dc[k] = self.rx(k)
        dc["gpu"] = int(c.get("gpu", 0))
        self.decw.send(("decode", v, self.mode.name, dc, snr_est, ref))
        self.dec_busy = dict(kind="pics", pic_start=pos[0] if pos else None, part=pos[1] if pos else 0,
                             nparts=self.lay.halves, snr_est=snr_est)

    def fps_factor(self):
        """Pictures shown per picture received (25 fps on: 2, or 3 for mode 5)."""
        c = self.app.cfg
        if not c.get("fps25", 1):
            return 1
        enc = C.eff_enc(self.mode, int(c["enc"]))
        return C.fps_factor(C.frame_seconds(self.lay, c["cp"]), self.lay.halves * C.pics_per_frame(enc))

    def poll_stages(self, block=False):
        """Collect whatever the decoder and the upscaler have finished (without waiting, unless block)."""
        if self.up_busy is not None and (block or self.upw.ready()):
            self.handle_up(self.upw.recv())
        if self.dec_busy is not None and (block or self.decw.ready()):
            self.handle_dec(self.decw.recv())
        while block and self.up_busy is not None:
            self.handle_up(self.upw.recv())

    def finish_pending(self, flush=True):
        if self.decw is None:
            self.dec_busy = self.up_busy = None
            return
        self.poll_stages(block=True)

    def handle_dec(self, d):
        """The decoder's pictures: to the upscaler if it is free, else straight to the window (as
        received - a frame missed by the upscaler rather than the whole picture late)."""
        info, self.dec_busy = self.dec_busy, None
        info.update(yccs=d["yccs"], pic_db=d["pic_db"], filt=d["filt"], dec_time=d["time"])
        self.gpu_dec = d.get("gpu")
        if info["pic_start"] is None or not d["yccs"]:
            if d["yccs"]:
                self.post(info)
            return
        meth = self.app.cfg.get("upscale", "Super-res")
        F = self.fps_factor()
        if self.app.cfg["realtime"]:
            meth, F = self.keep_up(meth, F)
        if self.upw is None or not (meth in C.UPSCALE[1:] or F > 1):
            self.post(info)
            return
        info["up_args"] = (d["yccs"], d.get("keys", [0]), d.get("next_key"), meth, info.get("snr_est"), F,
                           False, int(self.app.cfg.get("gpu", 0)))
        if self.up_busy is not None and self.upw.ready():
            self.handle_up(self.upw.recv())
        if self.up_busy is not None:
            # still busy: this frame waits its turn; one already waiting goes as it is
            if self.up_wait is not None:
                self.up_hist.append(1)
                old = self.up_wait
                old.pop("up_args", None)
                self.post(old)
            self.up_wait = info
            return
        self.send_up(info)

    def send_up(self, info):
        self.up_hist.append(0)
        self.upw.send(("upscale",) + info.pop("up_args"))
        self.up_busy = info

    def handle_up(self, d):
        info, self.up_busy = self.up_busy, None
        info["yccs"], info["up_time"] = d["yccs"], d["time"]
        self.gpu_up = d.get("gpu")
        if self.up_wait is not None:                   # the next in line
            nxt, self.up_wait = self.up_wait, None
            self.send_up(nxt)
        self.up_n = getattr(self, "up_n", 0) + 1
        if self.up_n > 3:                              # (the first few are slow: the process warming up)
            self.up_ema = d["time"] if getattr(self, "up_ema", None) is None else 0.8 * self.up_ema + 0.2 * d["time"]
        self.post(info)

    def keep_up(self, meth, F):
        """In real time the upscaler must keep up with the air (a data frame's time); if this
        computer can't: Super-res -> Sharp, then 25 fps off, for a while."""
        ft = C.frame_seconds(self.lay, self.mod.cp) / self.lay.halves     # (a codec frame's time)
        # slow = on average near a frame's time, or missing frames often (not a single hiccup)
        # (not while it warms up - the first frames after a start or a change are slow and come in
        # bursts; and frames passed over only count when the upscaler really is loaded: a burst from
        # the decoder can catch even a fast one busy)
        ema = getattr(self, "up_ema", None) or 0.0
        if getattr(self, "up_n", 0) < 8:
            self.up_hist.clear()
            slow = False
        else:
            slow = ema > 0.85 * ft or (sum(self.up_hist) >= 4 and ema > 0.5 * ft)
        if slow:
            self.up_hist.clear()
            self.up_ema = None
            self.up_n = 0
            # each step held for a while (75 frames, about 18 s) - stepping back up too soon only
            # falls behind again, and every fall costs pictures.  Smooth motion (25 fps) is kept
            # longest: the enlarging goes first, plain enlarging before the 25 fps
            if meth == "Super-res" and getattr(self, "up_sharp", 0) <= 0:
                self.up_sharp = 75
                self.app.log("Upscale: Super-res can't keep up here - Sharp for now")
            elif meth in ("Super-res", "Sharp") and getattr(self, "up_plain", 0) <= 0:
                self.up_plain = 75
                self.app.log("Upscale: %s can't keep up here - plain enlarging for now" % meth)
            elif F > 1 and getattr(self, "up_noint", 0) <= 0:
                self.up_noint = 75
                self.app.log("Upscale: still can't keep up - 25 fps off for now")
        if getattr(self, "up_sharp", 0) > 0:
            self.up_sharp -= 1
            if meth == "Super-res":
                meth = "Sharp"
        if getattr(self, "up_plain", 0) > 0:
            self.up_plain -= 1
            meth = "Off"
        if getattr(self, "up_noint", 0) > 0:
            self.up_noint -= 1
            F = 1
        return meth, F

    def rx(self, key):
        """A receiver setting: the operator's, or with Auto the transmitter's mode word's."""
        c = self.app.cfg
        w = getattr(self, "rx_word", None)
        if c.get("auto_rx", 0) and w is not None and key in w:
            return w[key]
        return c.get(key)

    def analyse(self, r):
        """Compare one received frame with what was sent (the lab knows), and play its sound."""
        m = self.mode
        if r.get("word") is not None:
            self.rx_word = r["word"]
        self.rx_call = r.get("callsign")
        self.rx_side = r.get("side") or {}
        self.rx_breaks = r.get("word_breaks", 0)
        v, a = r["video"], r["audio"]
        best, bi = None, None
        for i, (f, au, pics, _) in enumerate(self.sent):
            e = float(np.mean((v[::7].astype(np.float32) - f[::7].astype(np.float32)) ** 2))
            if best is None or e < best:
                best, bi = e, i
        f, au, pics, au0 = self.sent[bi]
        # per carrier: the bytes each carrier carried, sent and received
        sm = self.mod.video_matrix(f).astype(np.float32)
        rm = self.mod.video_matrix(v).astype(np.float32)
        err = (sm - rm) ** 2
        sig = np.var(sm, axis=0) + 1.0
        snr_v = 10 * np.log10(sig / (err.mean(axis=0) + 1e-3))
        lay = self.lay
        per = np.full(lay.nfft, np.nan)
        per[lay.video_bins] = 0.5 * (snr_v[0::2] + snr_v[1::2])
        same_a = len(au) == len(a) == lay.syms * lay.abps     # (not while a layout or sound coding changes over)
        if same_a:
            sa = au.reshape(lay.syms, lay.abps).astype(np.float32)
            ra = a.reshape(lay.syms, lay.abps).astype(np.float32)
            ea = 10 * np.log10((np.var(sa, axis=0) + 1.0) / (((sa - ra) ** 2).mean(axis=0) + 1e-3))
            per[lay.audio_bins] = 0.5 * (ea[0::2] + ea[1::2])
        mse = float(np.mean((v.astype(np.float32) - f.astype(np.float32)) ** 2))
        psnr = 10 * np.log10(255.0 ** 2 / max(mse, 1e-3))
        asnr = None
        if same_a:
            aerr = float(np.mean((a.astype(np.float32) - au.astype(np.float32)) ** 2))
            av = float(np.var(au.astype(np.float32)))
            asnr = 10 * np.log10(av / max(aerr, 1e-3)) if av > 10 else None        # silence: no measure
        c = self.app.cfg
        # sound noise reduction (it knows the noise from the SNR estimate), 21 ms late; scored
        # against what was sent 21 ms before
        if not hasattr(self, "anr"):
            self.anr = C.AudioNR()
        nm = C.nr_mode(c.get("audio_nr", "Auto"), r.get("snr_est"))
        ms_rx = True
        ms_delay = 0
        if ms_rx:
            # Sum/diff: M and S back to 24 kHz, lined up, and L = M + S, R = M - S; in a weak signal the
            # stereo is blended down (and its noise with it), as an FM receiver does
            H = lay.halves
            nb = len(a) // H
            dual = (self.rx("audio_mode") or "Stereo") == "Dual mono"
            sp = "Dual" if dual else (self.rx("ms_split") or "Auto")
            if getattr(self, "ms_rx", None) is None or self.ms_rx.nbytes != nb or self.ms_rx.split != sp:
                self.ms_rx = C.sound_coder(nb, sp)
                self.ms_g = 1.0
            if dual:
                # dual mono: no blending (that would mix the two languages); common mode - the two copies averaged
                w = getattr(self, "rx_word", None)
                self.rx_common = bool(w["common"]) if (w is not None and "common" in w) else bool(getattr(self, "tx_common", False))
                st = np.concatenate([self.ms_rx.decode(a[h * nb:(h + 1) * nb], self.rx_common) for h in range(H)])
                sig_n = C.noise_sigma(r.get("snr_est")) * (math.sqrt(0.5) if self.rx_common else 1.0)
            else:
                self.ms_g = 0.8 * getattr(self, "ms_g", 1.0) + 0.2 * C.ms_blend(r.get("snr_est"))
                st = np.concatenate([self.ms_rx.decode(a[h * nb:(h + 1) * nb], self.ms_g) for h in range(H)])
                sig_n = C.noise_sigma(r.get("snr_est")) * math.sqrt(1.0 + self.ms_g ** 2)
            ms_delay = self.ms_rx.delay
            a_nr = self.anr.process(st.astype(np.float32), sig_n, nm)
        else:
            a_nr = self.anr.process(a.reshape(-1, 2).astype(np.float32) - 128.0, C.noise_sigma(r.get("snr_est")), nm)
        # then the de-emphasis (after the noise reduction, which wants the hiss flat as it came)
        em = self.rx("emph") or "Off"
        if em != getattr(self, "rx_emph_name", "Off"):
            self.rx_emph_name = em
            self.rx_emph = C.Emphasis(C.emph_tau(em), False) if C.emph_tau(em) else None
        if getattr(self, "rx_emph", None) is not None:
            a_nr = self.rx_emph.process(a_nr)
        # then the expander: R+L and R-L back out 1:2, and L, R from them
        cmp_name = C.compander_name(self.rx("compander") or "Off")
        cmp_on = cmp_name != "Off"
        if cmp_name != getattr(self, "rx_comp_name", "Off"):
            self.rx_comp_name = cmp_name
            self.rx_comp = C.make_compander(cmp_name, False)
        cmp_lift = None
        if getattr(self, "rx_comp", None) is not None:
            a_nr = self.rx_comp.process(a_nr)
            cmp_lift = self.rx_comp.lift_db
        # 16 bit out (on the U8 scale, 1/256 steps) - always, since 5.7
        a_out = np.clip(np.round((a_nr + 128.0) * 256.0) / 256.0, 0.0, 255.99609375).astype(np.float32).ravel()
        asnr_nr = None
        if nm != "Off" or em != "Off" or cmp_on or ms_rx:
            # scored against the sound as it was before the TX's emphasis, 21 ms back
            prev_au = self.sent[bi - 1][3] if bi > 0 else au0
            d = 2 * (self.anr.DELAY + ms_delay)                  # the delay, in bytes
            ref_d = np.concatenate((prev_au, au0))[len(prev_au) - d:len(prev_au) - d + len(au0)].astype(np.float32)
            if len(ref_d) == len(a_out):
                e2 = float(np.mean((a_out.astype(np.float32) - ref_d) ** 2))
                asnr_nr = 10 * np.log10(float(np.var(ref_d)) / max(e2, 1e-3)) if np.var(ref_d) > 10 else None
        # which channel to listen to (dual mono: one language to both speakers) - after the scoring
        a_play = a_out
        if ms_rx and getattr(self.ms_rx, "split", "") == "Dual":
            ls = c.get("listen", "Both")
            if ls in ("Ch 1", "Ch 2"):
                k = 0 if ls == "Ch 1" else 1
                a_play = np.repeat(a_out.reshape(-1, 2)[:, k:k + 1], 2, axis=1).ravel()
            msi = (self.ms_rx.describe() + (" - common (both the same: the two copies averaged, +3 dB)" if self.rx_common else ""), None)
        else:
            msi = (self.ms_rx.describe(), self.ms_g) if ms_rx else None
        # the decoded pictures come one frame back (the decoder waits for the next key - not mode 5)
        return dict(start_s=float(r.get("start", 0)) / C.FS, yccs=[], pic_db=None, snr_est=r.get("snr_est"), filt=None, per=per, psnr=psnr, asnr=asnr,
                    audio=a_play, audio_raw=a, asnr_nr=asnr_nr, ms=msi, nr=nm, nr_cut=self.anr.used if nm != "Off" else 0.0, emph=em, comp=cmp_name if cmp_on else None, comp_gain=cmp_lift,
                    coherence=r["coherence"], mse=mse, frame=v, sent_frame=f, sent_pics=pics)


# ======================================================================= the window
class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_cfg()
        root.title("%s %s" % (APP, VERSION))
        self.logo = self.logo_small = None
        try:                                              # the NBTV logo: window icon and top bar
            self.logo = tk.PhotoImage(file=os.path.join(HERE, "nbtv_logo.png"))
            root.iconphoto(True, self.logo)
            self.logo_small = self.logo.subsample(2, 2)
        except Exception as e:
            print("Logo: %s" % e)
        root.configure(bg=BG)
        self.logs = collections.deque(maxlen=200)
        self.style()
        self.eng = Engine(self)
        self.avp = AVPlayer(self.log)                     # received sound, and the pictures timed to it
        self.avp.out.device = self.cfg.get("sound_out_dev", "")
        v = float(self.cfg.get("volume", 0.0))
        self.avp.gain = 0.0 if v <= -40 else 10 ** (v / 20.0)
        self.show_q = collections.deque()                 # (time, rgb) decoded pictures (Fast)
        self.sync_hist = collections.deque(maxlen=200)
        self.last_rx = None
        self.rec_dir = None
        self.rec_n = 0
        self.radio_link = R.NullRadio()
        self.wide_q = collections.deque()
        self.build()
        self.open_radio()
        self.set_tune(self.tune_hz, recenter=True)
        self.apply_hw()
        self.apply_source()
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(40, self.tick)
        root.after(10, self.video_tick)
        root.after(1500, self.lock_layout)
        self.eng.start()

    # ------------------------------------------------------------ helpers
    def style(self):
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure("TCombobox", fieldbackground=FIELD, background=CARD, foreground=FG, arrowcolor=FG)
        s.configure("Horizontal.TScale", background=CARD, troughcolor=FIELD)

    def log(self, s):
        self.logs.append(time.strftime("%H:%M:%S ") + s)
        print(s)

    def frame(self, parent, bg=CARD):
        return tk.Frame(parent, bg=bg)

    def group(self, parent, title):
        f = tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        tk.Label(f, text=title, bg=CARD, fg=ACC, font=F_HEAD).pack(anchor="w", padx=6, pady=(3, 1))
        return f

    def lbl(self, parent, text, muted=False, **kw):
        fg = kw.pop("fg", MUTED if muted else FG)
        return tk.Label(parent, text=text, bg=parent["bg"], fg=fg, font=kw.pop("font", F), **kw)

    def btn(self, parent, text, cmd, **kw):
        return tk.Button(parent, text=text, command=cmd, bg="#323942", fg=FG, activebackground="#3d4651",
                         activeforeground=FG, relief=tk.FLAT, font=F, padx=6, pady=1, highlightthickness=0, **kw)

    def radio(self, parent, var, values, cmd, width=None):
        f = self.frame(parent, parent["bg"])
        for v in values:
            tk.Radiobutton(f, text=v, value=v, variable=var, command=cmd, indicatoron=False, bg="#323942", fg=FG,
                           selectcolor="#2d5f91", activebackground="#3d4651", activeforeground=FG, relief=tk.FLAT,
                           font=F, padx=6, pady=1, highlightthickness=0, width=width or 0).pack(side=tk.LEFT, padx=1)
        return f

    def check(self, parent, text, key, cmd=None):
        v = tk.IntVar(value=int(self.cfg[key]))

        def changed():
            self.cfg[key] = int(v.get())
            (cmd or self.settings_changed)()
        tk.Checkbutton(parent, text=text, variable=v, command=changed, bg=parent["bg"], fg=FG, selectcolor=FIELD,
                       activebackground=parent["bg"], activeforeground=FG, font=F, highlightthickness=0).pack(side=tk.LEFT)
        return v

    def slider(self, parent, text, key, lo, hi, res, fmt="%g", cmd=None, length=150):
        row = self.frame(parent, parent["bg"])
        row.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(row, text, width=13, anchor="w").pack(side=tk.LEFT)
        v = tk.DoubleVar(value=float(self.cfg[key]))
        val = tk.Label(row, text=fmt % self.cfg[key], bg=row["bg"], fg=ACC, font=F, width=8, anchor="e")

        def moved(_=None):
            if getattr(self, "auto_showing", False):     # only showing Auto's choice: not a setting
                return
            x = round(float(v.get()) / res) * res
            self.cfg[key] = int(x) if res >= 1 else x
            val.config(text=fmt % self.cfg[key])
            (cmd or self.settings_changed)()
        s = ttk.Scale(row, from_=lo, to=hi, orient=tk.HORIZONTAL, variable=v, command=moved, length=length)
        s.pack(side=tk.LEFT, fill=tk.X, expand=True)
        val.pack(side=tk.LEFT)
        self.sliders[key] = (v, val, fmt)
        return s

    # ------------------------------------------------------------ layout
    def build(self):
        self.sliders = {}
        top = self.frame(self.root, BG)
        top.pack(fill=tk.X, padx=6, pady=(6, 3))
        if self.logo_small is not None:
            tk.Label(top, image=self.logo_small, bg=BG).pack(side=tk.LEFT, padx=(0, 6))
        tk.Label(top, text=APP, bg=BG, fg=FG, font=(SANS, 13, "bold")).pack(side=tk.LEFT)
        tk.Label(top, text="  %s" % VERSION, bg=BG, fg=MUTED, font=F).pack(side=tk.LEFT)
        self.v_mode = tk.StringVar(value=self.cfg["mode"])
        tk.Label(top, text="   Format", bg=BG, fg=MUTED, font=F).pack(side=tk.LEFT)
        self.radio(top, self.v_mode, list(C.MODES), self.mode_changed).pack(side=tk.LEFT, padx=4)
        self.v_multi = tk.IntVar(value=int(self.cfg.get("multicore", 1)))
        tk.Checkbutton(top, text="Multi-core (%d CPUs)" % (os.cpu_count() or 1), variable=self.v_multi,
                       command=self.multi_changed, bg=BG, fg=FG, selectcolor=FIELD, activebackground=BG,
                       font=F).pack(side=tk.LEFT, padx=8)
        self.v_gpu = tk.IntVar(value=int(self.cfg.get("gpu", 0)))
        tk.Checkbutton(top, text="GPU", variable=self.v_gpu, command=self.gpu_changed, bg=BG, fg=FG,
                       selectcolor=FIELD, activebackground=BG, font=F).pack(side=tk.LEFT)
        self.gpu_lbl = tk.Label(top, text=self.gpu_text(), bg=BG, fg=MUTED, font=F_SMALL, anchor="w")
        self.gpu_lbl.pack(side=tk.LEFT, padx=4)
        self.btn(top, "Help", self.help_window).pack(side=tk.RIGHT, padx=(8, 0))
        self.info = tk.Label(top, text="", bg=BG, fg=MUTED, font=F)
        self.info.pack(side=tk.RIGHT)
        body = self.frame(self.root, BG)
        body.pack(fill=tk.BOTH, expand=True, padx=6, pady=(0, 6))
        for i, w in enumerate((0, 1, 0)):
            body.columnconfigure(i, weight=w)
        body.rowconfigure(0, weight=1)
        self.cols = [self.build_encoder(body), self.build_centre(body), self.build_decoder(body)]
        self.cols[0].grid(row=0, column=0, sticky="nsew", padx=(0, 3))
        self.cols[1].grid(row=0, column=1, sticky="nsew", padx=3)
        self.cols[2].grid(row=0, column=2, sticky="nsew", padx=(3, 0))
        self.body = body
        self.status = tk.Label(self.root, text="", bg=BG, fg=MUTED, font=F_SMALL, anchor="w")
        self.status.pack(fill=tk.X, padx=6, pady=(0, 4))

    def lock_layout(self):
        """Fix the three panels at the size they came up with: changing texts (decoder line, modem
        line, file names) then cannot push the panels or the window around."""
        try:
            self.root.update_idletasks()
            ws = [f.winfo_reqwidth() for f in self.cols]
            h = max(f.winfo_reqheight() for f in self.cols)
            for f, w in zip(self.cols, ws):
                f.config(width=w + 6, height=h)
                f.pack_propagate(False)
            self.body.columnconfigure(0, minsize=ws[0] + 6)
            self.body.columnconfigure(2, minsize=ws[2] + 6)
            self.root.update_idletasks()
            self.root.geometry("%dx%d" % (self.root.winfo_width(), self.root.winfo_height()))
        except Exception as e:                          # (not on a real screen, e.g. in tests)
            self.log("Layout: %s" % e)

    def pic_size(self):
        return (360, 270) if self.cfg["aspect"] == "4:3" else (360, 203)

    def build_encoder(self, parent):
        g = self.group(parent, "Encode and TX")
        # transmit: press TX (or the space bar) to go on the air, again to come back to receive
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=(0, 4))
        self.ptt_btn = tk.Button(r, text="TX", command=self.ptt_toggle, width=6, bg="#323942", fg=FG,
                                 activebackground="#a33a3a", activeforeground="white", relief=tk.FLAT,
                                 font=(SANS, 12, "bold"), highlightthickness=0)
        self.ptt_btn.pack(side=tk.LEFT)
        self.ptt_lbl = tk.Label(r, text="RECEIVE", bg=CARD, fg="#6ccf7a", font=(SANS, 11, "bold"))
        self.ptt_lbl.pack(side=tk.LEFT, padx=8)
        self.lbl(r, "Hardware").pack(side=tk.LEFT, padx=(8, 2))
        self.v_hardware = tk.StringVar(value=self.cfg.get("hardware", "None"))
        hb = ttk.Combobox(r, textvariable=self.v_hardware, values=list(HARDWARE), width=12, state="readonly")
        hb.pack(side=tk.LEFT)
        hb.bind("<<ComboboxSelected>>", lambda e: self.hardware_changed())
        self.btn(r, "Radio / I/Q setup...", self.hardware).pack(side=tk.LEFT, padx=4)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6)
        self.v_loop = self.check(r, "Loop back test (cable: card out -> card in)", "loop_test", self.loop_changed)
        self.v_swloop = self.check(r, "Software loop back", "sw_loop", self.sw_loop_changed)
        self.slider(g, "TX level dBFS", "hw_level", -40, -6, 1, "%d", cmd=self.settings_changed)
        self.v_src = tk.StringVar(value=self.cfg["source"])
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6)
        self.radio(r, self.v_src, ["Test card", "Picture", "Video file", "Webcam", "Screen", "Stream URL"],
                   self.source_changed).pack(side=tk.LEFT)
        self.btn(r, "Test card editor...", self.open_tc_editor).pack(side=tk.LEFT, padx=6)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=(2, 0))
        self.lbl(r, "Sound in").pack(side=tk.LEFT)
        self.v_sin = tk.StringVar(value=self.cfg.get("sound_in", "Source"))
        self.radio(r, self.v_sin, list(SOUND_INS), self.sound_in_changed).pack(side=tk.LEFT, padx=4)
        self.btn(r, "Sound devices...", self.sound_dialog).pack(side=tk.LEFT, padx=4)
        self.scr_box = self.frame(g)                     # Screen: where the area is (shown with Screen)
        self.slider(self.scr_box, "Screen X", "screen_x", 0, SCREEN_X_MAX, 1, "%d", cmd=self.screen_moved, length=245)
        self.slider(self.scr_box, "Screen Y", "screen_y", 0, SCREEN_Y_MAX, 1, "%d", cmd=self.screen_moved, length=245)
        self.slider(g, "Sound in dB", "sound_gain", -12, 30, 1, "%+d", cmd=self.gain_changed)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=3)
        self.btn(r, "Load...", self.load).pack(side=tk.LEFT)
        self.v_play = tk.StringVar(value="Play")
        self.radio(r, self.v_play, ["Play", "Pause"], self.play_changed).pack(side=tk.LEFT, padx=6)
        self.v_aspect = tk.StringVar(value=self.cfg["aspect"])
        self.radio(r, self.v_aspect, ["4:3", "16:9"], self.aspect_changed).pack(side=tk.LEFT, padx=6)
        self.src_lbl = self.lbl(g, "", muted=True, anchor="w", font=F_SMALL, wraplength=360, justify=tk.LEFT)
        self.src_lbl.pack(fill=tk.X, padx=6)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=(3, 0))
        self.lbl(r, "Encoder mode").pack(side=tk.LEFT)
        self.v_enc = tk.StringVar()
        self.enc_box = ttk.Combobox(r, textvariable=self.v_enc, width=24, state="readonly")
        self.enc_box.pack(side=tk.LEFT, padx=6)
        self.enc_box.bind("<<ComboboxSelected>>", lambda e: self.enc_changed())
        self.enc_lbl = self.lbl(g, "", muted=True, anchor="w", font=F_SMALL)
        self.enc_lbl.pack(fill=tk.X, padx=6)
        self.lbl(g, "Fixed: interleave on, emphasis 75 \u00b5s, colour BT.601, 240x192 detail DCT", muted=True,
                 anchor="w", font=F_SMALL).pack(fill=tk.X, padx=6)
        w, h = self.pic_size()
        self.enc_cv = tk.Canvas(g, width=360, height=270, bg=DISPLAY, highlightthickness=0)
        self.enc_cv.pack(padx=6, pady=4)
        # where the video file / stream is: drag or click to move it (live streams: the time running)
        pr = self.frame(g)
        pr.pack(fill=tk.X, padx=6)
        self.pos_t = self.lbl(pr, "", font=F_SMALL, width=8, anchor="w")
        self.pos_t.pack(side=tk.LEFT)
        self.v_pos = tk.DoubleVar(value=0.0)
        self.pos_bar = ttk.Scale(pr, from_=0.0, to=1.0, orient=tk.HORIZONTAL, variable=self.v_pos, length=260)
        self.pos_bar.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        self.pos_d = self.lbl(pr, "", font=F_SMALL, width=8, anchor="e")
        self.pos_d.pack(side=tk.LEFT)
        self.pos_drag = False
        self.pos_shown = None
        self.pos_bar.bind("<ButtonPress-1>", self.pos_press)
        self.pos_bar.bind("<B1-Motion>", self.pos_motion)
        self.pos_bar.bind("<ButtonRelease-1>", self.pos_release)
        self.lbl(g, "Sending (one of the three pictures in each data frame)", muted=True, font=F_SMALL).pack(anchor="w", padx=6)
        self.enc_info = self.lbl(g, "", muted=True, font=F_SMALL, justify=tk.LEFT, anchor="w", wraplength=360)
        self.enc_info.pack(fill=tk.X, padx=6, pady=(4, 0))
        self.lbl(g, "Audio in (L / R)", muted=True, font=F_SMALL).pack(anchor="w", padx=6, pady=(6, 0))
        self.ain_cv = tk.Canvas(g, width=360, height=16, bg=DISPLAY, highlightthickness=0)
        self.ain_cv.pack(padx=6, pady=2)
        self.log_lbl = tk.Label(g, text="", bg=CARD, fg="#e5c07b", font=F_SMALL, justify=tk.LEFT, anchor="nw", wraplength=360)
        self.log_lbl.pack(fill=tk.BOTH, expand=True, padx=6, pady=4)
        return g

    def build_centre(self, parent):
        g = self.group(parent, "On the air")
        # the 200 kHz around the channel, as in ExSDR: what comes in on receive, what goes out on transmit
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6)
        self.lbl(r, "Spectrum and waterfall, 200 kHz (click to tune)", muted=True, font=F_SMALL).pack(side=tk.LEFT)
        self.sp_info = self.lbl(r, "", font=F_SMALL)
        self.sp_info.pack(side=tk.RIGHT)
        self.sp_cv = tk.Canvas(g, width=600, height=120, bg=DISPLAY, highlightthickness=0, cursor="crosshair")
        self.sp_cv.pack(fill=tk.X, padx=6)
        self.wf2_cv = tk.Canvas(g, width=600, height=140, bg=DISPLAY, highlightthickness=0, cursor="crosshair")
        self.wf2_cv.pack(fill=tk.X, padx=6, pady=(1, 2))
        for cv in (self.sp_cv, self.wf2_cv):
            cv.bind("<Button-1>", self.spec_click)
            cv.bind("<Button-4>", lambda e: self.digit_step(len(self.digits) - 4, 1))     # (wheel: 1 kHz)
            cv.bind("<Button-5>", lambda e: self.digit_step(len(self.digits) - 4, -1))
            cv.bind("<MouseWheel>", lambda e: self.digit_step(len(self.digits) - 4, 1 if e.delta > 0 else -1))
        self.wf_lines = None
        self.wide_ref = None
        self.slider(g, "Waterfall range dB", "wf_rng", 30, 110, 5, "%d", cmd=lambda: None, length=220)
        cols = self.frame(g)
        cols.pack(fill=tk.X, pady=(4, 0))
        frow = self.frame(cols)                           # (frequency and meter, then the 10 m channels to their right)
        frow.pack(side=tk.TOP, fill=tk.X, padx=6)
        left = self.frame(frow)
        left.pack(side=tk.LEFT, anchor="n")
        chb = self.frame(frow)
        chb.pack(side=tk.LEFT, anchor="n", padx=(14, 0))
        self.lbl(chb, "10 m channels", font=F_HEAD).pack(anchor="w")
        self.lbl(chb, "100 kHz each, 29.0 - 29.5 MHz", muted=True, font=F_SMALL).pack(anchor="w")
        self.ch_btns = []

        def chan_btn(parent, band, name, hz):
            b = tk.Button(parent, text="%s  %.3f" % (name, hz / 1e6), command=lambda: self.goto_channel(name, hz, band),
                          bg="#323942", fg=FG, activebackground="#3d4651", activeforeground=FG, relief=tk.FLAT, font=F,
                          padx=4, pady=1, highlightthickness=0, anchor="w", width=11)
            self.ch_btns.append((b, hz))
            return b
        for name, hz in CHANNELS_10M:
            chan_btn(chb, "10 m", name, hz).pack(anchor="w", pady=1)
        # 6 m: ten channels, two columns of five, to the right of the 10 m ones
        c6 = self.frame(frow)
        c6.pack(side=tk.LEFT, anchor="n", padx=(12, 0))
        self.lbl(c6, "6 m channels", font=F_HEAD).pack(anchor="w")
        self.lbl(c6, "100 kHz each, 51.0 - 52.0 MHz", muted=True, font=F_SMALL).pack(anchor="w")
        gr = self.frame(c6)
        gr.pack(anchor="w")
        for k, (name, hz) in enumerate(CHANNELS_6M):
            chan_btn(gr, "6 m", name, hz).grid(row=k % 5, column=k // 5, sticky="w", padx=(0, 3), pady=1)
        # frequency readout (as ExSDR): the channel's centre; wheel or click a digit to tune
        self.lbl(left, "Frequency (channel centre)", font=F_HEAD).pack(anchor="w")
        self.fq_box = tk.Frame(left, bg=DISPLAY, padx=8, pady=2, highlightthickness=1, highlightbackground=BORDER)
        self.fq_box.pack(anchor="w")
        self.set_digit_colours(self.cfg.get("digit_colour", "Amber"))
        self.fill_digits()
        self.lo_lbl = self.lbl(left, "", muted=True, font=F_SMALL, anchor="w", justify=tk.LEFT, wraplength=260)
        self.lo_lbl.pack(fill=tk.X)
        r = self.frame(left)
        r.pack(anchor="w", pady=(2, 0))
        self.lbl(r, "kHz", muted=True, font=F_SMALL).pack(side=tk.LEFT)
        self.e_freq = ttk.Entry(r, width=12)
        self.e_freq.pack(side=tk.LEFT, padx=4)
        self.e_freq.bind("<Return>", self.freq_entered)
        self.btn(r, "-1k", lambda: self.set_tune(self.tune_hz - 1000)).pack(side=tk.LEFT, padx=1)
        self.btn(r, "+1k", lambda: self.set_tune(self.tune_hz + 1000)).pack(side=tk.LEFT, padx=1)
        # signal meter, under the frequency
        self.meter = tk.Canvas(left, width=self.SM_X1 + 90, height=36, bg=DISPLAY, highlightthickness=0)
        self.meter.pack(anchor="w", pady=(5, 0))
        self.lvl_s = -120.0
        self.build_smeter()
        self.sm_info = self.lbl(left, "", font=F_SMALL, anchor="w", justify=tk.LEFT, wraplength=260)
        self.sm_info.pack(fill=tk.X)
        self.update_freq_display()
        right = self.frame(cols)
        right.pack(side=tk.TOP, fill=tk.X, pady=(6, 0))
        self.lbl(right, "Modem (TX and RX)", font=F_HEAD).pack(anchor="w", padx=6)
        r = self.frame(right)
        r.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(r, "Guard", width=8, anchor="w").pack(side=tk.LEFT)
        self.v_cp = tk.StringVar(value=str(self.cfg["cp"]))
        self.radio(r, self.v_cp, ["0", "10", "25", "50", "100", "200", "300"], self.cp_changed).pack(side=tk.LEFT)
        r = self.frame(right)
        r.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(r, "Equaliser", width=8, anchor="w").pack(side=tk.LEFT)
        self.v_eq = tk.StringVar(value={"off": "Off", "level": "Pilot level", "common": "Common", "pilots": "Pilots",
                                        "taps": "Echo fit"}[self.cfg["eq"]])
        self.radio(r, self.v_eq, ["Off", "Pilot level", "Common", "Pilots", "Echo fit"], self.eq_changed).pack(side=tk.LEFT)
        r = self.frame(right)
        r.pack(fill=tk.X, padx=6, pady=1)
        self.check(r, "Long symbols (400)", "long_sym", self.long_changed)
        self.check(r, "16 pilots (HF)", "pilots16", self.pilots_changed)
        rf = self.frame(right)
        rf.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(rf, "Frame rate", width=8, anchor="w").pack(side=tk.LEFT)
        self.v_fr = tk.StringVar(value={0: "Full sound", 1: "Video first", 2: "Balanced"}.get(int(self.cfg.get("fixed_fps", 0)), "Full sound"))
        self.radio(rf, self.v_fr, list(C.FRAME_RATES), self.fixed_changed).pack(side=tk.LEFT)
        rp = self.frame(right)
        rp.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(rp, "TX peaks", width=8, anchor="w").pack(side=tk.LEFT)
        self.v_clip = tk.StringVar(value=self.cfg.get("clip", "Off"))
        self.radio(rp, self.v_clip, list(C.CLIP_LEVELS), self.clip_changed).pack(side=tk.LEFT)
        self.check(rp, "Peak-limited TX", "peak_tx", self.clip_changed)
        rs = self.frame(right)
        rs.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(rs, "Spread", width=8, anchor="w").pack(side=tk.LEFT)
        self.v_spread = tk.StringVar(value=self.cfg.get("spread", "Off"))
        self.radio(rs, self.v_spread, list(C.SPREADS), self.spread_changed).pack(side=tk.LEFT)
        self.v_ti = self.check(rs, "Fold peaks (TI)", "ti", self.ti_changed)
        rq = self.frame(right)
        rq.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(rq, "To 200 kHz", width=8, anchor="w").pack(side=tk.LEFT)
        self.v_tx200 = tk.StringVar(value=self.cfg.get("tx_path", "2x IFFT"))
        self.radio(rq, self.v_tx200, list(C.TX200), self.tx200_changed).pack(side=tk.LEFT)
        self.check(rq, "I/Q flip", "iqflip", self.iqflip_changed)          # (picture by line pair, sound by symbol)
        ra = self.frame(right)
        ra.pack(fill=tk.X, padx=6, pady=1)
        self.check(ra, "Auto mode (RX)", "auto_rx", self.auto_changed)
        self.check(ra, "Send mode word (TX)", "tx_word", self.word_changed)
        self.lbl(ra, "  Callsign").pack(side=tk.LEFT)
        self.v_call = tk.StringVar(value=self.cfg.get("callsign", ""))
        ce = ttk.Entry(ra, textvariable=self.v_call, width=9)
        ce.pack(side=tk.LEFT, padx=2)
        ce.bind("<Return>", self.call_changed)
        ce.bind("<FocusOut>", self.call_changed)
        rb = self.frame(right)
        rb.pack(fill=tk.X, padx=6, pady=1)
        self.check(rb, "Time stamp (UTC)", "tx_stamp", self.side_changed)
        self.lbl(rb, "  Locator").pack(side=tk.LEFT)
        self.v_grid = tk.StringVar(value=self.cfg.get("grid", ""))
        ge = ttk.Entry(rb, textvariable=self.v_grid, width=7)
        ge.pack(side=tk.LEFT, padx=2)
        ge.bind("<Return>", self.side_changed)
        ge.bind("<FocusOut>", self.side_changed)
        self.lbl(rb, "  Title").pack(side=tk.LEFT)
        self.v_title = tk.StringVar(value=self.cfg.get("title", ""))
        te = ttk.Entry(rb, textvariable=self.v_title, width=13)
        te.pack(side=tk.LEFT, padx=2)
        te.bind("<Return>", self.side_changed)
        te.bind("<FocusOut>", self.side_changed)
        r2 = self.frame(right)
        r2.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(r2, "Sync", width=8, anchor="w").pack(side=tk.LEFT)
        names = {"std": "Std", "hxdx": "HxDX", "lab": "PN"}
        self.v_sync = tk.StringVar(value=names.get(self.cfg["sync"], "PN"))
        self.radio(r2, self.v_sync, ["Std", "HxDX", "PN"], self.sync_changed).pack(side=tk.LEFT)
        self.btn(r2, "Resync", self.resync).pack(side=tk.LEFT, padx=6)
        self.check(r2, "RX mute (no signal)", "rx_mute", self.mute_changed)
        self.rw_lbl = self.lbl(g, "", muted=True, font=F_SMALL, anchor="w", justify=tk.LEFT)
        self.rw_lbl.pack(fill=tk.X, padx=6, pady=(3, 0))
        disp = self.frame(g)
        disp.pack(fill=tk.X, padx=6, pady=(4, 0))
        # vector scopes: video carriers on the left, audio carriers on the right
        self.const_cv = tk.Canvas(disp, width=SCOPE, height=SCOPE, bg=DISPLAY, highlightthickness=0)
        self.const_cv.pack(side=tk.LEFT)
        self.const_a_cv = tk.Canvas(disp, width=SCOPE, height=SCOPE, bg=DISPLAY, highlightthickness=0)
        self.const_a_cv.pack(side=tk.RIGHT)
        rr = self.frame(disp)
        rr.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=4)
        self.car_cv = tk.Canvas(rr, width=180, height=(SCOPE - 4) // 2, bg=DISPLAY, highlightthickness=0)
        self.car_cv.pack(fill=tk.X)
        self.sync_cv = tk.Canvas(rr, width=180, height=(SCOPE - 4) // 2, bg=DISPLAY, highlightthickness=0)
        self.sync_cv.pack(fill=tk.X, pady=(4, 0))
        self.modem_info = self.lbl(g, "", muted=True, font=F_SMALL, anchor="w", justify=tk.LEFT)
        self.modem_info.pack(fill=tk.X, padx=6, pady=(3, 2))
        return g

    # ------------------------------------------------------------ frequency readout (as ExSDR)
    def set_digit_colours(self, name):
        c = DIGIT_COLOURS.get(name, DIGIT_COLOURS["Amber"])
        self.DIGIT = c
        self.DIGIT_DIM = _mix(c, DISPLAY, 0.45)

    def digit_menu(self, event):
        m = tk.Menu(self.root, tearoff=0, bg=CARD, fg=FG, activebackground="#2d5f91", activeforeground=FG, bd=0)
        m.add_command(label="Display colour", state=tk.DISABLED)
        for name in DIGIT_COLOURS:
            m.add_command(label="  %s" % name, foreground=DIGIT_COLOURS[name],
                          command=lambda n=name: self.change_digit_colour(n))
        try:
            m.tk_popup(event.x_root, event.y_root)
        finally:
            m.grab_release()

    def change_digit_colour(self, name):
        self.cfg["digit_colour"] = name
        self.set_digit_colours(name)
        self.fill_digits()
        self.update_freq_display()
        try:
            self.meter.itemconfig(self.sm_txt, fill=self.DIGIT)
        except Exception:
            pass

    def ndigits(self):
        """8 digits up to 99.999.999 Hz, 10 for the HackRF (up to 6 GHz)."""
        return 10 if self.freq_range()[1] > 99999999 else 8

    def fill_digits(self):
        box = self.fq_box
        for w in box.winfo_children():
            w.destroy()
        font = (MONO, 24, "bold")
        n = self.ndigits()
        self.digits = []
        for i in range(n):
            d = tk.Label(box, text="0", font=font, fg=self.DIGIT, bg=DISPLAY, padx=0, bd=0, cursor="sb_v_double_arrow")
            d.pack(side=tk.LEFT)
            d.bind("<Button-1>", lambda e, i=i: self.digit_step(i, 1 if e.y < e.widget.winfo_height() / 2 else -1))
            d.bind("<Button-4>", lambda e, i=i: self.digit_step(i, 1))
            d.bind("<Button-5>", lambda e, i=i: self.digit_step(i, -1))
            d.bind("<MouseWheel>", lambda e, i=i: self.digit_step(i, 1 if e.delta > 0 else -1))
            d.bind("<Button-3>", self.digit_menu)
            self.digits.append(d)
            if i < n - 1 and (n - 1 - i) % 3 == 0:            # G.MMM.kkk.hhh
                dot = tk.Label(box, text=".", font=font, fg=self.DIGIT_DIM, bg=DISPLAY, padx=0)
                dot.pack(side=tk.LEFT)
                dot.bind("<Button-3>", self.digit_menu)
        hz = tk.Label(box, text=" Hz", font=F_SMALL, fg=self.DIGIT_DIM, bg=DISPLAY)
        hz.pack(side=tk.LEFT, anchor="s")
        box.bind("<Button-3>", self.digit_menu)

    @property
    def tune_hz(self):
        return int(self.cfg.get("tune_hz", 29250000))

    def freq_range(self):
        """What the chosen hardware can tune (Hz)."""
        return HW_RANGE.get(self.cfg.get("hardware", "None"), HW_RANGE["None"])

    def update_freq_display(self):
        n = len(self.digits)
        s = "%0*d" % (n, self.tune_hz)
        lead = True
        for d, ch in zip(self.digits, s[-n:]):            # (leading zeros dimmed, as HDSDR / ExSDR)
            lead = lead and ch == "0"
            d.config(text=ch, fg=self.DIGIT_DIM if lead else self.DIGIT)
        hwn = self.cfg.get("hardware", "None")
        if hwn == "ExSDR radio":
            hwst = getattr(self.radio_link, "hw", {}) or {}
            t = "LO %d kHz, channel %+.1f kHz in the card\n%s" % (
                int(self.cfg.get("lo_khz", 0)), float(self.cfg.get("hw_offset", 0.0)),
                ("radio connected - pre-amp %s, att %s" % (
                    {True: "on", False: "off"}.get(hwst.get("pre"), "?"), {True: "on", False: "off"}.get(hwst.get("att"), "?")))
                if getattr(self.radio_link, "connected", False) else "radio NOT connected")
        elif hwn == "Airspy HF+":
            t = "Airspy HF+ on the channel, 192 kHz\nreceive only"
        elif hwn in SDRS:
            t = "%s LO %.4f MHz (%g kHz below)\n2 Msps%s" % (
                hwn, self.tune_hz / 1e6 - float(self.cfg.get("hw_lo_off", 250)) / 1000.0, float(self.cfg.get("hw_lo_off", 250)),
                " - receive only" if hwn in RX_ONLY else "")
        else:
            t = "No hardware: the receiver hears nothing;\nTX is shown and monitored here only"
        self.lo_lbl.config(text=t)
        self.e_freq.delete(0, tk.END)
        self.e_freq.insert(0, "%.3f" % (self.tune_hz / 1000.0))
        for b, hz in getattr(self, "ch_btns", []):        # (the channel the frequency is on, lit)
            on = self.tune_hz == hz
            near = abs(self.tune_hz - hz) < 50000
            b.config(bg="#2d5f91" if on else ("#2a3f55" if near else "#323942"))

    def goto_channel(self, name, hz, band="10 m"):
        lo, hi = self.freq_range()
        if not lo <= hz <= hi:
            self.log("%s (%.3f MHz) is outside what the %s can tune" % (name, hz / 1e6, self.cfg.get("hardware")))
            return
        self.set_tune(hz, recenter=True)
        self.log("%s %s: %.3f MHz (%.1f - %.1f MHz)" % (band, name, hz / 1e6, (hz - 50000) / 1e6, (hz + 50000) / 1e6))

    def digit_step(self, i, direction):
        if not 0 <= i < len(self.digits):
            return
        self.set_tune(self.tune_hz + direction * 10 ** (len(self.digits) - 1 - i))

    def freq_entered(self, ev=None):
        try:
            self.set_tune(int(round(float(self.e_freq.get().replace(",", "")) * 1000.0)), recenter=True)
        except ValueError:
            self.update_freq_display()

    def spec_click(self, e):
        W = max(1, e.widget.winfo_width())
        f = (e.x / float(W) - 0.5) * C.WIDE_SPAN
        self.set_tune(int(round((self.tune_hz + f) / 1000.0)) * 1000)

    def set_tune(self, hz, recenter=False):
        """Tune the channel centre.  ExSDR radio: the radio's LO in kHz (sent only when the channel would go
        more than 20 kHz from where it should sit in the card), the rest done in the card's I/Q; HackRF:
        hackrf_transfer started again on the new frequency (after the tuning stops for a moment)."""
        lo_f, hi_f = self.freq_range()
        hz = int(clamp(int(hz), lo_f, hi_f))
        self.cfg["tune_hz"] = hz
        hwn = self.cfg.get("hardware", "None")
        if hwn == "ExSDR radio":
            base = float(self.cfg.get("card_off_khz", 0.0))
            lo = int(self.cfg.get("lo_khz", 0))
            if recenter or abs(hz / 1000.0 - lo - base) > 20.0:
                lo = int(round(hz / 1000.0 - base))
                self.cfg["lo_khz"] = lo
                self.radio_link.set_freq_khz(lo)
            self.cfg["hw_offset"] = round(hz / 1000.0 - lo, 3)       # (the card's I/Q does the rest, live)
            self.settings_changed()
        elif hwn in SDRS:
            self.cfg["hw_freq"] = hz / 1e6
            if getattr(self, "_tune_job", None) is not None:
                self.root.after_cancel(self._tune_job)
            self._tune_job = self.root.after(400, self._tune_now)      # (a restart per wheel click: no)
        self.update_freq_display()
        self.wide_ref = None

    def _tune_now(self):
        self._tune_job = None
        self.log("%s: %.4f MHz" % (self.cfg.get("hardware"), self.tune_hz / 1e6))
        self.settings_changed()

    # ------------------------------------------------------------ transmit / receive, hardware
    def ptt_toggle(self, on=None):
        on = (not self.cfg.get("ptt", 0)) if on is None else bool(on)
        if on and self.cfg.get("hardware") in RX_ONLY:
            self.log("%s is receive only - no TX" % self.cfg.get("hardware"))
            return
        if on and self.cfg.get("sw_loop", 0):
            self.log("Software loop back is on: the transmitter is already going straight into the receiver - untick it to use TX")
            return
        if on and self.cfg.get("loop_test", 0):
            self.log("Loop back test is on: the transmitter is already going into the card and back - untick it to use TX")
            return
        if on and self.cfg.get("hardware") == "None":
            self.log("TX with no hardware: shown and monitored here only")
        self.cfg["ptt"] = int(on)
        self.ptt_btn.config(bg="#c0392b" if on else "#323942", text="RX" if on else "TX")
        self.ptt_lbl.config(text="TRANSMIT" if on else "RECEIVE", fg="#ff6b6b" if on else "#6ccf7a")
        if on:                                            # the radio to TX first, then the I/Q out
            self.radio_link.submit_txrx("TX")
            self.apply_hw()
        else:                                             # the I/Q stopped, then the radio back to RX
            self.apply_hw()
            self.radio_link.submit_txrx("RX", delay=0.1)
        self.log("%s" % ("TRANSMIT" if on else "Receive"))
        self.wide_ref = None
        self.wide_q.clear()

    def loop_changed(self):
        """Loop back test: the transmitter out of the sound card and back in through a cable, the receiver
        decoding what comes back (as the lab's Loop) - the radio left on RX, no TX command."""
        c = self.cfg
        if c.get("loop_test", 0):
            if c.get("hardware") != "ExSDR radio":
                why = ("there is no hardware" if c.get("hardware") == "None" else
                       "an SDR can't send and receive at once" if c.get("hardware") in SDRS else "")
                self.log("Loop back test needs the ExSDR radio's sound card (%s)" % why)
                c["loop_test"] = 0
                self.v_loop.set(0)
                return
            if c.get("ptt", 0):
                self.ptt_toggle(False)
            if c.get("sw_loop", 0):                       # (one loop at a time)
                c["sw_loop"] = 0
                self.v_swloop.set(0)
            self.ptt_lbl.config(text="LOOP TEST", fg="#e5c07b")
            self.log("Loop back test: out of %s, back in through %s - connect line out to line in" % (
                c.get("card_out", "Default"), c.get("card_in", "Default")))
        else:
            self.ptt_lbl.config(text="RECEIVE", fg="#6ccf7a")
            self.log("Loop back test off: receive")
        self.wide_ref = None
        self.wide_q.clear()
        self.apply_hw()

    def sw_loop_changed(self):
        """Software loop back: the transmitter straight into the receiver inside the program - no sound card, SDR
        or radio (the hardware path is closed while it runs) - to test the modem and codec on their own."""
        c = self.cfg
        if c.get("sw_loop", 0):
            if c.get("ptt", 0):
                self.ptt_toggle(False)
            if c.get("loop_test", 0):                     # (one loop at a time)
                c["loop_test"] = 0
                self.v_loop.set(0)
            self.ptt_lbl.config(text="SOFTWARE LOOP", fg="#e5c07b")
            self.log("Software loop back: TX straight into RX inside the program (no hardware, the radio stays on RX)")
        else:
            self.ptt_lbl.config(text="RECEIVE", fg="#6ccf7a")
            self.log("Software loop back off: receive")
        self.wide_ref = None
        self.wide_q.clear()
        self.apply_hw()

    def hardware_changed(self):
        new = self.v_hardware.get()
        if self.cfg.get("ptt", 0):
            self.ptt_toggle(False)
        self.cfg["hardware"] = new
        if new != "ExSDR radio" and self.cfg.get("loop_test", 0):
            self.cfg["loop_test"] = 0
            self.v_loop.set(0)
            self.ptt_lbl.config(text="RECEIVE", fg="#6ccf7a")
        self.open_radio()
        self.fill_digits()
        self.set_tune(self.tune_hz, recenter=True)
        self.apply_hw()
        self.log("Hardware: %s" % new)

    def open_radio(self):
        old = getattr(self, "radio_link", None)
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        self.radio_link = R.NullRadio()
        if self.cfg.get("hardware") == "ExSDR radio":
            link = R.SerialLink(self.cfg, self.log)
            try:
                link.open()
                self.radio_link = link
                link.query_all()
            except Exception as e:
                self.log("Radio: %s - no radio control (Radio / I/Q setup... sets the port)" % e)

    def apply_hw(self):
        """The I/Q path from the hardware choice and TX / RX: the receiver's input, or the transmitter's output."""
        c = self.cfg
        hwn = c.get("hardware", "None")
        ptt = bool(c.get("ptt", 0))
        if hwn == "ExSDR radio":
            c["hw_out"], c["hw_in"] = c.get("card_out", "Default"), c.get("card_in", "Default")
        elif hwn == "HackRF":
            c["hw_out"] = c["hw_in"] = c.get("hackrf_dev") or "HackRF"
            c["hw_offset"] = 0.0
        elif hwn == "RTL-SDR":
            c["hw_out"], c["hw_in"] = "Default", "RTL-SDR #%d" % int(c.get("rtl_index", 0))
            c["hw_offset"] = 0.0
        elif hwn == "Airspy HF+":
            c["hw_out"], c["hw_in"] = "Default", ("Airspy HF+ %s" % c.get("airspy_serial", "")).strip()
            c["hw_offset"] = 0.0
        elif hwn == "SDRplay":
            a = str(c.get("sdr_args", "")).strip()
            c["hw_out"], c["hw_in"] = "Default", "SoapySDR driver=sdrplay" + ("," + a if a and "driver=" not in a else "")
            c["hw_offset"] = 0.0
        elif hwn == "SoapySDR":
            c["hw_out"] = c["hw_in"] = ("SoapySDR %s" % c.get("sdr_args", "")).strip()
            c["hw_offset"] = 0.0
        if hwn in RX_ONLY and ptt:                         # (receive only)
            c["ptt"] = 0
            ptt = False
        loop = bool(c.get("loop_test", 0)) and hwn == "ExSDR radio"
        sw = bool(c.get("sw_loop", 0))
        c["hw_mode"] = "Off" if (hwn == "None" or sw) else ("Loop" if loop else ("TX out" if ptt else "RX in"))
        c["tx_on"] = int(ptt or loop or sw)
        self.settings_changed()

    def poll_radio(self):
        """What the radio reported: the window follows it (its LO; TX / RX)."""
        link = getattr(self, "radio_link", None)
        if link is None:
            return
        while True:
            try:
                ev = link.events.get_nowait()
            except queue.Empty:
                break
            if ev[0] == "freq" and (len(ev) < 3 or ev[2]) and self.cfg.get("hardware") == "ExSDR radio":
                lo = int(ev[1])
                if lo != int(self.cfg.get("lo_khz", 0)):
                    self.cfg["lo_khz"] = lo
                    self.cfg["hw_offset"] = round(self.tune_hz / 1000.0 - lo, 3)
                    if abs(self.cfg["hw_offset"]) > C.HW_MAX_OFFSET / 1000.0:   # (too far off: follow the radio)
                        self.cfg["tune_hz"] = int((lo + float(self.cfg.get("card_off_khz", 0.0))) * 1000)
                        self.cfg["hw_offset"] = float(self.cfg.get("card_off_khz", 0.0))
                    self.settings_changed()
                self.update_freq_display()
            elif ev[0] in ("pre", "att"):                 # (the window follows what the radio says)
                key = "radio_" + ev[0]
                self.cfg[key] = int(bool(ev[1]))
                v = getattr(self, "v_" + key, None)
                if v is not None:
                    try:
                        v.set(self.cfg[key])
                    except Exception:
                        pass
                self.log("Radio: %s %s" % ("pre-amp" if ev[0] == "pre" else "attenuator", "on" if ev[1] else "off"))
                self.update_freq_display()
                self.radio_status()
            elif ev[0] == "tx":
                if bool(ev[1]) != bool(self.cfg.get("ptt", 0)):
                    self.log("Radio says %s (the window says %s)" % ("TX" if ev[1] else "RX",
                                                                     "TX" if self.cfg.get("ptt") else "RX"))
            elif ev[0] == "hello":
                self.log("Radio: %s" % ev[1])
                self.update_freq_display()

    # ------------------------------------------------------------ signal meter (as ExSDR)
    SM_X0, SM_X1 = 8, 210            # S0 ... S9+60

    def sm_x(self, db_s9):
        x0, x1 = self.SM_X0, self.SM_X1
        if db_s9 <= 0:
            t = 0.6 * clamp((db_s9 + 54.0) / 54.0, 0.0, 1.0)
        else:
            t = 0.6 + 0.4 * clamp(db_s9 / 60.0, 0.0, 1.0)
        return x0 + (x1 - x0) * t

    def build_smeter(self):
        c = self.meter
        for s_ in (1, 3, 5, 7, 9):
            x = self.sm_x((s_ - 9) * 6.0)
            c.create_line(x, 22, x, 27, fill=MUTED)
            c.create_text(x, 31, text=str(s_), fill=MUTED, font=F_SMALL)
        for d in (20, 40, 60):
            x = self.sm_x(d)
            c.create_line(x, 22, x, 27, fill="#c06060")
            c.create_text(x, 31, text="+%d" % d, fill="#c06060", font=F_SMALL)
        c.create_rectangle(self.SM_X0, 6, self.SM_X1, 18, outline="#2c3640", fill="#0b0f13")
        self.sm_bar = c.create_rectangle(self.SM_X0, 7, self.SM_X0, 17, outline="", fill=ACC)
        self.sm_bar2 = c.create_rectangle(self.sm_x(0), 7, self.sm_x(0), 17, outline="", fill="#e05252")
        self.sm_txt = c.create_text(self.SM_X1 + 8, 12, text="", anchor="w", fill=self.DIGIT, font=F_HEAD)
        self.sm_dbfs = c.create_text(self.SM_X1 + 8, 28, text="", anchor="w", fill=MUTED, font=F_SMALL)

    def draw_smeter(self, lvl, tx=False):
        c = self.meter
        if tx:
            c.coords(self.sm_bar, self.SM_X0, 7, self.SM_X0, 17)
            c.coords(self.sm_bar2, self.sm_x(0), 7, self.sm_x(0), 17)
            c.itemconfig(self.sm_txt, text="TX", fill="#ff6b6b")
            c.itemconfig(self.sm_dbfs, text="out %.0f dBFS" % lvl if lvl is not None else "")
            return
        c.itemconfig(self.sm_txt, fill=self.DIGIT)
        if lvl is None:
            lvl = -150.0
        self.lvl_s = 0.6 * self.lvl_s + 0.4 * lvl if self.lvl_s > -149 else lvl
        d = self.lvl_s - float(self.cfg.get("s9_dbfs", -60.0))
        x, x9 = self.sm_x(d), self.sm_x(0)
        c.coords(self.sm_bar, self.SM_X0, 7, min(x, x9), 17)
        c.coords(self.sm_bar2, x9, 7, max(x, x9), 17)
        txt = ("S%d" % int(clamp(round(9 + d / 6.0), 0, 9))) if d <= 0 else ("S9+%d" % int(round(d)))
        c.itemconfig(self.sm_txt, text=txt)
        c.itemconfig(self.sm_dbfs, text="%.0f dBFS" % self.lvl_s if self.lvl_s > -149 else "no input")

    # ------------------------------------------------------------ 200 kHz spectrum and waterfall
    WF_LUT = None

    def wf_lut(self):
        if App.WF_LUT is None:                            # ExSDR's: dark blue - blue - cyan - yellow - orange - white
            pos = [0.0, 0.25, 0.45, 0.65, 0.85, 1.0]
            x = np.linspace(0, 1, 256)
            App.WF_LUT = np.stack([np.interp(x, pos, c) for c in ([12, 20, 30, 240, 250, 255], [16, 50, 170, 220, 120, 255],
                                                                  [28, 120, 220, 90, 40, 255])], axis=1).astype(np.uint8)
        return App.WF_LUT

    def draw_wide(self, rows, tx=False):
        if not rows:
            return
        cv, wf = self.sp_cv, self.wf2_cv
        W = max(100, int(cv.winfo_width() or 0) or int(cv["width"]))
        H = int(cv["height"])
        p = np.asarray(rows[-1], np.float64)
        seen = p[p > -149]
        if not len(seen):
            seen = np.array([-150.0])
        floor = float(np.median(seen))
        top = float(np.max(seen))
        if self.wide_ref is None:
            self.wide_ref = [floor, top]
        self.wide_ref[0] = 0.8 * self.wide_ref[0] + 0.2 * floor
        self.wide_ref[1] = max(top, 0.97 * self.wide_ref[1] + 0.03 * top)
        ref = self.wide_ref[1] + 5.0
        rng = max(40.0, ref - self.wide_ref[0] + 15.0)
        cv.delete("all")
        span = C.WIDE_SPAN
        f0 = self.tune_hz - span / 2
        # the channel's 100 kHz
        x1, x2 = W * 0.25, W * 0.75
        cv.create_rectangle(x1, 0, x2, H - 14, fill="#3a1e1e" if tx else "#13283a", outline="")
        for k in range(-100, 101, 25):
            x = (k * 1000 + span / 2) / span * W
            cv.create_line(x, 0, x, H - 14, fill="#1d2630")
            if k % 50 == 0:
                cv.create_text(x, H - 7, text="%.0f" % ((f0 + span / 2 + k * 1000) / 1000.0), fill=MUTED, font=F_SMALL,
                               anchor="w" if k == -100 else ("e" if k == 100 else "center"))
        d = ref
        while d > ref - rng:
            y = (ref - d) / rng * (H - 16)
            cv.create_line(0, y, W, y, fill="#1d2630")
            d -= 10.0
        xs = np.linspace(0, W, len(p))
        ys = np.clip((ref - p) / rng, 0, 1) * (H - 16)
        cv.create_line(*np.column_stack((xs, ys)).ravel().tolist(), fill="#ff8a65" if tx else "#7fd1ff")
        cv.create_line(W / 2, 0, W / 2, H - 14, fill="#e5c07b", dash=(3, 3))
        cv.create_text(4, 3, anchor="nw", text="TX out" if tx else "RX in", fill="#ff8a65" if tx else MUTED, font=F_SMALL)
        self.sp_info.config(text="%s   10 dB/div, kHz" % ("transmitting" if tx else "receiving"))
        # waterfall, newest at the top
        WW, WH = max(100, int(wf.winfo_width() or 0) or int(wf["width"])), int(wf["height"])
        if self.wf_lines is None or self.wf_lines.shape[1] != WW or self.wf_lines.shape[0] != WH:
            self.wf_lines = np.zeros((WH, WW, 3), np.uint8)
        wr = float(self.cfg.get("wf_rng", 70.0))
        lo = self.wide_ref[0] - 6.0
        for row in rows:
            v = np.interp(np.linspace(0, len(row) - 1, WW), np.arange(len(row)), np.asarray(row, np.float64))
            idx = (np.clip((v - lo) / wr, 0, 1) * 255).astype(np.uint8)
            self.wf_lines[1:] = self.wf_lines[:-1]
            self.wf_lines[0] = self.wf_lut()[idx]
        self.wf2_img = tk.PhotoImage(data=b"P6 %d %d 255\n" % (WW, WH) + self.wf_lines.tobytes(), format="PPM")
        wf.delete("all")
        wf.create_image(0, 0, image=self.wf2_img, anchor="nw")
        wf.create_line(WW / 2, 0, WW / 2, 4, fill="#e5c07b")

    def build_decoder(self, parent):
        g = self.group(parent, "Decoder and RX")
        self.dec_cv = tk.Canvas(g, width=360, height=270, bg=DISPLAY, highlightthickness=0)
        self.dec_cv.pack(padx=6, pady=4)
        self.rxsrc_lbl = self.lbl(g, "RX input: -", font=F_SMALL, anchor="w")
        self.rxsrc_lbl.pack(fill=tk.X, padx=6)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=(2, 0))
        self.lbl(r, "Upscale").pack(side=tk.LEFT)
        self.v_up = tk.StringVar(value=self.cfg.get("upscale", "Super-res"))
        self.radio(r, self.v_up, list(C.UPSCALE), self.upscale_changed).pack(side=tk.LEFT, padx=4)
        self.v_fps = tk.IntVar(value=int(self.cfg.get("fps25", 1)))
        tk.Checkbutton(r, text="25 fps", variable=self.v_fps, command=self.fps_changed, bg=r["bg"], fg=FG,
                       selectcolor=FIELD, activebackground=r["bg"], font=F).pack(side=tk.LEFT, padx=6)
        self.btn(r, "Large view", self.large_window).pack(side=tk.RIGHT)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=(2, 0))
        self.lbl(r, "Sound NR").pack(side=tk.LEFT)
        self.v_nr = tk.StringVar(value=self.cfg.get("audio_nr", "Auto"))
        self.radio(r, self.v_nr, list(C.AUDIO_NR), self.nr_changed).pack(side=tk.LEFT, padx=4)
        self.slider(g, "Volume dB", "volume", -40, 12, 1, "%+d", cmd=self.volume_changed)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=(2, 0))
        self.lbl(r, "Stereo compander R+L, R-L 2:1 (TX+RX)").pack(side=tk.LEFT)
        self.v_comp = tk.StringVar(value=C.compander_name(self.cfg.get("compander", "Off")))
        self.radio(r, self.v_comp, list(C.COMPANDERS), self.comp_changed).pack(side=tk.LEFT, padx=4)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=(2, 0))
        self.lbl(r, "Stereo as R+L / R-L:  M share").pack(side=tk.LEFT)
        self.v_msplit = tk.StringVar(value=self.cfg.get("ms_split", "Auto"))
        self.radio(r, self.v_msplit, list(C.MS_SPLITS), self.msplit_changed).pack(side=tk.LEFT, padx=4)
        r2 = self.frame(g)
        r2.pack(fill=tk.X, padx=6, pady=(2, 0))
        self.lbl(r2, "Sound").pack(side=tk.LEFT)
        self.v_amode = tk.StringVar(value=self.cfg.get("audio_mode", "Stereo"))
        self.radio(r2, self.v_amode, list(C.AUDIO_MODES), self.amode_changed).pack(side=tk.LEFT, padx=4)
        self.lbl(r2, " Common").pack(side=tk.LEFT)
        self.v_common = tk.StringVar(value=self.cfg.get("common", "Auto"))
        self.radio(r2, self.v_common, list(C.COMMON_MODES), self.amode_changed).pack(side=tk.LEFT, padx=4)
        self.lbl(r2, " Listen").pack(side=tk.LEFT)
        self.v_listen = tk.StringVar(value=self.cfg.get("listen", "Both"))
        self.radio(r2, self.v_listen, list(C.LISTEN), self.listen_changed).pack(side=tk.LEFT, padx=4)
        r3 = self.frame(g)
        r3.pack(fill=tk.X, padx=6, pady=(0, 0))
        self.ms_lbl = self.lbl(r3, "", font=F_SMALL, anchor="w")
        self.ms_lbl.pack(side=tk.LEFT, padx=4)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.check(r, "Y+C (colour)", "ycol", lambda: None)
        self.check(r, "Key only (Ave)", "key_only", lambda: None)
        self.check(r, "Sound", "audio_out", lambda: None)
        self.slider(g, "Brightness", "bright", -80, 80, 1, "%d", cmd=lambda: None)
        self.slider(g, "Contrast", "contrast", 0.3, 2.0, 0.05, "%.2f", cmd=lambda: None)
        self.slider(g, "Colour", "colour", 0.0, 2.0, 0.05, "%.2f", cmd=lambda: None)
        self.slider(g, "Sharpness", "sharp", 0.0, 2.0, 0.05, "%.2f", cmd=lambda: None)
        self.slider(g, "Lip sync ms", "lip_ms", -300, 300, 10, "%+d", cmd=lambda: None)
        self.slider(g, "Key mix", "kmx", 1, 5, 1, "%d", cmd=lambda: None)
        self.lbl(g, "Clean-up for poor signals", font=F_HEAD).pack(anchor="w", padx=6, pady=(4, 0))
        self.auto_showing = False
        self.slider(g, "Fuzzy colour", "fuzzy_c", 0, 5, 1, "%d", cmd=self.cleanup_moved)
        self.slider(g, "Fuzzy picture", "fuzzy_p", 0, 5, 1, "%d", cmd=self.cleanup_moved)
        self.slider(g, "Colour over frames", "cavg", 0.0, 0.8, 0.05, "%.2f", cmd=self.cleanup_moved)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=1)
        self.v_median = self.check(r, "Colour median", "median_c", self.cleanup_moved)
        self.v_autof = self.check(r, "Auto (by SNR)", "auto_f", self.autof_changed)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=1)
        self.check(r, "Motion search", "msearch")
        self.check(r, "Track colour", "ctrack")
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=1)
        self.lbl(r, "Temporal NR").pack(side=tk.LEFT)
        self.v_tnr = tk.StringVar(value=self.cfg.get("tnr", "Auto"))
        self.radio(r, self.v_tnr, list(C.TNR_MODES), self.tnr_changed).pack(side=tk.LEFT, padx=4)
        r = self.frame(g)
        r.pack(fill=tk.X, padx=6, pady=4)
        self.btn(r, "Save picture", self.save_pic).pack(side=tk.LEFT)
        self.rec_btn = self.btn(r, "Record", self.record)
        self.rec_btn.pack(side=tk.LEFT, padx=4)
        self.btn(r, "Defaults", self.dec_defaults).pack(side=tk.LEFT)
        self.lbl(g, "Audio out (L / R)", muted=True, font=F_SMALL).pack(anchor="w", padx=6, pady=(6, 0))
        self.aout_cv = tk.Canvas(g, width=360, height=16, bg=DISPLAY, highlightthickness=0)
        self.aout_cv.pack(padx=6, pady=2)
        # the receiver's information, under the sound meters
        self.dec_info = self.lbl(g, "", font=F_SMALL, anchor="nw", justify=tk.LEFT, wraplength=355, height=8)
        self.dec_info.pack(fill=tk.X, padx=6, pady=(4, 0))
        return g

    # ------------------------------------------------------------ control
    def settings_changed(self):
        # (flags only - no waiting for the engine's lock, which it holds through a whole frame: a slow
        # frame used to freeze the window here)
        if not self.eng.rebuild_needed:
            self.eng.apply()

    def rebuild(self):
        self.eng.rebuild_gen = getattr(self.eng, "rebuild_gen", 0) + 1
        self.eng.rebuild_needed = True

    def mute_changed(self):
        """RX mute: with no signal, the NO SIGNAL screen (on) or the noise that is coming in, shown as
        video noise (off)."""
        self.log("RX mute %s" % ("on: NO SIGNAL shown when there is none" if self.cfg["rx_mute"] else
                                 "off: with no signal, the receiver's noise is shown"))
        if getattr(self, "no_signal", False) and self.cfg["rx_mute"]:
            self.show_rx(None, blank=True)

    def fixed_changed(self):
        """Frame rate: Full sound (a guard costs pictures), Video first (a guard costs sound - 12.5 fps, or
        as near as the guard allows), Balanced (both the same share)."""
        self.cfg["fixed_fps"] = {"Full sound": 0, "Video first": 1, "Balanced": 2}.get(self.v_fr.get(), 0)
        self.log(self.fixed_text())
        self.apply_source()
        self.rebuild()

    def fixed_text(self):
        c = self.cfg
        lg, cp = bool(c.get("long_sym", 0)), int(c["cp"])
        kind = int(c.get("fixed_fps", 0))
        name = {0: "Full sound", 1: "Video first", 2: "Balanced"}[kind]
        full = C.layout(c["mode"], lg, cp, 0, int(c.get("pilots16", 0)))
        fps_full = full.halves * 3 / C.frame_seconds(full, cp)
        if kind == 0:
            return ("Frame rate Full sound: a guard makes each frame longer - %.1f fps with guard %d, the sound keeps "
                    "all its carriers (12 kHz)" % (fps_full, cp))
        if cp <= 0:
            return "Frame rate %s: no guard, so nothing changes (12.5 fps, full sound)" % name
        lay = C.layout(c["mode"], lg, cp, kind, int(c.get("pilots16", 0)))
        fps = lay.halves * 3 / C.frame_seconds(lay, cp)
        if not lay.fixed_cp:
            return ("Frame rate %s: guard %d is too long for it with %d carriers (the video would not fit) - "
                    "the normal layout is used: %.1f fps" % (name, cp, 400 if lg else 200, fps))
        nb = C.audio_capacity(lay) * 2 // lay.halves
        ms = C.sound_coder(nb, "Dual" if c.get("audio_mode", "Stereo") == "Dual mono" else c.get("ms_split", "Auto"))
        share = len(lay.audio_bins) / float(len(full.audio_bins))
        note = ""
        if kind == 1 and fps < 12.45:
            note = (" - the guard is longer than the sound can pay for, so the sound is at its least and the "
                    "frame rate as near 12.5 as it gets")
        return ("Frame rate %s: FFT %d + guard %d - %.1f fps (Full sound would give %.1f); the sound %d of %d carriers "
                "(%.0f%%): %s%s" % (name, lay.nfft, cp, fps, fps_full, len(lay.audio_bins), len(full.audio_bins),
                                     100 * share, ms.describe(), note))

    def amode_changed(self):
        """Stereo (R+L / R-L) or dual mono (Ch 1 = left in, Ch 2 = right in: two languages); common mode."""
        self.cfg["audio_mode"] = self.v_amode.get()
        self.cfg["common"] = self.v_common.get()
        if self.cfg["audio_mode"] == "Dual mono":
            lay = C.layout(self.cfg["mode"], bool(self.cfg.get("long_sym", 0)), int(self.cfg["cp"]),
                           int(self.cfg.get("fixed_fps", 0)), bool(self.cfg.get("pilots16", 0)))
            nb = C.audio_capacity(lay) * 2 // lay.halves
            self.log("Sound: %s; left in = Ch 1, right in = Ch 2.  Common %s" % (
                C.DualCoder(nb).describe(),
                {"Auto": "auto: when the two inputs are the same, Ch 1 goes out on both and the receiver averages them (+3 dB)",
                 "On": "on: Ch 1 sent on both halves, the receiver averages them (+3 dB); Ch 2 not sent",
                 "Off": "off: the two channels always sent separately"}[self.cfg["common"]]))
        else:
            self.log("Sound: stereo as R+L / R-L (the M share sets the split)")
        self.settings_changed()

    def listen_changed(self):
        self.cfg["listen"] = self.v_listen.get()
        self.log("Listen: %s" % {"Both": "Ch 1 left, Ch 2 right (dual mono) - stereo as it is",
                                 "Ch 1": "Ch 1 on both speakers (dual mono only)",
                                 "Ch 2": "Ch 2 on both speakers (dual mono only)"}[self.cfg["listen"]])

    def msplit_changed(self):
        self.cfg["ms_split"] = self.v_msplit.get()
        lay = C.layout(self.cfg["mode"], bool(self.cfg.get("long_sym", 0)), int(self.cfg["cp"]),
                       int(self.cfg.get("fixed_fps", 0)), bool(self.cfg.get("pilots16", 0)))
        nb = C.audio_capacity(lay) * 2 // lay.halves
        ms = C.MSCoder(nb, self.cfg["ms_split"])
        self.log("Sum/diff split %s: %s%s" % (
            self.cfg["ms_split"], ms.describe(),
            "" if nb < 2 * C.MS_FULL else " - this layout has room for both at full rate, so the split changes nothing"))
        self.settings_changed()

    def long_changed(self):
        """400 carriers at 250 Hz, 4 ms symbols, 0.48 s data frames of 6 pictures (each carrier still a
        line a frame); the source's timing follows."""
        self.log("Long symbols %s" % ("on: 400 carriers at 250 Hz, 4 ms symbols, 0.48 s frames (6 pictures); "
                                      "a guard can be twice as long for the same share (HF echoes)"
                                      if self.cfg["long_sym"] else "off: 200 carriers at 500 Hz, 2 ms symbols"))
        self.apply_source()
        self.rebuild()

    def cc_changed(self):
        self.cfg["colour_coding"] = {v: k for k, v in CC_NAMES.items()}[self.v_cc.get()]
        self.eng.reset_decoder()
        self.log({"1/4": "Colour coding 1/4 range (as CPU1: Saturation 0.5, (R + 255 - Y) / 2) - the colour noise x4",
                  "3/4": "Colour coding 3/4 range: R-Y byte = 0.75 (R - Y) + 127.5 - three times the swing, noise x1.33",
                  "BT.601": "Colour coding BT.601: Y = .299 R + .587 G + .114 B, full range Cr / Cb - green keeps clean"}
                 [self.cfg["colour_coding"]])

    def detail_changed(self):
        self.cfg["detail"] = "dct" if self.v_detail.get().startswith("DCT") else "masks"
        with self.eng.lock:
            self.eng.sent.clear()
            self.eng.reset_decoder()
        self.settings_changed()

    def mode_changed(self):
        new = self.v_mode.get()
        if new != self.cfg["mode"]:                      # as your RX's format button: Fuzzy 1 / 0
            for k in ("fuzzy_c", "fuzzy_p"):
                self.cfg[k] = 0 if new == "180x96" else 1
                if k in self.sliders:
                    v, val, fmt = self.sliders[k]
                    v.set(self.cfg[k])
                    val.config(text=fmt % self.cfg[k])
        self.cfg["mode"] = new
        self.rebuild()
        self.apply_source()

    def enc_names(self):
        m = C.MODES[self.cfg["mode"]]
        return [C.enc_name(m, k) for k in sdr_enc_list(m)]

    def enc_changed(self):
        names = self.enc_names()
        if self.v_enc.get() in names:
            self.cfg["enc"] = sdr_enc_list(C.MODES[self.cfg["mode"]])[names.index(self.v_enc.get())]
        with self.eng.lock:
            self.eng.sent.clear()
            self.eng.reset_decoder()
        self.apply_source()

    def gpu_changed(self):
        self.cfg["gpu"] = int(self.v_gpu.get())
        self.log("GPU %s" % ("on: Super-res, 25 fps and the motion search go to the NVIDIA card (CuPy), "
                             "falling back to the CPU if it can't" if self.cfg["gpu"] else "off: all on the CPU"))
        self.gpu_lbl.config(text=self.gpu_text())

    def gpu_text(self):
        """The GPU's state, as the decode and upscale workers last said."""
        if not self.cfg.get("gpu", 0):
            return "off (CPU)"
        eng = getattr(self, "eng", None)
        sts = [x for x in (getattr(eng, "gpu_dec", None), getattr(eng, "gpu_up", None))
               if x and x.get("want")]
        if not sts:
            return "waiting for the receiver"
        on = [x for x in sts if x.get("on")]
        if on:
            ms = [x["ms"] for x in on if x.get("ms") is not None]
            return "%s%s" % (on[0].get("name") or "GPU", ("   %.0f ms a call" % max(ms)) if ms else "")
        err = sts[0].get("err") or "not available"
        if err != getattr(self, "_gpu_err_logged", None):    # (the whole message, once, in the log)
            self._gpu_err_logged = err
            self.log("GPU not used - " + err)
        return "CPU - %s" % (err if len(err) <= 70 else err[:67] + "... (see the log)")

    def fps_changed(self):
        self.cfg["fps25"] = int(self.v_fps.get())
        self.log("25 fps %s" % ("on: a picture worked out between each two received (motion)" if self.cfg["fps25"]
                                else "off: the pictures as received (12.5 a second)"))

    def emph_changed(self):
        self.cfg["emph"] = self.v_emph.get().replace("\u00b5s", "us")
        self.log({"Off": "Emphasis off: the sound sent flat",
                  "50 us": "Emphasis 50 \u00b5s: treble lifted from 3.2 kHz at the TX, taken off at the RX (hiss -4 dB)",
                  "75 us": "Emphasis 75 \u00b5s: treble lifted from 2.1 kHz at the TX, taken off at the RX (hiss -6 dB)"}
                 [self.cfg["emph"]])

    def id_text(self):
        """The received callsign, time, locator and title (from the mode word), and frames found
        missing by its round."""
        call = getattr(self.eng, "rx_call", None)
        br = getattr(self.eng, "rx_breaks", 0) or 0
        sd = getattr(self.eng, "rx_side", None) or {}
        parts = []
        if call:
            parts.append("ID %s" % call)
        if sd.get("grid"):
            parts.append(sd["grid"])
        if sd.get("time"):
            parts.append(("%s " % sd["date"] if sd.get("date") else "") + sd["time"] + " UTC")
        if sd.get("title"):
            parts.append('"%s"' % sd["title"])
        if br:
            parts.append("frames out of turn: %d" % br)
        return ("   " + "   ".join(parts)) if parts else ""

    def side_changed(self, *_):
        """Time stamp, locator and title: more pages in the mode word's round (nothing more on the air)."""
        c = self.cfg
        g = self.v_grid.get().strip()
        g = (g[:2].upper() + g[2:4] + g[4:6].lower()) if g else ""
        if g and not C.grid_ok(g):
            self.log("Locator %s: not one the word can carry (4 or 6 characters, e.g. FN03 or FN03gp; "
                     "between 80 S and 80 N)" % g)
            g = c.get("grid", "")
        if g != self.v_grid.get():
            self.v_grid.set(g)
        t = "".join(ch for ch in self.v_title.get().upper() if ch in C.TITLE_CHARS)[:C.TITLE_LEN]
        if t != self.v_title.get():
            self.v_title.set(t)
        changed = (g != c.get("grid", "")) or (t != c.get("title", "")) or getattr(self, "_stamp_was", None) != c.get("tx_stamp", 0)
        c["grid"], c["title"] = g, t
        self._stamp_was = c.get("tx_stamp", 0)
        if changed:
            n = len(C.tx_pages(c.get("callsign", ""), bool(c.get("tx_stamp", 0)), g, t))
            self.log("Mode word pages: %d in the round besides the settings%s" % (
                n, (" - each comes round at least every %d frames" % (2 * n)) if n else " (settings every frame)"))

    def auto_text(self, au):
        """The Auto line: what the receiver found on the air, and what the mode word says."""
        if au.get("state") != "found":
            return "AUTO: listening (%.1f of %.1f s)%s" % (min(au.get("have_s", 0), au.get("need_s", 0)), au.get("need_s", 0),
                                                         ", try %d" % au["tries"] if au.get("tries") else "")
        t = "AUTO: %s, %d carriers%s%s, guard %d, %s sync" % (au["fmt"], 400 if au["long"] else 200,
                                                          {0: "", 1: " video first", 2: " balanced"}[int(au.get("fixed") or 0)],
                                                          " 16 pilots" if au.get("dense") else "", au["cp"],
                                                          {"std": "Std", "hxdx": "HxDX", "lab": "PN"}[au["sync"]])
        w = au.get("word")
        if w is None:
            return t + ("   |   no mode word: the last one heard is kept" if getattr(self.eng, "rx_word", None)
                        else "   |   no mode word: the settings here are used")
        fmt_ = au["fmt"] if au.get("fmt") in C.MODES else w["fmt"]      # (the format is told by the sync, not the word)
        mode = C.enc_name(C.MODES[fmt_], w["enc"]).split()
        parts = ["mode %s %s" % (mode[0], mode[-1]), "compander " + w["compander"]]
        age = au.get("word_age", 0)
        if au.get("callsign"):
            parts.append("ID " + au["callsign"])
        sd = au.get("side") or {}
        for k in ("grid", "time", "title"):
            if sd.get(k):
                parts.append(sd[k] + (" UTC" if k == "time" else ""))
        return t + "   |   word: " + ", ".join(parts) + ("" if age == 0 else
                                                       " (not heard for %d frames: kept)" % age if age < 99 else " (kept)")

    def call_changed(self, *_):
        """The callsign the mode word carries (up to 8 of A-Z 0-9 / - . and space), sent in turn with
        the settings: no more pilots, the same robustness."""
        t = "".join(ch for ch in self.v_call.get().upper() if ch in C.CALL_CHARS)[:C.CALL_LEN]
        if t != self.v_call.get():
            self.v_call.set(t)
        if t != self.cfg.get("callsign", ""):
            self.cfg["callsign"] = t
            self.log(("Callsign %s: sent in the mode word, in turn with the settings" % t)
                     if t.strip() else "No callsign")

    def auto_changed(self):
        self.eng.rx_word = None
        self.settings_changed()
        self.log("Auto mode on: the receiver finds the carriers, guard, format and sync itself, and takes the "
                 "rest from the transmitter's mode word" if self.cfg.get("auto_rx", 0)
                 else "Auto mode off: the receiver uses the settings here")

    def word_changed(self):
        self.log("Mode word sent: 16 bits on the pilots of a few symbols a frame (a receiver without Auto "
                 "loses some picture at good signals)" if self.cfg.get("tx_word", 1)
                 else "Mode word off: the pilots are sent as the pattern has them")

    def comp_changed(self):
        self.cfg["compander"] = self.v_comp.get()
        self.log({"Off": "Stereo compander off: L and R sent as they are",
                  "Syllabic": "Stereo compander, syllabic: R+L and R-L 2:1 from their level (1 ms up, 60 ms down), "
                              "expanded 1:2 at the RX",
                  "Instant": "Stereo compander, instant: R+L and R-L through a fixed 2:1 curve sample by sample, "
                             "the RX through its exact inverse - no attack, release or delay"}[self.cfg["compander"]])

    def tx200_changed(self):
        self.cfg["tx_path"] = self.v_tx200.get()
        self.settings_changed()
        self.eng.resync_needed = True                    # (a new path: the signal arrives at a new time)
        self.log("To 200 kHz: each sample twice + 50 kHz low pass, as the flowgraph does - the outer carriers roll off "
                 "(the sound most: about 2 dB more noise) and images are left just outside the band"
                 if self.cfg["tx_path"] == "Repeat + filter" else
                 "To 200 kHz: a 2N-point IFFT (papr_clip_ifft.py, oversample=2) - every carrier at the same level, no "
                 "images: the sound 1.1-1.8 dB better, the video 0.3 dB worse (it had the middle's extra)")

    def tnr_changed(self):
        self.cfg["tnr"] = self.v_tnr.get()
        self.settings_changed()
        self.log({"Off": "Temporal NR off",
                  "Light": "Temporal NR Light: each picture averaged with the last (moved to match) where they agree, up to 50 %",
                  "Auto": "Temporal NR Auto: up to 70 %, by the noise in the pictures and the signal's SNR (nothing on a clean "
                          "signal; off in 120x96 modes 1 and 2, where it would soften the 240x192 detail)",
                  "Strong": "Temporal NR Strong: up to 85 % - the most noise off, a little more risk of ghosts on fast motion"}
                 [self.cfg["tnr"]])

    def clip_changed(self):
        self.cfg["clip"] = self.v_clip.get()
        self.settings_changed()
        cl = C.clip_value(self.cfg["clip"])
        if cl is None:
            self.log("TX peaks: not limited (PAPR about 9.6 dB, one sample in 10,000)")
        else:
            self.log("TX peaks limited to %.0f dB over the average: the average can go up by what that saves - shown "
                     "live on the modem line (PAPR before -> after; real pictures save more than random bytes)%s" % (
                         cl, (". Peak-limited TX on: the channel's C/N goes up by that (the SNR slider is against the "
                              "unclipped average)") if self.cfg.get("peak_tx", 0) else
                         " (tick Peak-limited TX to have the lab's channel give it)"))
            if not self.cfg.get("scramble", 1):
                self.log("TX peaks with Scramble off: the clipping error is kept off the colour (R-Y, B-Y) and the "
                         "detail (DCT / wavelet) and eased on the sums and differences - it goes on the luma levels "
                         "and the sound instead (fine grain, not hue shifts or blocks). Real pictures peak 12-14 dB "
                         "unscrambled, so a little less comes off the peaks (about 0.5 dB)")

    def pilots_changed(self):
        on = bool(self.cfg.get("pilots16", 0))
        if on and self.cfg.get("long_sym", 0):
            self.log("16 pilots: the 400 carrier layouts have 16 (12 in 180x96) already - this is for 200 carriers")
        else:
            self.log("16 pilots %s: %s" % ("on" if on else "off",
                     "two pilots a group (12 in 180x96) - what the echo fit needs to find sky wave echoes with 200 "
                     "carriers; the sound gives up the carriers (40 of 48 in 120x96, 42 in 180x96: its sampling "
                     "rate 24 -> 20 / 21 kHz, audio bandwidth about 10 kHz). Auto mode finds it." if on else
                     "8 pilots (6 in 180x96), the sound's full 48 carriers"))
        self.rebuild()
        self.apply_source()

    def iqflip_changed(self):
        """I/Q flip by line: every other picture line, the carriers' I and Q change places (the receiver
        follows the settings word) - a phase error's leak between I and Q changes sign line to line."""
        w = C.MODES[self.cfg.get("mode", "120x96")].w
        self.log("I/Q flip %s" % ("on: I and Q change places every %d-byte picture line pair, and on every other symbol "
                                  "on the sound carriers - the scopes show the swapped points in another colour "
                                  "(the cloud's shape can't change: it is the same either side of its diagonal)" % w
                                  if self.cfg.get("iqflip", 0) else "off"))
        self.settings_changed()

    def ti_changed(self):
        """Tone injection: the sender moves a few values a fold away to take the peaks down; the receiver
        folds them back (it is told by the settings word).  It needs Spread off - ticking it sets it so
        (Scramble, which it needs too, is always on since 5.30)."""
        on = bool(self.cfg.get("ti", 0))
        if on:
            made = []
            if self.cfg.get("spread", "Off") != "Off":
                self.cfg["spread"] = "Off"
                self.v_spread.set("Off")
                made.append("Spread off")
            self.log("Fold peaks (TI) on: a few values a symbol sent a fold (3.0) away, the receiver folds them back - "
                     "peaks ~2 dB lower, nothing given up%s" % (("  (%s, as it needs)" % " and ".join(made)) if made else ""))
        else:
            self.log("Fold peaks (TI) off: values sent as they are")
        self.settings_changed()

    def spread_changed(self):
        """Spread: each picture value shared over a group of carriers (25 at a time - 8 groups at 200
        carriers, 16 at 400 - or all of them), so a fade's damage is spread thin instead of wiping out a
        few values (fewer wavelet blocks and hue errors, a little more fine noise).  The receiver follows
        the sender's settings word."""
        self.cfg["spread"] = self.v_spread.get()
        if self.cfg["spread"] != "Off" and self.cfg.get("ti", 0):    # (Fold doesn't go with Spread)
            self.cfg["ti"] = 0
            self.v_ti.set(0)
            self.log("Fold peaks (TI) off: it doesn't go with Spread")
        self.log({"Off": "Spread off: each picture value on its own carrier",
                  "Groups": "Spread: each picture value shared over its group of ~25 carriers (8 groups at 200, 16 at 400)",
                  "Whole band": "Spread: each picture value shared over all the picture carriers"}[self.cfg["spread"]])
        self.settings_changed()

    def cleanup_moved(self, *_):
        """A clean-up control moved: your setting takes over from Auto."""
        if self.auto_showing:
            return
        if self.cfg.get("auto_f", 0):
            self.cfg["auto_f"] = 0
            self.v_autof.set(0)
            self.log("Clean-up Auto off: your settings are used")

    def autof_changed(self):
        self.log("Clean-up Auto: the sliders follow the SNR (moving one turns Auto off)" if self.cfg.get("auto_f", 0)
                 else "Clean-up Auto off: the sliders as set")
        if not self.cfg.get("auto_f", 0):                # back to what the sliders were set to
            for k in ("fuzzy_c", "fuzzy_p", "cavg"):
                self.show_slider(k, self.cfg[k])
            self.auto_showing = True
            try:
                self.v_median.set(int(self.cfg.get("median_c", 0)))
            finally:
                self.auto_showing = False

    def show_slider(self, k, x):
        if k in self.sliders:
            v, val, fmt = self.sliders[k]
            self.auto_showing = True
            try:
                v.set(x)
                val.config(text=fmt % x)
            finally:
                self.auto_showing = False

    def show_auto_cleanup(self, fu):
        """Auto on: the sliders show what Auto chose (the settings themselves are left alone)."""
        if not self.cfg.get("auto_f", 0) or fu is None:
            return
        self.show_slider("fuzzy_c", int(fu[0]))
        self.show_slider("fuzzy_p", int(fu[1]))
        self.show_slider("cavg", float(fu[3]))
        self.auto_showing = True
        try:
            self.v_median.set(int(bool(fu[2])))
        finally:
            self.auto_showing = False

    def volume_changed(self, *_):
        v = float(self.cfg.get("volume", 0.0))
        self.avp.gain = 0.0 if v <= -40 else 10 ** (v / 20.0)     # (at the bottom: off)

    def nr_changed(self):
        self.cfg["audio_nr"] = self.v_nr.get()
        self.log({"Off": "Sound NR off",
                  "Light": "Sound NR Light: the hiss turned down by up to 12 dB where there is no sound",
                  "Strong": "Sound NR Strong: up to 20 dB, for a signal down in the noise",
                  "Auto": "Sound NR Auto: off with a clean signal, Light below 32 dB, Strong below 21 dB (RX SNR)"}
                 [self.cfg["audio_nr"]])

    def upscale_changed(self):
        self.cfg["upscale"] = self.v_up.get()
        for k in ("up_sharp", "up_plain", "up_noint"):     # (your choice now: any stepping down forgotten)
            setattr(self.eng, k, 0)
        self.eng.up_n, self.eng.up_ema = 0, None
        self.log({"Off": "Upscale off: the pictures are enlarged plainly (bilinear)",
                  "Sharp": "Upscale Sharp: each picture enlarged to fit what was received (back-projection)",
                  "Super-res": "Upscale Super-res: the key pictures either side add the detail between the pixels"}
                 [self.cfg["upscale"]])

    def large_window(self):
        """The received pictures in a window of their own, as big as you like: drag an edge or a corner
        (the picture keeps its shape - bars where the window is another shape), keys 1-4 for 1x-4x the
        received size, F11 or a double click for the whole screen (Esc back).  The size is remembered."""
        if getattr(self, "lg_win", None) is not None:
            try:
                self.lg_win.lift()
                return
            except Exception:
                self.lg_win = None
        w = tk.Toplevel(self.root, bg=DISPLAY)
        w.title("Received picture - large (drag the edges; 1-4: size, F11: full screen)")
        pw, ph = self.pic_size()
        try:
            gw, gh = [int(v) for v in str(self.cfg.get("large_size", "")).split("x")]
        except ValueError:
            gw, gh = 2 * pw, 2 * ph
        gw, gh = max(160, gw), max(120, gh)
        self.lg_cv = tk.Canvas(w, width=gw, height=gh, bg=DISPLAY, highlightthickness=0)
        self.lg_cv.pack(fill=tk.BOTH, expand=True)
        self.lg_lbl = tk.Label(w, text="", bg=CARD, fg=MUTED, font=F_SMALL, anchor="w")
        self.lg_lbl.pack(fill=tk.X)
        w.minsize(160, 140)
        self.lg_win = w
        self.lg_full = False
        self.lg_redraw = None

        def closed():
            try:
                if not self.lg_full:
                    self.cfg["large_size"] = "%dx%d" % (self.lg_cv.winfo_width(), self.lg_cv.winfo_height())
            except Exception:
                pass
            self.lg_win = None
            w.destroy()
        w.protocol("WM_DELETE_WINDOW", closed)

        def resized(ev):                                  # (a new size: drawn again once it settles)
            if self.lg_redraw is not None:
                try:
                    w.after_cancel(self.lg_redraw)
                except Exception:
                    pass
            self.lg_redraw = w.after(40, lambda: self.draw_large(getattr(self, "last_rx", None), True))
        self.lg_cv.bind("<Configure>", resized)

        def size_x(k):
            if self.lg_full:
                full(False)
            pw_, ph_ = self.pic_size()
            lh = self.lg_lbl.winfo_height() or 18
            w.geometry("%dx%d" % (k * pw_, k * ph_ + lh))

        def full(on=None):
            on = (not self.lg_full) if on is None else on
            self.lg_full = on
            try:
                w.attributes("-fullscreen", on)
            except Exception:
                pass
            if on:
                self.lg_lbl.pack_forget()
            else:
                self.lg_lbl.pack(fill=tk.X)
        for k in (1, 2, 3, 4):
            w.bind(str(k), lambda e, k=k: size_x(k))
        w.bind("<F11>", lambda e: full())
        w.bind("<Escape>", lambda e: full(False))
        self.lg_cv.bind("<Double-Button-1>", lambda e: full())
        if getattr(self, "last_rx", None) is not None:
            self.draw_large(self.last_rx)

    def big_photo(self, rgb, w, h):
        """A large picture for Tk: by PIL when it is there (much quicker for big sizes), else as photo()."""
        try:
            from PIL import Image, ImageTk
            a = resize(rgb, w, h, smooth=True)
            return ImageTk.PhotoImage(Image.fromarray(np.ascontiguousarray(a), "RGB"))
        except Exception:
            return self.photo(rgb, w, h)

    def draw_large(self, rgb, resized=False):
        if getattr(self, "lg_win", None) is None or rgb is None:
            return
        try:
            CW, CH = int(self.lg_cv.winfo_width() or 0), int(self.lg_cv.winfo_height() or 0)
        except Exception:
            CW = CH = 0                                   # (not on the screen yet)
        pw, ph = self.pic_size()
        if CW < 20 or CH < 20:
            CW, CH = 2 * pw, 2 * ph
        s = min(CW / float(pw), CH / float(ph))           # (the picture's own shape kept)
        W, H = max(2, int(pw * s)), max(2, int(ph * s))
        self.lg_img = self.big_photo(rgb, W, H)
        self.lg_shown = (W, H, CW, CH)
        self.lg_cv.delete("all")
        self.lg_cv.create_image(CW // 2, CH // 2, image=self.lg_img, anchor="center")
        if not self.lg_full:
            self.lg_lbl.config(text="%s received, shown %dx%d (x%.1f)   upscale: %s   - drag the edges, 1-4: size, "
                               "F11 / double click: full screen" % (
                                   getattr(self, "rx_native", "%dx%d" % (rgb.shape[1], rgb.shape[0])), W, H,
                                   W / float(pw), self.cfg.get("upscale", "Off")))

    def multi_changed(self):
        self.cfg["multicore"] = int(self.v_multi.get())
        self.log("Multi-core %s: the modem and the decoder %s" % (
            ("on", "each run in a process of their own") if self.cfg["multicore"] else ("off", "run in the engine thread")))

    def cp_changed(self):
        self.cfg["cp"] = int(self.v_cp.get())
        if self.cfg.get("fixed_fps", 0):
            self.log(self.fixed_text())
        self.rebuild()
        self.apply_source()                               # a guard makes the frames longer: fewer pictures a second

    def eq_changed(self):
        self.cfg["eq"] = {"Off": "off", "Pilot level": "level", "Common": "common", "Pilots": "pilots",
                          "Echo fit": "taps"}[self.v_eq.get()]
        self.settings_changed()

    def sync_changed(self):
        self.cfg["sync"] = {"Std": "std", "HxDX": "hxdx", "PN": "lab"}[self.v_sync.get()]
        self.rebuild()

    def resync(self):
        self.eng.resync()

    def open_tc_editor(self):
        """The test card editor (from ExSDR): a test card or your own picture, with text on it - Set +
        Save makes it the Picture source."""
        try:
            import testcard_editor as TE
        except Exception as e:
            self.log("Test card editor: can't load it (%s)" % e)
            return
        if getattr(self, "tc_host", None) is None:
            self.tc_host = TE.Host(self, (BG, CARD, FG, MUTED, ACC, FIELD, BORDER, DISPLAY), (F, F_SMALL, F_HEAD))
        TE.open_editor(self.tc_host)

    def tc_builtin_card(self, w, h):
        """The lab's own test card, still (for the editor's "NBTV Lab" button)."""
        return test_card(w, h, 0.0)

    def tc_use_picture(self, path, img):
        """The editor's Set + Save: the saved card becomes the Picture source."""
        self.cfg["picture"] = path
        self.cfg["source"] = "Picture"
        self.v_src.set("Picture")
        self.log("Test card editor: %s is the picture now" % os.path.basename(path))
        self.apply_source()

    def source_changed(self):
        self.cfg["source"] = self.v_src.get()
        k = self.cfg["source"]
        if ((k == "Picture" and not self.cfg["picture"]) or (k == "Video file" and not self.cfg["video"])
                or (k == "Stream URL" and not self.cfg.get("stream_url"))):
            self.load()
            return
        self.apply_source()

    def aspect_changed(self):
        self.cfg["aspect"] = self.v_aspect.get()
        if self.v_src.get() == "Screen":                 # as the TX's aspect button: the area's start
            self.cfg["screen_x"] = 124 if self.cfg["aspect"] == "16:9" else 12
            if self.cfg["aspect"] == "4:3":
                self.cfg["screen_y"] = 80
            for k in ("screen_x", "screen_y"):
                v, val, fmt = self.sliders[k]
                v.set(self.cfg[k])
                val.config(text=fmt % self.cfg[k])
        self.apply_source()

    def play_changed(self):
        self.eng.source.paused = self.v_play.get() == "Pause"

    def load(self):
        k = self.v_src.get()
        if k == "Picture":
            p = filedialog.askopenfilename(title="Picture", initialdir=os.path.dirname(self.cfg["picture"]) or pictures_dir(),
                                           filetypes=[("Pictures", "*.png *.jpg *.jpeg *.bmp *.gif *.webp *.tif *.tiff"), ("All", "*")])
            if p:
                self.cfg["picture"] = p
        elif k == "Video file":
            p = filedialog.askopenfilename(title="Video", initialdir=os.path.dirname(self.cfg["video"]) or videos_dir(),
                                           filetypes=[("Video", "*.mp4 *.mkv *.avi *.mpg *.mpeg *.webm *.mov *.vob *.ts"), ("All", "*")])
            if p:
                self.cfg["video"] = p
        elif k == "Webcam":
            self.webcam_dialog()
            return
        elif k == "Screen":
            self.screen_dialog()
            return
        elif k == "Stream URL":
            self.stream_dialog()
            return
        self.apply_source()

    def stream_dialog(self):
        w = tk.Toplevel(self.root, bg=CARD)
        w.title("Stream URL")
        self.lbl(w, "Paste an IPTV / stream link: http(s), .m3u8 (HLS), rtsp, rtmp, udp ... (Ctrl+V)").pack(
            anchor="w", padx=8, pady=(8, 2))
        hist = [u for u in self.cfg.get("stream_urls", []) if u]
        v = tk.StringVar(value=self.cfg.get("stream_url", ""))
        cb = ttk.Combobox(w, textvariable=v, values=hist, width=70)
        cb.pack(padx=8, pady=2)
        cb.focus_set()

        def paste():
            try:
                v.set(self.root.clipboard_get().strip())
            except Exception:
                pass
        r = self.frame(w)
        r.pack(anchor="w", padx=8)
        self.btn(r, "Paste", paste).pack(side=tk.LEFT)
        self.lbl(w, "The picture is cropped to 4:3 or 16:9 from its middle; the stream's sound goes with it\n"
                    "(Sound in: Source).  A stream that drops is opened again by itself.  Earlier links are in the list.",
                 muted=True, font=F_SMALL, justify=tk.LEFT).pack(anchor="w", padx=8, pady=4)

        def ok(*_):
            u = v.get().strip()
            if not u:
                return
            self.cfg["stream_url"] = u
            self.cfg["stream_urls"] = ([u] + [x for x in hist if x != u])[:12]
            w.destroy()
            self.apply_source()
        cb.bind("<Return>", ok)
        self.btn(w, "Use it", ok).pack(pady=8)

    def screen_dialog(self):
        w = tk.Toplevel(self.root, bg=CARD)
        w.title("Screen")
        self.lbl(w, "Display (Linux :0.0 - blank for this one; Windows desktop; macOS Capture screen 0)").pack(padx=8, pady=(8, 2))
        v = tk.StringVar(value=self.cfg.get("screen", ""))
        ttk.Entry(w, textvariable=v, width=36).pack(padx=8)
        self.lbl(w, "The area is 240 x 192 (4:3) or 342 x 192 (16:9) near the top left of the screen;\n"
                    "move it with the Screen X and Y sliders.", muted=True, font=F_SMALL).pack(padx=8, pady=4)

        def ok():
            self.cfg["screen"] = v.get().strip()
            w.destroy()
            self.apply_source()
        self.btn(w, "Use it", ok).pack(pady=8)

    def gain_changed(self, *_):
        self.eng.source.sound_gain = 10 ** (float(self.cfg.get("sound_gain", 0.0)) / 20.0)

    def screen_moved(self, *_):
        src = self.eng.source
        src.scr_x, src.scr_y = int(self.cfg["screen_x"]), int(self.cfg["screen_y"])
        if self.v_src.get() == "Screen":
            aw, ah = SCREEN_AREA.get(self.cfg["aspect"], (240, 192))
            self.src_lbl.config(text=self.screen_text())

    def screen_text(self):
        aw, ah = SCREEN_AREA.get(self.cfg["aspect"], (240, 192))
        return "screen %s: %d x %d at %d, %d" % (self.cfg.get("screen", "") or "(this one)", aw, ah,
                                               int(self.cfg["screen_x"]), int(self.cfg["screen_y"]))

    def sound_in_changed(self):
        self.cfg["sound_in"] = self.v_sin.get()
        if self.cfg["sound_in"] != "Source" and not self.cfg["realtime"]:
            self.log("Live sound comes at its own pace: turn Real time on, or the frames run short of it")
        self.apply_source()

    def sound_dialog(self):
        w = tk.Toplevel(self.root, bg=CARD)
        w.title("Sound devices")
        self.lbl(w, "These are the SOUND the encoder sends and the received sound you hear - not the radio's I/Q.\n"
                    "The 192 kHz I/Q card, the serial (COM) port and the hardware loop back test are in Radio / I/Q setup.\n"
                    "(Loopback under Sound in records this computer's own sound output as the programme sound.)",
                 font=F_SMALL, fg="#e5c07b", justify=tk.LEFT).pack(anchor="w", padx=8, pady=(8, 0))
        self.btn(w, "Radio / I/Q setup...", self.hardware).pack(anchor="w", padx=8, pady=(2, 4))
        self.lbl(w, "Sound in (Sound card / Loopback)", font=F_HEAD).pack(anchor="w", padx=8, pady=(8, 2))
        self.lbl(w, "Blank: the default input, or for Loopback the default output's monitor.\n"
                    + MIXER_DEFAULT + " (or pulse / pipewire): through the sound server - pick the input in the\n"
                    "mixer (pavucontrol, Recording tab, while the lab is taking sound in): a microphone, or\n"
                    "'Monitor of ...' for loopback.  plughw:... uses a card directly; a .monitor name is a loopback.",
                 muted=True, font=F_SMALL, justify=tk.LEFT).pack(anchor="w", padx=8)
        cur = self.cfg.get("sound_dev", "")
        v = tk.StringVar(value=MIXER_DEFAULT if cur == "default" else cur)
        ttk.Combobox(w, textvariable=v, values=[""] + list_sound_inputs(), width=56).pack(padx=8, pady=2)
        tip = ("Windows: loopback is a 'Stereo Mix' device (turn it on in Sound settings > Recording)." if IS_WIN else
               "macOS: for loopback install a loopback device such as BlackHole and play the sound to it." if sys.platform == "darwin" else
               "Linux: names ending in .monitor are loopbacks of an output; alsa:hw:Loopback,1 uses ALSA's snd-aloop.")
        self.lbl(w, tip, muted=True, font=F_SMALL, wraplength=460, justify=tk.LEFT).pack(anchor="w", padx=8, pady=(0, 6))
        self.lbl(w, "Sound out (the received sound)", font=F_HEAD).pack(anchor="w", padx=8, pady=(6, 2))
        self.lbl(w, "Blank: the system default.  pulse: through PulseAudio, so the mixer (Playback tab,\n'"
                    + APP_NAME + "') says where it goes.  Or a sound card by name.", muted=True, font=F_SMALL,
                 justify=tk.LEFT).pack(anchor="w", padx=8)
        o = tk.StringVar(value=self.cfg.get("sound_out_dev", ""))
        ttk.Combobox(w, textvariable=o, values=["", "pulse", "default"] + list_sound_outputs(), width=56).pack(padx=8, pady=2)

        res = self.lbl(w, "", muted=True, font=F_SMALL, wraplength=460, justify=tk.LEFT)

        def test():
            d = v.get().strip()
            kind = self.cfg.get("sound_in", "Source")
            kind = kind if kind != "Source" else "Sound card"
            res.config(text="Testing %s ..." % kind)
            w.update_idletasks()
            r = sound_in_test(kind, "default" if d == MIXER_DEFAULT else d)
            res.config(text="%s: %s" % (kind, r))
            self.log("Sound in test, %s: %s" % (kind, r))
        tb = self.frame(w)
        tb.pack(anchor="w", padx=8, pady=(0, 2))
        self.btn(tb, "Test sound in", test).pack(side=tk.LEFT)
        res.pack(anchor="w", padx=8, pady=(0, 6))

        def ok():
            d = v.get().strip()
            self.cfg["sound_dev"] = "default" if d == MIXER_DEFAULT else d
            out_changed = o.get().strip() != self.cfg.get("sound_out_dev", "")
            self.cfg["sound_out_dev"] = o.get().strip()
            w.destroy()
            if out_changed:
                self.avp.set_device(self.cfg["sound_out_dev"])
            self.apply_source()
        self.btn(w, "Use it", ok).pack(pady=8)

    def webcam_dialog(self):
        devs = sorted(glob.glob("/dev/video*")) if not IS_WIN else []
        w = tk.Toplevel(self.root, bg=CARD)
        w.title("Webcam")
        self.lbl(w, "Webcam device (Linux /dev/videoN, Windows video=Name, macOS 0)").pack(padx=8, pady=6)
        v = tk.StringVar(value=self.cfg["webcam"])
        ttk.Combobox(w, textvariable=v, values=devs, width=36).pack(padx=8)

        def ok():
            self.cfg["webcam"] = v.get().strip()
            w.destroy()
            self.apply_source()
        self.btn(w, "Use it", ok).pack(pady=8)

    def apply_source(self):
        k = self.v_src.get()
        path = {"Picture": self.cfg["picture"], "Video file": self.cfg["video"], "Webcam": self.cfg["webcam"],
                "Screen": self.cfg.get("screen", ""), "Stream URL": self.cfg.get("stream_url", "")}.get(k, "")
        m = C.MODES[self.cfg["mode"]]
        enc = C.eff_enc(m, self.cfg["enc"])                         # 120x96: modes 1-4, 180x96: 1-2
        enc = self.cfg["enc"] = SDR_NOT.get(enc, enc)
        lay = C.layout(m, bool(self.cfg.get("long_sym", 0)), int(self.cfg["cp"]), int(self.cfg.get("fixed_fps", 0)), bool(self.cfg.get("pilots16", 0)))
        ft = C.frame_seconds(lay, self.cfg["cp"]) / lay.halves     # the source's time per codec frame (3 pictures)
        self.enc_box.config(values=self.enc_names())
        self.v_enc.set(C.enc_name(m, enc))
        self.enc_lbl.config(text=C.ENC_MODES[enc]["text"])
        with self.eng.lock:
            self.eng.source.sound_in = self.cfg.get("sound_in", "Source")
            self.eng.source.sound_dev = self.cfg.get("sound_dev", "")
            self.eng.source.sound_gain = 10 ** (float(self.cfg.get("sound_gain", 0.0)) / 20.0)
            self.eng.source.scr_x, self.eng.source.scr_y = int(self.cfg["screen_x"]), int(self.cfg["screen_y"])
            self.eng.source.set(k, path, m, self.cfg["aspect"], enc, ft)
        self.v_play.set("Play")
        self.show_q.clear()
        shown = (os.path.basename(path) if k in ("Picture", "Video file") else
                 ("stream " + path) if k == "Stream URL" else
                 self.screen_text() if k == "Screen" else path) or k
        if k == "Screen":
            self.scr_box.pack(fill=tk.X, after=self.src_lbl)
        else:
            self.scr_box.pack_forget()
        if self.cfg.get("sound_in", "Source") != "Source":
            shown += "   |   sound: %s %s" % (self.cfg["sound_in"].lower(), self.cfg.get("sound_dev", "") or "(default)")
            if k in ("Stream URL", "Video file"):
                shown += " - not the %s's own (Sound in: Source)" % ("stream" if k == "Stream URL" else "file")
        self.src_lbl.config(text=shown)
        w, h = self.pic_size()
        for cv in (self.enc_cv, self.dec_cv):
            cv.config(width=w, height=h)
        pw, ph = C.pic_size(m, enc)
        self.enc_info.config(text="%s, mode %s: pictures %d x %d, %.1f a second (%d per data frame)\n"
                                  "data frame %d bytes every %.2f s (%d OFDM symbols)\n"
                                  "%d carriers: 144 video, 48 audio, %d pilots, 500 Hz apart, 100 kHz wide"
                                  % (m.name, C.enc_short(enc), pw, ph, C.pics_per_frame(enc) / ft, C.pics_per_frame(enc),
                                     m.frame_bytes, ft, m.syms, len(m.used), len(m.pilot_bins)))

    def hw_text(self, h, full=False):
        """The sound card's state, for the line under the channel buttons (and the window)."""
        mode = h.get("mode", "Off")
        if h.get("err"):
            return "Hardware %s: NOT RUNNING - %s  (%s)" % (mode, h["err"], "the receiver gets nothing" if mode != "TX out"
                                                             else "nothing goes out")
        parts = []
        if h.get("tx"):
            parts.append("out %.1f dBFS%s" % (h["out_dbfs"], (", clipping %.2f%%" % (100 * h["out_clip"]))
                                              if h.get("out_clip", 0) > 1e-4 else ""))
            parts.append("buffer %d ms%s" % (1000 * h["buf_s"], "" if h.get("playing") else " (filling)"))
        if h.get("rx"):
            parts.append("in %.1f dBFS%s%s" % (h["in_dbfs"], (", clipping %.2f%%" % (100 * h["in_clip"]))
                                               if h.get("in_clip", 0) > 1e-4 else "",
                                               " - TOO HOT: turn the capture gain down" if h["in_dbfs"] > -6 else ""))
        if h.get("offset"):
            parts.append("offset %+.0f kHz" % (h["offset"] / 1e3))
        bad = []
        for k, nm in (("under", "underruns"), ("over", "overruns"), ("late", "late")):
            if h.get(k):
                bad.append("%d %s" % (h[k], nm))
        if bad:
            parts.append(", ".join(bad))
        t = "Hardware %s @ %s: %s" % (mode, ("2 Msps HackRF, %.4f MHz" % (h["freq"] / 1e6)) if h.get("rf") and h.get("freq")
                                      else "192 kHz", "; ".join(parts))
        if full and not h.get("rx"):
            t += "\n(the receiver is monitoring the transmitter)"
        return t

    def card_check(self):
        """The card's own loop, measured (in this process, with the modem's streams closed)."""
        if getattr(self, "cc_running", False):
            return
        if C.hackrf_dev(self.cfg.get("hw_out")) is not None or C.hackrf_dev(self.cfg.get("hw_in")) is not None:
            return
        self.cc_running = True
        if self.cfg.get("hw_mode", "Off") != "Off":
            self.hw_path_off()
        devs, err = C.hw_devices()
        self.log("Sound devices: " + ("; ".join("%s [in %d%s, out %d%s]" % (
            e["name"], e["ins"], " 192k" if e["in192"] else "", e["outs"], " 192k" if e["out192"] else "")
            for e in devs) if devs else (err or "none")))
        self.cc_show("checking ... (about 3 s)")
        out_n, in_n = self.cfg.get("hw_out", "Default"), self.cfg.get("hw_in", "Default")
        trim = (float(self.cfg.get("hw_skew", 0.0)), float(self.cfg.get("hw_qgain", 0.0))) if self.cfg.get("hw_trim", 1) \
            else (0.0, 0.0)

        def work():
            time.sleep(1.0)                               # (the modem's streams closing)
            try:
                res, lines = C.card_check(out_n, in_n, trim=trim)
            except Exception as e:
                res, lines = {}, ["Card check: %s" % e]
            self.cc_result = (res, lines)
            self.cc_running = False
        threading.Thread(target=work, daemon=True).start()
        self.root.after(200, self.card_check_done)

    def offer_play(self, res, num):
        """The line out: the codec's Loopback Mixing off, the playback controls at 0 dB (unmuted), and
        a stronger Out level when the SNR is low everywhere - one question, then check again."""
        play = res.get("playback") or []
        if num is None or res.get("path") not in ("analogue", "none"):
            return False
        acts, desc = [], []
        for c in play:
            if c["kind"] == "enum" and "loopback" in c["name"].lower():
                off = next((it for it in c["items"] if it.lower().startswith(("disab", "off"))), None)
                if off and c["value"] != off:
                    acts.append(("enum", c["name"], off))
                    desc.append("'%s' -> '%s' (it mixes the input into the output)" % (c["name"], off))
            elif c["kind"] == "level" and c["db"] is not None and (c["db"] < -1.0 or c["sw"] == "off"):
                acts.append(("level" if c["sw"] != "off" else "level+on", c["name"], "0dB"))
                desc.append("'%s' %s -> 0 dB%s" % (c["name"], c["value"], ", on" if c["sw"] == "off" else ""))
        bands = res.get("snr_bands")
        lvl = float(self.cfg.get("hw_level", -18))
        if bands and min(bands[0][0], bands[1][0]) < 35 and lvl < -12.5 and res.get("in_clip", 0) < 1e-3:
            acts.append(("out", None, -12))
            desc.append("Out level %d -> -12 dBFS (OFDM peaks then about -2 dBFS)" % lvl)
        if not acts:
            return False
        try:
            from tkinter import messagebox
            ok = messagebox.askyesno("Line out", "For a stronger, cleaner line out:\n\n  " + "\n  ".join(desc) +
                                     "\n\n(amixer -c %s)  Then Card check runs again, and sets the capture gain to match."
                                     % num, parent=self.root)
        except Exception:
            ok = False
        if not ok:
            return False
        for kind, name, val in acts:
            if kind == "enum":
                err = C.alsa_set_enum(num, name, val)
            elif kind.startswith("level"):
                err = C.alsa_adjust(num, name, value=val)
                if not err and kind == "level+on":
                    err = C.alsa_adjust(num, name, value="unmute")
            else:
                self.cfg["hw_level"] = val
                self.settings_changed()
                err = None
            self.log("Line out: %s -> %s%s" % (name or "Out level", val, (": " + err) if err else ""))
        self.root.after(300, self.card_check)
        return True

    def offer_gain(self, res, num, ctl):
        """Loop gain far from 0 dB (or the input clipping): offer to set the card's capture gain with
        amixer - boosts to 0, Capture moved by what is needed - then check again.  -> True if it did."""
        if num is None or res.get("path") not in ("analogue", "none"):
            return False
        clip = res.get("in_clip", 0) > 1e-3
        g = res.get("gain_db")
        boosts = [c for c in ctl if c["kind"] == "level" and "boost" in c["name"].lower() and not c["value"].startswith("0%")]
        cap = next((c for c in ctl if c["kind"] == "level" and c["name"].lower() == "capture"), None)
        quiet_loud = (res.get("quiet") or {}).get("loud")
        if res.get("path") == "none":
            if not (quiet_loud and boosts):
                return False
            change = None
        else:
            if not clip and g is not None and -12 <= g <= 6:
                return False
            change = -20.0 if clip else -float(round(g))         # (clipping hides the real gain: 20 dB, then again)
        what = []
        if boosts:
            what.append("set %s to 0" % ", ".join("'%s'" % c["name"] for c in boosts))
        if change is not None and cap is not None:
            what.append("move 'Capture' %+.0f dB (now %s)" % (change, cap["value"]))
        if not what:
            return False
        why = ("the input is clipping" if clip else ("the loop gain is %+.1f dB" % g) if change is not None
               else "the input is loud with nothing connected")
        try:
            from tkinter import messagebox
            ok = messagebox.askyesno("Capture gain", "%s.  Aim: about 0 dB through the loop, about -20 dBFS in.\n\n"
                                     "%s (amixer -c %s)?\n\nThen Card check runs again." % (why[0].upper() + why[1:],
                                                                                         "; ".join(what).capitalize(), num),
                                     parent=self.root)
        except Exception:
            ok = False
        if not ok:
            return False
        for c in boosts:
            err = C.alsa_adjust(num, c["name"], value="0")
            self.log("Capture: %s -> 0%s" % (c["name"], (": " + err) if err else ""))
        if change is not None and cap is not None:
            err = C.alsa_adjust(num, "Capture", db_change=change)
            self.log("Capture: Capture %+.0f dB%s" % (change, (": " + err) if err else ""))
        self.root.after(300, self.card_check)
        return True

    def hw_trim_text(self):
        sk, g = float(self.cfg.get("hw_skew", 0.0)), float(self.cfg.get("hw_qgain", 0.0))
        t = ("left in delayed %+.4f samples (%+.1f ns), right %+.2f dB - set by Card check" % (sk, 1e9 * sk / C.HW_FS, -g)
             if (sk or g) else "not measured yet: Card check sets it")
        try:
            self.hw_trim_lbl.config(text=t)
        except Exception:
            pass

    def trim_changed(self):
        self.log("I/Q trim %s" % ("on" if self.cfg.get("hw_trim", 1) else "off"))
        self.settings_changed()

    def cc_show(self, text, fg=None):
        try:
            self.hw_cc.config(state=tk.NORMAL)
            self.hw_cc.delete("1.0", tk.END)
            self.hw_cc.insert("1.0", text)
            if fg:
                self.hw_cc.config(fg=fg)
        except Exception:
            pass

    def copy_report(self):
        """The last Card check report to the clipboard (to paste into a message)."""
        lines = (getattr(self, "cc_result", None) or ({}, []))[1]
        if not lines:
            self.log("Copy report: run Card check first")
            return
        txt = "NBTV SDR %s\n%s" % (VERSION, "\n".join(lines))
        self.root.clipboard_clear()
        self.root.clipboard_append(txt)
        self.log("Card check report copied to the clipboard (%d lines) - paste it with Ctrl+V" % len(lines))

    def card_check_done(self):
        if getattr(self, "cc_running", False):
            self.root.after(200, self.card_check_done)
            return
        res, lines = self.cc_result
        iq = res.get("iq")
        if iq and res.get("path") == "analogue" and abs(iq["skew"]) < 2.0 and abs(iq["gain"]) < 3.0:
            self.cfg["hw_skew"], self.cfg["hw_qgain"] = round(iq["skew"], 4), round(iq["gain"], 3)
            lines = lines + ["  I/Q trim now %+.4f samples (%+.1f ns), %+.2f dB%s" % (
                iq["skew"], 1e9 * iq["skew"] / C.HW_FS, iq["gain"], "" if self.cfg.get("hw_trim", 1) else " (I/Q trim is off)")]
            self.cc_result = (res, lines)
            self.hw_trim_text()
            self.settings_changed()
        for l in lines:
            self.log(l)
        try:                                              # (the report kept in a file, to send on)
            path = os.path.join(os.path.expanduser("~"), "nbtv_card_check.txt")
            with open(path, "a") as f:
                f.write("==== %s  NBTV SDR %s\n%s\n\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), VERSION, "\n".join(lines)))
            self.log("Card check report added to %s" % path)
            try:
                self.hw_cc_path.config(text="Saved in %s  -  or press Copy report and paste it" % path)
            except Exception:
                pass
        except Exception as e:
            self.log("Card check report not saved: %s" % e)
        num, ctl = (res.get("mixer") or (None, []))
        # the capture source not on Line: offer to switch it (amixer), then check again
        for c in ctl:
            if c["kind"] != "enum" or not any(k in c["name"].lower() for k in ("input source", "capture source")):
                continue
            line = next((it for it in c["items"] if it.lower().startswith("line")), None)
            if line is None or c["value"] == line:
                continue
            try:
                from tkinter import messagebox
                ok = messagebox.askyesno("Capture source", "The card's capture source ('%s') is '%s', not the line input.\n\n"
                                         "Switch it to '%s'?  (amixer -c %s sset '%s' '%s')\n\nThen Card check runs again."
                                         % (c["name"], c["value"], line, num, c["name"], line), parent=self.root)
            except Exception:
                ok = False
            if ok:
                err = C.alsa_set_enum(num, c["name"], line)
                self.log("Capture source %s -> '%s'%s" % (c["name"], line, (": " + err) if err else ""))
                if not err:
                    self.root.after(300, self.card_check)
                    return
            break
        if not self.offer_play(res, num):                # (the line out first, then the capture gain)
            self.offer_gain(res, num, ctl)
        self.cc_show("\n".join(l.rstrip() for l in lines),
                     {"none": "#e5c07b", "digital": "#e06c75", "analogue": "#6ccf7a"}.get(res.get("path"), FG))

    # ---- the card away from PulseAudio / PipeWire (its profile Off) and back
    def release_card(self, ask=True):
        """Set the PulseAudio / PipeWire card behind the chosen ALSA device to profile Off, so the lab
        can open hw: directly; the old profile is put back by Give card back, or when the lab closes."""
        names = [self.cfg.get("hw_out", ""), self.cfg.get("hw_in", "")]
        names = [n for n in names if C.alsa_dev(n)]
        if not names:
            self.log("Release card: choose an ALSA hw: device for Output / Input first")
            return False
        card, prof = C.pulse_card(names[0])
        if card is None:
            self.log("Release card: %s" % prof)
            return False
        held = getattr(self, "pulse_held", None) or {}
        if card in held:
            self.log("Release card: %s is already released by the lab" % card)
            return False
        if prof == "off":
            self.log("Release card: %s is already Off in PulseAudio / PipeWire - another program has %s "
                     "(see: fuser -v /dev/snd/*)" % (card, C.alsa_dev(names[0])))
            return False
        if ask:
            try:
                from tkinter import messagebox
                warn = ""
                if self.cfg.get("sound_in", "Source") != "Source":
                    warn = ("\n\nSound in is '%s' (through the mixer): it will stop.  Set Sound in to Source for "
                            "the test." % self.cfg.get("sound_in"))
                if not messagebox.askyesno("Release the card", "Set PulseAudio / PipeWire card\n  %s\nto profile Off "
                                           "(it is now '%s'), so the lab can use %s directly?\n\nThe card's sound "
                                           "through the mixer stops until you press Give card back or close the lab.%s"
                                           % (card, prof, C.alsa_dev(names[0]), warn), parent=self.root):
                    return False
            except Exception:
                pass
        err = C.pulse_set_profile(card, "off")
        if err:
            self.log("Release card: %s" % err)
            return False
        held[card] = prof
        self.pulse_held = held
        self.log("Released %s from PulseAudio / PipeWire (profile was %s) - %s is the lab's now"
                 % (card, prof, C.alsa_dev(names[0])))
        if getattr(self, "rel_btn", None) is not None:
            try:
                self.rel_btn.config(text="Give card back")
            except Exception:
                pass
        if self.cfg.get("sound_in", "Source") != "Source":
            self.log("Note: Sound in is '%s' (through the mixer) - set it to Source for the test" % self.cfg.get("sound_in"))
        self.hw_logged = None
        self.apply_hw()                                  # (the card opened again, now it is free)
        return True

    def hw_path_off(self):
        """Card check / Release card need the card to themselves: the I/Q path closed (receive)."""
        if self.cfg.get("ptt", 0):
            self.ptt_toggle(False)
        self.cfg["hw_mode"] = "Off"
        self.settings_changed()

    def card_held(self):
        """Is the card behind the chosen device one the lab has released?"""
        held = getattr(self, "pulse_held", None) or {}
        for n in (self.cfg.get("hw_out", ""), self.cfg.get("hw_in", "")):
            if C.alsa_dev(n):
                card, _ = C.pulse_card(n)
                if card in held:
                    return True
        return False

    def give_card_back(self):
        held = getattr(self, "pulse_held", None) or {}
        if not held:
            return
        if self.cfg.get("hw_mode", "Off") != "Off":
            self.hw_path_off()
            time.sleep(0.5)                               # (the lab's streams closing first)
        for card, prof in held.items():
            err = C.pulse_set_profile(card, prof or "output:analog-stereo+input:analog-stereo")
            self.log("Gave %s back to PulseAudio / PipeWire (profile %s)%s" % (card, prof, (": " + err) if err else ""))
        self.pulse_held = None
        if getattr(self, "rel_btn", None) is not None:
            try:
                self.rel_btn.config(text="Release card")
            except Exception:
                pass

    def release_toggle(self):
        if self.card_held() or (getattr(self, "pulse_held", None) and not any(C.alsa_dev(n) for n in
                                                                             (self.cfg.get("hw_out"), self.cfg.get("hw_in")))):
            self.give_card_back()
        else:
            self.release_card()                          # (another card: release it too)

    # ------------------------------------------------------------ hardware setup
    def hardware(self):
        """Setup: the homebrew SDR (its serial port and its 192 kHz sound card), the HackRF, the meter."""
        if getattr(self, "hw_win", None) is not None:
            try:
                self.hw_win.lift()
                return
            except Exception:
                self.hw_win = None
        w = tk.Toplevel(self.root, bg=CARD)
        w.title("%s - hardware setup" % APP)
        self.hw_win = w

        def closed():
            self.hw_win = None
            self.hw_stat = None
            w.destroy()
        w.protocol("WM_DELETE_WINDOW", closed)
        devs, err = C.hw_devices()

        def combo(parent, key, values, width=48, cmd=None):
            cur = self.cfg.get(key, "Default") or "Default"
            v = tk.StringVar(value=next((x for x in values if x.split("  (")[0] == cur), cur))
            if cur not in [x.split("  (")[0] for x in values]:
                values = values + [cur]
            cb = ttk.Combobox(parent, textvariable=v, values=values, width=width)
            cb.pack(side=tk.LEFT)

            def changed(_=None):
                new = v.get().split("  (")[0].strip() or "Default"
                if new != self.cfg.get(key):
                    self.cfg[key] = new
                    self.log("%s: %s" % (key, new))
                    (cmd or self.apply_hw)()
            cb.bind("<<ComboboxSelected>>", changed)
            cb.bind("<Return>", changed)
            cb.bind("<FocusOut>", changed)
            return cb

        def entry(parent, txt, key, width, check=None, cmd=None):
            self.lbl(parent, txt).pack(side=tk.LEFT)
            v = tk.StringVar(value=str(self.cfg.get(key)))
            e = ttk.Entry(parent, textvariable=v, width=width)
            e.pack(side=tk.LEFT, padx=2)

            def ent(_=None):
                raw = v.get().strip()
                try:
                    x = type(self.cfg.get(key))(raw) if not isinstance(self.cfg.get(key), str) else raw
                except ValueError:
                    return
                if check and not check(x):
                    return
                if x != self.cfg.get(key):
                    self.cfg[key] = x
                    self.log("%s: %s" % (key, x))
                    (cmd or self.apply_hw)()
            e.bind("<Return>", ent)
            e.bind("<FocusOut>", ent)
            return e

        # one tab a kind of hardware, the meter and the state below them
        win = w
        nb = ttk.Notebook(win)
        nb.pack(fill=tk.BOTH, expand=True, padx=6, pady=(6, 0))

        def page(title):
            f = tk.Frame(nb, bg=CARD)
            nb.add(f, text=title)
            return f
        tabs = {}
        w = tabs["ExSDR radio"] = page("ExSDR radio")
        # ---- the homebrew SDR (ExSDR's radio)
        self.lbl(w, "ExSDR radio: VE3XTV's homebrew HF SDR - serial control, I/Q through a 192 kHz sound card",
                 font=F_HEAD).pack(anchor="w", padx=6, pady=(6, 0))
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.lbl(r, "Serial port", width=13, anchor="w").pack(side=tk.LEFT)
        self.port_cb = combo(r, "serial_port", list_ports() or [self.cfg.get("serial_port", "/dev/ttyUSB0")], width=34,
                             cmd=self.reconnect_radio)

        def refresh():
            self.port_cb.config(values=list_ports() or ["(no serial ports found)"])
            self.log("Serial ports: %s" % (", ".join(list_ports()) or "none found"))
        self.btn(r, "Refresh", refresh).pack(side=tk.LEFT, padx=4)
        self.btn(r, "Connect", self.reconnect_radio).pack(side=tk.LEFT, padx=2)
        self.radio_stat = self.lbl(r, "", font=F_SMALL)
        self.radio_stat.pack(side=tk.LEFT, padx=6)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.lbl(r, "Radio", width=13, anchor="w").pack(side=tk.LEFT)
        self.v_radio_pre = self.check(r, "Pre-amp", "radio_pre", lambda: self.radio_flag("P"))
        self.v_radio_att = self.check(r, "Attenuator", "radio_att", lambda: self.radio_flag("A"))
        self.btn(r, "Read back", lambda: self.radio_link.query_all()).pack(side=tk.LEFT, padx=8)
        self.lbl(w, "9600 baud 8N1, no terminator; F (kHz), TX, RX, P1/P0 (pre-amp), A1/A0 (attenuator) - the window "
                    "follows the radio's replies.  "
                    "Permission: sudo usermod -aG dialout $USER", muted=True, font=F_SMALL).pack(anchor="w", padx=6)
        for kind, key, txt in (("out", "card_out", "Card output"), ("in", "card_in", "Card input")):
            r = self.frame(w)
            r.pack(fill=tk.X, padx=6, pady=2)
            self.lbl(r, txt, width=13, anchor="w").pack(side=tk.LEFT)
            vals = ["Default"] + [e["name"] + ("" if e[kind + "192"] else "  (no 192 kHz)") for e in devs
                                  if e[kind + "s"] >= 2 and C.hackrf_dev(e["name"]) is None]
            combo(r, key, vals)
        if not IS_WIN and sys.platform != "darwin":
            self.lbl(w, "ALSA hw:C,D = the card itself, past PulseAudio / PipeWire (nothing resampled or mixed).  You can type one\n"
                        "in, e.g. hw:1,0.  If it says busy: Release card (below), or start with  pasuspender -- python3 nbtv_sdr.py",
                     muted=True, font=F_SMALL, justify="left").pack(anchor="w", padx=6)
        if IS_WIN:
            self.lbl(w, "Windows: use the card's [Windows WASAPI] entries (listed first) - they run at the card's own 192 kHz.\n"
                        "In Windows Sound settings set the card to 2 channel, 24 bit, 192000 Hz, and turn its audio enhancements off.",
                     muted=True, font=F_SMALL, justify="left").pack(anchor="w", padx=6)
        if err:
            self.lbl(w, err + "  (pip install sounddevice; Linux also needs libportaudio2 - or use ALSA hw: devices)",
                     muted=True, font=F_SMALL).pack(anchor="w", padx=6)
        self.slider(w, "Channel in card kHz", "card_off_khz", -40, 40, 1, "%+d", cmd=self.card_off_changed, length=220)
        self.lbl(w, "where the 100 kHz channel sits in the card's +-96 kHz (away from its DC / LO leak); the radio's LO is set\n"
                    "that far below the frequency.  Past +-30 kHz the card's own filter edge may show.",
                 muted=True, font=F_SMALL, justify="left").pack(anchor="w", padx=6)
        self.slider(w, "Buffer ms", "hw_buf", 100, 1000, 10, "%d", length=220)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.check(r, "Swap I/Q", "hw_swap")
        self.check(r, "I/Q trim", "hw_trim", self.trim_changed)
        self.hw_trim_lbl = self.lbl(r, "", font=F_SMALL)
        self.hw_trim_lbl.pack(side=tk.LEFT, padx=6)
        self.hw_trim_text()
        # ---- card check (on the ExSDR radio's tab: it is its card)
        self.lbl(w, "Card check: line out -> line in on its own, with no modem; it measures the path and sets the I/Q trim.\n"
                    "The I/Q path is closed for it (receive).", muted=True, font=F_SMALL,
                 justify="left").pack(anchor="w", padx=6, pady=(6, 0))
        self.hw_cc = tk.Text(w, height=10, width=104, bg=FIELD, fg=FG, font=("Courier", 9), wrap="none",
                             relief=tk.FLAT, insertbackground=FG)
        self.hw_cc.pack(fill=tk.X, padx=6, pady=2)
        self.hw_cc_path = self.lbl(w, "", muted=True, font=F_SMALL, anchor="w")
        self.hw_cc_path.pack(fill=tk.X, padx=6)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=6)
        self.btn(r, "Card check", self.card_check_sdr).pack(side=tk.LEFT)
        self.btn(r, "Copy report", self.copy_report).pack(side=tk.LEFT, padx=6)
        if not IS_WIN and sys.platform != "darwin":
            self.rel_btn = self.btn(r, "Give card back" if self.card_held() else "Release card", self.release_toggle)
            self.rel_btn.pack(side=tk.LEFT, padx=6)
        # ---- HackRF
        w = tabs["HackRF"] = page("HackRF")
        self.lbl(w, "HackRF One - TX and RX, 1 MHz to 6 GHz (hackrf_transfer, 2 Msps; half duplex: TX and RX take turns)",
                 font=F_HEAD).pack(anchor="w", padx=6, pady=(6, 0))
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.lbl(r, "Device", width=13, anchor="w").pack(side=tk.LEFT)
        vals = [e["name"] for e in devs if C.hackrf_dev(e["name"]) is not None] or ["HackRF"]
        combo(r, "hackrf_dev", vals, width=40)
        self.slider(w, "TX VGA dB", "hw_txvga", 0, 47, 1, "%d", length=220)
        self.slider(w, "RX LNA dB", "hw_lna", 0, 40, 8, "%d", length=220)
        self.slider(w, "RX VGA dB", "hw_vga", 0, 62, 2, "%d", length=220)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.check(r, "TX amp (+11 dB)", "hw_txamp")
        self.check(r, "RX amp (+11 dB)", "hw_rxamp")
        self.lbl(w, "sudo apt install hackrf.  A gain change starts hackrf_transfer again.  Below 30 MHz a low-pass filter on\n"
                    "TX is a must (the HackRF's harmonics are strong).", muted=True, font=F_SMALL, justify="left").pack(anchor="w", padx=6)
        # ---- RTL-SDR
        w = tabs["RTL-SDR"] = page("RTL-SDR")
        self.lbl(w, "RTL-SDR (Blog V3 / V4, NooElec ...) - receive only (rtl_sdr, 2 Msps)", font=F_HEAD).pack(
            anchor="w", padx=6, pady=(6, 0))
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.lbl(r, "HF by", width=13, anchor="w").pack(side=tk.LEFT)
        v_hf = tk.StringVar(value=self.cfg.get("rtl_hf", C.RTL_HF[0]))

        def hf_changed():
            self.cfg["rtl_hf"] = v_hf.get()
            self.log("RTL-SDR HF: %s" % v_hf.get())
            self.apply_hw()
        self.radio(r, v_hf, list(C.RTL_HF), hf_changed).pack(side=tk.LEFT)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        entry(r, "Device index", "rtl_index", 4, check=lambda x: 0 <= x <= 9)
        entry(r, "  Frequency correction ppm", "rtl_ppm", 5, check=lambda x: -200 <= x <= 200)
        self.slider(w, "Gain dB (0 = auto)", "rtl_gain", 0, 50, 1, "%d", cmd=self.apply_hw, length=220)
        self.lbl(w, "sudo apt install rtl-sdr.  V4: HF is built in.  V3: direct sampling below 28.8 MHz (RTL-SDR Blog\n"
                    "drivers).  Upconverter: a 125 MHz upconverter (Ham-it-up etc.) in front.", muted=True, font=F_SMALL,
                 justify="left").pack(anchor="w", padx=6)
        # ---- Airspy HF+
        w = tabs["Airspy HF+"] = page("Airspy HF+")
        self.lbl(w, "Airspy HF+ / HF+ Discovery - receive only (airspyhf_rx, 192 kHz)", font=F_HEAD).pack(
            anchor="w", padx=6, pady=(6, 0))
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        entry(r, "Serial (blank: the first)", "airspy_serial", 18)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        self.check(r, "LNA (+6 dB)", "airspy_lna", self.apply_hw)
        self.check(r, "AGC", "airspy_agc", self.apply_hw)
        self.slider(w, "Attenuator dB", "airspy_att", 0, 48, 6, "%d", cmd=self.apply_hw, length=220)
        self.lbl(w, "sudo apt install airspyhf.  Tuned straight to the channel (no DC spike to keep away from).",
                 muted=True, font=F_SMALL).pack(anchor="w", padx=6)
        # ---- SDRplay / SoapySDR
        w = tabs["SDRplay / SoapySDR"] = page("SDRplay / SoapySDR")
        self.lbl(w, "SDRplay RSP (receive only) and any other radio with a SoapySDR driver (TX and RX where it can, e.g. "
                    "LimeSDR)", font=F_HEAD).pack(anchor="w", padx=6, pady=(6, 0))
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        entry(r, "Device arguments", "sdr_args", 34)
        self.lbl(r, "  e.g. driver=lime, or serial=... (SDRplay adds driver=sdrplay)", muted=True, font=F_SMALL).pack(side=tk.LEFT)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=2)
        entry(r, "Antenna (blank: default)", "soapy_ant", 14)
        self.slider(w, "Gain dB", "soapy_gain", 0, 70, 1, "%d", cmd=self.apply_hw, length=220)
        self.lbl(w, "sudo apt install python3-soapysdr soapysdr-tools, plus the radio's module (SDRplay: the SDRplay API\n"
                    "and SoapySDRPlay3; LimeSDR: soapysdr-module-lms7).  SoapySDRUtil --find lists what it sees.  2 Msps.",
                 muted=True, font=F_SMALL, justify="left").pack(anchor="w", padx=6)
        # ---- the 2 Msps SDRs' LO offset (HackRF, RTL-SDR, SoapySDR)
        for name in ("HackRF", "RTL-SDR", "SDRplay / SoapySDR"):
            r = self.frame(tabs[name])
            r.pack(fill=tk.X, padx=6, pady=(6, 2))
            entry(r, "LO offset kHz", "hw_lo_off", 6, check=lambda x: 60 <= x <= 900, cmd=self.lo_off_changed)
            entry(r, "  RX trim Hz", "hw_rx_trim", 7, cmd=self.settings_changed)
            self.lbl(tabs[name], "the SDR is tuned the LO offset below the channel and the signal moved up in software, so its DC\n"
                                 "spike stays out of the 100 kHz.  RX trim corrects a frequency difference between stations.",
                     muted=True, font=F_SMALL, justify="left").pack(anchor="w", padx=6)
        hwn = self.cfg.get("hardware", "None")
        sel = {"SDRplay": "SDRplay / SoapySDR", "SoapySDR": "SDRplay / SoapySDR"}.get(hwn, hwn)
        if sel in tabs:
            nb.select(tabs[sel])
        # ---- below the tabs: the meter and the hardware's state
        w = win
        self.slider(w, "S9 at dBFS", "s9_dbfs", -100, -10, 1, "%d", cmd=lambda: None, length=220)
        self.hw_stat = self.lbl(w, self.hw_text(self.hw_last, True) if getattr(self, "hw_last", None) else
                                "Hardware off", font=F_SMALL, justify="left", anchor="w")
        self.hw_stat.pack(fill=tk.X, padx=6, pady=(4, 0))
        r = self.frame(w)
        r.pack(fill=tk.X, padx=6, pady=6)
        self.btn(r, "Close", closed).pack(side=tk.RIGHT)
        self.radio_status()

    def radio_status(self):
        lk = getattr(self, "radio_link", None)
        try:
            if self.cfg.get("hardware") != "ExSDR radio":
                t, col = "(hardware is %s)" % self.cfg.get("hardware"), MUTED
            elif getattr(lk, "connected", False):
                t, col = "connected%s" % ((": " + lk.hw["version"]) if lk.hw.get("version") else ""), "#6ccf7a"
            else:
                t, col = "not connected", "#e06c75"
            self.radio_stat.config(text=t, fg=col)
        except Exception:
            pass

    def radio_flag(self, letter):
        """Pre-amp (P) or attenuator (A) to the radio; the tick box then follows the radio's answer."""
        key = {"P": "radio_pre", "A": "radio_att"}[letter]
        on = bool(self.cfg.get(key, 0))
        if not getattr(self.radio_link, "connected", False):
            self.log("Radio not connected - %s not sent" % ("pre-amp" if letter == "P" else "attenuator"))
            return
        self.radio_link.set_flag(letter, on)
        self.log("Radio: %s%d" % (letter, 1 if on else 0))

    def reconnect_radio(self):
        self.open_radio()
        self.set_tune(self.tune_hz, recenter=True)
        self.update_freq_display()
        self.radio_status()

    def card_off_changed(self):
        self.set_tune(self.tune_hz, recenter=True)

    def lo_off_changed(self):
        self.update_freq_display()
        self.settings_changed()

    def card_check_sdr(self):
        if self.cfg.get("hardware") != "ExSDR radio":
            self.cc_show("Card check is for the ExSDR radio's sound card (Hardware: ExSDR radio)")
            return
        self.cfg["hw_out"], self.cfg["hw_in"] = self.cfg.get("card_out", "Default"), self.cfg.get("card_in", "Default")
        self.card_check()
        self.root.after(4500, self.apply_hw)              # (the I/Q path back once it is done)

    def help_window(self):
        """The help file (NBTV_SDR_Help.txt, next to the program) in a window of its own."""
        if getattr(self, "help_win", None) is not None:
            try:
                self.help_win.lift()
                return
            except Exception:
                self.help_win = None
        w = tk.Toplevel(self.root, bg=CARD)
        w.title("%s %s - Help" % (APP, VERSION))
        self.help_win = w

        def closed():
            self.help_win = None
            w.destroy()
        w.protocol("WM_DELETE_WINDOW", closed)
        r = self.frame(w)
        r.pack(fill=tk.X, padx=8, pady=6)
        if self.logo is not None:
            tk.Label(r, image=self.logo, bg=CARD).pack(side=tk.LEFT)
        tk.Label(r, text="%s %s\nGrant Taylor VE3XTV" % (APP, VERSION), bg=CARD, fg=FG, justify=tk.LEFT,
                 font=(SANS, 13, "bold")).pack(side=tk.LEFT, padx=10)
        f = self.frame(w)
        f.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        t = tk.Text(f, width=92, height=40, bg=FIELD, fg=FG, font=(MONO, 9), wrap="word",
                    relief=tk.FLAT, insertbackground=FG, padx=8, pady=6)
        sb = ttk.Scrollbar(f, orient=tk.VERTICAL, command=t.yview)
        t.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        t.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        try:
            with open(HELP_FILE, encoding="utf-8") as fh:
                txt = fh.read()
        except Exception as e:
            txt = "The help file %s could not be read: %s" % (HELP_FILE, e)
        t.tag_configure("head", foreground=ACC, font=(SANS, 11, "bold"))
        for line in txt.splitlines():
            if line.startswith("== "):
                t.insert(tk.END, line[3:].rstrip(" =") + "\n", "head")
            else:
                t.insert(tk.END, line + "\n")
        t.config(state=tk.DISABLED)
        self.btn(w, "Close", closed).pack(pady=(0, 8))

    def dec_defaults(self):
        for k in ("bright", "contrast", "colour", "sharp", "kmx", "wl", "fuzzy_c", "fuzzy_p", "cavg"):
            self.cfg[k] = DEFAULTS[k]
            if k in ("fuzzy_c", "fuzzy_p") and self.cfg["mode"] == "180x96":
                self.cfg[k] = 0                        # as your RX: Fuzzy 0 in 180 x 96
            v, val, fmt = self.sliders[k]
            v.set(self.cfg[k])
            val.config(text=fmt % self.cfg[k])

    def save_pic(self):
        if self.last_rx is None:
            return
        d = os.path.join(pictures_dir(), "NBTV SDR")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "nbtv-%s.png" % time.strftime("%Y%m%d-%H%M%S"))
        self.write_png(self.last_rx, p)
        self.log("Saved %s" % p)

    def write_png(self, rgb, path):
        if Image is not None:
            Image.fromarray(rgb).save(path)
        else:
            ph = tk.PhotoImage(data=b"P6 %d %d 255\n" % (rgb.shape[1], rgb.shape[0]) + rgb.tobytes(), format="PPM")
            ph.write(path, format="png")

    def record(self):
        if self.rec_dir is None:
            self.rec_dir = os.path.join(pictures_dir(), "NBTV SDR", "rec-%s" % time.strftime("%Y%m%d-%H%M%S"))
            os.makedirs(self.rec_dir, exist_ok=True)
            self.rec_n = 0
            self.rec_audio = open(os.path.join(self.rec_dir, "audio.s16"), "wb")
            self.rec_amap = collections.OrderedDict()
            self.rec_rs = None
            lay = C.layout(self.cfg["mode"], bool(self.cfg.get("long_sym", 0)), int(self.cfg["cp"]), int(self.cfg.get("fixed_fps", 0)), bool(self.cfg.get("pilots16", 0)))
            self.rec_clk = C.AudioClock(C.frame_seconds(lay, self.cfg["cp"]) / lay.halves)
            self.rec_btn.config(text="Stop rec", bg="#8b2b2b")
            self.log("Recording to %s" % self.rec_dir)
        else:
            self.rec_audio.close()
            d, n = self.rec_dir, self.rec_n
            self.rec_dir = None
            self.rec_btn.config(text="Record", bg="#323942")
            ff = shutil.which("ffmpeg")
            m = C.MODES[self.cfg["mode"]]
            if ff and n:
                out = d + ".mp4"
                lay = C.layout(m, bool(self.cfg.get("long_sym", 0)), int(self.cfg["cp"]), int(self.cfg.get("fixed_fps", 0)), bool(self.cfg.get("pilots16", 0)))
                ppf = getattr(self, "rec_ppf", None) or C.pics_per_frame(C.eff_enc(m, int(self.cfg["enc"])))
                fps = ppf * lay.halves / C.frame_seconds(lay, self.cfg["cp"])     # (25 with the in-between pictures)
                cmd = [ff, "-y", "-loglevel", "error", "-framerate", "%.4f" % fps, "-i", os.path.join(d, "f%05d.png"),
                       "-f", "s16le", "-ar", str(C.AUDIO_FS), "-ac", "2", "-i", os.path.join(d, "audio.s16"),
                       "-vf", "scale=%d:%d:flags=neighbor" % (480, 384 if m.w == 120 else 256), "-pix_fmt", "yuv420p", "-shortest", out]
                threading.Thread(target=self.rec_finish, args=(cmd, d, out, n), daemon=True).start()
            else:
                self.log("Recording: %d pictures in %s" % (n, d))

    def rec_finish(self, cmd, d, out, n):
        """The video made from the recording's pictures and sound; then, only if it really is there, the
        folder of pictures and the sound file removed (they take far more room than the video)."""
        try:
            r = subprocess.run(cmd, capture_output=True, text=True)
        except Exception as e:
            self.log("Recording: ffmpeg did not run (%s) - the pictures and sound are kept in %s" % (e, d))
            return
        if r.returncode != 0 or not os.path.isfile(out) or os.path.getsize(out) < 1024:
            why = (r.stderr or "").strip().splitlines()
            self.log("Recording: the video was not made (%s) - the pictures and sound are kept in %s"
                     % (why[-1][:160] if why else "ffmpeg exit %d" % r.returncode, d))
            return
        size = 0
        for root_, _, files in os.walk(d):
            for f_ in files:
                try:
                    size += os.path.getsize(os.path.join(root_, f_))
                except OSError:
                    pass
        try:
            shutil.rmtree(d)
            self.log("Recording saved: %s (%.1f MB) - the %d pictures and the sound (%.1f MB) removed"
                     % (out, os.path.getsize(out) / 1e6, n, size / 1e6))
        except Exception as e:
            self.log("Recording saved: %s - but %s could not be removed (%s)" % (out, d, e))

    def close(self):
        if getattr(self, "lg_win", None) is not None and not getattr(self, "lg_full", False):
            try:                                          # (the large view's size, kept for next time)
                self.cfg["large_size"] = "%dx%d" % (self.lg_cv.winfo_width(), self.lg_cv.winfo_height())
            except Exception:
                pass
        if self.cfg.get("ptt", 0):
            self.ptt_toggle(False)
            time.sleep(0.6)                               # (the RX command on its way to the radio)
        save_cfg(self.cfg)
        self.avp.close()
        self.eng.stop()
        try:
            self.radio_link.close()
        except Exception:
            pass
        for card, prof in (getattr(self, "pulse_held", None) or {}).items():   # (the cards back to the sound server)
            try:
                err = C.pulse_set_profile(card, prof)
                print("Gave %s back (profile %s)%s" % (card, prof, (": " + err) if err else ""))
            except Exception:
                pass
        self.eng.source.close()
        if self.rec_dir is not None:
            self.record()
        self.root.destroy()

    def load_text(self, d):
        """How busy the stages are, against the air time of a data frame (and the TX peaks)."""
        pk = ""
        if d.get("papr") is not None:
            pin = d.get("papr_in")
            pk = "   PAPR %s%.1f dB%s" % (("%.1f -> " % pin) if pin is not None and pin - d["papr"] > 0.2 else "", d["papr"],
                                       ("  (+%.1f dB C/N)" % d["peak_gain"]) if d.get("peak_gain") else "")
        return self._load_text(d) + pk

    def _load_text(self, d):
        dec = [self.last_dec_time] if getattr(self, "last_dec_time", None) is not None else []
        up = [self.last_up_time] if getattr(self, "last_up_time", None) is not None else []
        if d.get("cores", 1) > 1:
            return "modem %.0f + decode %.0f + upscale %.0f ms (4 cores)" % (
                d.get("modem_time", 0) * 1000, (dec[-1] if dec else 0) * 1000, (up[-1] if up else 0) * 1000)
        return "%.0f ms/frame (1 core)" % ((d.get("modem_time", 0) + sum(dec) + sum(up)) * 1000)

    # ------------------------------------------------------------ drawing
    def photo(self, rgb, w, h):
        a = resize(rgb, w, h, smooth=True)
        return tk.PhotoImage(data=b"P6 %d %d 255\n" % (w, h) + np.ascontiguousarray(a).tobytes(), format="PPM")

    def tick(self):
        try:
            self.update_ui()
        except Exception as e:
            import traceback
            tb = traceback.extract_tb(e.__traceback__)[-1]
            self.log("GUI: %s (line %d, %s)" % (e, tb.lineno, tb.name))
        self.root.after(40, self.tick)

    # ---- the position bar under the TX viewer
    def pos_frac(self, ev):
        try:
            w = max(1, self.pos_bar.winfo_width())
            return min(1.0, max(0.0, (ev.x - 8) / float(max(1, w - 16))))   # (the slider's half-width at each end)
        except Exception:
            return None

    def pos_press(self, ev):
        p = self.eng.source.position()
        if not p or not p[2]:
            return "break"                                # (live / not a video: nothing to move)
        self.pos_drag = True
        f = self.pos_frac(ev)
        if f is not None:                                 # (a click anywhere on the bar: straight there)
            self.v_pos.set(f * p[1])
            self.pos_t.config(text=fmt_time(f * p[1]))
        return "break"

    def pos_motion(self, ev):
        if not self.pos_drag:
            return "break"
        p = self.eng.source.position()
        f = self.pos_frac(ev)
        if p and p[1] and f is not None:
            self.v_pos.set(f * p[1])
            self.pos_t.config(text=fmt_time(f * p[1]))
        return "break"

    def pos_release(self, ev):
        if not self.pos_drag:
            return "break"
        self.pos_drag = False
        t = float(self.v_pos.get())
        try:
            self.eng.source.seek(t)
        except Exception as e:
            self.log("Seek: %s" % e)
        return "break"

    def update_pos(self):
        """The time and the bar for a video file or stream (moved by hand: left alone while dragged)."""
        try:
            p = self.eng.source.position()
        except Exception:
            p = None
        if p is None:
            if getattr(self, "pos_shown", None) != "none":
                self.pos_shown = "none"
                self.pos_t.config(text="")
                self.pos_d.config(text="")
                self.v_pos.set(0.0)
                self.pos_bar.state(["disabled"])
            return
        t, dur, seekable = p
        if seekable:
            if self.pos_shown != "seek":
                self.pos_shown = "seek"
                self.pos_bar.state(["!disabled"])
            self.pos_bar.config(to=max(dur, 1.0))
            self.pos_d.config(text=fmt_time(dur))
            if not self.pos_drag:
                self.v_pos.set(t)
                self.pos_t.config(text=fmt_time(t))
        else:
            if self.pos_shown != "live":
                self.pos_shown = "live"
                self.pos_bar.state(["disabled"])
                self.v_pos.set(0.0)
            src = self.eng.source
            self.pos_d.config(text="LIVE" if getattr(src, "live", None) else "...")
            self.pos_t.config(text=fmt_time(t))

    def update_ui(self):
        self.update_pos()
        now = time.time()
        due = []
        while self.wide_q and self.wide_q[0][0] <= now:
            due.append(self.wide_q.popleft())
        if due:
            self.draw_wide([x[1] for x in due], due[-1][2])
        got = None
        while True:
            try:
                got = self.eng.q.get_nowait()
            except queue.Empty:
                break
            self.take(got, now)
        # fast: the newest decoded picture as it comes (real time: video_tick, by the sound's clock)
        if self.show_q:
            self.show_rx(self.show_q[-1][1])
            self.show_q.clear()
        # nothing decoded for a while: say so, rather than leave the last picture up as if it were live
        try:
            ft = C.frame_seconds(self.eng.lay, self.cfg["cp"])
        except Exception:
            ft = 1.0
        if not getattr(self, "no_signal", False) and now - getattr(self, "rx_pic_t", now) > max(2.5 * ft, 1.5):
            self.no_signal = True
            self.dec_info.config(text="No signal: nothing decoded")
            if self.cfg.get("rx_mute", 1) or getattr(self, "snow", None) is None:
                self.show_rx(None, blank=True)
            self.log("Receiver: no signal")
        self.poll_radio()
        self.log_lbl.config(text="\n".join(list(self.logs)[-6:]))

    def snd_tag(self, r):
        t = []
        if r.get("nr", "Off") != "Off":
            t.append("NR %s" % r["nr"])
        if r.get("emph", "Off") != "Off":
            t.append("emph %s" % r["emph"].replace(" us", " \u00b5s"))
        if r.get("comp"):
            t.append("compander %s" % r["comp"].lower() + (" (R-L lift %+.0f dB)" % -r["comp_gain"] if r.get("comp_gain") is not None else ""))
        if r.get("ms"):
            t.append(r["ms"][0] if r["ms"][1] is None else "sum/diff %s, stereo %d%%" % (r["ms"][0], round(100 * r["ms"][1])))
        if hasattr(self, "ms_lbl"):
            txt = (r["ms"][0] if r["ms"][1] is None else "%s, stereo %d%%" % (r["ms"][0], round(100 * r["ms"][1]))) if r.get("ms") else ""
            if txt != getattr(self, "_ms_shown", None):
                self._ms_shown = txt
                self.ms_lbl.config(text=txt)
        return ", ".join(t)

    def av_text(self):
        """How the pictures and sound are keeping together."""
        if not self.cfg["realtime"]:
            return "A/V: Fast - not timed"
        r = self.avp.report()
        if r is None or not r["playing"]:
            return "A/V: filling the buffer ..."
        tx = self.eng.source.av_skew if hasattr(self.eng.source, "a_taken") else 0.0
        return ("A/V %+.0f ms (+-%.0f)   sound buffer %.2f s   clock trim %+.0f ppm   lost %d   gaps %d   TX %+.0f ms"
                % (r["av_ms"], r["av_jit_ms"], r["depth"], r["ppm"], r["lost"], r["under"], tx * 1000))

    def record_frame(self, pic_start, rgbs, part=0, nparts=1):
        """Recording: each frame's pictures with that same frame's sound (kept until its pictures
        come; with long symbols, each half with its half), the sound stretched to the air time - so
        the file's pictures and sound are the same length, frame by frame."""
        key = int(round(pic_start * 1000)) if pic_start is not None else None
        a = self.rec_amap.get(key) if key is not None else None
        if a is None or not rgbs:
            return
        if part >= nparts - 1:
            self.rec_amap.pop(key, None)
        h = len(a) // nparts
        a = a[part * h:(part + 1) * h]
        n = self.rec_clk.next()
        if self.rec_rs is None:
            self.rec_rs = C.StreamResampler(len(a) / 2.0 / self.rec_clk.per)
        ra = np.asarray(self.rec_rs.process(np.asarray(a, np.float32), n), np.float64)
        self.rec_audio.write(np.clip(np.round((ra - 128.0) * 256.0), -32768, 32767).astype("<i2").tobytes())
        self.rec_ppf = len(rgbs)
        for rgb in rgbs:
            self.write_png(rgb, os.path.join(self.rec_dir, "f%05d.png" % self.rec_n))
            self.rec_n += 1

    def snow_picture(self, z, ref):
        """Video noise from what the receiver is getting: each pixel the size of a received sample,
        turned up as a TV's AGC would (noise = snow; nothing at all, digital silence = black)."""
        shp = self.last_rx.shape if getattr(self, "last_rx", None) is not None else (96, 120, 3)
        n = shp[0] * shp[1] * 3
        z = np.resize(np.asarray(z), n)
        r = float(np.sqrt(np.mean(np.abs(z) ** 2)))
        if r < 1e-6 * max(float(ref or 1.0), 1e-9):     # true silence (nothing at all): black
            return np.zeros(shp, np.uint8)
        a = np.abs(z) / r * 100.0                         # as a TV's AGC would: the noise turned up
        return np.clip(a, 0, 255).astype(np.uint8).reshape(shp)

    def show_rx(self, rgb, blank=False, snow=False):
        if snow:
            pass
        elif blank:
            rgb = np.full_like(self.last_rx if getattr(self, "last_rx", None) is not None else
                               np.zeros((96, 120, 3), np.uint8), 24)
        elif getattr(self, "no_signal", False):
            return                                        # (an old picture still queued: not now)
        self.last_rx = rgb
        w, h = self.pic_size()
        self.dec_img = self.photo(rgb, w, h)
        self.dec_cv.delete("all")
        self.dec_cv.create_image(0, 0, image=self.dec_img, anchor="nw")
        if blank and not snow:
            self.dec_cv.create_text(w // 2, h // 2, text="NO SIGNAL", fill="#e06c75", font=F_HEAD)
        self.draw_large(rgb)

    def video_tick(self):
        """Every 10 ms: show the picture whose time the sound (or, with the sound off, the clock
        that stands in for it) has reached."""
        try:
            now = time.time()
            dt = now - getattr(self, "vt_last", now)
            self.vt_last = now
            if self.cfg["realtime"]:
                rgb = self.avp.pick(self.avp.clock(min(dt, 0.2)))
                if rgb is not None:
                    self.show_rx(rgb)
        except Exception as e:
            self.log("Video: %s" % e)
        self.root.after(10, self.video_tick)

    def take_pics(self, d, now):
        """A frame's pictures (from the decoder, maybe enlarged and with in-between pictures)."""
        c = self.cfg
        self.rx_pic_t = now
        self.no_signal = False
        rgbs = [C.finish_picture(ycc, colour=c["colour"], bright=c["bright"], contrast=c["contrast"],
                                 sharp=c["sharp"], mono=not c["ycol"]) for ycc in d["yccs"]]
        if c["realtime"]:
            self.avp.push_pics(d["pic_start"], rgbs, d.get("part", 0), d.get("nparts", 1))
        else:
            self.show_q.extend((now, x) for x in rgbs)
        if self.rec_dir is not None:
            self.record_frame(d["pic_start"], rgbs, d.get("part", 0), d.get("nparts", 1))
        if d.get("pic_db"):
            self.pic_db_txt = "pictures " + " / ".join("%.1f" % x for x in d["pic_db"]) + " dB"
        self.last_filt = d.get("filt")
        self.last_dec_time = d.get("dec_time")
        if d.get("up_time") is not None:
            self.last_up_time = d["up_time"]

    def take(self, d, now):
        if d.get("kind") == "pics":
            self.take_pics(d, now)
            return
        m = C.MODES[self.cfg["mode"]]
        w, h = self.pic_size()
        self.enc_img = self.photo(d["sent"][0], w, h)
        self.enc_cv.delete("all")
        self.enc_cv.create_image(0, 0, image=self.enc_img, anchor="nw")
        tx = bool(self.cfg.get("ptt", 0))
        if d.get("wide") and d.get("wide_mode", "Off") == self.cfg.get("hw_mode", "Off"):
            # (a frame made before TX / RX / loop back was switched - still in the pipeline - is not drawn)
            # a data frame's rows (one per 50 ms of signal) shown over the frame's own time, as they came,
            # so the spectrum and waterfall move in real time rather than jump once a frame
            try:
                ft = C.frame_seconds(self.eng.lay, self.cfg["cp"])
            except Exception:
                ft = 0.25
            rows = d["wide"]
            t0 = max(now, self.wide_q[-1][0] if self.wide_q else now)
            if t0 - now > 1.5 * ft:                       # (behind: catch up)
                self.wide_q.clear()
                t0 = now
            wtx = bool(d.get("wide_tx", False)) and not self.cfg.get("sw_loop", 0)   # (the frame's own: TX out or RX in)
            for i, row in enumerate(rows):
                self.wide_q.append((t0 + ft * i / float(len(rows)), row, wtx))
        self.snow = (d.get("snow"), d.get("snow_ref")) if d.get("snow") is not None else None
        if self.snow is not None and getattr(self, "no_signal", False) and not self.cfg.get("rx_mute", 1):
            self.show_rx(self.snow_picture(*self.snow), snow=True)
        st = d["stats"]
        if d.get("const") is not None:
            self.draw_const(d["const"], flip=d.get("const_flip"))
        if d.get("const_a") is not None:
            self.draw_const(d["const_a"], audio=True, flip=d.get("const_flip_a"))
        a = self.eng.sent[-1][1] if self.eng.sent else None
        if a is not None:
            self.draw_meter(self.ain_cv, a)
        rxs = d.get("rx", [])
        c = self.cfg
        self.rx_native = "%dx%d" % C.pic_size(m, int(c["enc"]))
        enc = C.eff_enc(m, int(c["enc"]))
        lay = getattr(self.eng, "lay", None) or m
        period = C.frame_seconds(lay, c["cp"])
        lag = 0 if enc == 5 else 1                        # the decoder gives a frame's pictures with the next one
        rt = bool(self.cfg["realtime"])
        self.avp.configure(period, lay.halves * C.pics_per_frame(enc) * self.eng.fps_factor(), lag)
        if self.avp.sync is not None:
            # + : pictures earlier; the sound's noise reduction holds it back 21 ms: the pictures wait too
            self.avp.sync.lip = float(c.get("lip_ms", 0)) / 1000.0 - 512.0 / C.AUDIO_FS
        self.avp.set_sound(rt and bool(c["audio_out"]))
        for r in rxs:
            if rt:
                self.avp.push(r["audio"], r["start_s"])
            self.draw_carriers(r["per"])
            self.last_cn = r.get("snr_est")
            if self.rec_dir is not None:
                self.rec_amap[int(round(r["start_s"] * 1000))] = r["audio"]
                while len(self.rec_amap) > 8:
                    self.rec_amap.popitem(last=False)
            self.draw_meter(self.aout_cv, r["audio"])
            fu = getattr(self, "last_filt", None) or (0, 0, False, 0.0)
            self.show_auto_cleanup(fu)
            # one item a line, so nothing runs off the end
            idt = self.id_text().strip()
            self.dec_info.config(text="%sRX C/N %s   pilots %.2f\nSound: %s\nClean-up%s: fuzzy %d/%d%s%s%s\n%s%s"
                                      % ("MONITOR (own TX)   " if self.cfg.get("ptt", 0) else "",
                                         (">60 dB" if r["snr_est"] > 60 else "%.1f dB" % r["snr_est"]) if r.get("snr_est") is not None else "-",
                                         r["coherence"], self.snd_tag(r) or "-",
                                         " (auto)" if c["auto_f"] else "", fu[0], fu[1],
                                         ", median" if fu[2] else "", ", frames %.2f" % fu[3] if fu[3] else "",
                                         (", temporal NR %d%%" % round(100 * fu[4]) if len(fu) > 4 and fu[4] else ""),
                                         self.av_text(), ("\nStation: " + idt) if idt else ""))
        self.sync_hist.append((st.get("state", "-"), st.get("cfo", 0.0), d.get("timing_err", 0.0),
                               st.get("coherence", 0.0)))
        self.draw_sync(d.get("timing_curve"))
        state = st.get("state", "searching")
        col = {"locked": "#6ccf7a", "lost": "#ff6b6b"}.get(state, "#e5c07b")
        au = d.get("auto")
        if au is not None:
            self.auto_txt = self.auto_text(au)
        echo = d.get("echo_est", 0) if self.cfg["eq"] == "taps" else None
        self.modem_info.config(fg=col, text="%s   %s sync %.2f   freq %+.1f Hz   clock %+.0f ppm   timing %s%s   frame %d   %s"
                                            % (state.upper(), {"std": "Std", "hxdx": "HxDX", "lab": "PN"}[self.cfg["sync"]],
                                               st.get("sync_q", 0.0), st.get("cfo", 0.0), -st.get("ppm", 0.0), st.get("offset", "-"),
                                               ("   echo %d smp" % echo) if echo else "", self.eng.frames,
                                               self.load_text(d))
                                    + ("\n" + getattr(self, "auto_txt", "") if self.cfg.get("auto_rx", 0) else ""))
        if hasattr(self, "gpu_lbl"):
            gt = self.gpu_text()
            if gt != getattr(self, "_gpu_shown", None):
                self._gpu_shown = gt
                self.gpu_lbl.config(text=gt, fg="#6ccf7a" if self.cfg.get("gpu", 0) and not gt.startswith(("CPU", "wait"))
                                    else ("#e5c07b" if self.cfg.get("gpu", 0) else FG))
        fg = d.get("fade_gain", 1.0)
        fe = d.get("front") or {}
        fe_txt = ""
        if fe:
            fe_txt = "   RX: %s %+.0f dB, ADC %.0f dBFS%s, pilots %+.1f dB" % (
                "AGC" if self.cfg.get("rx_agc") == "AGC" else "gain", fe.get("agc_db", 0.0), fe.get("rms_dbfs", 0.0),
                (", clipping %.1f%%" % (100 * fe["clip"])) if fe.get("clip", 0) > 0.0005 else "",
                fe["level"] if fe.get("level") is not None else 0.0)
        hw = d.get("hw")
        self.hw_last = hw
        if not hw:
            src, col = ("RX input: software loop back (TX straight in)" if self.cfg.get("sw_loop", 0) else
                        "RX input: own TX (monitor)" if self.cfg.get("ptt", 0) else "RX input: none (no hardware)"), FG
        elif hw.get("err"):
            src, col = ("RX input: NOTHING - the I/Q device failed (%s)" % hw["err"][:60] if hw.get("mode") != "TX out"
                        else "TX: NOT GOING OUT - the I/Q device failed (%s)" % hw["err"][:60]), "#e06c75"
        elif hw.get("rx"):
            src, col = "RX input: %s (%s), in %.1f dBFS" % (self.cfg.get("hardware") if C.iq_kind(self.cfg.get("hw_in")) else "sound card",
                                                           hw.get("mode"), hw.get("in_dbfs", -120)), "#6ccf7a"
        else:
            src, col = "RX input: own TX (monitor) - TX going out of the %s" % (
                self.cfg.get("hardware") if C.iq_kind(self.cfg.get("hw_out")) else "sound card"), "#ff8a65"
        if getattr(self, "rxsrc_lbl", None) is not None:
            self.rxsrc_lbl.config(text=src, fg=col)
        if hw:
            st = (hw.get("mode"), hw.get("err"))
            if st != getattr(self, "hw_logged", None):     # say once what the card did
                self.hw_logged = st
                if hw.get("err") and "busy" in hw["err"] and self.card_held():
                    self.log("Hardware %s: the card is still busy - the sound server letting go after Release card;"
                             " trying again every 2 s" % st[0])
                elif hw.get("err"):
                    rxs = st[0] in ("Loop", "RX in")
                    self.log("Hardware %s FAILED - %s.  %s" % (st[0], st[1], "The receiver gets nothing." if rxs
                                                                     else "Nothing is going out."))
                    busy = "busy" in (st[1] or "") and not self.card_held()
                    if busy:
                        self.root.after(50, self.release_card)   # (it asks first)
                    try:
                        from tkinter import messagebox
                        if busy:
                            raise RuntimeError
                        messagebox.showerror("Hardware %s failed" % st[0], "The I/Q device did not open:\n\n%s\n\n"
                                             "Output: %s\nInput: %s\n\nRadio / I/Q setup... lists them (and has Card check)." % (st[1], self.cfg.get("hw_out"), self.cfg.get("hw_in")),
                                             parent=self.root)
                    except Exception:
                        pass
                else:
                    self.log("Hardware %s running at %s (%s%s)" % (
                        st[0], ("2 Msps, %.4f MHz" % (hw["freq"] / 1e6)) if hw.get("rf") and hw.get("freq") else "192 kHz",
                        "out: %s" % self.cfg.get("hw_out") if hw.get("tx") else "",
                        ("%sin: %s" % (", " if hw.get("tx") else "", self.cfg.get("hw_in"))) if hw.get("rx") else ""))
            hot = hw.get("rx") and hw.get("in_dbfs", -120) > -6.0
            col = "#e06c75" if (hw.get("err") or hot or hw.get("in_clip", 0) > 1e-3) else (
                "#e5c07b" if (hw.get("under") or hw.get("late") or hw.get("in_clip", 0) > 1e-4 or
                              hw.get("out_clip", 0) > 1e-4) else "#6ccf7a")
            self.rw_lbl.config(text=self.hw_text(hw), fg=col)
            if getattr(self, "hw_stat", None) is not None:
                try:
                    self.hw_stat.config(text=self.hw_text(hw, True), fg=col)
                except Exception:
                    pass
        else:
            self.hw_logged = None
            self.rw_lbl.config(fg=MUTED)
            if getattr(self, "hw_stat", None) is not None:
                try:
                    self.hw_stat.config(text="Hardware off", fg=FG)
                except Exception:
                    pass
            self.rw_lbl.config(text="Software loop back: no hardware in use (the radio stays on RX)" if self.cfg.get("sw_loop", 0)
                               else "Hardware: none - choose one under Encode and TX (Radio / I/Q setup...)")
        lay = C.layout(m, bool(self.cfg.get("long_sym", 0)), int(self.cfg["cp"]), int(self.cfg.get("fixed_fps", 0)), bool(self.cfg.get("pilots16", 0)))
        ft = C.frame_seconds(lay, self.cfg["cp"])
        self.info.config(text="%s  mode %s  %.1f fps  %.2f s per data frame  %d carriers"
                              % (m.name, C.enc_short(self.cfg["enc"]), lay.halves * C.pics_per_frame(int(self.cfg["enc"])) / ft,
                                 ft, lay.nfft))
        # the signal meter: the channel's level coming in (or what is going out)
        if tx:
            self.draw_smeter(hw.get("out_dbfs") if hw and hw.get("tx") else None, tx=True)
        else:
            self.draw_smeter(hw.get("ch_dbfs") if hw and hw.get("rx") and not hw.get("err") else None)
        cn = getattr(self, "last_cn", None)
        stt = d["stats"]
        self.sm_info.config(text="%s   C/N %s   %s" % (
            state.upper(), ((">60 dB" if cn > 60 else "%.1f dB" % cn)) if cn is not None and state == "locked" else "-",
            ("freq %+.0f Hz" % stt.get("cfo", 0.0)) if state == "locked" else ""),
            fg={"locked": "#6ccf7a", "lost": "#ff6b6b"}.get(state, "#e5c07b"))

    def lut(self):
        if not hasattr(self, "_lut"):
            x = np.linspace(0, 1, 256)                    # black - blue - cyan - yellow - red - white
            pts = [(0, (0, 0, 0)), (0.25, (0, 0, 160)), (0.45, (0, 170, 220)), (0.65, (240, 230, 0)),
                   (0.85, (255, 40, 0)), (1.0, (255, 255, 255))]
            xs = [p[0] for p in pts]
            self._lut = np.stack([np.interp(x, xs, [p[1][i] for p in pts]) for i in range(3)], -1).astype(np.uint8)
        return self._lut

    def draw_const(self, z, audio=False, flip=None):
        """A vector scope: where the carriers' values land (I across, Q up), a histogram on a log
        scale; the box is the full byte range.  Video carriers in blue-green, audio in amber; with the
        I/Q flip on, the points sent swapped in magenta (as received, before the swap is undone)."""
        cv = self.const_a_cv if audio else self.const_cv
        n = SCOPE
        x = np.clip(((z.real + 1.25) / 2.5 * n).astype(int), 0, n - 1)
        y = np.clip(((1.25 - z.imag) / 2.5 * n).astype(int), 0, n - 1)
        hst = np.zeros((n, n))
        fl = flip is not None and len(flip) == len(z)
        if fl:
            flip = np.asarray(flip, bool)
            np.add.at(hst, (y[~flip], x[~flip]), 1)
            hf = np.zeros((n, n))
            np.add.at(hf, (y[flip], x[flip]), 1)
        else:
            np.add.at(hst, (y, x), 1)
        top = np.log1p(max(hst.max(), hf.max() if fl else 0)) + 1e-9
        v = np.log1p(hst) / top
        img = np.stack((v * 255, v * 200, v * 90) if audio else (v * 120, v * 230, v * 255), -1)
        if fl:
            u = np.log1p(hf) / top
            img = np.maximum(img, np.stack((u * 255, u * 70, u * 230), -1))
        img = img.astype(np.uint8)
        img[n // 2, :] = np.maximum(img[n // 2, :], 40)
        img[:, n // 2] = np.maximum(img[:, n // 2], 40)
        q = int(n * 0.25 / 2.5)
        img[q, q:n - q] = img[n - q, q:n - q] = (90, 90, 50)
        img[q:n - q, q] = img[q:n - q, n - q] = (90, 90, 50)
        photo = tk.PhotoImage(data=b"P6 %d %d 255\n" % (n, n) + img.tobytes(), format="PPM")
        if audio:
            self.const_a_img = photo
        else:
            self.const_img = photo
        cv.delete("all")
        cv.create_image(0, 0, image=photo, anchor="nw")
        cv.create_text(3, 3, anchor="nw", text=("audio carriers" if audio else "video carriers") + ("  I/Q flip" if fl else ""),
                       fill=MUTED, font=F_SMALL)
        snr = getattr(self, "car_snr", {}).get("audio" if audio else "video")
        if snr is not None:
            cv.create_text(n - 3, n - 3, anchor="se", text="%.1f dB" % snr, fill=MUTED, font=F_SMALL)

    def draw_carriers(self, per):
        m_ = getattr(self.eng, "lay", None) or C.MODES[self.cfg["mode"]]
        if len(per) != m_.nfft:
            return
        with np.errstate(all="ignore"):
            self.car_snr = {"video": float(np.nanmean(per[m_.video_bins])), "audio": float(np.nanmean(per[m_.audio_bins]))}
        cv = self.car_cv
        W, H = max(100, cv.winfo_width() or 0), int(cv["height"])
        cv.delete("all")
        m = m_
        bw = W / float(m.nfft)
        for db in (10, 20, 30, 40):
            y = H - 2 - db / 50.0 * (H - 12)
            cv.create_line(0, y, W, y, fill="#1d2630")
        aud = set(m.audio_bins.tolist())
        pil = set(m.pilot_bins.tolist())
        for k in range(m.nfft):
            x = k * bw
            if k in pil:
                cv.create_line(x + bw / 2, 10, x + bw / 2, H, fill="#e5c07b")
                continue
            v = per[k]
            if v != v:
                continue
            y = H - 2 - clamp(v, 0, 50) / 50.0 * (H - 12)
            cv.create_rectangle(x, y, x + max(1, bw - 0.4), H, outline="", fill="#5f9bff" if k in aud else "#6ccf7a")
        cv.create_text(3, 2, anchor="nw", text="SNR per carrier: video green, audio blue, pilots yellow",
                       fill=MUTED, font=F_SMALL)

    def draw_sync(self, curve):
        cv = self.sync_cv
        W, H = max(100, cv.winfo_width() or 0), int(cv["height"])
        cv.delete("all")
        hist = list(self.sync_hist)[-100:]
        if curve is not None and len(curve) > 2:            # the timing search, when it ran
            ys = H - 4 - np.clip(np.asarray(curve), 0, 1) * (H - 14)
            xs = np.linspace(0, W, len(curve))
            cv.create_line(*np.column_stack((xs, ys)).ravel().tolist(), fill="#c678dd")
        if len(hist) > 1:
            xs = np.linspace(0, W, len(hist))
            te = np.array([h[2] for h in hist])
            ys = H / 2 - np.clip(te, -4, 4) / 4.0 * (H / 2 - 6)
            cv.create_line(*np.column_stack((xs, ys)).ravel().tolist(), fill="#5fd3f3")
            co = np.array([h[3] for h in hist])
            ys = H - 4 - np.clip(co, 0, 1) * (H - 14)
            cv.create_line(*np.column_stack((xs, ys)).ravel().tolist(), fill="#6ccf7a")
        cv.create_line(0, H / 2, W, H / 2, fill="#1d2630")
        cv.create_text(3, 2, anchor="nw", text="sync: timing +-4 smp (blue), pilots (green)",
                       fill=MUTED, font=F_SMALL)

    def draw_meter(self, cv, a):
        W, H = max(100, cv.winfo_width() or 0), int(cv["height"])
        cv.delete("all")
        a = a.astype(np.float32) - 128.0
        for i, ch in enumerate((a[0::2], a[1::2])):
            lvl = float(np.max(np.abs(ch))) / 128.0 if len(ch) else 0.0
            y0 = 2 + i * 7
            col = "#6ccf7a" if lvl < 0.7 else "#e5c07b" if lvl < 0.9 else "#ff6b6b"
            cv.create_rectangle(0, y0, W * clamp(lvl, 0, 1), y0 + 5, outline="", fill=col)


def list_devices():
    """--list-devices: the sound devices (with their 192 kHz ability) and serial ports this computer has."""
    print("%s %s on %s" % (APP, VERSION, sys.platform))
    devs, err = C.hw_devices()
    print("Sound devices / SDRs:" + ("  (%s)" % err if err else ""))
    for e in devs:
        print("  %-60s in %d%s  out %d%s" % (e["name"], e["ins"], " 192k" if e.get("in192") else "", e["outs"],
                                             " 192k" if e.get("out192") else ""))
    print("Serial ports: %s" % (", ".join(list_ports()) or "none"))


def gpu_check():
    """--gpu-check: everything about the GPU in one go - the versions, the card, and CuPy's own full error."""
    import platform
    import shutil
    import subprocess
    import traceback
    print("%s %s - GPU check" % (APP, VERSION))
    print("Python %s  (%s)" % (platform.python_version(), sys.executable))
    print("NumPy  %s  (%s)" % (np.__version__, os.path.dirname(np.__file__)))
    try:
        from importlib import metadata as md
        for d in ("cupy-cuda13x", "cupy-cuda12x", "cupy-cuda11x", "cupy"):
            try:
                print("%-13s %s" % (d, md.version(d)))
            except Exception:
                pass
    except Exception:
        pass
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version", "--format=csv,noheader"],
                                 capture_output=True, text=True, timeout=10)
            print("Card / driver: %s" % (out.stdout.strip() or out.stderr.strip()))
            top = subprocess.run(["nvidia-smi"], capture_output=True, text=True, timeout=10).stdout
            ver = [l for l in top.splitlines() if "CUDA Version" in l]
            if ver:
                print(ver[0].strip(" |"))
        except Exception as e:
            print("nvidia-smi: %s" % e)
    else:
        print("nvidia-smi not found (no NVIDIA driver loaded?)")
    try:
        other = C.cuda_namespace_fix()
        if other:
            print("Another package called 'cuda' set aside for this program: %s\n"
                  "  (it is not NVIDIA's - CuPy was loading it, and GNU Radio with it)" % other)
        try:                                          # (what a child process - CuPy's own library probe - finds)
            r = subprocess.run([sys.executable, "-c", "import cuda, cuda.pathfinder; print(list(cuda.__path__))"],
                               capture_output=True, text=True, timeout=30)
            print("A child process finds 'cuda' in: %s" % ((r.stdout.strip() or r.stderr.strip().splitlines()[-1])
                                                            if (r.stdout or r.stderr) else "?"))
        except Exception as e:
            print("Child process check: %s" % e)
        import cupy
        print("CuPy imported: %s" % cupy.__version__)
        x = cupy.arange(1024, dtype=cupy.float32)
        print("Test on the card: %s (should be 1047552)" % float((x * 2.0).sum()))
        print("GPU OK: %s" % C.gpu_init()[0])
    except Exception as e:
        print("CuPy failed - its full error:\n")
        traceback.print_exc()
        print("\nIn short: %s" % C.gpu_why(e))


def main():
    import multiprocessing
    multiprocessing.freeze_support()                  # (Windows .exe: the worker processes start from it)
    # tools put next to the program (ffmpeg, hackrf_transfer, rtl_sdr, airspyhf_rx ...) are found there too
    extra = [d for d in (os.path.dirname(os.path.abspath(sys.argv[0])), os.path.dirname(sys.executable), HERE) if d]
    os.environ["PATH"] = os.pathsep.join(extra + [os.environ.get("PATH", "")])
    if "--list-devices" in sys.argv:
        list_devices()
        return
    if "--gpu-check" in sys.argv:
        gpu_check()
        return
    if IS_WIN:
        try:                                          # (sharp on a high-DPI Windows screen)
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()
    try:
        root.tk.call("tk", "scaling", 1.0 * root.winfo_fpixels("1i") / 72.0)
    except tk.TclError:
        pass
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
