#!/bin/bash
./Noise_filter/Noise_filter_RF.py
