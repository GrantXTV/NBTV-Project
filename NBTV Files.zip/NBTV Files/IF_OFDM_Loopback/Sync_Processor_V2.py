# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Sync_Processor_V2
# GNU Radio version: 3.10.12.0

from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import sys
import signal
import Sync_Processor_V2_epy_block_0 as epy_block_0  # embedded python block
import Sync_Processor_V2_epy_block_0_0 as epy_block_0_0  # embedded python block
import threading







class Sync_Processor_V2(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Sync_Processor_V2",
                gr.io_signature.makev(2, 2, [gr.sizeof_float*1, gr.sizeof_float*1]),
                gr.io_signature.makev(4, 4, [gr.sizeof_char*1, gr.sizeof_float*1, gr.sizeof_char*1, gr.sizeof_float*1]),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 3000

        ##################################################
        # Blocks
        ##################################################

        self.epy_block_0_0 = epy_block_0_0.blk()
        self.epy_block_0 = epy_block_0.blk()
        self.blocks_repeat_0_0 = blocks.repeat(gr.sizeof_char*1, 2)
        self.blocks_repeat_0 = blocks.repeat(gr.sizeof_char*1, 2)
        self.blocks_not_xx_0_0 = blocks.not_bb()
        self.blocks_not_xx_0 = blocks.not_bb()
        self.blocks_float_to_complex_1_0 = blocks.float_to_complex(1)
        self.blocks_float_to_complex_0_0 = blocks.float_to_complex(1)
        self.blocks_delay_0_1 = blocks.delay(gr.sizeof_float*1, 9)
        self.blocks_delay_0_0_0 = blocks.delay(gr.sizeof_float*1, 6)
        self.blocks_deinterleave_0 = blocks.deinterleave(gr.sizeof_char*1, 480)
        self.blocks_complex_to_float_1_0 = blocks.complex_to_float(1)
        self.blocks_complex_to_float_0_0 = blocks.complex_to_float(1)
        self.blocks_and_xx_0 = blocks.and_bb()
        self.blocks_add_const_vxx_1_0 = blocks.add_const_ff((-128))
        self.blocks_add_const_vxx_0_1 = blocks.add_const_ff((-128))
        self.band_pass_filter_0_1 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                samp_rate,
                100,
                150,
                10,
                window.WIN_KAISER,
                8.32))
        self.band_pass_filter_0_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                samp_rate,
                75,
                125,
                10,
                window.WIN_KAISER,
                8.32))
        self.analog_pll_refout_cc_1_0 = analog.pll_refout_cc(.2, 0.1, 0.066)
        self.analog_pll_refout_cc_0_0 = analog.pll_refout_cc(0.2, 0.083, 0.05)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_pll_refout_cc_0_0, 0), (self.blocks_complex_to_float_1_0, 0))
        self.connect((self.analog_pll_refout_cc_1_0, 0), (self.blocks_complex_to_float_0_0, 0))
        self.connect((self.band_pass_filter_0_0_0, 0), (self.analog_pll_refout_cc_0_0, 0))
        self.connect((self.band_pass_filter_0_1, 0), (self.analog_pll_refout_cc_1_0, 0))
        self.connect((self.blocks_add_const_vxx_0_1, 0), (self.blocks_delay_0_0_0, 0))
        self.connect((self.blocks_add_const_vxx_0_1, 0), (self.blocks_float_to_complex_0_0, 0))
        self.connect((self.blocks_add_const_vxx_1_0, 0), (self.blocks_delay_0_1, 0))
        self.connect((self.blocks_add_const_vxx_1_0, 0), (self.blocks_float_to_complex_1_0, 0))
        self.connect((self.blocks_and_xx_0, 0), (self.blocks_deinterleave_0, 0))
        self.connect((self.blocks_complex_to_float_0_0, 0), (self.epy_block_0, 0))
        self.connect((self.blocks_complex_to_float_0_0, 0), (self, 1))
        self.connect((self.blocks_complex_to_float_1_0, 0), (self.epy_block_0_0, 0))
        self.connect((self.blocks_complex_to_float_1_0, 0), (self, 3))
        self.connect((self.blocks_deinterleave_0, 0), (self.blocks_repeat_0, 0))
        self.connect((self.blocks_deinterleave_0, 1), (self.blocks_repeat_0_0, 0))
        self.connect((self.blocks_delay_0_0_0, 0), (self.blocks_float_to_complex_0_0, 1))
        self.connect((self.blocks_delay_0_1, 0), (self.blocks_float_to_complex_1_0, 1))
        self.connect((self.blocks_float_to_complex_0_0, 0), (self.band_pass_filter_0_1, 0))
        self.connect((self.blocks_float_to_complex_1_0, 0), (self.band_pass_filter_0_0_0, 0))
        self.connect((self.blocks_not_xx_0, 0), (self.blocks_and_xx_0, 0))
        self.connect((self.blocks_not_xx_0_0, 0), (self.blocks_and_xx_0, 1))
        self.connect((self.blocks_repeat_0, 0), (self, 0))
        self.connect((self.blocks_repeat_0_0, 0), (self, 2))
        self.connect((self.epy_block_0, 0), (self.blocks_not_xx_0, 0))
        self.connect((self.epy_block_0_0, 0), (self.blocks_not_xx_0_0, 0))
        self.connect((self, 0), (self.blocks_add_const_vxx_0_1, 0))
        self.connect((self, 1), (self.blocks_add_const_vxx_1_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.band_pass_filter_0_0_0.set_taps(firdes.band_pass(1, self.samp_rate, 75, 125, 10, window.WIN_KAISER, 8.32))
        self.band_pass_filter_0_1.set_taps(firdes.band_pass(1, self.samp_rate, 100, 150, 10, window.WIN_KAISER, 8.32))

