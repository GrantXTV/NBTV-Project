import numpy as np
from gnuradio import gr

class blk(gr.sync_block):
    """
    Zero Crossing Detector to Byte Trigger.

    Inputs:
    - Float Sine Wave

    Parameters:
    - None (Logic is fixed: 0 at crossing, 0xFF elsewhere)

    Output:
    - Byte stream: 0x00 at zero crossing, 0xFF otherwise.
    """
    def __init__(self):
        gr.sync_block.__init__(
            self,
            name="Zero Crossing Trigger",
            in_sig=[np.float32],
            out_sig=[np.uint8]
        )

        # State to track previous sample for crossing detection
        self.prev_sample = 0.0

    def work(self, input_items, output_items):
        n_samples = len(output_items[0])
        in_data = input_items[0]
        out_data = output_items[0]

        # Default output to 0xFF (High)
        out_data[:] = np.uint8(255)

        # Check for Zero Crossing
        # A crossing occurs if the sign changes between prev_sample and current sample
        # i.e., (prev > 0 and curr < 0) OR (prev < 0 and curr > 0)
        # We also handle the exact case where sample == 0.0

        for i in range(n_samples):
            curr = in_data[i]

            # Detect Sign Change or Exact Zero
            is_crossing = False

            if curr == 0.0:
                is_crossing = True
            elif (self.prev_sample > 0 and curr < 0) or \
                 (self.prev_sample < 0 and curr > 0):
                is_crossing = True

            if is_crossing:
                out_data[i] = np.uint8(0) # Output 0 at crossing

            # Update state for next sample
            self.prev_sample = curr

        return n_samples
