#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: IF OFDM Loopback
# Author: VE3XTV
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Audio_RX_Set import Audio_RX_Set  # grc-generated hier_block
from Audio_TX_Set import Audio_TX_Set  # grc-generated hier_block
from D192_Carrier_RX import D192_Carrier_RX  # grc-generated hier_block
from M192_Carrier_TX import M192_Carrier_TX  # grc-generated hier_block
from PyQt5 import QtCore
from Sync_Processor_V2 import Sync_Processor_V2  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import eng_notation
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import network
import sip
import threading



class IF_OFDM_Loopback(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "IF OFDM Loopback", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("IF OFDM Loopback")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "IF_OFDM_Loopback")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.variable_range = variable_range = 0
        self.variable_control_2 = variable_control_2 = 1196
        self.samp_rate = samp_rate = 200000
        self.UDP_VO = UDP_VO = 1234
        self.UDP_VI = UDP_VI = 1244
        self.UDP_SO = UDP_SO = 1236
        self.UDP_SI = UDP_SI = 1243
        self.UDP_IP = UDP_IP = '192.168.2.15'
        self.UDP_AO = UDP_AO = 1235
        self.UDP_AI = UDP_AI = 1245

        ##################################################
        # Blocks
        ##################################################

        self._variable_range_range = qtgui.Range(-100, 100, 1, 0, 200)
        self._variable_range_win = qtgui.RangeWidget(self._variable_range_range, self.set_variable_range, "Output Level", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._variable_range_win, 3, 1, 1, 4)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_VO_tool_bar = Qt.QToolBar(self)
        self._UDP_VO_tool_bar.addWidget(Qt.QLabel("UDP Video Port" + ": "))
        self._UDP_VO_line_edit = Qt.QLineEdit(str(self.UDP_VO))
        self._UDP_VO_tool_bar.addWidget(self._UDP_VO_line_edit)
        self._UDP_VO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_VO(int(str(self._UDP_VO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_VO_tool_bar, 2, 1, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_VI_tool_bar = Qt.QToolBar(self)
        self._UDP_VI_tool_bar.addWidget(Qt.QLabel("UDP Video Port " + ": "))
        self._UDP_VI_line_edit = Qt.QLineEdit(str(self.UDP_VI))
        self._UDP_VI_tool_bar.addWidget(self._UDP_VI_line_edit)
        self._UDP_VI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_VI(int(str(self._UDP_VI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_VI_tool_bar, 1, 1, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_SO_tool_bar = Qt.QToolBar(self)
        self._UDP_SO_tool_bar.addWidget(Qt.QLabel("UDP Sync Port" + ": "))
        self._UDP_SO_line_edit = Qt.QLineEdit(str(self.UDP_SO))
        self._UDP_SO_tool_bar.addWidget(self._UDP_SO_line_edit)
        self._UDP_SO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_SO(int(str(self._UDP_SO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_SO_tool_bar, 2, 3, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_SI_tool_bar = Qt.QToolBar(self)
        self._UDP_SI_tool_bar.addWidget(Qt.QLabel("UDP Sync Port" + ": "))
        self._UDP_SI_line_edit = Qt.QLineEdit(str(self.UDP_SI))
        self._UDP_SI_tool_bar.addWidget(self._UDP_SI_line_edit)
        self._UDP_SI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_SI(int(str(self._UDP_SI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_SI_tool_bar, 1, 3, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_IP_tool_bar = Qt.QToolBar(self)
        self._UDP_IP_tool_bar.addWidget(Qt.QLabel("UDP IP Address" + ": "))
        self._UDP_IP_line_edit = Qt.QLineEdit(str(self.UDP_IP))
        self._UDP_IP_tool_bar.addWidget(self._UDP_IP_line_edit)
        self._UDP_IP_line_edit.returnPressed.connect(
            lambda: self.set_UDP_IP(str(str(self._UDP_IP_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_IP_tool_bar, 2, 4, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_AO_tool_bar = Qt.QToolBar(self)
        self._UDP_AO_tool_bar.addWidget(Qt.QLabel("UDP_Audio Port" + ": "))
        self._UDP_AO_line_edit = Qt.QLineEdit(str(self.UDP_AO))
        self._UDP_AO_tool_bar.addWidget(self._UDP_AO_line_edit)
        self._UDP_AO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_AO(int(str(self._UDP_AO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_AO_tool_bar, 2, 2, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_AI_tool_bar = Qt.QToolBar(self)
        self._UDP_AI_tool_bar.addWidget(Qt.QLabel("UDP Audio Port " + ": "))
        self._UDP_AI_line_edit = Qt.QLineEdit(str(self.UDP_AI))
        self._UDP_AI_tool_bar.addWidget(self._UDP_AI_line_edit)
        self._UDP_AI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_AI(int(str(self._UDP_AI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_AI_tool_bar, 1, 2, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        if "int" == "int":
        	isFloat = False
        	scaleFactor = 1
        else:
        	isFloat = True
        	scaleFactor = 1

        _variable_control_2_dial_control = qtgui.GrDialControl('Delay', self, 1150,1250,1196,"default",self.set_variable_control_2,isFloat, scaleFactor, 100, True, "'value'")
        self.variable_control_2 = _variable_control_2_dial_control

        self.top_grid_layout.addWidget(_variable_control_2_dial_control, 1, 4, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_time_sink_x_0 = qtgui.time_sink_f(
            512, #size
            3000, #samp_rate
            "", #name
            4, #number of inputs
            None # parent
        )
        self.qtgui_time_sink_x_0.set_update_time(0.10)
        self.qtgui_time_sink_x_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_0.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_0.enable_tags(True)
        self.qtgui_time_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_AUTO, qtgui.TRIG_SLOPE_NEG, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_0.enable_autoscale(True)
        self.qtgui_time_sink_x_0.enable_grid(False)
        self.qtgui_time_sink_x_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_0.enable_control_panel(False)
        self.qtgui_time_sink_x_0.enable_stem_plot(False)


        labels = ['Signal 1', 'Signal 2', 'Signal 3', 'Signal 4', 'Signal 5',
            'Signal 6', 'Signal 7', 'Signal 8', 'Signal 9', 'Signal 10']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ['blue', 'red', 'green', 'black', 'cyan',
            'magenta', 'yellow', 'dark red', 'dark green', 'dark blue']
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]
        styles = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1]


        for i in range(4):
            if len(labels[i]) == 0:
                self.qtgui_time_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_time_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_0_win = sip.wrapinstance(self.qtgui_time_sink_x_0.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_0_win, 5, 1, 1, 4)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_sink_x_0 = qtgui.sink_c(
            1024, #fftsize
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "", #name
            True, #plotfreq
            True, #plotwaterfall
            True, #plottime
            True, #plotconst
            None # parent
        )
        self.qtgui_sink_x_0.set_update_time(1.0/10)
        self._qtgui_sink_x_0_win = sip.wrapinstance(self.qtgui_sink_x_0.qwidget(), Qt.QWidget)

        self.qtgui_sink_x_0.enable_rf_freq(True)

        self.top_grid_layout.addWidget(self._qtgui_sink_x_0_win, 4, 1, 1, 4)
        for r in range(4, 5):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.network_udp_source_0_1 = network.udp_source(gr.sizeof_char, 1, UDP_VI, 0, 34560, False, False, False)
        self.network_udp_source_0_0_0 = network.udp_source(gr.sizeof_char, 1, UDP_AI, 0, 500, False, False, False)
        self.network_udp_source_0_0 = network.udp_source(gr.sizeof_char, 1, UDP_SI, 0, 1440, False, False, False)
        self.network_udp_sink_0_0_0_0 = network.udp_sink(gr.sizeof_char, 1, UDP_IP, UDP_SO, 0, 240, False)
        self.network_udp_sink_0_0 = network.udp_sink(gr.sizeof_char, 1, UDP_IP, UDP_AO, 0, 500, False)
        self.network_udp_sink_0 = network.udp_sink(gr.sizeof_char, 1, UDP_IP, UDP_VO, 0, 34560, False)
        self.blocks_uchar_to_float_0_1_0_1 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1_0_0 = blocks.uchar_to_float()
        self.blocks_throttle2_0 = blocks.throttle( gr.sizeof_gr_complex*1, samp_rate, True, 0 if "auto" == "auto" else max( int(float(0.1) * samp_rate) if "auto" == "time" else int(0.1), 1) )
        self.blocks_stream_mux_0_0_1 = blocks.stream_mux(gr.sizeof_char*1, (120,120))
        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_char*1, (5760,5760,5760,5760,5760,5760))
        self.blocks_stream_demux_0_1_0 = blocks.stream_demux(gr.sizeof_float*1, (120,120,120,120,120,120))
        self.blocks_stream_demux_0_1 = blocks.stream_demux(gr.sizeof_float*1, (120,120,120,120,120,120))
        self.blocks_stream_demux_0_0 = blocks.stream_demux(gr.sizeof_char*1, (720,720))
        self.blocks_stream_demux_0 = blocks.stream_demux(gr.sizeof_char*1, (5760,5760,5760,5760,5760,5760))
        self.blocks_null_sink_0_3_0 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_3 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_2 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_1 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_0_2_0 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_0_2 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_0_1 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_0_0 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_0 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(1+(variable_range/100))
        self.blocks_delay_0 = blocks.delay(gr.sizeof_float*1, 0)
        self.blocks_char_to_float_0_0 = blocks.char_to_float(1, 1)
        self.blocks_char_to_float_0 = blocks.char_to_float(1, 1)
        self.Sync_Processor_V2_0 = Sync_Processor_V2()
        self.M192_Carrier_TX_0 = M192_Carrier_TX()
        self.D192_Carrier_RX_0 = D192_Carrier_RX()
        self.Audio_TX_Set_0 = Audio_TX_Set()
        self.Audio_RX_Set_0 = Audio_RX_Set()


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self.variable_control_2, 'value'), (self.D192_Carrier_RX_0, 'Din'))
        self.msg_connect((self.variable_control_2, 'value'), (self.blocks_delay_0, 'dly'))
        self.connect((self.Audio_RX_Set_0, 0), (self.network_udp_sink_0_0, 0))
        self.connect((self.Audio_TX_Set_0, 0), (self.M192_Carrier_TX_0, 6))
        self.connect((self.Audio_TX_Set_0, 1), (self.M192_Carrier_TX_0, 7))
        self.connect((self.D192_Carrier_RX_0, 7), (self.Audio_RX_Set_0, 1))
        self.connect((self.D192_Carrier_RX_0, 6), (self.Audio_RX_Set_0, 0))
        self.connect((self.D192_Carrier_RX_0, 0), (self.blocks_stream_mux_0, 0))
        self.connect((self.D192_Carrier_RX_0, 5), (self.blocks_stream_mux_0, 5))
        self.connect((self.D192_Carrier_RX_0, 2), (self.blocks_stream_mux_0, 2))
        self.connect((self.D192_Carrier_RX_0, 4), (self.blocks_stream_mux_0, 4))
        self.connect((self.D192_Carrier_RX_0, 3), (self.blocks_stream_mux_0, 3))
        self.connect((self.D192_Carrier_RX_0, 1), (self.blocks_stream_mux_0, 1))
        self.connect((self.M192_Carrier_TX_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.Sync_Processor_V2_0, 0), (self.blocks_char_to_float_0, 0))
        self.connect((self.Sync_Processor_V2_0, 2), (self.blocks_char_to_float_0_0, 0))
        self.connect((self.Sync_Processor_V2_0, 0), (self.blocks_stream_mux_0_0_1, 0))
        self.connect((self.Sync_Processor_V2_0, 2), (self.blocks_stream_mux_0_0_1, 1))
        self.connect((self.Sync_Processor_V2_0, 1), (self.qtgui_time_sink_x_0, 2))
        self.connect((self.Sync_Processor_V2_0, 3), (self.qtgui_time_sink_x_0, 3))
        self.connect((self.blocks_char_to_float_0, 0), (self.qtgui_time_sink_x_0, 0))
        self.connect((self.blocks_char_to_float_0_0, 0), (self.qtgui_time_sink_x_0, 1))
        self.connect((self.blocks_delay_0, 0), (self.Sync_Processor_V2_0, 0))
        self.connect((self.blocks_delay_0, 1), (self.Sync_Processor_V2_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_throttle2_0, 0))
        self.connect((self.blocks_stream_demux_0, 4), (self.M192_Carrier_TX_0, 4))
        self.connect((self.blocks_stream_demux_0, 3), (self.M192_Carrier_TX_0, 3))
        self.connect((self.blocks_stream_demux_0, 1), (self.M192_Carrier_TX_0, 1))
        self.connect((self.blocks_stream_demux_0, 0), (self.M192_Carrier_TX_0, 0))
        self.connect((self.blocks_stream_demux_0, 5), (self.M192_Carrier_TX_0, 5))
        self.connect((self.blocks_stream_demux_0, 2), (self.M192_Carrier_TX_0, 2))
        self.connect((self.blocks_stream_demux_0_0, 0), (self.blocks_uchar_to_float_0_1_0_0, 0))
        self.connect((self.blocks_stream_demux_0_0, 1), (self.blocks_uchar_to_float_0_1_0_1, 0))
        self.connect((self.blocks_stream_demux_0_1, 0), (self.blocks_delay_0, 0))
        self.connect((self.blocks_stream_demux_0_1, 1), (self.blocks_null_sink_0, 0))
        self.connect((self.blocks_stream_demux_0_1, 2), (self.blocks_null_sink_0_0, 0))
        self.connect((self.blocks_stream_demux_0_1, 4), (self.blocks_null_sink_0_0_0, 0))
        self.connect((self.blocks_stream_demux_0_1, 3), (self.blocks_null_sink_0_1, 0))
        self.connect((self.blocks_stream_demux_0_1, 5), (self.blocks_null_sink_0_2, 0))
        self.connect((self.blocks_stream_demux_0_1_0, 0), (self.blocks_delay_0, 1))
        self.connect((self.blocks_stream_demux_0_1_0, 1), (self.blocks_null_sink_0_0_1, 0))
        self.connect((self.blocks_stream_demux_0_1_0, 3), (self.blocks_null_sink_0_0_2, 0))
        self.connect((self.blocks_stream_demux_0_1_0, 5), (self.blocks_null_sink_0_0_2_0, 0))
        self.connect((self.blocks_stream_demux_0_1_0, 2), (self.blocks_null_sink_0_3, 0))
        self.connect((self.blocks_stream_demux_0_1_0, 4), (self.blocks_null_sink_0_3_0, 0))
        self.connect((self.blocks_stream_mux_0, 0), (self.network_udp_sink_0, 0))
        self.connect((self.blocks_stream_mux_0_0_1, 0), (self.network_udp_sink_0_0_0_0, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.D192_Carrier_RX_0, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.qtgui_sink_x_0, 0))
        self.connect((self.blocks_uchar_to_float_0_1_0_0, 0), (self.blocks_stream_demux_0_1, 0))
        self.connect((self.blocks_uchar_to_float_0_1_0_1, 0), (self.blocks_stream_demux_0_1_0, 0))
        self.connect((self.network_udp_source_0_0, 0), (self.blocks_stream_demux_0_0, 0))
        self.connect((self.network_udp_source_0_0_0, 0), (self.Audio_TX_Set_0, 0))
        self.connect((self.network_udp_source_0_1, 0), (self.blocks_stream_demux_0, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "IF_OFDM_Loopback")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_variable_range(self):
        return self.variable_range

    def set_variable_range(self, variable_range):
        self.variable_range = variable_range
        self.blocks_multiply_const_vxx_0.set_k(1+(self.variable_range/100))

    def get_variable_control_2(self):
        return self.variable_control_2

    def set_variable_control_2(self, variable_control_2):
        self.variable_control_2 = variable_control_2

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.blocks_throttle2_0.set_sample_rate(self.samp_rate)
        self.qtgui_sink_x_0.set_frequency_range(0, self.samp_rate)

    def get_UDP_VO(self):
        return self.UDP_VO

    def set_UDP_VO(self, UDP_VO):
        self.UDP_VO = UDP_VO
        Qt.QMetaObject.invokeMethod(self._UDP_VO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_VO)))

    def get_UDP_VI(self):
        return self.UDP_VI

    def set_UDP_VI(self, UDP_VI):
        self.UDP_VI = UDP_VI
        Qt.QMetaObject.invokeMethod(self._UDP_VI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_VI)))

    def get_UDP_SO(self):
        return self.UDP_SO

    def set_UDP_SO(self, UDP_SO):
        self.UDP_SO = UDP_SO
        Qt.QMetaObject.invokeMethod(self._UDP_SO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_SO)))

    def get_UDP_SI(self):
        return self.UDP_SI

    def set_UDP_SI(self, UDP_SI):
        self.UDP_SI = UDP_SI
        Qt.QMetaObject.invokeMethod(self._UDP_SI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_SI)))

    def get_UDP_IP(self):
        return self.UDP_IP

    def set_UDP_IP(self, UDP_IP):
        self.UDP_IP = UDP_IP
        Qt.QMetaObject.invokeMethod(self._UDP_IP_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_IP)))

    def get_UDP_AO(self):
        return self.UDP_AO

    def set_UDP_AO(self, UDP_AO):
        self.UDP_AO = UDP_AO
        Qt.QMetaObject.invokeMethod(self._UDP_AO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_AO)))

    def get_UDP_AI(self):
        return self.UDP_AI

    def set_UDP_AI(self, UDP_AI):
        self.UDP_AI = UDP_AI
        Qt.QMetaObject.invokeMethod(self._UDP_AI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_AI)))




def main(top_block_cls=IF_OFDM_Loopback, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
