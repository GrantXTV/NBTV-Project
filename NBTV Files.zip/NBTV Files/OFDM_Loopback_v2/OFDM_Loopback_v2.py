#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: OFDM Loopback v2
# Author: VE3XTV
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Audio_RX_Set import Audio_RX_Set  # grc-generated hier_block
from Audio_TX_Set import Audio_TX_Set  # grc-generated hier_block
from OFDM_200_RX import OFDM_200_RX  # grc-generated hier_block
from OFDM_200_TX import OFDM_200_TX  # grc-generated hier_block
from PyQt5 import QtCore
from Sync_Processor_V3 import Sync_Processor_V3  # grc-generated hier_block
from Sync_control import Sync_control  # grc-generated hier_block
from gnuradio import analog
from gnuradio import blocks
from gnuradio import eng_notation
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import network
import OFDM_Loopback_v2_epy_block_0 as epy_block_0  # embedded python block
import OFDM_Loopback_v2_epy_block_2 as epy_block_2  # embedded python block
import sip
import threading



class OFDM_Loopback_v2(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "OFDM Loopback v2", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("OFDM Loopback v2")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "OFDM_Loopback_v2")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.variable_range = variable_range = 200
        self.toggle_button_msg = toggle_button_msg = 0
        self.samp_rate = samp_rate = 100000
        self.Variable_Noise = Variable_Noise = 0
        self.Variable_Delay_0 = Variable_Delay_0 = 21
        self.UDP_VO = UDP_VO = 1234
        self.UDP_VI = UDP_VI = 1244
        self.UDP_SO = UDP_SO = 1233
        self.UDP_SI = UDP_SI = 1243
        self.UDP_IP = UDP_IP = '192.168.2.15'
        self.UDP_AO = UDP_AO = 1235
        self.UDP_AI = UDP_AI = 1245

        ##################################################
        # Blocks
        ##################################################

        self._variable_range_range = qtgui.Range(1, 300, 1, 200, 200)
        self._variable_range_win = qtgui.RangeWidget(self._variable_range_range, self.set_variable_range, "Output Level", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._variable_range_win, 3, 1, 1, 3)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        if "int" == "int":
        	isFloat = False
        	scaleFactor = 1
        else:
        	isFloat = True
        	scaleFactor = 1

        _Variable_Noise_dial_control = qtgui.GrDialControl('Noise', self, 0,100,0,"gray",self.set_Variable_Noise,isFloat, scaleFactor, 100, True, "'value'")
        self.Variable_Noise = _Variable_Noise_dial_control

        self.top_grid_layout.addWidget(_Variable_Noise_dial_control, 1, 5, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(5, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        if "int" == "int":
        	isFloat = False
        	scaleFactor = 1
        else:
        	isFloat = True
        	scaleFactor = 1

        _Variable_Delay_0_dial_control = qtgui.GrDialControl('Delay Ref', self, 0,120,21,"gray",self.set_Variable_Delay_0,isFloat, scaleFactor, 100, True, "'value'")
        self.Variable_Delay_0 = _Variable_Delay_0_dial_control

        self.top_grid_layout.addWidget(_Variable_Delay_0_dial_control, 2, 5, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(5, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_VO_tool_bar = Qt.QToolBar(self)
        self._UDP_VO_tool_bar.addWidget(Qt.QLabel("UDP Video Port" + ": "))
        self._UDP_VO_line_edit = Qt.QLineEdit(str(self.UDP_VO))
        self._UDP_VO_tool_bar.addWidget(self._UDP_VO_line_edit)
        self._UDP_VO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_VO(int(str(self._UDP_VO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_VO_tool_bar, 2, 1, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_VI_tool_bar = Qt.QToolBar(self)
        self._UDP_VI_tool_bar.addWidget(Qt.QLabel("UDP Video Port " + ": "))
        self._UDP_VI_line_edit = Qt.QLineEdit(str(self.UDP_VI))
        self._UDP_VI_tool_bar.addWidget(self._UDP_VI_line_edit)
        self._UDP_VI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_VI(int(str(self._UDP_VI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_VI_tool_bar, 1, 1, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_IP_tool_bar = Qt.QToolBar(self)
        self._UDP_IP_tool_bar.addWidget(Qt.QLabel("UDP IP Address" + ": "))
        self._UDP_IP_line_edit = Qt.QLineEdit(str(self.UDP_IP))
        self._UDP_IP_tool_bar.addWidget(self._UDP_IP_line_edit)
        self._UDP_IP_line_edit.returnPressed.connect(
            lambda: self.set_UDP_IP(str(str(self._UDP_IP_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_IP_tool_bar, 2, 4, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_AO_tool_bar = Qt.QToolBar(self)
        self._UDP_AO_tool_bar.addWidget(Qt.QLabel("UDP_Audio Port" + ": "))
        self._UDP_AO_line_edit = Qt.QLineEdit(str(self.UDP_AO))
        self._UDP_AO_tool_bar.addWidget(self._UDP_AO_line_edit)
        self._UDP_AO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_AO(int(str(self._UDP_AO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_AO_tool_bar, 2, 2, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_AI_tool_bar = Qt.QToolBar(self)
        self._UDP_AI_tool_bar.addWidget(Qt.QLabel("UDP Audio Port " + ": "))
        self._UDP_AI_line_edit = Qt.QLineEdit(str(self.UDP_AI))
        self._UDP_AI_tool_bar.addWidget(self._UDP_AI_line_edit)
        self._UDP_AI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_AI(int(str(self._UDP_AI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_AI_tool_bar, 1, 2, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._toggle_button_msg_choices = {'Pressed': 0, 'Released': 1}

        _toggle_button_msg_toggle_button = qtgui.ToggleButton(self.set_toggle_button_msg, 'Sync ', self._toggle_button_msg_choices, True, 'value')
        _toggle_button_msg_toggle_button.setColors("default", "silver", "silver", "default")
        self.toggle_button_msg = _toggle_button_msg_toggle_button

        self.top_grid_layout.addWidget(_toggle_button_msg_toggle_button, 3, 4, 1, 1)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_time_sink_x_0 = qtgui.time_sink_f(
            1024, #size
            3000, #samp_rate
            "Sync Timing", #name
            5, #number of inputs
            None # parent
        )
        self.qtgui_time_sink_x_0.set_update_time(0.10)
        self.qtgui_time_sink_x_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_0.set_y_label("Amplitude", "")

        self.qtgui_time_sink_x_0.enable_tags(False)
        self.qtgui_time_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_AUTO, qtgui.TRIG_SLOPE_NEG, 0.0, 0.1, 0, "")
        self.qtgui_time_sink_x_0.enable_autoscale(True)
        self.qtgui_time_sink_x_0.enable_grid(False)
        self.qtgui_time_sink_x_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_0.enable_control_panel(False)
        self.qtgui_time_sink_x_0.enable_stem_plot(False)


        labels = ['Signal 1', 'Signal 2', 'Signal 3', 'Signal 4', 'Signal 5',
            'Signal 6', 'Signal 7', 'Signal 8', 'Signal 9', 'Signal 10']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ['blue', 'red', 'green', 'black', 'cyan',
            'magenta', 'yellow', 'dark red', 'dark green', 'dark blue']
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]
        styles = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1]


        for i in range(5):
            if len(labels[i]) == 0:
                self.qtgui_time_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_time_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_0_win = sip.wrapinstance(self.qtgui_time_sink_x_0.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_0_win, 5, 1, 1, 5)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_sink_x_0 = qtgui.sink_c(
            4096, #fftsize
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            (samp_rate*2), #bw
            "OFDM Monitor", #name
            True, #plotfreq
            True, #plotwaterfall
            True, #plottime
            True, #plotconst
            None # parent
        )
        self.qtgui_sink_x_0.set_update_time(1.0/10)
        self._qtgui_sink_x_0_win = sip.wrapinstance(self.qtgui_sink_x_0.qwidget(), Qt.QWidget)

        self.qtgui_sink_x_0.enable_rf_freq(True)

        self.top_grid_layout.addWidget(self._qtgui_sink_x_0_win, 4, 1, 1, 5)
        for r in range(4, 5):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_ledindicator_0 = self._qtgui_ledindicator_0_win = qtgui.GrLEDIndicator("Sync state", "yellow", "blue", False, 40, 1, 1, 1, self)
        self.qtgui_ledindicator_0 = self._qtgui_ledindicator_0_win
        self.top_grid_layout.addWidget(self._qtgui_ledindicator_0_win, 3, 5, 1, 1)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(5, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.network_udp_source_0_1 = network.udp_source(gr.sizeof_char, 1, UDP_VI, 0, 34560, False, False, False)
        self.network_udp_source_0_0_0 = network.udp_source(gr.sizeof_char, 1, UDP_AI, 0, 480, False, False, False)
        self.network_udp_source_0_0 = network.udp_source(gr.sizeof_char, 1, 1243, 0, 1440, False, False, False)
        self.network_udp_sink_0_0_0_0_0 = network.udp_sink(gr.sizeof_char, 1, '192.168.2.15', 1233, 0, 1440, False)
        self.network_udp_sink_0_0 = network.udp_sink(gr.sizeof_char, 1, UDP_IP, UDP_AO, 0, 480, False)
        self.network_udp_sink_0 = network.udp_sink(gr.sizeof_char, 1, UDP_IP, UDP_VO, 0, 34560, False)
        self.filter_fft_low_pass_filter_0 = filter.fft_filter_ccc(1, firdes.low_pass(1, (samp_rate*2), 50000, 5000, window.WIN_BLACKMAN, 6.76), 1)
        self.epy_block_2 = epy_block_2.blk(period=120, ma_length=8)
        self.epy_block_0 = epy_block_0.blk()
        self.blocks_throttle2_0 = blocks.throttle( gr.sizeof_gr_complex*1, samp_rate, True, 0 if "auto" == "auto" else max( int(float(0.1) * samp_rate) if "auto" == "time" else int(0.1), 1) )
        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_char*1, (5760,5760,5760,5760,5760,5760))
        self.blocks_stream_demux_0 = blocks.stream_demux(gr.sizeof_char*1, (5760,5760,5760,5760,5760,5760))
        self.blocks_repeat_0 = blocks.repeat(gr.sizeof_gr_complex*1, 2)
        self.blocks_null_sink_0_1_0_1_1 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_1_0_1_0_0 = blocks.null_sink(gr.sizeof_char*1)
        self.blocks_null_sink_0_1_0_1_0 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0_1_0_1 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_multiply_const_vxx_0_2 = blocks.multiply_const_cc(1/8)
        self.blocks_multiply_const_vxx_0_0 = blocks.multiply_const_cc((1/variable_range))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc((1/variable_range))
        self.blocks_delay_1_1_0 = blocks.delay(gr.sizeof_float*1, Variable_Delay_0)
        self.blocks_char_to_float_0_0_0 = blocks.char_to_float(1, 1)
        self.blocks_char_to_float_0_0 = blocks.char_to_float(1, 1)
        self.blocks_add_xx_0_0_0_0_1 = blocks.add_vcc(1)
        self.analog_sig_source_x_0 = analog.sig_source_f(500, analog.GR_COS_WAVE, (6.25/3), 1, 0, 0)
        self.analog_noise_source_x_0_1_0_1_0 = analog.noise_source_c(analog.GR_GAUSSIAN, Variable_Noise, 1)
        self._UDP_SO_tool_bar = Qt.QToolBar(self)
        self._UDP_SO_tool_bar.addWidget(Qt.QLabel("UDP Sync Port" + ": "))
        self._UDP_SO_line_edit = Qt.QLineEdit(str(self.UDP_SO))
        self._UDP_SO_tool_bar.addWidget(self._UDP_SO_line_edit)
        self._UDP_SO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_SO(int(str(self._UDP_SO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_SO_tool_bar, 2, 3, 1, 1)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_SI_tool_bar = Qt.QToolBar(self)
        self._UDP_SI_tool_bar.addWidget(Qt.QLabel("UDP Sync Port" + ": "))
        self._UDP_SI_line_edit = Qt.QLineEdit(str(self.UDP_SI))
        self._UDP_SI_tool_bar.addWidget(self._UDP_SI_line_edit)
        self._UDP_SI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_SI(int(str(self._UDP_SI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_SI_tool_bar, 1, 3, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.Sync_control_0 = Sync_control()
        self.Sync_Processor_V3_0 = Sync_Processor_V3(
            samp_rate=500,
        )
        self.OFDM_200_TX_0 = OFDM_200_TX()
        self.OFDM_200_RX_0 = OFDM_200_RX()
        self.Audio_TX_Set_0 = Audio_TX_Set()
        self.Audio_RX_Set_0 = Audio_RX_Set()


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self.epy_block_2, 'delay'), (self.OFDM_200_RX_0, 'in'))
        self.msg_connect((self.toggle_button_msg, 'state'), (self.epy_block_2, 'toggle'))
        self.msg_connect((self.toggle_button_msg, 'state'), (self.qtgui_ledindicator_0, 'state'))
        self.connect((self.Audio_RX_Set_0, 0), (self.network_udp_sink_0_0, 0))
        self.connect((self.Audio_TX_Set_0, 0), (self.OFDM_200_TX_0, 8))
        self.connect((self.Audio_TX_Set_0, 1), (self.OFDM_200_TX_0, 9))
        self.connect((self.OFDM_200_RX_0, 9), (self.Audio_RX_Set_0, 1))
        self.connect((self.OFDM_200_RX_0, 8), (self.Audio_RX_Set_0, 0))
        self.connect((self.OFDM_200_RX_0, 5), (self.Sync_Processor_V3_0, 1))
        self.connect((self.OFDM_200_RX_0, 4), (self.Sync_Processor_V3_0, 0))
        self.connect((self.OFDM_200_RX_0, 7), (self.blocks_stream_mux_0, 5))
        self.connect((self.OFDM_200_RX_0, 3), (self.blocks_stream_mux_0, 3))
        self.connect((self.OFDM_200_RX_0, 6), (self.blocks_stream_mux_0, 4))
        self.connect((self.OFDM_200_RX_0, 2), (self.blocks_stream_mux_0, 2))
        self.connect((self.OFDM_200_RX_0, 0), (self.blocks_stream_mux_0, 0))
        self.connect((self.OFDM_200_RX_0, 1), (self.blocks_stream_mux_0, 1))
        self.connect((self.OFDM_200_TX_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.Sync_Processor_V3_0, 0), (self.blocks_char_to_float_0_0_0, 0))
        self.connect((self.Sync_Processor_V3_0, 2), (self.blocks_null_sink_0_1_0_1, 0))
        self.connect((self.Sync_Processor_V3_0, 1), (self.blocks_null_sink_0_1_0_1_0, 0))
        self.connect((self.Sync_Processor_V3_0, 3), (self.blocks_null_sink_0_1_0_1_1, 0))
        self.connect((self.Sync_Processor_V3_0, 0), (self.epy_block_2, 1))
        self.connect((self.Sync_Processor_V3_0, 4), (self.network_udp_sink_0_0_0_0_0, 0))
        self.connect((self.Sync_Processor_V3_0, 3), (self.qtgui_time_sink_x_0, 2))
        self.connect((self.Sync_Processor_V3_0, 2), (self.qtgui_time_sink_x_0, 1))
        self.connect((self.Sync_control_0, 1), (self.OFDM_200_TX_0, 2))
        self.connect((self.Sync_control_0, 0), (self.OFDM_200_TX_0, 1))
        self.connect((self.analog_noise_source_x_0_1_0_1_0, 0), (self.blocks_multiply_const_vxx_0_2, 0))
        self.connect((self.analog_sig_source_x_0, 0), (self.blocks_delay_1_1_0, 0))
        self.connect((self.blocks_add_xx_0_0_0_0_1, 0), (self.blocks_throttle2_0, 0))
        self.connect((self.blocks_char_to_float_0_0, 0), (self.qtgui_time_sink_x_0, 3))
        self.connect((self.blocks_char_to_float_0_0_0, 0), (self.qtgui_time_sink_x_0, 4))
        self.connect((self.blocks_delay_1_1_0, 0), (self.epy_block_0, 0))
        self.connect((self.blocks_delay_1_1_0, 0), (self.qtgui_time_sink_x_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_add_xx_0_0_0_0_1, 1))
        self.connect((self.blocks_multiply_const_vxx_0_0, 0), (self.qtgui_sink_x_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2, 0), (self.blocks_add_xx_0_0_0_0_1, 0))
        self.connect((self.blocks_repeat_0, 0), (self.filter_fft_low_pass_filter_0, 0))
        self.connect((self.blocks_stream_demux_0, 5), (self.OFDM_200_TX_0, 7))
        self.connect((self.blocks_stream_demux_0, 2), (self.OFDM_200_TX_0, 4))
        self.connect((self.blocks_stream_demux_0, 0), (self.OFDM_200_TX_0, 0))
        self.connect((self.blocks_stream_demux_0, 1), (self.OFDM_200_TX_0, 3))
        self.connect((self.blocks_stream_demux_0, 4), (self.OFDM_200_TX_0, 6))
        self.connect((self.blocks_stream_demux_0, 3), (self.OFDM_200_TX_0, 5))
        self.connect((self.blocks_stream_mux_0, 0), (self.network_udp_sink_0, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.OFDM_200_RX_0, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.blocks_repeat_0, 0))
        self.connect((self.epy_block_0, 0), (self.blocks_char_to_float_0_0, 0))
        self.connect((self.epy_block_0, 0), (self.epy_block_2, 0))
        self.connect((self.epy_block_2, 0), (self.blocks_null_sink_0_1_0_1_0_0, 0))
        self.connect((self.filter_fft_low_pass_filter_0, 0), (self.blocks_multiply_const_vxx_0_0, 0))
        self.connect((self.network_udp_source_0_0, 0), (self.Sync_control_0, 0))
        self.connect((self.network_udp_source_0_0_0, 0), (self.Audio_TX_Set_0, 0))
        self.connect((self.network_udp_source_0_1, 0), (self.blocks_stream_demux_0, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "OFDM_Loopback_v2")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_variable_range(self):
        return self.variable_range

    def set_variable_range(self, variable_range):
        self.variable_range = variable_range
        self.blocks_multiply_const_vxx_0.set_k((1/self.variable_range))
        self.blocks_multiply_const_vxx_0_0.set_k((1/self.variable_range))

    def get_toggle_button_msg(self):
        return self.toggle_button_msg

    def set_toggle_button_msg(self, toggle_button_msg):
        self.toggle_button_msg = toggle_button_msg

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.blocks_throttle2_0.set_sample_rate(self.samp_rate)
        self.filter_fft_low_pass_filter_0.set_taps(firdes.low_pass(1, (self.samp_rate*2), 50000, 5000, window.WIN_BLACKMAN, 6.76))
        self.qtgui_sink_x_0.set_frequency_range(0, (self.samp_rate*2))

    def get_Variable_Noise(self):
        return self.Variable_Noise

    def set_Variable_Noise(self, Variable_Noise):
        self.Variable_Noise = Variable_Noise
        self.analog_noise_source_x_0_1_0_1_0.set_amplitude(self.Variable_Noise)

    def get_Variable_Delay_0(self):
        return self.Variable_Delay_0

    def set_Variable_Delay_0(self, Variable_Delay_0):
        self.Variable_Delay_0 = Variable_Delay_0
        self.blocks_delay_1_1_0.set_dly(int(self.Variable_Delay_0))

    def get_UDP_VO(self):
        return self.UDP_VO

    def set_UDP_VO(self, UDP_VO):
        self.UDP_VO = UDP_VO
        Qt.QMetaObject.invokeMethod(self._UDP_VO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_VO)))

    def get_UDP_VI(self):
        return self.UDP_VI

    def set_UDP_VI(self, UDP_VI):
        self.UDP_VI = UDP_VI
        Qt.QMetaObject.invokeMethod(self._UDP_VI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_VI)))

    def get_UDP_SO(self):
        return self.UDP_SO

    def set_UDP_SO(self, UDP_SO):
        self.UDP_SO = UDP_SO
        Qt.QMetaObject.invokeMethod(self._UDP_SO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_SO)))

    def get_UDP_SI(self):
        return self.UDP_SI

    def set_UDP_SI(self, UDP_SI):
        self.UDP_SI = UDP_SI
        Qt.QMetaObject.invokeMethod(self._UDP_SI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_SI)))

    def get_UDP_IP(self):
        return self.UDP_IP

    def set_UDP_IP(self, UDP_IP):
        self.UDP_IP = UDP_IP
        Qt.QMetaObject.invokeMethod(self._UDP_IP_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_IP)))

    def get_UDP_AO(self):
        return self.UDP_AO

    def set_UDP_AO(self, UDP_AO):
        self.UDP_AO = UDP_AO
        Qt.QMetaObject.invokeMethod(self._UDP_AO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_AO)))

    def get_UDP_AI(self):
        return self.UDP_AI

    def set_UDP_AI(self, UDP_AI):
        self.UDP_AI = UDP_AI
        Qt.QMetaObject.invokeMethod(self._UDP_AI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_AI)))




def main(top_block_cls=OFDM_Loopback_v2, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
