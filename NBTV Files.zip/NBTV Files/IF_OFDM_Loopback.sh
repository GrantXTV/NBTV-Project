#!/bin/bash
./IF_OFDM_Loopback/IF_OFDM_Loopback.py
