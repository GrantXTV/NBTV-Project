# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Bulk_Space_v1
# Author: PA0SIM
# Description: Calculating Bulk Space information: Ratio and Phase difference
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Compare_v1 import Compare_v1  # grc-generated hier_block
from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import signal
import threading







class Bulk_Space_v1(gr.hier_block2):
    def __init__(self, display_threshold=0.25):
        gr.hier_block2.__init__(
            self, "Bulk_Space_v1",
                gr.io_signature.makev(2, 2, [gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512]),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*512),
        )

        ##################################################
        # Parameters
        ##################################################
        self.display_threshold = display_threshold

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 8000

        ##################################################
        # Blocks
        ##################################################

        self.low_pass_filter_0 = filter.interp_fir_filter_fff(
            1,
            firdes.low_pass(
                1,
                samp_rate,
                200,
                500,
                window.WIN_HAMMING,
                6.76))
        self.blocks_vector_source_x_0_1_0_0 = blocks.vector_source_f([0.0]*512, True, 512, [])
        self.blocks_vector_source_x_0_1_0 = blocks.vector_source_f([-1.0]*512, True, 512, [])
        self.blocks_vector_source_x_0_1 = blocks.vector_source_f([6.283]*512, True, 512, [])
        self.blocks_sub_xx_0_0 = blocks.sub_ff(512)
        self.blocks_sub_xx_0 = blocks.sub_ff(512)
        self.blocks_multiply_xx_2 = blocks.multiply_vff(512)
        self.blocks_multiply_xx_1 = blocks.multiply_vff(512)
        self.blocks_multiply_xx_0_0 = blocks.multiply_vcc(512)
        self.blocks_multiply_const_vxx_0_0 = blocks.multiply_const_vff([180/3.1415]*512)
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_ff(display_threshold)
        self.blocks_max_xx_0_0 = blocks.max_ff(512, 1)
        self.blocks_float_to_complex_1 = blocks.float_to_complex(512)
        self.blocks_float_to_complex_0 = blocks.float_to_complex(512)
        self.blocks_divide_xx_0 = blocks.divide_ff(512)
        self.blocks_complex_to_magphase_0_0 = blocks.complex_to_magphase(512)
        self.blocks_complex_to_magphase_0 = blocks.complex_to_magphase(512)
        self.blocks_add_xx_0_0_0 = blocks.add_vff(512)
        self.blocks_add_xx_0 = blocks.add_vff(512)
        self.analog_const_source_x_0 = analog.sig_source_f(0, analog.GR_CONST_WAVE, 0, 0, 0)
        self.Compare_v1_0_0 = Compare_v1()
        self.Compare_v1_0 = Compare_v1()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.Compare_v1_0, 0), (self.blocks_float_to_complex_1, 0))
        self.connect((self.Compare_v1_0_0, 0), (self.blocks_multiply_xx_1, 0))
        self.connect((self.analog_const_source_x_0, 0), (self.Compare_v1_0_0, 0))
        self.connect((self.blocks_add_xx_0, 0), (self.Compare_v1_0, 1))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_divide_xx_0, 1))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_max_xx_0_0, 0))
        self.connect((self.blocks_add_xx_0_0_0, 0), (self.blocks_multiply_const_vxx_0_0, 0))
        self.connect((self.blocks_complex_to_magphase_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.blocks_complex_to_magphase_0, 0), (self.blocks_sub_xx_0, 0))
        self.connect((self.blocks_complex_to_magphase_0, 1), (self.blocks_sub_xx_0_0, 0))
        self.connect((self.blocks_complex_to_magphase_0_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.blocks_complex_to_magphase_0_0, 0), (self.blocks_sub_xx_0, 1))
        self.connect((self.blocks_complex_to_magphase_0_0, 1), (self.blocks_sub_xx_0_0, 1))
        self.connect((self.blocks_divide_xx_0, 0), (self.blocks_float_to_complex_0, 1))
        self.connect((self.blocks_float_to_complex_0, 0), (self.blocks_multiply_xx_0_0, 0))
        self.connect((self.blocks_float_to_complex_1, 0), (self.blocks_multiply_xx_0_0, 1))
        self.connect((self.blocks_max_xx_0_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.low_pass_filter_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0, 0), (self.blocks_float_to_complex_0, 0))
        self.connect((self.blocks_multiply_xx_0_0, 0), (self, 0))
        self.connect((self.blocks_multiply_xx_1, 0), (self.blocks_add_xx_0_0_0, 1))
        self.connect((self.blocks_multiply_xx_2, 0), (self.Compare_v1_0_0, 1))
        self.connect((self.blocks_sub_xx_0, 0), (self.blocks_divide_xx_0, 0))
        self.connect((self.blocks_sub_xx_0_0, 0), (self.blocks_add_xx_0_0_0, 0))
        self.connect((self.blocks_sub_xx_0_0, 0), (self.blocks_multiply_xx_2, 0))
        self.connect((self.blocks_vector_source_x_0_1, 0), (self.blocks_multiply_xx_1, 1))
        self.connect((self.blocks_vector_source_x_0_1_0, 0), (self.blocks_multiply_xx_2, 1))
        self.connect((self.blocks_vector_source_x_0_1_0_0, 0), (self.blocks_float_to_complex_1, 1))
        self.connect((self.low_pass_filter_0, 0), (self.Compare_v1_0, 0))
        self.connect((self, 0), (self.blocks_complex_to_magphase_0, 0))
        self.connect((self, 1), (self.blocks_complex_to_magphase_0_0, 0))


    def get_display_threshold(self):
        return self.display_threshold

    def set_display_threshold(self, display_threshold):
        self.display_threshold = display_threshold
        self.blocks_multiply_const_vxx_0.set_k(self.display_threshold)

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.low_pass_filter_0.set_taps(firdes.low_pass(1, self.samp_rate, 200, 500, window.WIN_HAMMING, 6.76))

