# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Var2Vec_v1
# Author: PA0SIM
# Description: Variable to vector conversion
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class Var2Vec_v1(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Var2Vec_v1",
                gr.io_signature(1, 1, gr.sizeof_float*1),
                gr.io_signature(1, 1, gr.sizeof_float*512),
        )

        ##################################################
        # Blocks
        ##################################################

        self.blocks_stream_to_vector_0 = blocks.stream_to_vector(gr.sizeof_float*1, 512)
        self.blocks_repeat_0 = blocks.repeat(gr.sizeof_float*1, 512)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_repeat_0, 0), (self.blocks_stream_to_vector_0, 0))
        self.connect((self.blocks_stream_to_vector_0, 0), (self, 0))
        self.connect((self, 0), (self.blocks_repeat_0, 0))


