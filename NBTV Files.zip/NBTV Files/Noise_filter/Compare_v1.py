# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Compare_v1
# Author: PA0SIM
# Description: Compare constant and vector
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Var2Vec_v1 import Var2Vec_v1  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
import threading







class Compare_v1(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Compare_v1",
                gr.io_signature.makev(2, 2, [gr.sizeof_float*1, gr.sizeof_float*512]),
                gr.io_signature(1, 1, gr.sizeof_float*512),
        )

        ##################################################
        # Blocks
        ##################################################

        self.blocks_vector_source_x_0_0_0 = blocks.vector_source_f([1000000]*512, True, 512, [])
        self.blocks_vector_source_x_0_0 = blocks.vector_source_f([1]*512, True, 512, [])
        self.blocks_vector_source_x_0 = blocks.vector_source_f([0]*512, True, 512, [])
        self.blocks_sub_xx_0 = blocks.sub_ff(512)
        self.blocks_multiply_xx_1 = blocks.multiply_vff(512)
        self.blocks_min_xx_0_0_0 = blocks.min_ff(512,512)
        self.blocks_max_xx_0_1 = blocks.max_ff(512, 512)
        self.Var2Vec_v1_0 = Var2Vec_v1()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.Var2Vec_v1_0, 0), (self.blocks_sub_xx_0, 1))
        self.connect((self.blocks_max_xx_0_1, 0), (self.blocks_multiply_xx_1, 0))
        self.connect((self.blocks_min_xx_0_0_0, 0), (self, 0))
        self.connect((self.blocks_multiply_xx_1, 0), (self.blocks_min_xx_0_0_0, 0))
        self.connect((self.blocks_sub_xx_0, 0), (self.blocks_max_xx_0_1, 0))
        self.connect((self.blocks_vector_source_x_0, 0), (self.blocks_max_xx_0_1, 1))
        self.connect((self.blocks_vector_source_x_0_0, 0), (self.blocks_min_xx_0_0_0, 1))
        self.connect((self.blocks_vector_source_x_0_0_0, 0), (self.blocks_multiply_xx_1, 1))
        self.connect((self, 0), (self.Var2Vec_v1_0, 0))
        self.connect((self, 1), (self.blocks_sub_xx_0, 0))


