# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Phase Offset
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import sys
import signal
import threading







class Phase_Offset(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Phase Offset",
                gr.io_signature.makev(2, 2, [gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1]),
                gr.io_signature.makev(2, 2, [gr.sizeof_float*1, gr.sizeof_gr_complex*1]),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 384000

        ##################################################
        # Blocks
        ##################################################

        self.blocks_swapiq_0_0_0_0_1_0 = blocks.swap_iq(1, gr.sizeof_gr_complex)
        self.blocks_swapiq_0_0_0_0_1 = blocks.swap_iq(1, gr.sizeof_gr_complex)
        self.blocks_sub_xx_0 = blocks.sub_ff(1)
        self.blocks_multiply_xx_0_3 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_2_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_2 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_0_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0 = blocks.multiply_const_cc(0.175)
        self.blocks_multiply_const_vxx_0_0_0_0_0_0_0 = blocks.multiply_const_cc(15)
        self.blocks_multiply_const_vxx_0_0_0_0_0_0 = blocks.multiply_const_cc(30)
        self.blocks_multiply_const_vxx_0_0_0 = blocks.multiply_const_cc(40)
        self.blocks_moving_average_xx_0 = blocks.moving_average_ff(1000, 0.001, 2000, 1)
        self.blocks_complex_to_imag_1 = blocks.complex_to_imag(1)
        self.blocks_complex_to_imag_0 = blocks.complex_to_imag(1)
        self.band_pass_filter_0_1_0_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                samp_rate,
                60000,
                84000,
                1000,
                window.WIN_BLACKMAN,
                8.32))
        self.band_pass_filter_0_1_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                samp_rate,
                60000,
                84000,
                1000,
                window.WIN_BLACKMAN,
                8.32))
        self.band_pass_filter_0_0_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                samp_rate,
                94000,
                98000,
                5000,
                window.WIN_BLACKMAN,
                6.76))
        self.band_pass_filter_0_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                samp_rate,
                70000,
                74000,
                5000,
                window.WIN_BLACKMAN,
                6.76))
        self.band_pass_filter_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                samp_rate,
                46000,
                50000,
                5000,
                window.WIN_BLACKMAN,
                6.76))


        ##################################################
        # Connections
        ##################################################
        self.connect((self.band_pass_filter_0_0, 0), (self.blocks_multiply_xx_0_2, 0))
        self.connect((self.band_pass_filter_0_0_0, 0), (self.blocks_multiply_xx_0_2_0, 0))
        self.connect((self.band_pass_filter_0_0_0_0, 0), (self.blocks_swapiq_0_0_0_0_1, 0))
        self.connect((self.band_pass_filter_0_1_0_0, 0), (self.blocks_complex_to_imag_1, 0))
        self.connect((self.band_pass_filter_0_1_0_0_0, 0), (self.blocks_complex_to_imag_0, 0))
        self.connect((self.band_pass_filter_0_1_0_0_0, 0), (self.blocks_multiply_const_vxx_0_0_0, 0))
        self.connect((self.blocks_complex_to_imag_0, 0), (self.blocks_sub_xx_0, 0))
        self.connect((self.blocks_complex_to_imag_1, 0), (self.blocks_sub_xx_0, 1))
        self.connect((self.blocks_moving_average_xx_0, 0), (self, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0_0, 0), (self.blocks_multiply_xx_0_2_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0, 0), (self.band_pass_filter_0_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0, 0), (self.band_pass_filter_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_0, 2))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_0, 3))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_0_0, 2))
        self.connect((self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_0_0, 1))
        self.connect((self.blocks_multiply_xx_0, 0), (self.band_pass_filter_0_0, 0))
        self.connect((self.blocks_multiply_xx_0_0, 0), (self.blocks_multiply_const_vxx_0_0_0_0_0_0, 0))
        self.connect((self.blocks_multiply_xx_0_0_0, 0), (self.blocks_multiply_const_vxx_0_0_0_0_0_0_0, 0))
        self.connect((self.blocks_multiply_xx_0_2, 0), (self.blocks_swapiq_0_0_0_0_1_0, 0))
        self.connect((self.blocks_multiply_xx_0_2_0, 0), (self, 1))
        self.connect((self.blocks_multiply_xx_0_3, 0), (self.band_pass_filter_0_1_0_0_0, 0))
        self.connect((self.blocks_sub_xx_0, 0), (self.blocks_moving_average_xx_0, 0))
        self.connect((self.blocks_swapiq_0_0_0_0_1, 0), (self.blocks_multiply_xx_0_3, 0))
        self.connect((self.blocks_swapiq_0_0_0_0_1_0, 0), (self.band_pass_filter_0_1_0_0, 0))
        self.connect((self, 0), (self.blocks_multiply_xx_0_2, 1))
        self.connect((self, 0), (self.blocks_multiply_xx_0_3, 1))
        self.connect((self, 1), (self.blocks_multiply_const_vxx_0_0_0_0_0_0_0_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.band_pass_filter_0_0.set_taps(firdes.band_pass(1, self.samp_rate, 46000, 50000, 5000, window.WIN_BLACKMAN, 6.76))
        self.band_pass_filter_0_0_0.set_taps(firdes.band_pass(1, self.samp_rate, 70000, 74000, 5000, window.WIN_BLACKMAN, 6.76))
        self.band_pass_filter_0_0_0_0.set_taps(firdes.band_pass(1, self.samp_rate, 94000, 98000, 5000, window.WIN_BLACKMAN, 6.76))
        self.band_pass_filter_0_1_0_0.set_taps(firdes.band_pass(1, self.samp_rate, 60000, 84000, 1000, window.WIN_BLACKMAN, 8.32))
        self.band_pass_filter_0_1_0_0_0.set_taps(firdes.band_pass(1, self.samp_rate, 60000, 84000, 1000, window.WIN_BLACKMAN, 8.32))

