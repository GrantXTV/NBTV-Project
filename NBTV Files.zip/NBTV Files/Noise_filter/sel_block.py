# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: sel_block_v1
# Author: PA0SIM
# Copyright: PA0SIM
# Description: switch input pairs
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class sel_block(gr.hier_block2):
    def __init__(self, sel=0):
        gr.hier_block2.__init__(
            self, "sel_block_v1",
                gr.io_signature.makev(4, 4, [gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512]),
                gr.io_signature.makev(2, 2, [gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512]),
        )

        ##################################################
        # Parameters
        ##################################################
        self.sel = sel

        ##################################################
        # Blocks
        ##################################################

        self.blocks_vector_source_x_0_0_0 = blocks.vector_source_c([sel]*512, True, 512, [])
        self.blocks_vector_source_x_0_0 = blocks.vector_source_c([1-sel]*512, True, 512, [])
        self.blocks_multiply_xx_0_0_2 = blocks.multiply_vcc(512)
        self.blocks_multiply_xx_0_0_1 = blocks.multiply_vcc(512)
        self.blocks_multiply_xx_0_0_0 = blocks.multiply_vcc(512)
        self.blocks_multiply_xx_0_0 = blocks.multiply_vcc(512)
        self.blocks_add_xx_0_1 = blocks.add_vcc(512)
        self.blocks_add_xx_0_0 = blocks.add_vcc(512)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_add_xx_0_0, 0), (self, 1))
        self.connect((self.blocks_add_xx_0_1, 0), (self, 0))
        self.connect((self.blocks_multiply_xx_0_0, 0), (self.blocks_add_xx_0_0, 0))
        self.connect((self.blocks_multiply_xx_0_0_0, 0), (self.blocks_add_xx_0_0, 1))
        self.connect((self.blocks_multiply_xx_0_0_1, 0), (self.blocks_add_xx_0_1, 0))
        self.connect((self.blocks_multiply_xx_0_0_2, 0), (self.blocks_add_xx_0_1, 1))
        self.connect((self.blocks_vector_source_x_0_0, 0), (self.blocks_multiply_xx_0_0_0, 1))
        self.connect((self.blocks_vector_source_x_0_0, 0), (self.blocks_multiply_xx_0_0_2, 1))
        self.connect((self.blocks_vector_source_x_0_0_0, 0), (self.blocks_multiply_xx_0_0, 1))
        self.connect((self.blocks_vector_source_x_0_0_0, 0), (self.blocks_multiply_xx_0_0_1, 1))
        self.connect((self, 0), (self.blocks_multiply_xx_0_0, 0))
        self.connect((self, 1), (self.blocks_multiply_xx_0_0_1, 0))
        self.connect((self, 2), (self.blocks_multiply_xx_0_0_0, 0))
        self.connect((self, 3), (self.blocks_multiply_xx_0_0_2, 0))


    def get_sel(self):
        return self.sel

    def set_sel(self, sel):
        self.sel = sel
        self.blocks_vector_source_x_0_0.set_data([1-self.sel]*512, [])
        self.blocks_vector_source_x_0_0_0.set_data([self.sel]*512, [])

