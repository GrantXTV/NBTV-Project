# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: sel_block_float_v1
# Author: PA0SIM
# Copyright: PA0SIM
# Description: switch input pairs floats
# GNU Radio version: 3.10.12.0

from gnuradio import analog
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class sel_block_float_v1(gr.hier_block2):
    def __init__(self, sel=0):
        gr.hier_block2.__init__(
            self, "sel_block_float_v1",
                gr.io_signature.makev(4, 4, [gr.sizeof_float*1, gr.sizeof_float*1, gr.sizeof_float*1, gr.sizeof_float*1]),
                gr.io_signature.makev(2, 2, [gr.sizeof_float*1, gr.sizeof_float*1]),
        )

        ##################################################
        # Parameters
        ##################################################
        self.sel = sel

        ##################################################
        # Blocks
        ##################################################

        self.blocks_multiply_xx_0_0_2 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0_0_1 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0_0_0 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0_0 = blocks.multiply_vff(1)
        self.blocks_add_xx_0_1 = blocks.add_vff(1)
        self.blocks_add_xx_0_0 = blocks.add_vff(1)
        self.analog_const_source_x_0_0 = analog.sig_source_f(0, analog.GR_CONST_WAVE, 0, 0, sel)
        self.analog_const_source_x_0 = analog.sig_source_f(0, analog.GR_CONST_WAVE, 0, 0, ((1-sel)))


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_const_source_x_0, 0), (self.blocks_multiply_xx_0_0_0, 1))
        self.connect((self.analog_const_source_x_0, 0), (self.blocks_multiply_xx_0_0_2, 1))
        self.connect((self.analog_const_source_x_0_0, 0), (self.blocks_multiply_xx_0_0, 1))
        self.connect((self.analog_const_source_x_0_0, 0), (self.blocks_multiply_xx_0_0_1, 1))
        self.connect((self.blocks_add_xx_0_0, 0), (self, 0))
        self.connect((self.blocks_add_xx_0_1, 0), (self, 1))
        self.connect((self.blocks_multiply_xx_0_0, 0), (self.blocks_add_xx_0_0, 0))
        self.connect((self.blocks_multiply_xx_0_0_0, 0), (self.blocks_add_xx_0_0, 1))
        self.connect((self.blocks_multiply_xx_0_0_1, 0), (self.blocks_add_xx_0_1, 0))
        self.connect((self.blocks_multiply_xx_0_0_2, 0), (self.blocks_add_xx_0_1, 1))
        self.connect((self, 0), (self.blocks_multiply_xx_0_0, 0))
        self.connect((self, 1), (self.blocks_multiply_xx_0_0_1, 0))
        self.connect((self, 2), (self.blocks_multiply_xx_0_0_0, 0))
        self.connect((self, 3), (self.blocks_multiply_xx_0_0_2, 0))


    def get_sel(self):
        return self.sel

    def set_sel(self, sel):
        self.sel = sel
        self.analog_const_source_x_0.set_offset(((1-self.sel)))
        self.analog_const_source_x_0_0.set_offset(self.sel)

