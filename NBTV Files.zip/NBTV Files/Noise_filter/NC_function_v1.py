# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: NC_function_v1
# Author: PA0SIM
# Description: Noise Cancelling in time domain
# GNU Radio version: 3.10.12.0

from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class NC_function_v1(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "NC_function_v1",
                gr.io_signature.makev(4, 4, [gr.sizeof_float*1, gr.sizeof_float*1, gr.sizeof_float*1, gr.sizeof_float*1]),
                gr.io_signature(1, 1, gr.sizeof_float*1),
        )

        ##################################################
        # Blocks
        ##################################################

        self.hilbert_fc_0_0 = filter.hilbert_fc(128, window.WIN_HAMMING, 6.76)
        self.hilbert_fc_0 = filter.hilbert_fc(128, window.WIN_HAMMING, 6.76)
        self.blocks_transcendental_0_0_0 = blocks.transcendental('sin', "float")
        self.blocks_transcendental_0_0 = blocks.transcendental('cos', "float")
        self.blocks_threshold_ff_0 = blocks.threshold_ff(1, (1+1e-6), 0)
        self.blocks_sub_xx_0_1 = blocks.sub_ff(1)
        self.blocks_sub_xx_0_0 = blocks.sub_ff(1)
        self.blocks_sub_xx_0 = blocks.sub_ff(1)
        self.blocks_multiply_xx_0_1_0_0 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0_1_0 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0_1 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0_0 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0 = blocks.multiply_vff(1)
        self.blocks_multiply_const_vxx_0_0 = blocks.multiply_const_ff((3.1415/180))
        self.blocks_divide_xx_0 = blocks.divide_ff(1)
        self.blocks_complex_to_real_0_0 = blocks.complex_to_real(1)
        self.blocks_complex_to_real_0 = blocks.complex_to_real(1)
        self.blocks_complex_to_imag_0 = blocks.complex_to_imag(1)
        self.blocks_add_xx_0_0 = blocks.add_vff(1)
        self.blocks_add_xx_0 = blocks.add_vff(1)
        self.analog_const_source_x_0 = analog.sig_source_f(0, analog.GR_CONST_WAVE, 0, 0, 1)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_const_source_x_0, 0), (self.blocks_sub_xx_0_1, 0))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_divide_xx_0, 0))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_sub_xx_0_0, 0))
        self.connect((self.blocks_add_xx_0_0, 0), (self, 0))
        self.connect((self.blocks_complex_to_imag_0, 0), (self.blocks_multiply_xx_0, 0))
        self.connect((self.blocks_complex_to_real_0, 0), (self.blocks_multiply_xx_0_0, 0))
        self.connect((self.blocks_complex_to_real_0_0, 0), (self.blocks_multiply_xx_0_1, 0))
        self.connect((self.blocks_complex_to_real_0_0, 0), (self.blocks_sub_xx_0, 1))
        self.connect((self.blocks_divide_xx_0, 0), (self.blocks_sub_xx_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0, 0), (self.blocks_transcendental_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0, 0), (self.blocks_transcendental_0_0_0, 0))
        self.connect((self.blocks_multiply_xx_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.blocks_multiply_xx_0_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.blocks_multiply_xx_0_1, 0), (self.blocks_sub_xx_0_0, 1))
        self.connect((self.blocks_multiply_xx_0_1_0, 0), (self.blocks_add_xx_0_0, 0))
        self.connect((self.blocks_multiply_xx_0_1_0_0, 0), (self.blocks_add_xx_0_0, 1))
        self.connect((self.blocks_sub_xx_0, 0), (self.blocks_multiply_xx_0_1_0, 0))
        self.connect((self.blocks_sub_xx_0_0, 0), (self.blocks_multiply_xx_0_1_0_0, 0))
        self.connect((self.blocks_sub_xx_0_1, 0), (self.blocks_multiply_xx_0_1_0_0, 1))
        self.connect((self.blocks_threshold_ff_0, 0), (self.blocks_multiply_xx_0_1_0, 1))
        self.connect((self.blocks_threshold_ff_0, 0), (self.blocks_sub_xx_0_1, 1))
        self.connect((self.blocks_transcendental_0_0, 0), (self.blocks_multiply_xx_0_0, 1))
        self.connect((self.blocks_transcendental_0_0_0, 0), (self.blocks_multiply_xx_0, 1))
        self.connect((self.hilbert_fc_0, 0), (self.blocks_complex_to_imag_0, 0))
        self.connect((self.hilbert_fc_0, 0), (self.blocks_complex_to_real_0, 0))
        self.connect((self.hilbert_fc_0_0, 0), (self.blocks_complex_to_real_0_0, 0))
        self.connect((self, 0), (self.blocks_multiply_const_vxx_0_0, 0))
        self.connect((self, 1), (self.blocks_divide_xx_0, 1))
        self.connect((self, 1), (self.blocks_multiply_xx_0_1, 1))
        self.connect((self, 1), (self.blocks_threshold_ff_0, 0))
        self.connect((self, 2), (self.hilbert_fc_0, 0))
        self.connect((self, 3), (self.hilbert_fc_0_0, 0))


