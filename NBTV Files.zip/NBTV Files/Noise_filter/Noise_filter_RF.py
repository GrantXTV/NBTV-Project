#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Noise filter
# Author: pcuser
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from ABXO import ABXO  # grc-generated hier_block
from Bulk_Space_v1 import Bulk_Space_v1  # grc-generated hier_block
from Bulk_space_plot_v1 import Bulk_space_plot_v1  # grc-generated hier_block
from FFT_overlap_v1 import FFT_overlap_v1  # grc-generated hier_block
from NC_function_v1 import NC_function_v1  # grc-generated hier_block
from Phase_Offset import Phase_Offset  # grc-generated hier_block
from PyQt5 import QtCore
from PyQt5.QtCore import QObject, pyqtSlot
from gnuradio import analog
from gnuradio import audio
from gnuradio import blocks
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import eng_notation
from gnuradio import soapy
from phasing2xo_v1 import phasing2xo_v1  # grc-generated hier_block
from sel_block_float_v1 import sel_block_float_v1  # grc-generated hier_block
import sip
import threading



class Noise_filter_RF(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "Noise filter", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("Noise filter")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "Noise_filter_RF")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 96000
        self.volume = volume = -20
        self.sb_sel = sb_sel = (-1)
        self.samp_rate_0 = samp_rate_0 = 24000
        self.gainDiversity = gainDiversity = 3
        self.bfo = bfo = 1500
        self.band_pass_filter_taps = band_pass_filter_taps = firdes.complex_band_pass(1.0, samp_rate, 20, 6250, 12500, window.WIN_HAMMING, 6.76)
        self.Threshold = Threshold = 0.25
        self.Stereo_Phase = Stereo_Phase = 0
        self.Ratio = Ratio = 0.0
        self.Phasing = Phasing = 0
        self.Phase = Phase = 10
        self.Noise = Noise = -00
        self.NC = NC = 0
        self.IF_Gain = IF_Gain = 20
        self.Frequency = Frequency = 1480
        self.Filter_set = Filter_set = 5
        self.Demod = Demod = 0
        self.De_Emphasis = De_Emphasis = 0
        self.ABXOsel = ABXOsel = 0

        ##################################################
        # Blocks
        ##################################################

        self._volume_range = qtgui.Range(-60, 30, 1, -20, 200)
        self._volume_win = qtgui.RangeWidget(self._volume_range, self.set_volume, "Volume (dB)", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._volume_win, 1, 0, 1, 2)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        # Create the options list
        self._sb_sel_options = [-1, 1]
        # Create the labels list
        self._sb_sel_labels = ['Upper', 'Lower']
        # Create the combo box
        # Create the radio buttons
        self._sb_sel_group_box = Qt.QGroupBox("Weaver rcv SB" + ": ")
        self._sb_sel_box = Qt.QVBoxLayout()
        class variable_chooser_button_group(Qt.QButtonGroup):
            def __init__(self, parent=None):
                Qt.QButtonGroup.__init__(self, parent)
            @pyqtSlot(int)
            def updateButtonChecked(self, button_id):
                self.button(button_id).setChecked(True)
        self._sb_sel_button_group = variable_chooser_button_group()
        self._sb_sel_group_box.setLayout(self._sb_sel_box)
        for i, _label in enumerate(self._sb_sel_labels):
            radio_button = Qt.QRadioButton(_label)
            self._sb_sel_box.addWidget(radio_button)
            self._sb_sel_button_group.addButton(radio_button, i)
        self._sb_sel_callback = lambda i: Qt.QMetaObject.invokeMethod(self._sb_sel_button_group, "updateButtonChecked", Qt.Q_ARG("int", self._sb_sel_options.index(i)))
        self._sb_sel_callback(self.sb_sel)
        self._sb_sel_button_group.buttonClicked[int].connect(
            lambda i: self.set_sb_sel(self._sb_sel_options[i]))
        self.top_grid_layout.addWidget(self._sb_sel_group_box, 5, 1, 1, 1)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._gainDiversity_range = qtgui.Range(0, 20, 0.1, 3, 300)
        self._gainDiversity_win = qtgui.RangeWidget(self._gainDiversity_range, self.set_gainDiversity, "Diversity", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._gainDiversity_win, 1, 2, 1, 2)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._bfo_range = qtgui.Range(0, 3000, 10, 1500, 200)
        self._bfo_win = qtgui.RangeWidget(self._bfo_range, self.set_bfo, "Weaver fine tuning", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._bfo_win, 6, 0, 1, 2)
        for r in range(6, 7):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Threshold_range = qtgui.Range(0, 1.0, 0.01, 0.25, 300)
        self._Threshold_win = qtgui.RangeWidget(self._Threshold_range, self.set_Threshold, "Threshold", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Threshold_win, 2, 2, 1, 2)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        # Create the options list
        self._Stereo_Phase_options = [0, 1, 2]
        # Create the labels list
        self._Stereo_Phase_labels = ['Mono', 'Kahn', 'C-QuAM']
        # Create the combo box
        # Create the radio buttons
        self._Stereo_Phase_group_box = Qt.QGroupBox("Stereo Phasing" + ": ")
        self._Stereo_Phase_box = Qt.QVBoxLayout()
        class variable_chooser_button_group(Qt.QButtonGroup):
            def __init__(self, parent=None):
                Qt.QButtonGroup.__init__(self, parent)
            @pyqtSlot(int)
            def updateButtonChecked(self, button_id):
                self.button(button_id).setChecked(True)
        self._Stereo_Phase_button_group = variable_chooser_button_group()
        self._Stereo_Phase_group_box.setLayout(self._Stereo_Phase_box)
        for i, _label in enumerate(self._Stereo_Phase_labels):
            radio_button = Qt.QRadioButton(_label)
            self._Stereo_Phase_box.addWidget(radio_button)
            self._Stereo_Phase_button_group.addButton(radio_button, i)
        self._Stereo_Phase_callback = lambda i: Qt.QMetaObject.invokeMethod(self._Stereo_Phase_button_group, "updateButtonChecked", Qt.Q_ARG("int", self._Stereo_Phase_options.index(i)))
        self._Stereo_Phase_callback(self.Stereo_Phase)
        self._Stereo_Phase_button_group.buttonClicked[int].connect(
            lambda i: self.set_Stereo_Phase(self._Stereo_Phase_options[i]))
        self.top_grid_layout.addWidget(self._Stereo_Phase_group_box, 5, 2, 1, 1)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Ratio_range = qtgui.Range(-0.99, 0.99, 0.01, 0.0, 200)
        self._Ratio_win = qtgui.RangeWidget(self._Ratio_range, self.set_Ratio, "'Ratio'", "eng", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Ratio_win, 6, 4, 1, 1)
        for r in range(6, 7):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        # Create the options list
        self._Phasing_options = [0, 1]
        # Create the labels list
        self._Phasing_labels = ['Normal', 'Inverted']
        # Create the combo box
        # Create the radio buttons
        self._Phasing_group_box = Qt.QGroupBox("'Phasing'" + ": ")
        self._Phasing_box = Qt.QVBoxLayout()
        class variable_chooser_button_group(Qt.QButtonGroup):
            def __init__(self, parent=None):
                Qt.QButtonGroup.__init__(self, parent)
            @pyqtSlot(int)
            def updateButtonChecked(self, button_id):
                self.button(button_id).setChecked(True)
        self._Phasing_button_group = variable_chooser_button_group()
        self._Phasing_group_box.setLayout(self._Phasing_box)
        for i, _label in enumerate(self._Phasing_labels):
            radio_button = Qt.QRadioButton(_label)
            self._Phasing_box.addWidget(radio_button)
            self._Phasing_button_group.addButton(radio_button, i)
        self._Phasing_callback = lambda i: Qt.QMetaObject.invokeMethod(self._Phasing_button_group, "updateButtonChecked", Qt.Q_ARG("int", self._Phasing_options.index(i)))
        self._Phasing_callback(self.Phasing)
        self._Phasing_button_group.buttonClicked[int].connect(
            lambda i: self.set_Phasing(self._Phasing_options[i]))
        self.top_grid_layout.addWidget(self._Phasing_group_box, 5, 4, 1, 1)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.Phase_Offset = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_HORIZ,
            1,
            None # parent
        )
        self.Phase_Offset.set_update_time(0.1)
        self.Phase_Offset.set_title("Phase offset")

        labels = ['', '', '', '', '',
            '', '', '', '', '']
        units = ['', '', '', '', '',
            '', '', '', '', '']
        colors = [("black", "white"), ("blue", "red"), ("black", "black"), ("black", "black"), ("black", "black"),
            ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]

        for i in range(1):
            self.Phase_Offset.set_min(i, -1)
            self.Phase_Offset.set_max(i, 1)
            self.Phase_Offset.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.Phase_Offset.set_label(i, "Data {0}".format(i))
            else:
                self.Phase_Offset.set_label(i, labels[i])
            self.Phase_Offset.set_unit(i, units[i])
            self.Phase_Offset.set_factor(i, factor[i])

        self.Phase_Offset.enable_autoscale(False)
        self._Phase_Offset_win = sip.wrapinstance(self.Phase_Offset.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._Phase_Offset_win, 10, 4, 3, 3)
        for r in range(10, 13):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 7):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Phase_range = qtgui.Range(0, 360, 1, 10, 200)
        self._Phase_win = qtgui.RangeWidget(self._Phase_range, self.set_Phase, "Phase", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Phase_win, 3, 2, 1, 2)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Noise_range = qtgui.Range(-30, 30, 1, -00, 200)
        self._Noise_win = qtgui.RangeWidget(self._Noise_range, self.set_Noise, "Noise Filter", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Noise_win, 2, 0, 1, 2)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        # Create the options list
        self._NC_options = [0, 1]
        # Create the labels list
        self._NC_labels = ['Off', 'On']
        # Create the combo box
        # Create the radio buttons
        self._NC_group_box = Qt.QGroupBox("NC" + ": ")
        self._NC_box = Qt.QVBoxLayout()
        class variable_chooser_button_group(Qt.QButtonGroup):
            def __init__(self, parent=None):
                Qt.QButtonGroup.__init__(self, parent)
            @pyqtSlot(int)
            def updateButtonChecked(self, button_id):
                self.button(button_id).setChecked(True)
        self._NC_button_group = variable_chooser_button_group()
        self._NC_group_box.setLayout(self._NC_box)
        for i, _label in enumerate(self._NC_labels):
            radio_button = Qt.QRadioButton(_label)
            self._NC_box.addWidget(radio_button)
            self._NC_button_group.addButton(radio_button, i)
        self._NC_callback = lambda i: Qt.QMetaObject.invokeMethod(self._NC_button_group, "updateButtonChecked", Qt.Q_ARG("int", self._NC_options.index(i)))
        self._NC_callback(self.NC)
        self._NC_button_group.buttonClicked[int].connect(
            lambda i: self.set_NC(self._NC_options[i]))
        self.top_grid_layout.addWidget(self._NC_group_box, 5, 6, 1, 1)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(6, 7):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._IF_Gain_range = qtgui.Range(1, 40, 1, 20, 200)
        self._IF_Gain_win = qtgui.RangeWidget(self._IF_Gain_range, self.set_IF_Gain, "HackRF IF Gain", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._IF_Gain_win, 4, 0, 1, 2)
        for r in range(4, 5):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Frequency_range = qtgui.Range(100, 30000, 5, 1480, 200)
        self._Frequency_win = qtgui.RangeWidget(self._Frequency_range, self.set_Frequency, "Frequency in kHz", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Frequency_win, 4, 2, 1, 2)
        for r in range(4, 5):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Filter_set_range = qtgui.Range(2, 12, 1, 5, 200)
        self._Filter_set_win = qtgui.RangeWidget(self._Filter_set_range, self.set_Filter_set, "Filter Bandwidth", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Filter_set_win, 3, 0, 1, 2)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        # Create the options list
        self._Demod_options = [0, 1, 2, 3, 4]
        # Create the labels list
        self._Demod_labels = ['AM', 'DSB', 'USB', 'LSB', 'Weaver']
        # Create the combo box
        # Create the radio buttons
        self._Demod_group_box = Qt.QGroupBox("Demodulator" + ": ")
        self._Demod_box = Qt.QVBoxLayout()
        class variable_chooser_button_group(Qt.QButtonGroup):
            def __init__(self, parent=None):
                Qt.QButtonGroup.__init__(self, parent)
            @pyqtSlot(int)
            def updateButtonChecked(self, button_id):
                self.button(button_id).setChecked(True)
        self._Demod_button_group = variable_chooser_button_group()
        self._Demod_group_box.setLayout(self._Demod_box)
        for i, _label in enumerate(self._Demod_labels):
            radio_button = Qt.QRadioButton(_label)
            self._Demod_box.addWidget(radio_button)
            self._Demod_button_group.addButton(radio_button, i)
        self._Demod_callback = lambda i: Qt.QMetaObject.invokeMethod(self._Demod_button_group, "updateButtonChecked", Qt.Q_ARG("int", self._Demod_options.index(i)))
        self._Demod_callback(self.Demod)
        self._Demod_button_group.buttonClicked[int].connect(
            lambda i: self.set_Demod(self._Demod_options[i]))
        self.top_grid_layout.addWidget(self._Demod_group_box, 5, 0, 1, 1)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 1):
            self.top_grid_layout.setColumnStretch(c, 1)
        # Create the options list
        self._De_Emphasis_options = [0, 1, 2]
        # Create the labels list
        self._De_Emphasis_labels = ['Off', 'On', 'NBFM']
        # Create the combo box
        # Create the radio buttons
        self._De_Emphasis_group_box = Qt.QGroupBox("De-Emphasis" + ": ")
        self._De_Emphasis_box = Qt.QVBoxLayout()
        class variable_chooser_button_group(Qt.QButtonGroup):
            def __init__(self, parent=None):
                Qt.QButtonGroup.__init__(self, parent)
            @pyqtSlot(int)
            def updateButtonChecked(self, button_id):
                self.button(button_id).setChecked(True)
        self._De_Emphasis_button_group = variable_chooser_button_group()
        self._De_Emphasis_group_box.setLayout(self._De_Emphasis_box)
        for i, _label in enumerate(self._De_Emphasis_labels):
            radio_button = Qt.QRadioButton(_label)
            self._De_Emphasis_box.addWidget(radio_button)
            self._De_Emphasis_button_group.addButton(radio_button, i)
        self._De_Emphasis_callback = lambda i: Qt.QMetaObject.invokeMethod(self._De_Emphasis_button_group, "updateButtonChecked", Qt.Q_ARG("int", self._De_Emphasis_options.index(i)))
        self._De_Emphasis_callback(self.De_Emphasis)
        self._De_Emphasis_button_group.buttonClicked[int].connect(
            lambda i: self.set_De_Emphasis(self._De_Emphasis_options[i]))
        self.top_grid_layout.addWidget(self._De_Emphasis_group_box, 5, 3, 1, 1)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        # Create the options list
        self._ABXOsel_options = [0, 1]
        # Create the labels list
        self._ABXOsel_labels = ['XO', 'AB']
        # Create the combo box
        # Create the radio buttons
        self._ABXOsel_group_box = Qt.QGroupBox("ABXOsel" + ": ")
        self._ABXOsel_box = Qt.QVBoxLayout()
        class variable_chooser_button_group(Qt.QButtonGroup):
            def __init__(self, parent=None):
                Qt.QButtonGroup.__init__(self, parent)
            @pyqtSlot(int)
            def updateButtonChecked(self, button_id):
                self.button(button_id).setChecked(True)
        self._ABXOsel_button_group = variable_chooser_button_group()
        self._ABXOsel_group_box.setLayout(self._ABXOsel_box)
        for i, _label in enumerate(self._ABXOsel_labels):
            radio_button = Qt.QRadioButton(_label)
            self._ABXOsel_box.addWidget(radio_button)
            self._ABXOsel_button_group.addButton(radio_button, i)
        self._ABXOsel_callback = lambda i: Qt.QMetaObject.invokeMethod(self._ABXOsel_button_group, "updateButtonChecked", Qt.Q_ARG("int", self._ABXOsel_options.index(i)))
        self._ABXOsel_callback(self.ABXOsel)
        self._ABXOsel_button_group.buttonClicked[int].connect(
            lambda i: self.set_ABXOsel(self._ABXOsel_options[i]))
        self.top_grid_layout.addWidget(self._ABXOsel_group_box, 5, 5, 1, 1)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(5, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.soapy_hackrf_source_0 = None
        dev = 'driver=hackrf'
        stream_args = ''
        tune_args = ['']
        settings = ['']

        self.soapy_hackrf_source_0 = soapy.source(dev, "fc32", 1, '',
                                  stream_args, tune_args, settings)
        self.soapy_hackrf_source_0.set_sample_rate(0, 4000000)
        self.soapy_hackrf_source_0.set_bandwidth(0, 0)
        self.soapy_hackrf_source_0.set_frequency(0, ((Frequency*1000)-24000))
        self.soapy_hackrf_source_0.set_gain(0, 'AMP', True)
        self.soapy_hackrf_source_0.set_gain(0, 'LNA', min(max(IF_Gain, 0.0), 40.0))
        self.soapy_hackrf_source_0.set_gain(0, 'VGA', min(max(16, 0.0), 62.0))
        self.sel_block_float_v1_0_0 = sel_block_float_v1(
            sel=NC,
        )
        self.rational_resampler_xxx_0_2 = filter.rational_resampler_ccc(
                interpolation=samp_rate,
                decimation=(samp_rate*4),
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_1 = filter.rational_resampler_fff(
                interpolation=1,
                decimation=6,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0_3 = filter.rational_resampler_fff(
                interpolation=1,
                decimation=6,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0_2 = filter.rational_resampler_fff(
                interpolation=48000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0_1_0 = filter.rational_resampler_ccc(
                interpolation=24000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0_1 = filter.rational_resampler_fff(
                interpolation=48000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0_0_1_0 = filter.rational_resampler_fff(
                interpolation=48000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0_0_1 = filter.rational_resampler_fff(
                interpolation=48000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0_0 = filter.rational_resampler_fff(
                interpolation=48000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0_0 = filter.rational_resampler_fff(
                interpolation=48000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.rational_resampler_xxx_0 = filter.rational_resampler_ccc(
                interpolation=(samp_rate*4),
                decimation=4000000,
                taps=[],
                fractional_bw=0)
        self.qtgui_sink_x_0 = qtgui.sink_c(
            4096, #fftsize
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            (samp_rate/4), #bw
            "IF input", #name
            True, #plotfreq
            True, #plotwaterfall
            True, #plottime
            False, #plotconst
            None # parent
        )
        self.qtgui_sink_x_0.set_update_time(1.0/10)
        self._qtgui_sink_x_0_win = sip.wrapinstance(self.qtgui_sink_x_0.qwidget(), Qt.QWidget)

        self.qtgui_sink_x_0.enable_rf_freq(False)

        self.top_grid_layout.addWidget(self._qtgui_sink_x_0_win, 8, 0, 4, 4)
        for r in range(8, 12):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(0, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_number_sink_1 = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_NONE,
            1,
            None # parent
        )
        self.qtgui_number_sink_1.set_update_time(0.10)
        self.qtgui_number_sink_1.set_title("")

        labels = ['AX/BO (dB)', '', '', '', '',
            '', '', '', '', '']
        units = ['', '', '', '', '',
            '', '', '', '', '']
        colors = [("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"),
            ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]

        for i in range(1):
            self.qtgui_number_sink_1.set_min(i, -60)
            self.qtgui_number_sink_1.set_max(i, 60)
            self.qtgui_number_sink_1.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.qtgui_number_sink_1.set_label(i, "Data {0}".format(i))
            else:
                self.qtgui_number_sink_1.set_label(i, labels[i])
            self.qtgui_number_sink_1.set_unit(i, units[i])
            self.qtgui_number_sink_1.set_factor(i, factor[i])

        self.qtgui_number_sink_1.enable_autoscale(False)
        self._qtgui_number_sink_1_win = sip.wrapinstance(self.qtgui_number_sink_1.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_number_sink_1_win, 6, 3, 1, 1)
        for r in range(6, 7):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_number_sink_0_1 = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_VERT,
            1,
            None # parent
        )
        self.qtgui_number_sink_0_1.set_update_time(0.1)
        self.qtgui_number_sink_0_1.set_title("S meter AX")

        labels = ['6dB / S point', '', '', '', '',
            '', '', '', '', '']
        units = ['', '', '', '', '',
            '', '', '', '', '']
        colors = [("blue", "red"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"),
            ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]

        for i in range(1):
            self.qtgui_number_sink_0_1.set_min(i, 0)
            self.qtgui_number_sink_0_1.set_max(i, 20)
            self.qtgui_number_sink_0_1.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.qtgui_number_sink_0_1.set_label(i, "Data {0}".format(i))
            else:
                self.qtgui_number_sink_0_1.set_label(i, labels[i])
            self.qtgui_number_sink_0_1.set_unit(i, units[i])
            self.qtgui_number_sink_0_1.set_factor(i, factor[i])

        self.qtgui_number_sink_0_1.enable_autoscale(False)
        self._qtgui_number_sink_0_1_win = sip.wrapinstance(self.qtgui_number_sink_0_1.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_number_sink_0_1_win, 0, 4, 4, 1)
        for r in range(0, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_number_sink_0_0 = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_VERT,
            1,
            None # parent
        )
        self.qtgui_number_sink_0_0.set_update_time(0.1)
        self.qtgui_number_sink_0_0.set_title("S meter BO")

        labels = ['6dB / S point', '', '', '', '',
            '', '', '', '', '']
        units = ['', '', '', '', '',
            '', '', '', '', '']
        colors = [("blue", "red"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"),
            ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]

        for i in range(1):
            self.qtgui_number_sink_0_0.set_min(i, 0)
            self.qtgui_number_sink_0_0.set_max(i, 20)
            self.qtgui_number_sink_0_0.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.qtgui_number_sink_0_0.set_label(i, "Data {0}".format(i))
            else:
                self.qtgui_number_sink_0_0.set_label(i, labels[i])
            self.qtgui_number_sink_0_0.set_unit(i, units[i])
            self.qtgui_number_sink_0_0.set_factor(i, factor[i])

        self.qtgui_number_sink_0_0.enable_autoscale(False)
        self._qtgui_number_sink_0_0_win = sip.wrapinstance(self.qtgui_number_sink_0_0.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_number_sink_0_0_win, 0, 5, 4, 1)
        for r in range(0, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(5, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_number_sink_0 = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_VERT,
            2,
            None # parent
        )
        self.qtgui_number_sink_0.set_update_time(0.10)
        self.qtgui_number_sink_0.set_title("Audio Meter")

        labels = ['', '', '', '', '',
            '', '', '', '', '']
        units = ['', '', '', '', '',
            '', '', '', '', '']
        colors = [("blue", "red"), ("blue", "red"), ("black", "black"), ("black", "black"), ("black", "black"),
            ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]

        for i in range(2):
            self.qtgui_number_sink_0.set_min(i, 0)
            self.qtgui_number_sink_0.set_max(i, 1)
            self.qtgui_number_sink_0.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.qtgui_number_sink_0.set_label(i, "Data {0}".format(i))
            else:
                self.qtgui_number_sink_0.set_label(i, labels[i])
            self.qtgui_number_sink_0.set_unit(i, units[i])
            self.qtgui_number_sink_0.set_factor(i, factor[i])

        self.qtgui_number_sink_0.enable_autoscale(False)
        self._qtgui_number_sink_0_win = sip.wrapinstance(self.qtgui_number_sink_0.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_number_sink_0_win, 0, 6, 4, 1)
        for r in range(0, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(6, 7):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.qtgui_const_sink_x_0 = qtgui.const_sink_c(
            2000, #size
            "", #name
            5, #number of inputs
            None # parent
        )
        self.qtgui_const_sink_x_0.set_update_time(0.05)
        self.qtgui_const_sink_x_0.set_y_axis((-1), 1)
        self.qtgui_const_sink_x_0.set_x_axis(0, 360)
        self.qtgui_const_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_0.enable_autoscale(False)
        self.qtgui_const_sink_x_0.enable_grid(True)
        self.qtgui_const_sink_x_0.enable_axis_labels(False)

        self.qtgui_const_sink_x_0.disable_legend()

        labels = ['RX0', 'RX1', 'RX2', 'NC setting', '',
            '', '', '', '', '']
        widths = [1, 1, 1, 10, 2,
            1, 1, 1, 1, 1]
        colors = ["black", "black", "black", "red", "green",
            "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
            0, 0, 0, 0, 0]
        markers = [0, 0, 0, 1, 0,
            0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]

        for i in range(5):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_0_win = sip.wrapinstance(self.qtgui_const_sink_x_0.qwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_0_win, 7, 4, 3, 3)
        for r in range(7, 10):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 7):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.phasing2xo_v1_0 = phasing2xo_v1(
            sel=ABXOsel,
        )
        self.low_pass_filter_0_0 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                1,
                samp_rate,
                (Filter_set*1000),
                1000,
                window.WIN_BLACKMAN,
                6.76))
        self.low_pass_filter_0 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                1,
                samp_rate,
                (Filter_set*1000),
                1000,
                window.WIN_BLACKMAN,
                6.76))
        self.freq_xlating_fir_filter_xxx_0 = filter.freq_xlating_fir_filter_ccf(1, firdes.low_pass(1,samp_rate,samp_rate/2, 1500), ((sb_sel)*(-1500.0)), samp_rate)
        self.fft_filter_xxx_0_0 = filter.fft_filter_ccc(1, band_pass_filter_taps, 1)
        self.fft_filter_xxx_0_0.declare_sample_delay(0)
        self.fft_filter_xxx_0 = filter.fft_filter_ccc(1, band_pass_filter_taps, 1)
        self.fft_filter_xxx_0.declare_sample_delay(0)
        self.blocks_vector_source_x_0_1_0_0 = blocks.vector_source_f([(Phase)]*512, True, 512, [])
        self.blocks_vector_source_x_0_1_0 = blocks.vector_source_f([(Ratio)]*512, True, 512, [])
        self.blocks_swapiq_0_0_0 = blocks.swap_iq(1, gr.sizeof_gr_complex)
        self.blocks_sub_xx_1 = blocks.sub_ff(1)
        self.blocks_sub_xx_0_0 = blocks.sub_ff(1)
        self.blocks_sub_xx_0 = blocks.sub_ff(1)
        self.blocks_selector_0_2 = blocks.selector(gr.sizeof_gr_complex*1,Demod,0)
        self.blocks_selector_0_2.set_enabled(True)
        self.blocks_selector_0_1 = blocks.selector(gr.sizeof_gr_complex*1,Demod,0)
        self.blocks_selector_0_1.set_enabled(True)
        self.blocks_selector_0_0_0_2_0 = blocks.selector(gr.sizeof_float*1,De_Emphasis,0)
        self.blocks_selector_0_0_0_2_0.set_enabled(True)
        self.blocks_selector_0_0_0_2 = blocks.selector(gr.sizeof_float*1,De_Emphasis,0)
        self.blocks_selector_0_0_0_2.set_enabled(True)
        self.blocks_selector_0_0_0 = blocks.selector(gr.sizeof_float*1,Stereo_Phase,0)
        self.blocks_selector_0_0_0.set_enabled(True)
        self.blocks_selector_0_0 = blocks.selector(gr.sizeof_float*1,Stereo_Phase,0)
        self.blocks_selector_0_0.set_enabled(True)
        self.blocks_selector_0 = blocks.selector(gr.sizeof_float*1,Demod,0)
        self.blocks_selector_0.set_enabled(True)
        self.blocks_nlog10_ff_0_1 = blocks.nlog10_ff((20/6), 1, 2)
        self.blocks_nlog10_ff_0_0 = blocks.nlog10_ff(20, 1, 0)
        self.blocks_nlog10_ff_0 = blocks.nlog10_ff((20/6), 1, 2)
        self.blocks_multiply_xx_0_0_0 = blocks.multiply_vff(1)
        self.blocks_multiply_xx_0_0 = blocks.multiply_vff(1)
        self.blocks_multiply_const_vxx_1_1_1_1_1_0 = blocks.multiply_const_ff((gainDiversity))
        self.blocks_multiply_const_vxx_1_1_1_1_1 = blocks.multiply_const_ff((gainDiversity))
        self.blocks_multiply_const_vxx_0_2_0_0_0_3_0 = blocks.multiply_const_cc(10)
        self.blocks_multiply_const_vxx_0_2_0_0_0_3 = blocks.multiply_const_cc(10)
        self.blocks_multiply_const_vxx_0_2_0_0_0_2_0 = blocks.multiply_const_ff(.125)
        self.blocks_multiply_const_vxx_0_2_0_0_0_2 = blocks.multiply_const_ff(.125)
        self.blocks_multiply_const_vxx_0_2_0_0_0_1 = blocks.multiply_const_ff(1000)
        self.blocks_multiply_const_vxx_0_2_0_0_0_0_0 = blocks.multiply_const_ff(5)
        self.blocks_multiply_const_vxx_0_2_0_0_0_0 = blocks.multiply_const_ff(5)
        self.blocks_multiply_const_vxx_0_2_0_0_0 = blocks.multiply_const_ff(20)
        self.blocks_multiply_const_vxx_0_2_0_0 = blocks.multiply_const_ff(0.125)
        self.blocks_multiply_const_vxx_0_2_0 = blocks.multiply_const_ff(0.125)
        self.blocks_multiply_const_vxx_0_2 = blocks.multiply_const_ff((10**(volume/20)))
        self.blocks_multiply_const_vxx_0_0_2 = blocks.multiply_const_ff(sb_sel)
        self.blocks_multiply_const_vxx_0_0_1 = blocks.multiply_const_ff((10**(Noise/20)))
        self.blocks_multiply_const_vxx_0_0_0 = blocks.multiply_const_ff((10**(volume/20)))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_ff(0.001)
        self.blocks_moving_average_xx_0_0 = blocks.moving_average_ff(10000, 1, 1000, 1)
        self.blocks_moving_average_xx_0 = blocks.moving_average_ff(10000, 1, 1000, 1)
        self.blocks_float_to_complex_0 = blocks.float_to_complex(512)
        self.blocks_divide_xx_0_0 = blocks.divide_ff(1)
        self.blocks_divide_xx_0 = blocks.divide_ff(1)
        self.blocks_delay_0_0 = blocks.delay(gr.sizeof_float*1, 3300)
        self.blocks_delay_0 = blocks.delay(gr.sizeof_float*1, 3300)
        self.blocks_complex_to_real_0_0 = blocks.complex_to_real(1)
        self.blocks_complex_to_real_0 = blocks.complex_to_real(1)
        self.blocks_complex_to_float_1_0_0 = blocks.complex_to_float(1)
        self.blocks_complex_to_float_0 = blocks.complex_to_float(1)
        self.blocks_add_xx_0_3 = blocks.add_vff(1)
        self.blocks_add_xx_0_2 = blocks.add_vff(1)
        self.blocks_add_xx_0_1 = blocks.add_vff(1)
        self.blocks_add_xx_0_0 = blocks.add_vff(1)
        self.blocks_add_xx_0 = blocks.add_vff(1)
        self.blocks_add_const_vxx_0_0 = blocks.add_const_ff(.4)
        self.blocks_add_const_vxx_0 = blocks.add_const_ff(.4)
        self.blocks_abs_xx_0_0 = blocks.abs_ff(1)
        self.blocks_abs_xx_0 = blocks.abs_ff(1)
        self.band_pass_filter_0_1_0_1 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                (samp_rate*4),
                24000,
                27000,
                500,
                window.WIN_HANN,
                8.32))
        self.band_pass_filter_0_1_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                (samp_rate*4),
                21000,
                24000,
                500,
                window.WIN_HANN,
                8.32))
        self.band_pass_filter_0_1_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                (samp_rate*4),
                6000,
                40000,
                1000,
                window.WIN_KAISER,
                8.32))
        self.band_pass_filter_0_1 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                1,
                (samp_rate*4),
                23000,
                25000,
                1000,
                window.WIN_KAISER,
                8.32))
        self.audio_sink_1 = audio.sink(48000, '', True)
        self.analog_sig_source_x_0_0_0 = analog.sig_source_f(samp_rate, analog.GR_SIN_WAVE, bfo, 1, 0, 0)
        self.analog_sig_source_x_0_0 = analog.sig_source_f(samp_rate, analog.GR_COS_WAVE, bfo, 1, 0, 0)
        self.analog_sig_source_x_0 = analog.sig_source_c((samp_rate*4), analog.GR_COS_WAVE, 24000, 1, 0, 0)
        self.analog_pll_refout_cc_0_0 = analog.pll_refout_cc(0.05, 0.4, 0.37)
        self.analog_nbfm_rx_0 = analog.nbfm_rx(
        	audio_rate=48000,
        	quad_rate=samp_rate,
        	tau=(50e-6),
        	max_dev=5e3,
          )
        self.analog_fm_deemph_0_0 = analog.fm_deemph(fs=48000, tau=(50e-6))
        self.analog_fm_deemph_0 = analog.fm_deemph(fs=48000, tau=(50e-6))
        self.analog_const_source_x_1_0 = analog.sig_source_f(0, analog.GR_CONST_WAVE, 0, 0, ((Phase+(Phasing*180))))
        self.analog_const_source_x_1 = analog.sig_source_f(0, analog.GR_CONST_WAVE, 0, 0, (((1+Ratio)/(1-Ratio))*(1-Phasing) + ((1-Ratio)/(1+Ratio))*Phasing))
        self.analog_am_demod_cf_0_0_0 = analog.am_demod_cf(
        	channel_rate=samp_rate,
        	audio_decim=1,
        	audio_pass=12500,
        	audio_stop=15000,
        )
        self.analog_am_demod_cf_0_0 = analog.am_demod_cf(
        	channel_rate=samp_rate,
        	audio_decim=1,
        	audio_pass=12500,
        	audio_stop=15000,
        )
        self.analog_agc_xx_0 = analog.agc_cc((1e-4), 1.0, 1, 65536)
        self.Phase_Offset_0 = Phase_Offset()
        self.NC_function_v1_0 = NC_function_v1()
        self.FFT_overlap_v1_1 = FFT_overlap_v1()
        self.FFT_overlap_v1_0 = FFT_overlap_v1()
        self.Bulk_space_plot_v1_0 = Bulk_space_plot_v1()
        self.Bulk_Space_v1_0 = Bulk_Space_v1(
            display_threshold=Threshold,
        )
        self.ABXO = ABXO(
            sel=ABXOsel,
        )


        ##################################################
        # Connections
        ##################################################
        self.connect((self.ABXO, 1), (self.Bulk_Space_v1_0, 1))
        self.connect((self.ABXO, 0), (self.Bulk_Space_v1_0, 0))
        self.connect((self.Bulk_Space_v1_0, 0), (self.Bulk_space_plot_v1_0, 0))
        self.connect((self.Bulk_space_plot_v1_0, 1), (self.qtgui_const_sink_x_0, 1))
        self.connect((self.Bulk_space_plot_v1_0, 4), (self.qtgui_const_sink_x_0, 4))
        self.connect((self.Bulk_space_plot_v1_0, 2), (self.qtgui_const_sink_x_0, 2))
        self.connect((self.Bulk_space_plot_v1_0, 3), (self.qtgui_const_sink_x_0, 3))
        self.connect((self.Bulk_space_plot_v1_0, 0), (self.qtgui_const_sink_x_0, 0))
        self.connect((self.FFT_overlap_v1_0, 0), (self.ABXO, 0))
        self.connect((self.FFT_overlap_v1_1, 0), (self.ABXO, 1))
        self.connect((self.NC_function_v1_0, 0), (self.sel_block_float_v1_0_0, 0))
        self.connect((self.NC_function_v1_0, 0), (self.sel_block_float_v1_0_0, 1))
        self.connect((self.Phase_Offset_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0_1, 0))
        self.connect((self.Phase_Offset_0, 1), (self.rational_resampler_xxx_0_2, 0))
        self.connect((self.analog_agc_xx_0, 0), (self.Phase_Offset_0, 0))
        self.connect((self.analog_agc_xx_0, 0), (self.band_pass_filter_0_1, 0))
        self.connect((self.analog_am_demod_cf_0_0, 0), (self.blocks_add_xx_0_0, 0))
        self.connect((self.analog_am_demod_cf_0_0_0, 0), (self.blocks_add_xx_0_0, 1))
        self.connect((self.analog_const_source_x_1, 0), (self.NC_function_v1_0, 0))
        self.connect((self.analog_const_source_x_1, 0), (self.blocks_nlog10_ff_0_0, 0))
        self.connect((self.analog_const_source_x_1_0, 0), (self.NC_function_v1_0, 1))
        self.connect((self.analog_fm_deemph_0, 0), (self.blocks_selector_0_0_0_2_0, 1))
        self.connect((self.analog_fm_deemph_0_0, 0), (self.blocks_selector_0_0_0_2, 1))
        self.connect((self.analog_nbfm_rx_0, 0), (self.blocks_selector_0_0_0_2, 2))
        self.connect((self.analog_nbfm_rx_0, 0), (self.blocks_selector_0_0_0_2_0, 2))
        self.connect((self.analog_pll_refout_cc_0_0, 0), (self.blocks_selector_0_1, 1))
        self.connect((self.analog_pll_refout_cc_0_0, 0), (self.blocks_selector_0_1, 0))
        self.connect((self.analog_sig_source_x_0, 0), (self.blocks_selector_0_1, 2))
        self.connect((self.analog_sig_source_x_0, 0), (self.blocks_selector_0_1, 3))
        self.connect((self.analog_sig_source_x_0_0, 0), (self.blocks_multiply_xx_0_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0, 0), (self.blocks_multiply_xx_0_0_0, 1))
        self.connect((self.band_pass_filter_0_1, 0), (self.analog_pll_refout_cc_0_0, 0))
        self.connect((self.band_pass_filter_0_1_0, 0), (self.band_pass_filter_0_1_0_0, 0))
        self.connect((self.band_pass_filter_0_1_0, 0), (self.band_pass_filter_0_1_0_1, 0))
        self.connect((self.band_pass_filter_0_1_0, 0), (self.blocks_selector_0_2, 0))
        self.connect((self.band_pass_filter_0_1_0, 0), (self.blocks_selector_0_2, 4))
        self.connect((self.band_pass_filter_0_1_0, 0), (self.blocks_selector_0_2, 1))
        self.connect((self.band_pass_filter_0_1_0_0, 0), (self.blocks_selector_0_2, 3))
        self.connect((self.band_pass_filter_0_1_0_1, 0), (self.blocks_selector_0_2, 2))
        self.connect((self.blocks_abs_xx_0, 0), (self.blocks_moving_average_xx_0_0, 0))
        self.connect((self.blocks_abs_xx_0_0, 0), (self.blocks_moving_average_xx_0, 0))
        self.connect((self.blocks_add_const_vxx_0, 0), (self.qtgui_number_sink_0, 0))
        self.connect((self.blocks_add_const_vxx_0_0, 0), (self.qtgui_number_sink_0, 1))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_sub_xx_1, 0))
        self.connect((self.blocks_add_xx_0_0, 0), (self.rational_resampler_xxx_0_0_1, 0))
        self.connect((self.blocks_add_xx_0_1, 0), (self.rational_resampler_xxx_0_0_0_1_0, 0))
        self.connect((self.blocks_add_xx_0_2, 0), (self.rational_resampler_xxx_0_0_2, 0))
        self.connect((self.blocks_add_xx_0_3, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.blocks_complex_to_float_0, 0), (self.blocks_multiply_xx_0_0, 1))
        self.connect((self.blocks_complex_to_float_0, 1), (self.blocks_multiply_xx_0_0_0, 0))
        self.connect((self.blocks_complex_to_float_1_0_0, 0), (self.blocks_add_xx_0_2, 0))
        self.connect((self.blocks_complex_to_float_1_0_0, 1), (self.blocks_add_xx_0_2, 1))
        self.connect((self.blocks_complex_to_float_1_0_0, 0), (self.blocks_sub_xx_0_0, 0))
        self.connect((self.blocks_complex_to_float_1_0_0, 1), (self.blocks_sub_xx_0_0, 1))
        self.connect((self.blocks_complex_to_real_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0_2, 0))
        self.connect((self.blocks_complex_to_real_0_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0_2_0, 0))
        self.connect((self.blocks_delay_0, 0), (self.blocks_divide_xx_0, 0))
        self.connect((self.blocks_delay_0_0, 0), (self.blocks_divide_xx_0_0, 0))
        self.connect((self.blocks_divide_xx_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0_0, 0))
        self.connect((self.blocks_divide_xx_0_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0_0_0, 0))
        self.connect((self.blocks_float_to_complex_0, 0), (self.Bulk_space_plot_v1_0, 1))
        self.connect((self.blocks_moving_average_xx_0, 0), (self.blocks_add_xx_0_3, 1))
        self.connect((self.blocks_moving_average_xx_0, 0), (self.blocks_nlog10_ff_0_1, 0))
        self.connect((self.blocks_moving_average_xx_0_0, 0), (self.blocks_add_xx_0_3, 0))
        self.connect((self.blocks_moving_average_xx_0_0, 0), (self.blocks_nlog10_ff_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0_0_0, 0), (self.audio_sink_1, 1))
        self.connect((self.blocks_multiply_const_vxx_0_0_1, 0), (self.blocks_sub_xx_1, 1))
        self.connect((self.blocks_multiply_const_vxx_0_0_2, 0), (self.blocks_add_xx_0_1, 1))
        self.connect((self.blocks_multiply_const_vxx_0_2, 0), (self.audio_sink_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0, 0), (self.blocks_add_const_vxx_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0, 0), (self.blocks_add_const_vxx_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0, 0), (self.blocks_selector_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0_0, 0), (self.blocks_multiply_const_vxx_0_2, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0_0_0, 0), (self.blocks_multiply_const_vxx_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0_1, 0), (self.Phase_Offset, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0_2, 0), (self.rational_resampler_xxx_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0_2_0, 0), (self.rational_resampler_xxx_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0_3, 0), (self.analog_am_demod_cf_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_2_0_0_0_3_0, 0), (self.analog_am_demod_cf_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_1_1_1_1_1, 0), (self.sel_block_float_v1_0_0, 2))
        self.connect((self.blocks_multiply_const_vxx_1_1_1_1_1_0, 0), (self.sel_block_float_v1_0_0, 3))
        self.connect((self.blocks_multiply_xx_0_0, 0), (self.blocks_add_xx_0_1, 0))
        self.connect((self.blocks_multiply_xx_0_0_0, 0), (self.blocks_multiply_const_vxx_0_0_2, 0))
        self.connect((self.blocks_nlog10_ff_0, 0), (self.qtgui_number_sink_0_1, 0))
        self.connect((self.blocks_nlog10_ff_0_0, 0), (self.qtgui_number_sink_1, 0))
        self.connect((self.blocks_nlog10_ff_0_1, 0), (self.qtgui_number_sink_0_0, 0))
        self.connect((self.blocks_selector_0, 0), (self.blocks_selector_0_0, 0))
        self.connect((self.blocks_selector_0, 0), (self.blocks_selector_0_0_0, 0))
        self.connect((self.blocks_selector_0_0, 0), (self.analog_fm_deemph_0, 0))
        self.connect((self.blocks_selector_0_0, 0), (self.blocks_multiply_const_vxx_0_2_0, 0))
        self.connect((self.blocks_selector_0_0, 0), (self.blocks_selector_0_0_0_2_0, 0))
        self.connect((self.blocks_selector_0_0_0, 0), (self.analog_fm_deemph_0_0, 0))
        self.connect((self.blocks_selector_0_0_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0, 0))
        self.connect((self.blocks_selector_0_0_0, 0), (self.blocks_selector_0_0_0_2, 0))
        self.connect((self.blocks_selector_0_0_0_2, 0), (self.phasing2xo_v1_0, 0))
        self.connect((self.blocks_selector_0_0_0_2, 0), (self.rational_resampler_xxx_0_0_3, 0))
        self.connect((self.blocks_selector_0_0_0_2_0, 0), (self.phasing2xo_v1_0, 1))
        self.connect((self.blocks_selector_0_0_0_2_0, 0), (self.rational_resampler_xxx_0_1, 0))
        self.connect((self.blocks_selector_0_1, 0), (self.Phase_Offset_0, 1))
        self.connect((self.blocks_selector_0_2, 0), (self.analog_agc_xx_0, 0))
        self.connect((self.blocks_sub_xx_0, 0), (self.blocks_multiply_const_vxx_0_0_1, 0))
        self.connect((self.blocks_sub_xx_0_0, 0), (self.rational_resampler_xxx_0_0_0_1, 0))
        self.connect((self.blocks_sub_xx_1, 0), (self.blocks_selector_0, 1))
        self.connect((self.blocks_swapiq_0_0_0, 0), (self.low_pass_filter_0_0, 0))
        self.connect((self.blocks_vector_source_x_0_1_0, 0), (self.blocks_float_to_complex_0, 1))
        self.connect((self.blocks_vector_source_x_0_1_0_0, 0), (self.blocks_float_to_complex_0, 0))
        self.connect((self.fft_filter_xxx_0, 0), (self.blocks_complex_to_real_0, 0))
        self.connect((self.fft_filter_xxx_0_0, 0), (self.blocks_complex_to_real_0_0, 0))
        self.connect((self.freq_xlating_fir_filter_xxx_0, 0), (self.blocks_complex_to_float_0, 0))
        self.connect((self.low_pass_filter_0, 0), (self.blocks_complex_to_float_1_0_0, 0))
        self.connect((self.low_pass_filter_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0_3, 0))
        self.connect((self.low_pass_filter_0, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0_3_0, 0))
        self.connect((self.low_pass_filter_0, 0), (self.fft_filter_xxx_0, 0))
        self.connect((self.low_pass_filter_0, 0), (self.freq_xlating_fir_filter_xxx_0, 0))
        self.connect((self.low_pass_filter_0, 0), (self.rational_resampler_xxx_0_0_1_0, 0))
        self.connect((self.low_pass_filter_0_0, 0), (self.analog_nbfm_rx_0, 0))
        self.connect((self.low_pass_filter_0_0, 0), (self.fft_filter_xxx_0_0, 0))
        self.connect((self.phasing2xo_v1_0, 1), (self.NC_function_v1_0, 3))
        self.connect((self.phasing2xo_v1_0, 0), (self.NC_function_v1_0, 2))
        self.connect((self.phasing2xo_v1_0, 1), (self.blocks_multiply_const_vxx_1_1_1_1_1, 0))
        self.connect((self.phasing2xo_v1_0, 0), (self.blocks_multiply_const_vxx_1_1_1_1_1_0, 0))
        self.connect((self.rational_resampler_xxx_0, 0), (self.band_pass_filter_0_1_0, 0))
        self.connect((self.rational_resampler_xxx_0_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.rational_resampler_xxx_0_0, 0), (self.blocks_selector_0, 2))
        self.connect((self.rational_resampler_xxx_0_0, 0), (self.blocks_selector_0_0_0, 1))
        self.connect((self.rational_resampler_xxx_0_0, 0), (self.blocks_sub_xx_0, 0))
        self.connect((self.rational_resampler_xxx_0_0_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.rational_resampler_xxx_0_0_0, 0), (self.blocks_selector_0, 3))
        self.connect((self.rational_resampler_xxx_0_0_0, 0), (self.blocks_selector_0_0, 1))
        self.connect((self.rational_resampler_xxx_0_0_0, 0), (self.blocks_sub_xx_0, 1))
        self.connect((self.rational_resampler_xxx_0_0_0_1, 0), (self.blocks_selector_0_0, 2))
        self.connect((self.rational_resampler_xxx_0_0_0_1_0, 0), (self.blocks_selector_0, 4))
        self.connect((self.rational_resampler_xxx_0_0_1, 0), (self.blocks_multiply_const_vxx_0_2_0_0_0, 0))
        self.connect((self.rational_resampler_xxx_0_0_1_0, 0), (self.qtgui_sink_x_0, 0))
        self.connect((self.rational_resampler_xxx_0_0_2, 0), (self.blocks_selector_0_0_0, 2))
        self.connect((self.rational_resampler_xxx_0_0_3, 0), (self.FFT_overlap_v1_0, 0))
        self.connect((self.rational_resampler_xxx_0_1, 0), (self.FFT_overlap_v1_1, 0))
        self.connect((self.rational_resampler_xxx_0_2, 0), (self.blocks_swapiq_0_0_0, 0))
        self.connect((self.rational_resampler_xxx_0_2, 0), (self.low_pass_filter_0, 0))
        self.connect((self.sel_block_float_v1_0_0, 0), (self.blocks_abs_xx_0, 0))
        self.connect((self.sel_block_float_v1_0_0, 1), (self.blocks_abs_xx_0_0, 0))
        self.connect((self.sel_block_float_v1_0_0, 0), (self.blocks_delay_0, 0))
        self.connect((self.sel_block_float_v1_0_0, 1), (self.blocks_delay_0_0, 0))
        self.connect((self.soapy_hackrf_source_0, 0), (self.rational_resampler_xxx_0, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "Noise_filter_RF")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.set_band_pass_filter_taps(firdes.complex_band_pass(1.0, self.samp_rate, 20, 6250, 12500, window.WIN_HAMMING, 6.76))
        self.analog_sig_source_x_0.set_sampling_freq((self.samp_rate*4))
        self.analog_sig_source_x_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0.set_sampling_freq(self.samp_rate)
        self.band_pass_filter_0_1.set_taps(firdes.band_pass(1, (self.samp_rate*4), 23000, 25000, 1000, window.WIN_KAISER, 8.32))
        self.band_pass_filter_0_1_0.set_taps(firdes.band_pass(1, (self.samp_rate*4), 6000, 40000, 1000, window.WIN_KAISER, 8.32))
        self.band_pass_filter_0_1_0_0.set_taps(firdes.band_pass(1, (self.samp_rate*4), 21000, 24000, 500, window.WIN_HANN, 8.32))
        self.band_pass_filter_0_1_0_1.set_taps(firdes.band_pass(1, (self.samp_rate*4), 24000, 27000, 500, window.WIN_HANN, 8.32))
        self.freq_xlating_fir_filter_xxx_0.set_taps(firdes.low_pass(1,self.samp_rate,self.samp_rate/2, 1500))
        self.low_pass_filter_0.set_taps(firdes.low_pass(1, self.samp_rate, (self.Filter_set*1000), 1000, window.WIN_BLACKMAN, 6.76))
        self.low_pass_filter_0_0.set_taps(firdes.low_pass(1, self.samp_rate, (self.Filter_set*1000), 1000, window.WIN_BLACKMAN, 6.76))
        self.qtgui_sink_x_0.set_frequency_range(0, (self.samp_rate/4))

    def get_volume(self):
        return self.volume

    def set_volume(self, volume):
        self.volume = volume
        self.blocks_multiply_const_vxx_0_0_0.set_k((10**(self.volume/20)))
        self.blocks_multiply_const_vxx_0_2.set_k((10**(self.volume/20)))

    def get_sb_sel(self):
        return self.sb_sel

    def set_sb_sel(self, sb_sel):
        self.sb_sel = sb_sel
        self._sb_sel_callback(self.sb_sel)
        self.blocks_multiply_const_vxx_0_0_2.set_k(self.sb_sel)
        self.freq_xlating_fir_filter_xxx_0.set_center_freq(((self.sb_sel)*(-1500.0)))

    def get_samp_rate_0(self):
        return self.samp_rate_0

    def set_samp_rate_0(self, samp_rate_0):
        self.samp_rate_0 = samp_rate_0

    def get_gainDiversity(self):
        return self.gainDiversity

    def set_gainDiversity(self, gainDiversity):
        self.gainDiversity = gainDiversity
        self.blocks_multiply_const_vxx_1_1_1_1_1.set_k((self.gainDiversity))
        self.blocks_multiply_const_vxx_1_1_1_1_1_0.set_k((self.gainDiversity))

    def get_bfo(self):
        return self.bfo

    def set_bfo(self, bfo):
        self.bfo = bfo
        self.analog_sig_source_x_0_0.set_frequency(self.bfo)
        self.analog_sig_source_x_0_0_0.set_frequency(self.bfo)

    def get_band_pass_filter_taps(self):
        return self.band_pass_filter_taps

    def set_band_pass_filter_taps(self, band_pass_filter_taps):
        self.band_pass_filter_taps = band_pass_filter_taps
        self.fft_filter_xxx_0.set_taps(self.band_pass_filter_taps)
        self.fft_filter_xxx_0_0.set_taps(self.band_pass_filter_taps)

    def get_Threshold(self):
        return self.Threshold

    def set_Threshold(self, Threshold):
        self.Threshold = Threshold
        self.Bulk_Space_v1_0.set_display_threshold(self.Threshold)

    def get_Stereo_Phase(self):
        return self.Stereo_Phase

    def set_Stereo_Phase(self, Stereo_Phase):
        self.Stereo_Phase = Stereo_Phase
        self._Stereo_Phase_callback(self.Stereo_Phase)
        self.blocks_selector_0_0.set_input_index(self.Stereo_Phase)
        self.blocks_selector_0_0_0.set_input_index(self.Stereo_Phase)

    def get_Ratio(self):
        return self.Ratio

    def set_Ratio(self, Ratio):
        self.Ratio = Ratio
        self.analog_const_source_x_1.set_offset((((1+self.Ratio)/(1-self.Ratio))*(1-self.Phasing) + ((1-self.Ratio)/(1+self.Ratio))*self.Phasing))
        self.blocks_vector_source_x_0_1_0.set_data([(self.Ratio)]*512, [])

    def get_Phasing(self):
        return self.Phasing

    def set_Phasing(self, Phasing):
        self.Phasing = Phasing
        self._Phasing_callback(self.Phasing)
        self.analog_const_source_x_1.set_offset((((1+self.Ratio)/(1-self.Ratio))*(1-self.Phasing) + ((1-self.Ratio)/(1+self.Ratio))*self.Phasing))
        self.analog_const_source_x_1_0.set_offset(((self.Phase+(self.Phasing*180))))

    def get_Phase(self):
        return self.Phase

    def set_Phase(self, Phase):
        self.Phase = Phase
        self.analog_const_source_x_1_0.set_offset(((self.Phase+(self.Phasing*180))))
        self.blocks_vector_source_x_0_1_0_0.set_data([(self.Phase)]*512, [])

    def get_Noise(self):
        return self.Noise

    def set_Noise(self, Noise):
        self.Noise = Noise
        self.blocks_multiply_const_vxx_0_0_1.set_k((10**(self.Noise/20)))

    def get_NC(self):
        return self.NC

    def set_NC(self, NC):
        self.NC = NC
        self._NC_callback(self.NC)
        self.sel_block_float_v1_0_0.set_sel(self.NC)

    def get_IF_Gain(self):
        return self.IF_Gain

    def set_IF_Gain(self, IF_Gain):
        self.IF_Gain = IF_Gain
        self.soapy_hackrf_source_0.set_gain(0, 'LNA', min(max(self.IF_Gain, 0.0), 40.0))

    def get_Frequency(self):
        return self.Frequency

    def set_Frequency(self, Frequency):
        self.Frequency = Frequency
        self.soapy_hackrf_source_0.set_frequency(0, ((self.Frequency*1000)-24000))

    def get_Filter_set(self):
        return self.Filter_set

    def set_Filter_set(self, Filter_set):
        self.Filter_set = Filter_set
        self.low_pass_filter_0.set_taps(firdes.low_pass(1, self.samp_rate, (self.Filter_set*1000), 1000, window.WIN_BLACKMAN, 6.76))
        self.low_pass_filter_0_0.set_taps(firdes.low_pass(1, self.samp_rate, (self.Filter_set*1000), 1000, window.WIN_BLACKMAN, 6.76))

    def get_Demod(self):
        return self.Demod

    def set_Demod(self, Demod):
        self.Demod = Demod
        self._Demod_callback(self.Demod)
        self.blocks_selector_0.set_input_index(self.Demod)
        self.blocks_selector_0_1.set_input_index(self.Demod)
        self.blocks_selector_0_2.set_input_index(self.Demod)

    def get_De_Emphasis(self):
        return self.De_Emphasis

    def set_De_Emphasis(self, De_Emphasis):
        self.De_Emphasis = De_Emphasis
        self._De_Emphasis_callback(self.De_Emphasis)
        self.blocks_selector_0_0_0_2.set_input_index(self.De_Emphasis)
        self.blocks_selector_0_0_0_2_0.set_input_index(self.De_Emphasis)

    def get_ABXOsel(self):
        return self.ABXOsel

    def set_ABXOsel(self, ABXOsel):
        self.ABXOsel = ABXOsel
        self._ABXOsel_callback(self.ABXOsel)
        self.ABXO.set_sel(self.ABXOsel)
        self.phasing2xo_v1_0.set_sel(self.ABXOsel)




def main(top_block_cls=Noise_filter_RF, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
