# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: ABXO_v1
# Author: PA0SIM
# Copyright: PA0SIM
# Description: switch AB to XO
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
from sel_block import sel_block  # grc-generated hier_block
import threading







class ABXO(gr.hier_block2):
    def __init__(self, sel=0):
        gr.hier_block2.__init__(
            self, "ABXO_v1",
                gr.io_signature.makev(2, 2, [gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512]),
                gr.io_signature.makev(2, 2, [gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512]),
        )

        ##################################################
        # Parameters
        ##################################################
        self.sel = sel

        ##################################################
        # Blocks
        ##################################################

        self.sel_block_0 = sel_block(
            sel=sel,
        )
        self.blocks_vector_source_x_0 = blocks.vector_source_c([1.0j]*512, True, 512, [])
        self.blocks_sub_xx_0 = blocks.sub_cc(512)
        self.blocks_multiply_xx_0 = blocks.multiply_vcc(512)
        self.blocks_add_xx_0 = blocks.add_vcc(512)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_add_xx_0, 0), (self.sel_block_0, 3))
        self.connect((self.blocks_multiply_xx_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.blocks_multiply_xx_0, 0), (self.blocks_sub_xx_0, 1))
        self.connect((self.blocks_sub_xx_0, 0), (self.sel_block_0, 2))
        self.connect((self.blocks_vector_source_x_0, 0), (self.blocks_multiply_xx_0, 1))
        self.connect((self, 0), (self.blocks_multiply_xx_0, 0))
        self.connect((self, 0), (self.sel_block_0, 1))
        self.connect((self, 1), (self.blocks_add_xx_0, 0))
        self.connect((self, 1), (self.blocks_sub_xx_0, 0))
        self.connect((self, 1), (self.sel_block_0, 0))
        self.connect((self.sel_block_0, 1), (self, 0))
        self.connect((self.sel_block_0, 0), (self, 1))


    def get_sel(self):
        return self.sel

    def set_sel(self, sel):
        self.sel = sel
        self.sel_block_0.set_sel(self.sel)

