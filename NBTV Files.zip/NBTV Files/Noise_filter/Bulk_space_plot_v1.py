# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Bulk_space_plot_v1
# Author: PA0SIM
# Description: Adapt Bulk Space for plotting and adding NC setting in plot
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class Bulk_space_plot_v1(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Bulk_space_plot_v1",
                gr.io_signature.makev(2, 2, [gr.sizeof_gr_complex*512, gr.sizeof_gr_complex*512]),
                gr.io_signature.makev(5, 5, [gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1]),
        )

        ##################################################
        # Blocks
        ##################################################

        self.blocks_vector_to_stream_0_0_1 = blocks.vector_to_stream(gr.sizeof_gr_complex*1, 512)
        self.blocks_vector_to_stream_0_0_0 = blocks.vector_to_stream(gr.sizeof_gr_complex*1, 512)
        self.blocks_vector_to_stream_0_0 = blocks.vector_to_stream(gr.sizeof_gr_complex*1, 512)
        self.blocks_vector_source_x_0_1_0_0_0 = blocks.vector_source_f([0, 0, 0, 0, 90, 180, 270, 360]*128, True, 512, [])
        self.blocks_vector_source_x_0_1_0_0 = blocks.vector_source_f([(0)]*512, True, 512, [])
        self.blocks_keep_m_in_n_0_0_0 = blocks.keep_m_in_n(gr.sizeof_gr_complex, 200, 512, 1)
        self.blocks_keep_m_in_n_0_0 = blocks.keep_m_in_n(gr.sizeof_gr_complex, 200, 512, 5)
        self.blocks_float_to_complex_0 = blocks.float_to_complex(512)
        self.blocks_delay_0_0 = blocks.delay(gr.sizeof_gr_complex*1, 512)
        self.blocks_delay_0 = blocks.delay(gr.sizeof_gr_complex*1, 512)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_delay_0, 0), (self.blocks_delay_0_0, 0))
        self.connect((self.blocks_delay_0, 0), (self, 1))
        self.connect((self.blocks_delay_0_0, 0), (self, 2))
        self.connect((self.blocks_float_to_complex_0, 0), (self.blocks_vector_to_stream_0_0_1, 0))
        self.connect((self.blocks_keep_m_in_n_0_0, 0), (self.blocks_delay_0, 0))
        self.connect((self.blocks_keep_m_in_n_0_0, 0), (self, 0))
        self.connect((self.blocks_keep_m_in_n_0_0_0, 0), (self, 3))
        self.connect((self.blocks_vector_source_x_0_1_0_0, 0), (self.blocks_float_to_complex_0, 1))
        self.connect((self.blocks_vector_source_x_0_1_0_0_0, 0), (self.blocks_float_to_complex_0, 0))
        self.connect((self.blocks_vector_to_stream_0_0, 0), (self.blocks_keep_m_in_n_0_0_0, 0))
        self.connect((self.blocks_vector_to_stream_0_0_0, 0), (self.blocks_keep_m_in_n_0_0, 0))
        self.connect((self.blocks_vector_to_stream_0_0_1, 0), (self, 4))
        self.connect((self, 0), (self.blocks_vector_to_stream_0_0, 0))
        self.connect((self, 1), (self.blocks_vector_to_stream_0_0_0, 0))


