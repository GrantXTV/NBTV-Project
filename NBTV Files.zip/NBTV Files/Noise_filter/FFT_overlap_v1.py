# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: FFT_overlap_v1
# Author: PA0SIM
# Description: FFT using times overlap
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import fft
from gnuradio.fft import window
from gnuradio import gr
from gnuradio.filter import firdes
import sys
import signal
import threading







class FFT_overlap_v1(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "FFT_overlap_v1",
                gr.io_signature(1, 1, gr.sizeof_float*1),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*512),
        )

        ##################################################
        # Blocks
        ##################################################

        self.fft_vxx_0 = fft.fft_vfc(512, True, window.hann(512), False, 1)
        self.blocks_stream_to_vector_0 = blocks.stream_to_vector(gr.sizeof_float*1, 512)
        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_float*1, [512,512,512,512])
        self.blocks_delay_0_2 = blocks.delay(gr.sizeof_float*1, 128)
        self.blocks_delay_0_1 = blocks.delay(gr.sizeof_float*1, 128)
        self.blocks_delay_0 = blocks.delay(gr.sizeof_float*1, 128)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_delay_0, 0), (self.blocks_delay_0_1, 0))
        self.connect((self.blocks_delay_0, 0), (self.blocks_stream_mux_0, 1))
        self.connect((self.blocks_delay_0_1, 0), (self.blocks_delay_0_2, 0))
        self.connect((self.blocks_delay_0_1, 0), (self.blocks_stream_mux_0, 2))
        self.connect((self.blocks_delay_0_2, 0), (self.blocks_stream_mux_0, 3))
        self.connect((self.blocks_stream_mux_0, 0), (self.blocks_stream_to_vector_0, 0))
        self.connect((self.blocks_stream_to_vector_0, 0), (self.fft_vxx_0, 0))
        self.connect((self.fft_vxx_0, 0), (self, 0))
        self.connect((self, 0), (self.blocks_delay_0, 0))
        self.connect((self, 0), (self.blocks_stream_mux_0, 0))


