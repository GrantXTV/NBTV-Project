# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: OFDM 200 TX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Mux_50_TX import Mux_50_TX  # grc-generated hier_block
from Mux_50_TX_A import Mux_50_TX_A  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import fft
from gnuradio.fft import window
from gnuradio import gr
from gnuradio.filter import firdes
import signal
import threading







class OFDM_200_TX(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "OFDM 200 TX",
                gr.io_signature.makev(10, 10, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
        )

        ##################################################
        # Blocks
        ##################################################

        self.fft_vxx_0 = fft.fft_vcc(200, False, window.rectangular(200), True, 1)
        self.blocks_vector_to_stream_0 = blocks.vector_to_stream(gr.sizeof_gr_complex*1, 200)
        self.blocks_streams_to_vector_0 = blocks.streams_to_vector(gr.sizeof_gr_complex*1, 200)
        self.Mux_50_TX_A_0_0 = Mux_50_TX_A()
        self.Mux_50_TX_A_0 = Mux_50_TX_A()
        self.Mux_50_TX_0_0_0_0_0_0 = Mux_50_TX()
        self.Mux_50_TX_0_0_0_0_0 = Mux_50_TX()
        self.Mux_50_TX_0_0_0_0 = Mux_50_TX()
        self.Mux_50_TX_0_0_0 = Mux_50_TX()
        self.Mux_50_TX_0_0 = Mux_50_TX()
        self.Mux_50_TX_0 = Mux_50_TX()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.Mux_50_TX_0, 0), (self.blocks_streams_to_vector_0, 3))
        self.connect((self.Mux_50_TX_0, 20), (self.blocks_streams_to_vector_0, 5))
        self.connect((self.Mux_50_TX_0, 11), (self.blocks_streams_to_vector_0, 9))
        self.connect((self.Mux_50_TX_0, 18), (self.blocks_streams_to_vector_0, 2))
        self.connect((self.Mux_50_TX_0, 21), (self.blocks_streams_to_vector_0, 21))
        self.connect((self.Mux_50_TX_0, 19), (self.blocks_streams_to_vector_0, 18))
        self.connect((self.Mux_50_TX_0, 23), (self.blocks_streams_to_vector_0, 17))
        self.connect((self.Mux_50_TX_0, 17), (self.blocks_streams_to_vector_0, 8))
        self.connect((self.Mux_50_TX_0, 12), (self.blocks_streams_to_vector_0, 11))
        self.connect((self.Mux_50_TX_0, 14), (self.blocks_streams_to_vector_0, 14))
        self.connect((self.Mux_50_TX_0, 8), (self.blocks_streams_to_vector_0, 22))
        self.connect((self.Mux_50_TX_0, 3), (self.blocks_streams_to_vector_0, 23))
        self.connect((self.Mux_50_TX_0, 22), (self.blocks_streams_to_vector_0, 19))
        self.connect((self.Mux_50_TX_0, 9), (self.blocks_streams_to_vector_0, 12))
        self.connect((self.Mux_50_TX_0, 15), (self.blocks_streams_to_vector_0, 16))
        self.connect((self.Mux_50_TX_0, 24), (self.blocks_streams_to_vector_0, 15))
        self.connect((self.Mux_50_TX_0, 16), (self.blocks_streams_to_vector_0, 13))
        self.connect((self.Mux_50_TX_0, 10), (self.blocks_streams_to_vector_0, 0))
        self.connect((self.Mux_50_TX_0, 4), (self.blocks_streams_to_vector_0, 24))
        self.connect((self.Mux_50_TX_0, 7), (self.blocks_streams_to_vector_0, 6))
        self.connect((self.Mux_50_TX_0, 13), (self.blocks_streams_to_vector_0, 4))
        self.connect((self.Mux_50_TX_0, 1), (self.blocks_streams_to_vector_0, 7))
        self.connect((self.Mux_50_TX_0, 2), (self.blocks_streams_to_vector_0, 10))
        self.connect((self.Mux_50_TX_0, 5), (self.blocks_streams_to_vector_0, 1))
        self.connect((self.Mux_50_TX_0, 6), (self.blocks_streams_to_vector_0, 20))
        self.connect((self.Mux_50_TX_0_0, 24), (self.blocks_streams_to_vector_0, 40))
        self.connect((self.Mux_50_TX_0_0, 12), (self.blocks_streams_to_vector_0, 36))
        self.connect((self.Mux_50_TX_0_0, 11), (self.blocks_streams_to_vector_0, 34))
        self.connect((self.Mux_50_TX_0_0, 6), (self.blocks_streams_to_vector_0, 45))
        self.connect((self.Mux_50_TX_0_0, 18), (self.blocks_streams_to_vector_0, 27))
        self.connect((self.Mux_50_TX_0_0, 17), (self.blocks_streams_to_vector_0, 33))
        self.connect((self.Mux_50_TX_0_0, 23), (self.blocks_streams_to_vector_0, 42))
        self.connect((self.Mux_50_TX_0_0, 1), (self.blocks_streams_to_vector_0, 32))
        self.connect((self.Mux_50_TX_0_0, 15), (self.blocks_streams_to_vector_0, 41))
        self.connect((self.Mux_50_TX_0_0, 21), (self.blocks_streams_to_vector_0, 46))
        self.connect((self.Mux_50_TX_0_0, 14), (self.blocks_streams_to_vector_0, 39))
        self.connect((self.Mux_50_TX_0_0, 20), (self.blocks_streams_to_vector_0, 30))
        self.connect((self.Mux_50_TX_0_0, 2), (self.blocks_streams_to_vector_0, 35))
        self.connect((self.Mux_50_TX_0_0, 22), (self.blocks_streams_to_vector_0, 44))
        self.connect((self.Mux_50_TX_0_0, 4), (self.blocks_streams_to_vector_0, 49))
        self.connect((self.Mux_50_TX_0_0, 10), (self.blocks_streams_to_vector_0, 25))
        self.connect((self.Mux_50_TX_0_0, 9), (self.blocks_streams_to_vector_0, 37))
        self.connect((self.Mux_50_TX_0_0, 13), (self.blocks_streams_to_vector_0, 29))
        self.connect((self.Mux_50_TX_0_0, 16), (self.blocks_streams_to_vector_0, 38))
        self.connect((self.Mux_50_TX_0_0, 3), (self.blocks_streams_to_vector_0, 48))
        self.connect((self.Mux_50_TX_0_0, 5), (self.blocks_streams_to_vector_0, 26))
        self.connect((self.Mux_50_TX_0_0, 0), (self.blocks_streams_to_vector_0, 28))
        self.connect((self.Mux_50_TX_0_0, 19), (self.blocks_streams_to_vector_0, 43))
        self.connect((self.Mux_50_TX_0_0, 8), (self.blocks_streams_to_vector_0, 47))
        self.connect((self.Mux_50_TX_0_0, 7), (self.blocks_streams_to_vector_0, 31))
        self.connect((self.Mux_50_TX_0_0_0, 9), (self.blocks_streams_to_vector_0, 62))
        self.connect((self.Mux_50_TX_0_0_0, 16), (self.blocks_streams_to_vector_0, 63))
        self.connect((self.Mux_50_TX_0_0_0, 11), (self.blocks_streams_to_vector_0, 59))
        self.connect((self.Mux_50_TX_0_0_0, 8), (self.blocks_streams_to_vector_0, 72))
        self.connect((self.Mux_50_TX_0_0_0, 7), (self.blocks_streams_to_vector_0, 56))
        self.connect((self.Mux_50_TX_0_0_0, 18), (self.blocks_streams_to_vector_0, 52))
        self.connect((self.Mux_50_TX_0_0_0, 14), (self.blocks_streams_to_vector_0, 64))
        self.connect((self.Mux_50_TX_0_0_0, 10), (self.blocks_streams_to_vector_0, 50))
        self.connect((self.Mux_50_TX_0_0_0, 15), (self.blocks_streams_to_vector_0, 66))
        self.connect((self.Mux_50_TX_0_0_0, 19), (self.blocks_streams_to_vector_0, 68))
        self.connect((self.Mux_50_TX_0_0_0, 21), (self.blocks_streams_to_vector_0, 71))
        self.connect((self.Mux_50_TX_0_0_0, 17), (self.blocks_streams_to_vector_0, 58))
        self.connect((self.Mux_50_TX_0_0_0, 3), (self.blocks_streams_to_vector_0, 73))
        self.connect((self.Mux_50_TX_0_0_0, 5), (self.blocks_streams_to_vector_0, 51))
        self.connect((self.Mux_50_TX_0_0_0, 0), (self.blocks_streams_to_vector_0, 53))
        self.connect((self.Mux_50_TX_0_0_0, 4), (self.blocks_streams_to_vector_0, 74))
        self.connect((self.Mux_50_TX_0_0_0, 6), (self.blocks_streams_to_vector_0, 70))
        self.connect((self.Mux_50_TX_0_0_0, 1), (self.blocks_streams_to_vector_0, 57))
        self.connect((self.Mux_50_TX_0_0_0, 22), (self.blocks_streams_to_vector_0, 69))
        self.connect((self.Mux_50_TX_0_0_0, 20), (self.blocks_streams_to_vector_0, 55))
        self.connect((self.Mux_50_TX_0_0_0, 24), (self.blocks_streams_to_vector_0, 65))
        self.connect((self.Mux_50_TX_0_0_0, 12), (self.blocks_streams_to_vector_0, 61))
        self.connect((self.Mux_50_TX_0_0_0, 13), (self.blocks_streams_to_vector_0, 54))
        self.connect((self.Mux_50_TX_0_0_0, 2), (self.blocks_streams_to_vector_0, 60))
        self.connect((self.Mux_50_TX_0_0_0, 23), (self.blocks_streams_to_vector_0, 67))
        self.connect((self.Mux_50_TX_0_0_0_0, 7), (self.blocks_streams_to_vector_0, 81))
        self.connect((self.Mux_50_TX_0_0_0_0, 24), (self.blocks_streams_to_vector_0, 90))
        self.connect((self.Mux_50_TX_0_0_0_0, 8), (self.blocks_streams_to_vector_0, 97))
        self.connect((self.Mux_50_TX_0_0_0_0, 17), (self.blocks_streams_to_vector_0, 83))
        self.connect((self.Mux_50_TX_0_0_0_0, 21), (self.blocks_streams_to_vector_0, 96))
        self.connect((self.Mux_50_TX_0_0_0_0, 12), (self.blocks_streams_to_vector_0, 86))
        self.connect((self.Mux_50_TX_0_0_0_0, 15), (self.blocks_streams_to_vector_0, 91))
        self.connect((self.Mux_50_TX_0_0_0_0, 6), (self.blocks_streams_to_vector_0, 95))
        self.connect((self.Mux_50_TX_0_0_0_0, 20), (self.blocks_streams_to_vector_0, 80))
        self.connect((self.Mux_50_TX_0_0_0_0, 3), (self.blocks_streams_to_vector_0, 98))
        self.connect((self.Mux_50_TX_0_0_0_0, 18), (self.blocks_streams_to_vector_0, 77))
        self.connect((self.Mux_50_TX_0_0_0_0, 11), (self.blocks_streams_to_vector_0, 84))
        self.connect((self.Mux_50_TX_0_0_0_0, 16), (self.blocks_streams_to_vector_0, 88))
        self.connect((self.Mux_50_TX_0_0_0_0, 14), (self.blocks_streams_to_vector_0, 89))
        self.connect((self.Mux_50_TX_0_0_0_0, 5), (self.blocks_streams_to_vector_0, 76))
        self.connect((self.Mux_50_TX_0_0_0_0, 0), (self.blocks_streams_to_vector_0, 78))
        self.connect((self.Mux_50_TX_0_0_0_0, 13), (self.blocks_streams_to_vector_0, 79))
        self.connect((self.Mux_50_TX_0_0_0_0, 9), (self.blocks_streams_to_vector_0, 87))
        self.connect((self.Mux_50_TX_0_0_0_0, 2), (self.blocks_streams_to_vector_0, 85))
        self.connect((self.Mux_50_TX_0_0_0_0, 23), (self.blocks_streams_to_vector_0, 92))
        self.connect((self.Mux_50_TX_0_0_0_0, 1), (self.blocks_streams_to_vector_0, 82))
        self.connect((self.Mux_50_TX_0_0_0_0, 10), (self.blocks_streams_to_vector_0, 75))
        self.connect((self.Mux_50_TX_0_0_0_0, 4), (self.blocks_streams_to_vector_0, 99))
        self.connect((self.Mux_50_TX_0_0_0_0, 19), (self.blocks_streams_to_vector_0, 93))
        self.connect((self.Mux_50_TX_0_0_0_0, 22), (self.blocks_streams_to_vector_0, 94))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 22), (self.blocks_streams_to_vector_0, 119))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 9), (self.blocks_streams_to_vector_0, 112))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 3), (self.blocks_streams_to_vector_0, 123))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 13), (self.blocks_streams_to_vector_0, 104))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 5), (self.blocks_streams_to_vector_0, 101))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 6), (self.blocks_streams_to_vector_0, 120))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 4), (self.blocks_streams_to_vector_0, 124))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 11), (self.blocks_streams_to_vector_0, 109))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 24), (self.blocks_streams_to_vector_0, 115))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 8), (self.blocks_streams_to_vector_0, 122))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 15), (self.blocks_streams_to_vector_0, 116))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 16), (self.blocks_streams_to_vector_0, 113))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 18), (self.blocks_streams_to_vector_0, 102))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 20), (self.blocks_streams_to_vector_0, 105))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 23), (self.blocks_streams_to_vector_0, 117))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 0), (self.blocks_streams_to_vector_0, 103))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 17), (self.blocks_streams_to_vector_0, 108))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 14), (self.blocks_streams_to_vector_0, 114))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 7), (self.blocks_streams_to_vector_0, 106))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 12), (self.blocks_streams_to_vector_0, 111))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 1), (self.blocks_streams_to_vector_0, 107))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 2), (self.blocks_streams_to_vector_0, 110))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 19), (self.blocks_streams_to_vector_0, 118))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 21), (self.blocks_streams_to_vector_0, 121))
        self.connect((self.Mux_50_TX_0_0_0_0_0, 10), (self.blocks_streams_to_vector_0, 100))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 2), (self.blocks_streams_to_vector_0, 135))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 12), (self.blocks_streams_to_vector_0, 136))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 5), (self.blocks_streams_to_vector_0, 126))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 11), (self.blocks_streams_to_vector_0, 134))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 22), (self.blocks_streams_to_vector_0, 144))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 7), (self.blocks_streams_to_vector_0, 131))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 1), (self.blocks_streams_to_vector_0, 132))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 10), (self.blocks_streams_to_vector_0, 125))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 20), (self.blocks_streams_to_vector_0, 130))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 18), (self.blocks_streams_to_vector_0, 127))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 4), (self.blocks_streams_to_vector_0, 149))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 3), (self.blocks_streams_to_vector_0, 148))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 0), (self.blocks_streams_to_vector_0, 128))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 8), (self.blocks_streams_to_vector_0, 147))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 16), (self.blocks_streams_to_vector_0, 138))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 14), (self.blocks_streams_to_vector_0, 139))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 9), (self.blocks_streams_to_vector_0, 137))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 21), (self.blocks_streams_to_vector_0, 146))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 23), (self.blocks_streams_to_vector_0, 142))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 17), (self.blocks_streams_to_vector_0, 133))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 6), (self.blocks_streams_to_vector_0, 145))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 13), (self.blocks_streams_to_vector_0, 129))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 19), (self.blocks_streams_to_vector_0, 143))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 15), (self.blocks_streams_to_vector_0, 141))
        self.connect((self.Mux_50_TX_0_0_0_0_0_0, 24), (self.blocks_streams_to_vector_0, 140))
        self.connect((self.Mux_50_TX_A_0, 18), (self.blocks_streams_to_vector_0, 152))
        self.connect((self.Mux_50_TX_A_0, 4), (self.blocks_streams_to_vector_0, 174))
        self.connect((self.Mux_50_TX_A_0, 2), (self.blocks_streams_to_vector_0, 160))
        self.connect((self.Mux_50_TX_A_0, 24), (self.blocks_streams_to_vector_0, 165))
        self.connect((self.Mux_50_TX_A_0, 8), (self.blocks_streams_to_vector_0, 172))
        self.connect((self.Mux_50_TX_A_0, 0), (self.blocks_streams_to_vector_0, 153))
        self.connect((self.Mux_50_TX_A_0, 12), (self.blocks_streams_to_vector_0, 161))
        self.connect((self.Mux_50_TX_A_0, 6), (self.blocks_streams_to_vector_0, 170))
        self.connect((self.Mux_50_TX_A_0, 21), (self.blocks_streams_to_vector_0, 171))
        self.connect((self.Mux_50_TX_A_0, 3), (self.blocks_streams_to_vector_0, 173))
        self.connect((self.Mux_50_TX_A_0, 15), (self.blocks_streams_to_vector_0, 166))
        self.connect((self.Mux_50_TX_A_0, 1), (self.blocks_streams_to_vector_0, 157))
        self.connect((self.Mux_50_TX_A_0, 20), (self.blocks_streams_to_vector_0, 155))
        self.connect((self.Mux_50_TX_A_0, 23), (self.blocks_streams_to_vector_0, 167))
        self.connect((self.Mux_50_TX_A_0, 19), (self.blocks_streams_to_vector_0, 168))
        self.connect((self.Mux_50_TX_A_0, 16), (self.blocks_streams_to_vector_0, 163))
        self.connect((self.Mux_50_TX_A_0, 14), (self.blocks_streams_to_vector_0, 164))
        self.connect((self.Mux_50_TX_A_0, 10), (self.blocks_streams_to_vector_0, 150))
        self.connect((self.Mux_50_TX_A_0, 13), (self.blocks_streams_to_vector_0, 154))
        self.connect((self.Mux_50_TX_A_0, 17), (self.blocks_streams_to_vector_0, 158))
        self.connect((self.Mux_50_TX_A_0, 9), (self.blocks_streams_to_vector_0, 162))
        self.connect((self.Mux_50_TX_A_0, 7), (self.blocks_streams_to_vector_0, 156))
        self.connect((self.Mux_50_TX_A_0, 22), (self.blocks_streams_to_vector_0, 169))
        self.connect((self.Mux_50_TX_A_0, 5), (self.blocks_streams_to_vector_0, 151))
        self.connect((self.Mux_50_TX_A_0, 11), (self.blocks_streams_to_vector_0, 159))
        self.connect((self.Mux_50_TX_A_0_0, 12), (self.blocks_streams_to_vector_0, 186))
        self.connect((self.Mux_50_TX_A_0_0, 8), (self.blocks_streams_to_vector_0, 197))
        self.connect((self.Mux_50_TX_A_0_0, 0), (self.blocks_streams_to_vector_0, 178))
        self.connect((self.Mux_50_TX_A_0_0, 5), (self.blocks_streams_to_vector_0, 176))
        self.connect((self.Mux_50_TX_A_0_0, 10), (self.blocks_streams_to_vector_0, 175))
        self.connect((self.Mux_50_TX_A_0_0, 7), (self.blocks_streams_to_vector_0, 181))
        self.connect((self.Mux_50_TX_A_0_0, 4), (self.blocks_streams_to_vector_0, 199))
        self.connect((self.Mux_50_TX_A_0_0, 19), (self.blocks_streams_to_vector_0, 193))
        self.connect((self.Mux_50_TX_A_0_0, 22), (self.blocks_streams_to_vector_0, 194))
        self.connect((self.Mux_50_TX_A_0_0, 23), (self.blocks_streams_to_vector_0, 192))
        self.connect((self.Mux_50_TX_A_0_0, 9), (self.blocks_streams_to_vector_0, 187))
        self.connect((self.Mux_50_TX_A_0_0, 6), (self.blocks_streams_to_vector_0, 195))
        self.connect((self.Mux_50_TX_A_0_0, 17), (self.blocks_streams_to_vector_0, 183))
        self.connect((self.Mux_50_TX_A_0_0, 21), (self.blocks_streams_to_vector_0, 196))
        self.connect((self.Mux_50_TX_A_0_0, 3), (self.blocks_streams_to_vector_0, 198))
        self.connect((self.Mux_50_TX_A_0_0, 24), (self.blocks_streams_to_vector_0, 190))
        self.connect((self.Mux_50_TX_A_0_0, 2), (self.blocks_streams_to_vector_0, 185))
        self.connect((self.Mux_50_TX_A_0_0, 1), (self.blocks_streams_to_vector_0, 182))
        self.connect((self.Mux_50_TX_A_0_0, 11), (self.blocks_streams_to_vector_0, 184))
        self.connect((self.Mux_50_TX_A_0_0, 14), (self.blocks_streams_to_vector_0, 189))
        self.connect((self.Mux_50_TX_A_0_0, 15), (self.blocks_streams_to_vector_0, 191))
        self.connect((self.Mux_50_TX_A_0_0, 18), (self.blocks_streams_to_vector_0, 177))
        self.connect((self.Mux_50_TX_A_0_0, 20), (self.blocks_streams_to_vector_0, 180))
        self.connect((self.Mux_50_TX_A_0_0, 13), (self.blocks_streams_to_vector_0, 179))
        self.connect((self.Mux_50_TX_A_0_0, 16), (self.blocks_streams_to_vector_0, 188))
        self.connect((self.blocks_streams_to_vector_0, 0), (self.fft_vxx_0, 0))
        self.connect((self.blocks_vector_to_stream_0, 0), (self, 0))
        self.connect((self.fft_vxx_0, 0), (self.blocks_vector_to_stream_0, 0))
        self.connect((self, 0), (self.Mux_50_TX_0, 0))
        self.connect((self, 1), (self.Mux_50_TX_0, 1))
        self.connect((self, 1), (self.Mux_50_TX_0_0, 2))
        self.connect((self, 1), (self.Mux_50_TX_0_0_0, 1))
        self.connect((self, 1), (self.Mux_50_TX_0_0_0_0, 2))
        self.connect((self, 1), (self.Mux_50_TX_0_0_0_0_0, 1))
        self.connect((self, 1), (self.Mux_50_TX_0_0_0_0_0_0, 2))
        self.connect((self, 1), (self.Mux_50_TX_A_0, 1))
        self.connect((self, 1), (self.Mux_50_TX_A_0_0, 2))
        self.connect((self, 2), (self.Mux_50_TX_0, 2))
        self.connect((self, 2), (self.Mux_50_TX_0_0, 1))
        self.connect((self, 2), (self.Mux_50_TX_0_0_0, 2))
        self.connect((self, 2), (self.Mux_50_TX_0_0_0_0, 1))
        self.connect((self, 2), (self.Mux_50_TX_0_0_0_0_0, 2))
        self.connect((self, 2), (self.Mux_50_TX_0_0_0_0_0_0, 1))
        self.connect((self, 2), (self.Mux_50_TX_A_0, 2))
        self.connect((self, 2), (self.Mux_50_TX_A_0_0, 1))
        self.connect((self, 3), (self.Mux_50_TX_0_0, 0))
        self.connect((self, 4), (self.Mux_50_TX_0_0_0, 0))
        self.connect((self, 5), (self.Mux_50_TX_0_0_0_0, 0))
        self.connect((self, 6), (self.Mux_50_TX_0_0_0_0_0, 0))
        self.connect((self, 7), (self.Mux_50_TX_0_0_0_0_0_0, 0))
        self.connect((self, 8), (self.Mux_50_TX_A_0, 0))
        self.connect((self, 9), (self.Mux_50_TX_A_0_0, 0))


