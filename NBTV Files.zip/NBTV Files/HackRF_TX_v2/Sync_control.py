# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Sync control
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class Sync_control(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Sync control",
                gr.io_signature(1, 1, gr.sizeof_char*1),
                gr.io_signature.makev(2, 2, [gr.sizeof_char*1, gr.sizeof_char*1]),
        )

        ##################################################
        # Blocks
        ##################################################

        self.blocks_uchar_to_float_0_1_0_0 = blocks.uchar_to_float()
        self.blocks_stream_demux_0_0_0_0 = blocks.stream_demux(gr.sizeof_float*1, (720,720,720))
        self.blocks_stream_demux_0_0_0 = blocks.stream_demux(gr.sizeof_float*1, (720,720,720))
        self.blocks_stream_demux_0_0 = blocks.stream_demux(gr.sizeof_float*1, (720,720))
        self.blocks_multiply_const_vxx_0_1_0 = blocks.multiply_const_ff((1/3))
        self.blocks_multiply_const_vxx_0_1 = blocks.multiply_const_ff((1/3))
        self.blocks_float_to_uchar_0_1_0_1_0_1 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_float_to_uchar_0_1_0_1_0 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_add_xx_0_0 = blocks.add_vff(1)
        self.blocks_add_xx_0 = blocks.add_vff(1)
        self.blocks_add_const_vxx_0_0 = blocks.add_const_ff((-128))
        self.blocks_add_const_vxx_0 = blocks.add_const_ff((-128))


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_add_const_vxx_0, 0), (self.blocks_stream_demux_0_0_0, 0))
        self.connect((self.blocks_add_const_vxx_0_0, 0), (self.blocks_stream_demux_0_0_0_0, 0))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_multiply_const_vxx_0_1_0, 0))
        self.connect((self.blocks_add_xx_0_0, 0), (self.blocks_multiply_const_vxx_0_1, 0))
        self.connect((self.blocks_float_to_uchar_0_1_0_1_0, 0), (self, 0))
        self.connect((self.blocks_float_to_uchar_0_1_0_1_0_1, 0), (self, 1))
        self.connect((self.blocks_multiply_const_vxx_0_1, 0), (self.blocks_float_to_uchar_0_1_0_1_0_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0_1_0, 0), (self.blocks_float_to_uchar_0_1_0_1_0, 0))
        self.connect((self.blocks_stream_demux_0_0, 0), (self.blocks_add_const_vxx_0, 0))
        self.connect((self.blocks_stream_demux_0_0, 1), (self.blocks_add_const_vxx_0_0, 0))
        self.connect((self.blocks_stream_demux_0_0_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.blocks_stream_demux_0_0_0, 2), (self.blocks_add_xx_0, 2))
        self.connect((self.blocks_stream_demux_0_0_0, 1), (self.blocks_add_xx_0, 1))
        self.connect((self.blocks_stream_demux_0_0_0_0, 1), (self.blocks_add_xx_0_0, 1))
        self.connect((self.blocks_stream_demux_0_0_0_0, 2), (self.blocks_add_xx_0_0, 2))
        self.connect((self.blocks_stream_demux_0_0_0_0, 0), (self.blocks_add_xx_0_0, 0))
        self.connect((self.blocks_uchar_to_float_0_1_0_0, 0), (self.blocks_stream_demux_0_0, 0))
        self.connect((self, 0), (self.blocks_uchar_to_float_0_1_0_0, 0))


