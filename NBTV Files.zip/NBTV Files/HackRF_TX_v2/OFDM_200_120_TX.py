# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: OFDM 200 120 TX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Audio_TX_Set import Audio_TX_Set  # grc-generated hier_block
from OFDM_200_TX_R import OFDM_200_TX_R  # grc-generated hier_block
from Sync_control import Sync_control  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
import threading







class OFDM_200_120_TX(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "OFDM 200 120 TX",
                gr.io_signature.makev(3, 3, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
        )

        ##################################################
        # Variables
        ##################################################
        self.DB = DB = 5760

        ##################################################
        # Blocks
        ##################################################

        self.blocks_stream_demux_0 = blocks.stream_demux(gr.sizeof_char*1, (DB,DB,DB,DB,DB,DB))
        self.Sync_control_0 = Sync_control()
        self.OFDM_200_TX_R_0 = OFDM_200_TX_R()
        self.Audio_TX_Set_0 = Audio_TX_Set()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.Audio_TX_Set_0, 1), (self.OFDM_200_TX_R_0, 9))
        self.connect((self.Audio_TX_Set_0, 0), (self.OFDM_200_TX_R_0, 0))
        self.connect((self.OFDM_200_TX_R_0, 0), (self, 0))
        self.connect((self.Sync_control_0, 1), (self.OFDM_200_TX_R_0, 2))
        self.connect((self.Sync_control_0, 0), (self.OFDM_200_TX_R_0, 1))
        self.connect((self.blocks_stream_demux_0, 0), (self.OFDM_200_TX_R_0, 5))
        self.connect((self.blocks_stream_demux_0, 2), (self.OFDM_200_TX_R_0, 7))
        self.connect((self.blocks_stream_demux_0, 5), (self.OFDM_200_TX_R_0, 6))
        self.connect((self.blocks_stream_demux_0, 4), (self.OFDM_200_TX_R_0, 4))
        self.connect((self.blocks_stream_demux_0, 1), (self.OFDM_200_TX_R_0, 3))
        self.connect((self.blocks_stream_demux_0, 3), (self.OFDM_200_TX_R_0, 8))
        self.connect((self, 0), (self.blocks_stream_demux_0, 0))
        self.connect((self, 1), (self.Audio_TX_Set_0, 0))
        self.connect((self, 2), (self.Sync_control_0, 0))


    def get_DB(self):
        return self.DB

    def set_DB(self, DB):
        self.DB = DB

