#!/bin/bash
./HackRF_TX_v2/HackRF_TX_v2.py
