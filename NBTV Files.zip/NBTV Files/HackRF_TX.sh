#!/bin/bash
./HackRF_TX/HackRF_TX.py
