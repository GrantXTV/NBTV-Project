#!/bin/bash
./OFDM_Loopback_v2_180/OFDM_Loopback_v2_180.py
