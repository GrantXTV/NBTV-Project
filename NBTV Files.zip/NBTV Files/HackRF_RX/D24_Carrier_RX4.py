# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: D24 Carrier RX4
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from QAM_Demod import QAM_Demod  # grc-generated hier_block
from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import signal
import threading







class D24_Carrier_RX4(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "D24 Carrier RX4",
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
                gr.io_signature(1, 1, gr.sizeof_char*1),
        )
        self.message_port_register_hier_in("Din")

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 384000
        self.T_set_0 = T_set_0 = 1
        self.T_set = T_set = 4
        self.Scale_N = Scale_N = 32
        self.Scale = Scale = 768
        self.Level = Level = 8.1
        self.H_rate = H_rate = 32000
        self.Freq = Freq = 500
        self.Filter = Filter = 225
        self.Delay = Delay = 0
        self.DB = DB = 48
        self.Cut_off = Cut_off = 250
        self.Beta = Beta = 6

        ##################################################
        # Blocks
        ##################################################

        self.rational_resampler_xxx_0_2_0_0_0_2_8 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_7 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_6 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_5 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_4 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_3 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_2 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_1 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2_0 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_2 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_1 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_8 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_7 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_6 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_5 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_4 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_3 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_2 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_1 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1_0 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_1 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0_0 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0 = filter.rational_resampler_ccc(
                interpolation=1,
                decimation=Scale,
                taps=[T_set],
                fractional_bw=0)
        self.low_pass_filter_0_23_2_8 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_7 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_6 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_5 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_4 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_3 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_2 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_1 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2_0 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_2 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_1 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_8 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_7 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_6 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_5 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_4 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_3 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_2 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_1 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1_0 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_1 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0_0 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23_0 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.low_pass_filter_0_23 = filter.fir_filter_ccf(
            1,
            firdes.low_pass(
                Level,
                samp_rate,
                Filter,
                Cut_off,
                window.WIN_HANN,
                Beta))
        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_char*1, (DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(24)
        self.blocks_divide_xx_0_1_5 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_4 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_3 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_2 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_1 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_0_3 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_0_2 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_0_1 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_0_0 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1_0 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_1 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_5 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_4 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_3 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_2 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_1 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_0_3 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_0_2 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_0_1 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_0_0 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0_0 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0_0 = blocks.divide_cc(1)
        self.blocks_divide_xx_0_0 = blocks.divide_cc(1)
        self.blocks_divide_xx_0 = blocks.divide_cc(1)
        self.blocks_delay_0 = blocks.delay(gr.sizeof_gr_complex*1, Delay)
        self.analog_sig_source_x_0_0_0_0_1_5 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*95), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_4 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*91), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*87), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*83), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*79), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*93), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*89), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*85), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*81), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*77), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*75), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_5 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*96), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_4 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*92), 1, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*88), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*84), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*80), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*94), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*90), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*86), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*82), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*78), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*76), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*74), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*73), T_set_0, 0, 0)
        self.QAM_Demod_0_6 = QAM_Demod()
        self.QAM_Demod_0_5 = QAM_Demod()
        self.QAM_Demod_0_4 = QAM_Demod()
        self.QAM_Demod_0_3 = QAM_Demod()
        self.QAM_Demod_0_2 = QAM_Demod()
        self.QAM_Demod_0_1_4 = QAM_Demod()
        self.QAM_Demod_0_1_3 = QAM_Demod()
        self.QAM_Demod_0_1_2 = QAM_Demod()
        self.QAM_Demod_0_1_1 = QAM_Demod()
        self.QAM_Demod_0_1_0 = QAM_Demod()
        self.QAM_Demod_0_1 = QAM_Demod()
        self.QAM_Demod_0_0_6 = QAM_Demod()
        self.QAM_Demod_0_0_5 = QAM_Demod()
        self.QAM_Demod_0_0_4 = QAM_Demod()
        self.QAM_Demod_0_0_3 = QAM_Demod()
        self.QAM_Demod_0_0_2 = QAM_Demod()
        self.QAM_Demod_0_0_1 = QAM_Demod()
        self.QAM_Demod_0_0_0_4 = QAM_Demod()
        self.QAM_Demod_0_0_0_3 = QAM_Demod()
        self.QAM_Demod_0_0_0_2 = QAM_Demod()
        self.QAM_Demod_0_0_0_1 = QAM_Demod()
        self.QAM_Demod_0_0_0_0 = QAM_Demod()
        self.QAM_Demod_0_0_0 = QAM_Demod()
        self.QAM_Demod_0_0 = QAM_Demod()


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self, 'Din'), (self.blocks_delay_0, 'dly'))
        self.connect((self.QAM_Demod_0_0, 1), (self.blocks_stream_mux_0, 3))
        self.connect((self.QAM_Demod_0_0, 0), (self.blocks_stream_mux_0, 2))
        self.connect((self.QAM_Demod_0_0_0, 1), (self.blocks_stream_mux_0, 7))
        self.connect((self.QAM_Demod_0_0_0, 0), (self.blocks_stream_mux_0, 6))
        self.connect((self.QAM_Demod_0_0_0_0, 0), (self.blocks_stream_mux_0, 14))
        self.connect((self.QAM_Demod_0_0_0_0, 1), (self.blocks_stream_mux_0, 15))
        self.connect((self.QAM_Demod_0_0_0_1, 0), (self.blocks_stream_mux_0, 22))
        self.connect((self.QAM_Demod_0_0_0_1, 1), (self.blocks_stream_mux_0, 23))
        self.connect((self.QAM_Demod_0_0_0_2, 0), (self.blocks_stream_mux_0, 30))
        self.connect((self.QAM_Demod_0_0_0_2, 1), (self.blocks_stream_mux_0, 31))
        self.connect((self.QAM_Demod_0_0_0_3, 1), (self.blocks_stream_mux_0, 39))
        self.connect((self.QAM_Demod_0_0_0_3, 0), (self.blocks_stream_mux_0, 38))
        self.connect((self.QAM_Demod_0_0_0_4, 1), (self.blocks_stream_mux_0, 47))
        self.connect((self.QAM_Demod_0_0_0_4, 0), (self.blocks_stream_mux_0, 46))
        self.connect((self.QAM_Demod_0_0_1, 0), (self.blocks_stream_mux_0, 10))
        self.connect((self.QAM_Demod_0_0_1, 1), (self.blocks_stream_mux_0, 11))
        self.connect((self.QAM_Demod_0_0_2, 1), (self.blocks_stream_mux_0, 19))
        self.connect((self.QAM_Demod_0_0_2, 0), (self.blocks_stream_mux_0, 18))
        self.connect((self.QAM_Demod_0_0_3, 0), (self.blocks_stream_mux_0, 26))
        self.connect((self.QAM_Demod_0_0_3, 1), (self.blocks_stream_mux_0, 27))
        self.connect((self.QAM_Demod_0_0_4, 0), (self.blocks_stream_mux_0, 34))
        self.connect((self.QAM_Demod_0_0_4, 1), (self.blocks_stream_mux_0, 35))
        self.connect((self.QAM_Demod_0_0_5, 0), (self.blocks_stream_mux_0, 42))
        self.connect((self.QAM_Demod_0_0_5, 1), (self.blocks_stream_mux_0, 43))
        self.connect((self.QAM_Demod_0_0_6, 0), (self.blocks_stream_mux_0, 1))
        self.connect((self.QAM_Demod_0_0_6, 1), (self.blocks_stream_mux_0, 0))
        self.connect((self.QAM_Demod_0_1, 0), (self.blocks_stream_mux_0, 5))
        self.connect((self.QAM_Demod_0_1, 1), (self.blocks_stream_mux_0, 4))
        self.connect((self.QAM_Demod_0_1_0, 1), (self.blocks_stream_mux_0, 12))
        self.connect((self.QAM_Demod_0_1_0, 0), (self.blocks_stream_mux_0, 13))
        self.connect((self.QAM_Demod_0_1_1, 1), (self.blocks_stream_mux_0, 20))
        self.connect((self.QAM_Demod_0_1_1, 0), (self.blocks_stream_mux_0, 21))
        self.connect((self.QAM_Demod_0_1_2, 1), (self.blocks_stream_mux_0, 28))
        self.connect((self.QAM_Demod_0_1_2, 0), (self.blocks_stream_mux_0, 29))
        self.connect((self.QAM_Demod_0_1_3, 0), (self.blocks_stream_mux_0, 37))
        self.connect((self.QAM_Demod_0_1_3, 1), (self.blocks_stream_mux_0, 36))
        self.connect((self.QAM_Demod_0_1_4, 1), (self.blocks_stream_mux_0, 44))
        self.connect((self.QAM_Demod_0_1_4, 0), (self.blocks_stream_mux_0, 45))
        self.connect((self.QAM_Demod_0_2, 0), (self.blocks_stream_mux_0, 9))
        self.connect((self.QAM_Demod_0_2, 1), (self.blocks_stream_mux_0, 8))
        self.connect((self.QAM_Demod_0_3, 0), (self.blocks_stream_mux_0, 17))
        self.connect((self.QAM_Demod_0_3, 1), (self.blocks_stream_mux_0, 16))
        self.connect((self.QAM_Demod_0_4, 1), (self.blocks_stream_mux_0, 24))
        self.connect((self.QAM_Demod_0_4, 0), (self.blocks_stream_mux_0, 25))
        self.connect((self.QAM_Demod_0_5, 0), (self.blocks_stream_mux_0, 33))
        self.connect((self.QAM_Demod_0_5, 1), (self.blocks_stream_mux_0, 32))
        self.connect((self.QAM_Demod_0_6, 1), (self.blocks_stream_mux_0, 40))
        self.connect((self.QAM_Demod_0_6, 0), (self.blocks_stream_mux_0, 41))
        self.connect((self.analog_sig_source_x_0_0_0_0, 0), (self.blocks_divide_xx_0, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0, 0), (self.blocks_divide_xx_0_0, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0, 0), (self.blocks_divide_xx_0_0_0, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0, 0), (self.blocks_divide_xx_0_0_0_0, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_0, 0), (self.blocks_divide_xx_0_0_0_0_0, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_1, 0), (self.blocks_divide_xx_0_0_0_0_1, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_2, 0), (self.blocks_divide_xx_0_0_0_0_2, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_3, 0), (self.blocks_divide_xx_0_0_0_0_3, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_1, 0), (self.blocks_divide_xx_0_0_0_1, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_2, 0), (self.blocks_divide_xx_0_0_0_2, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_3, 0), (self.blocks_divide_xx_0_0_0_3, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_4, 0), (self.blocks_divide_xx_0_0_0_4, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_5, 0), (self.blocks_divide_xx_0_0_0_5, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1, 0), (self.blocks_divide_xx_0_1, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0, 0), (self.blocks_divide_xx_0_1_0, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_0, 0), (self.blocks_divide_xx_0_1_0_0, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_1, 0), (self.blocks_divide_xx_0_1_0_1, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_2, 0), (self.blocks_divide_xx_0_1_0_2, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_3, 0), (self.blocks_divide_xx_0_1_0_3, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_1, 0), (self.blocks_divide_xx_0_1_1, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_2, 0), (self.blocks_divide_xx_0_1_2, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_3, 0), (self.blocks_divide_xx_0_1_3, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_4, 0), (self.blocks_divide_xx_0_1_4, 1))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_5, 0), (self.blocks_divide_xx_0_1_5, 1))
        self.connect((self.blocks_delay_0, 1), (self.QAM_Demod_0_0, 0))
        self.connect((self.blocks_delay_0, 3), (self.QAM_Demod_0_0_0, 0))
        self.connect((self.blocks_delay_0, 7), (self.QAM_Demod_0_0_0_0, 0))
        self.connect((self.blocks_delay_0, 11), (self.QAM_Demod_0_0_0_1, 0))
        self.connect((self.blocks_delay_0, 15), (self.QAM_Demod_0_0_0_2, 0))
        self.connect((self.blocks_delay_0, 19), (self.QAM_Demod_0_0_0_3, 0))
        self.connect((self.blocks_delay_0, 23), (self.QAM_Demod_0_0_0_4, 0))
        self.connect((self.blocks_delay_0, 5), (self.QAM_Demod_0_0_1, 0))
        self.connect((self.blocks_delay_0, 9), (self.QAM_Demod_0_0_2, 0))
        self.connect((self.blocks_delay_0, 13), (self.QAM_Demod_0_0_3, 0))
        self.connect((self.blocks_delay_0, 17), (self.QAM_Demod_0_0_4, 0))
        self.connect((self.blocks_delay_0, 21), (self.QAM_Demod_0_0_5, 0))
        self.connect((self.blocks_delay_0, 0), (self.QAM_Demod_0_0_6, 0))
        self.connect((self.blocks_delay_0, 2), (self.QAM_Demod_0_1, 0))
        self.connect((self.blocks_delay_0, 6), (self.QAM_Demod_0_1_0, 0))
        self.connect((self.blocks_delay_0, 10), (self.QAM_Demod_0_1_1, 0))
        self.connect((self.blocks_delay_0, 14), (self.QAM_Demod_0_1_2, 0))
        self.connect((self.blocks_delay_0, 18), (self.QAM_Demod_0_1_3, 0))
        self.connect((self.blocks_delay_0, 22), (self.QAM_Demod_0_1_4, 0))
        self.connect((self.blocks_delay_0, 4), (self.QAM_Demod_0_2, 0))
        self.connect((self.blocks_delay_0, 8), (self.QAM_Demod_0_3, 0))
        self.connect((self.blocks_delay_0, 12), (self.QAM_Demod_0_4, 0))
        self.connect((self.blocks_delay_0, 16), (self.QAM_Demod_0_5, 0))
        self.connect((self.blocks_delay_0, 20), (self.QAM_Demod_0_6, 0))
        self.connect((self.blocks_divide_xx_0, 0), (self.low_pass_filter_0_23, 0))
        self.connect((self.blocks_divide_xx_0_0, 0), (self.low_pass_filter_0_23_0, 0))
        self.connect((self.blocks_divide_xx_0_0_0, 0), (self.low_pass_filter_0_23_0_0, 0))
        self.connect((self.blocks_divide_xx_0_0_0_0, 0), (self.low_pass_filter_0_23_0_1, 0))
        self.connect((self.blocks_divide_xx_0_0_0_0_0, 0), (self.low_pass_filter_0_23_0_1_1, 0))
        self.connect((self.blocks_divide_xx_0_0_0_0_1, 0), (self.low_pass_filter_0_23_0_1_3, 0))
        self.connect((self.blocks_divide_xx_0_0_0_0_2, 0), (self.low_pass_filter_0_23_0_1_5, 0))
        self.connect((self.blocks_divide_xx_0_0_0_0_3, 0), (self.low_pass_filter_0_23_0_1_7, 0))
        self.connect((self.blocks_divide_xx_0_0_0_1, 0), (self.low_pass_filter_0_23_0_1_0, 0))
        self.connect((self.blocks_divide_xx_0_0_0_2, 0), (self.low_pass_filter_0_23_0_1_2, 0))
        self.connect((self.blocks_divide_xx_0_0_0_3, 0), (self.low_pass_filter_0_23_0_1_4, 0))
        self.connect((self.blocks_divide_xx_0_0_0_4, 0), (self.low_pass_filter_0_23_0_1_6, 0))
        self.connect((self.blocks_divide_xx_0_0_0_5, 0), (self.low_pass_filter_0_23_0_1_8, 0))
        self.connect((self.blocks_divide_xx_0_1, 0), (self.low_pass_filter_0_23_1, 0))
        self.connect((self.blocks_divide_xx_0_1_0, 0), (self.low_pass_filter_0_23_2, 0))
        self.connect((self.blocks_divide_xx_0_1_0_0, 0), (self.low_pass_filter_0_23_2_1, 0))
        self.connect((self.blocks_divide_xx_0_1_0_1, 0), (self.low_pass_filter_0_23_2_3, 0))
        self.connect((self.blocks_divide_xx_0_1_0_2, 0), (self.low_pass_filter_0_23_2_5, 0))
        self.connect((self.blocks_divide_xx_0_1_0_3, 0), (self.low_pass_filter_0_23_2_7, 0))
        self.connect((self.blocks_divide_xx_0_1_1, 0), (self.low_pass_filter_0_23_2_0, 0))
        self.connect((self.blocks_divide_xx_0_1_2, 0), (self.low_pass_filter_0_23_2_2, 0))
        self.connect((self.blocks_divide_xx_0_1_3, 0), (self.low_pass_filter_0_23_2_4, 0))
        self.connect((self.blocks_divide_xx_0_1_4, 0), (self.low_pass_filter_0_23_2_6, 0))
        self.connect((self.blocks_divide_xx_0_1_5, 0), (self.low_pass_filter_0_23_2_8, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_0_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_0_2, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_0_3, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_2, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_3, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_4, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_0_0_5, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_0_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_0_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_0_2, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_0_3, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_2, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_3, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_4, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_divide_xx_0_1_5, 0))
        self.connect((self.blocks_stream_mux_0, 0), (self, 0))
        self.connect((self.low_pass_filter_0_23, 0), (self.rational_resampler_xxx_0_2_0_0_0, 0))
        self.connect((self.low_pass_filter_0_23_0, 0), (self.rational_resampler_xxx_0_2_0_0_0_0, 0))
        self.connect((self.low_pass_filter_0_23_0_0, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_0, 0))
        self.connect((self.low_pass_filter_0_23_0_1, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1, 0))
        self.connect((self.low_pass_filter_0_23_0_1_0, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_0, 0))
        self.connect((self.low_pass_filter_0_23_0_1_1, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_1, 0))
        self.connect((self.low_pass_filter_0_23_0_1_2, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_2, 0))
        self.connect((self.low_pass_filter_0_23_0_1_3, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_3, 0))
        self.connect((self.low_pass_filter_0_23_0_1_4, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_4, 0))
        self.connect((self.low_pass_filter_0_23_0_1_5, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_5, 0))
        self.connect((self.low_pass_filter_0_23_0_1_6, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_6, 0))
        self.connect((self.low_pass_filter_0_23_0_1_7, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_7, 0))
        self.connect((self.low_pass_filter_0_23_0_1_8, 0), (self.rational_resampler_xxx_0_2_0_0_0_0_1_8, 0))
        self.connect((self.low_pass_filter_0_23_1, 0), (self.rational_resampler_xxx_0_2_0_0_0_1, 0))
        self.connect((self.low_pass_filter_0_23_2, 0), (self.rational_resampler_xxx_0_2_0_0_0_2, 0))
        self.connect((self.low_pass_filter_0_23_2_0, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_0, 0))
        self.connect((self.low_pass_filter_0_23_2_1, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_1, 0))
        self.connect((self.low_pass_filter_0_23_2_2, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_2, 0))
        self.connect((self.low_pass_filter_0_23_2_3, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_3, 0))
        self.connect((self.low_pass_filter_0_23_2_4, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_4, 0))
        self.connect((self.low_pass_filter_0_23_2_5, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_5, 0))
        self.connect((self.low_pass_filter_0_23_2_6, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_6, 0))
        self.connect((self.low_pass_filter_0_23_2_7, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_7, 0))
        self.connect((self.low_pass_filter_0_23_2_8, 0), (self.rational_resampler_xxx_0_2_0_0_0_2_8, 0))
        self.connect((self, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0, 0), (self.blocks_delay_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0, 0), (self.blocks_delay_0, 1))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_0, 0), (self.blocks_delay_0, 3))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1, 0), (self.blocks_delay_0, 5))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_0, 0), (self.blocks_delay_0, 7))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_1, 0), (self.blocks_delay_0, 9))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_2, 0), (self.blocks_delay_0, 11))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_3, 0), (self.blocks_delay_0, 13))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_4, 0), (self.blocks_delay_0, 15))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_5, 0), (self.blocks_delay_0, 17))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_6, 0), (self.blocks_delay_0, 19))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_7, 0), (self.blocks_delay_0, 21))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0_1_8, 0), (self.blocks_delay_0, 23))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_1, 0), (self.blocks_delay_0, 2))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2, 0), (self.blocks_delay_0, 4))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_0, 0), (self.blocks_delay_0, 6))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_1, 0), (self.blocks_delay_0, 8))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_2, 0), (self.blocks_delay_0, 10))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_3, 0), (self.blocks_delay_0, 12))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_4, 0), (self.blocks_delay_0, 14))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_5, 0), (self.blocks_delay_0, 16))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_6, 0), (self.blocks_delay_0, 18))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_7, 0), (self.blocks_delay_0, 20))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_2_8, 0), (self.blocks_delay_0, 22))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.analog_sig_source_x_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_4.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_5.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_4.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_5.set_sampling_freq(self.samp_rate)
        self.low_pass_filter_0_23.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))

    def get_T_set_0(self):
        return self.T_set_0

    def set_T_set_0(self, T_set_0):
        self.T_set_0 = T_set_0
        self.analog_sig_source_x_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_5.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_4.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_5.set_amplitude(self.T_set_0)

    def get_T_set(self):
        return self.T_set

    def set_T_set(self, T_set):
        self.T_set = T_set
        self.rational_resampler_xxx_0_2_0_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_3.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_4.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_5.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_6.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_7.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0_1_8.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_3.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_4.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_5.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_6.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_7.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_2_8.set_taps([self.T_set])

    def get_Scale_N(self):
        return self.Scale_N

    def set_Scale_N(self, Scale_N):
        self.Scale_N = Scale_N

    def get_Scale(self):
        return self.Scale

    def set_Scale(self, Scale):
        self.Scale = Scale

    def get_Level(self):
        return self.Level

    def set_Level(self, Level):
        self.Level = Level
        self.low_pass_filter_0_23.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))

    def get_H_rate(self):
        return self.H_rate

    def set_H_rate(self, H_rate):
        self.H_rate = H_rate

    def get_Freq(self):
        return self.Freq

    def set_Freq(self, Freq):
        self.Freq = Freq
        self.analog_sig_source_x_0_0_0_0.set_frequency((self.Freq*73))
        self.analog_sig_source_x_0_0_0_0_0.set_frequency((self.Freq*74))
        self.analog_sig_source_x_0_0_0_0_0_0.set_frequency((self.Freq*76))
        self.analog_sig_source_x_0_0_0_0_0_0_0.set_frequency((self.Freq*78))
        self.analog_sig_source_x_0_0_0_0_0_0_0_0.set_frequency((self.Freq*82))
        self.analog_sig_source_x_0_0_0_0_0_0_0_1.set_frequency((self.Freq*86))
        self.analog_sig_source_x_0_0_0_0_0_0_0_2.set_frequency((self.Freq*90))
        self.analog_sig_source_x_0_0_0_0_0_0_0_3.set_frequency((self.Freq*94))
        self.analog_sig_source_x_0_0_0_0_0_0_1.set_frequency((self.Freq*80))
        self.analog_sig_source_x_0_0_0_0_0_0_2.set_frequency((self.Freq*84))
        self.analog_sig_source_x_0_0_0_0_0_0_3.set_frequency((self.Freq*88))
        self.analog_sig_source_x_0_0_0_0_0_0_4.set_frequency((self.Freq*92))
        self.analog_sig_source_x_0_0_0_0_0_0_5.set_frequency((self.Freq*96))
        self.analog_sig_source_x_0_0_0_0_1.set_frequency((self.Freq*75))
        self.analog_sig_source_x_0_0_0_0_1_0.set_frequency((self.Freq*77))
        self.analog_sig_source_x_0_0_0_0_1_0_0.set_frequency((self.Freq*81))
        self.analog_sig_source_x_0_0_0_0_1_0_1.set_frequency((self.Freq*85))
        self.analog_sig_source_x_0_0_0_0_1_0_2.set_frequency((self.Freq*89))
        self.analog_sig_source_x_0_0_0_0_1_0_3.set_frequency((self.Freq*93))
        self.analog_sig_source_x_0_0_0_0_1_1.set_frequency((self.Freq*79))
        self.analog_sig_source_x_0_0_0_0_1_2.set_frequency((self.Freq*83))
        self.analog_sig_source_x_0_0_0_0_1_3.set_frequency((self.Freq*87))
        self.analog_sig_source_x_0_0_0_0_1_4.set_frequency((self.Freq*91))
        self.analog_sig_source_x_0_0_0_0_1_5.set_frequency((self.Freq*95))

    def get_Filter(self):
        return self.Filter

    def set_Filter(self, Filter):
        self.Filter = Filter
        self.low_pass_filter_0_23.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))

    def get_Delay(self):
        return self.Delay

    def set_Delay(self, Delay):
        self.Delay = Delay
        self.blocks_delay_0.set_dly(int(self.Delay))

    def get_DB(self):
        return self.DB

    def set_DB(self, DB):
        self.DB = DB

    def get_Cut_off(self):
        return self.Cut_off

    def set_Cut_off(self, Cut_off):
        self.Cut_off = Cut_off
        self.low_pass_filter_0_23.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))

    def get_Beta(self):
        return self.Beta

    def set_Beta(self, Beta):
        self.Beta = Beta
        self.low_pass_filter_0_23.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_0_1_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))
        self.low_pass_filter_0_23_2_8.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, self.Beta))

