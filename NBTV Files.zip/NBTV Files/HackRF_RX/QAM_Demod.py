# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: QAM Demod
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class QAM_Demod(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "QAM Demod",
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
                gr.io_signature.makev(2, 2, [gr.sizeof_char*1, gr.sizeof_char*1]),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 500

        ##################################################
        # Blocks
        ##################################################

        self.blocks_sub_xx_0_0 = blocks.sub_ff(1)
        self.blocks_multiply_const_vxx_0_0 = blocks.multiply_const_ff(.5)
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_ff(.5)
        self.blocks_float_to_uchar_0_0 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_float_to_uchar_0 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_complex_to_float_0 = blocks.complex_to_float(1)
        self.blocks_add_xx_1_0 = blocks.add_vff(1)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_add_xx_1_0, 0), (self.blocks_multiply_const_vxx_0_0, 0))
        self.connect((self.blocks_complex_to_float_0, 0), (self.blocks_add_xx_1_0, 0))
        self.connect((self.blocks_complex_to_float_0, 1), (self.blocks_add_xx_1_0, 1))
        self.connect((self.blocks_complex_to_float_0, 1), (self.blocks_sub_xx_0_0, 1))
        self.connect((self.blocks_complex_to_float_0, 0), (self.blocks_sub_xx_0_0, 0))
        self.connect((self.blocks_float_to_uchar_0, 0), (self, 0))
        self.connect((self.blocks_float_to_uchar_0_0, 0), (self, 1))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_float_to_uchar_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0_0, 0), (self.blocks_float_to_uchar_0_0, 0))
        self.connect((self.blocks_sub_xx_0_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self, 0), (self.blocks_complex_to_float_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate

