#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: OFDM NBTV RX
# Author: VE3XTV
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Audio_RX_Set import Audio_RX_Set  # grc-generated hier_block
from D192_Carrier_RX import D192_Carrier_RX  # grc-generated hier_block
from PyQt5 import QtCore
from gnuradio import analog
from gnuradio import blocks
from gnuradio import eng_notation
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import network
from gnuradio import soapy
import sip
import threading



class HackRF_RX(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "OFDM NBTV RX", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("OFDM NBTV RX")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "HackRF_RX")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.variable_control_2 = variable_control_2 = 1196
        self.samp_rate = samp_rate = 384000
        self.VGA_Gain = VGA_Gain = 16
        self.UDP_VO = UDP_VO = 1234
        self.UDP_SO = UDP_SO = 1236
        self.UDP_IP = UDP_IP = '192.168.2.15'
        self.UDP_AO = UDP_AO = 1235
        self.IF_Gain = IF_Gain = 16
        self.Center_Freq = Center_Freq = 29250

        ##################################################
        # Blocks
        ##################################################

        self._VGA_Gain_range = qtgui.Range(1, 62, 1, 16, 62)
        self._VGA_Gain_win = qtgui.RangeWidget(self._VGA_Gain_range, self.set_VGA_Gain, "IF Gain    ", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._VGA_Gain_win, 4, 1, 1, 5)
        for r in range(4, 5):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_VO_tool_bar = Qt.QToolBar(self)
        self._UDP_VO_tool_bar.addWidget(Qt.QLabel("UDP Video Port" + ": "))
        self._UDP_VO_line_edit = Qt.QLineEdit(str(self.UDP_VO))
        self._UDP_VO_tool_bar.addWidget(self._UDP_VO_line_edit)
        self._UDP_VO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_VO(int(str(self._UDP_VO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_VO_tool_bar, 1, 1, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_IP_tool_bar = Qt.QToolBar(self)
        self._UDP_IP_tool_bar.addWidget(Qt.QLabel("UDP IP Address" + ": "))
        self._UDP_IP_line_edit = Qt.QLineEdit(str(self.UDP_IP))
        self._UDP_IP_tool_bar.addWidget(self._UDP_IP_line_edit)
        self._UDP_IP_line_edit.returnPressed.connect(
            lambda: self.set_UDP_IP(str(str(self._UDP_IP_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_IP_tool_bar, 1, 4, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(4, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_AO_tool_bar = Qt.QToolBar(self)
        self._UDP_AO_tool_bar.addWidget(Qt.QLabel("UDP_Audio Port" + ": "))
        self._UDP_AO_line_edit = Qt.QLineEdit(str(self.UDP_AO))
        self._UDP_AO_tool_bar.addWidget(self._UDP_AO_line_edit)
        self._UDP_AO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_AO(int(str(self._UDP_AO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_AO_tool_bar, 1, 2, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._IF_Gain_range = qtgui.Range(1, 40, 1, 16, 40)
        self._IF_Gain_win = qtgui.RangeWidget(self._IF_Gain_range, self.set_IF_Gain, "IF Gain    ", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._IF_Gain_win, 3, 1, 1, 5)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Center_Freq_range = qtgui.Range(29000, 29700, 10, 29250, (29700-29000))
        self._Center_Freq_win = qtgui.RangeWidget(self._Center_Freq_range, self.set_Center_Freq, "RF in kHz", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Center_Freq_win, 2, 1, 1, 5)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        if "int" == "int":
        	isFloat = False
        	scaleFactor = 1
        else:
        	isFloat = True
        	scaleFactor = 1

        _variable_control_2_dial_control = qtgui.GrDialControl('Delay', self, 1150,1250,1196,"default",self.set_variable_control_2,isFloat, scaleFactor, 100, True, "'value'")
        self.variable_control_2 = _variable_control_2_dial_control

        self.top_grid_layout.addWidget(_variable_control_2_dial_control, 1, 5, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(5, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.soapy_hackrf_source_0 = None
        dev = 'driver=hackrf'
        stream_args = ''
        tune_args = ['']
        settings = ['']

        self.soapy_hackrf_source_0 = soapy.source(dev, "fc32", 1, '',
                                  stream_args, tune_args, settings)
        self.soapy_hackrf_source_0.set_sample_rate(0, 2000000)
        self.soapy_hackrf_source_0.set_bandwidth(0, 0)
        self.soapy_hackrf_source_0.set_frequency(0, (Center_Freq*1000))
        self.soapy_hackrf_source_0.set_gain(0, 'AMP', False)
        self.soapy_hackrf_source_0.set_gain(0, 'LNA', min(max(IF_Gain, 0.0), 40.0))
        self.soapy_hackrf_source_0.set_gain(0, 'VGA', min(max(VGA_Gain, 0.0), 62.0))
        self.rational_resampler_xxx_0_2_0_0_0 = filter.rational_resampler_ccc(
                interpolation=samp_rate,
                decimation=2000000,
                taps=[],
                fractional_bw=0)
        self.qtgui_sink_x_0 = qtgui.sink_c(
            1024, #fftsize
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "RF in", #name
            True, #plotfreq
            True, #plotwaterfall
            True, #plottime
            True, #plotconst
            None # parent
        )
        self.qtgui_sink_x_0.set_update_time(1.0/10)
        self._qtgui_sink_x_0_win = sip.wrapinstance(self.qtgui_sink_x_0.qwidget(), Qt.QWidget)

        self.qtgui_sink_x_0.enable_rf_freq(False)

        self.top_grid_layout.addWidget(self._qtgui_sink_x_0_win, 5, 1, 1, 5)
        for r in range(5, 6):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 6):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.network_udp_sink_0_0 = network.udp_sink(gr.sizeof_char, 1, UDP_IP, UDP_AO, 0, 500, False)
        self.network_udp_sink_0 = network.udp_sink(gr.sizeof_char, 1, UDP_IP, UDP_VO, 0, 34560, False)
        self.blocks_throttle2_0 = blocks.throttle( gr.sizeof_gr_complex*1, samp_rate, True, 0 if "auto" == "auto" else max( int(float(0.1) * samp_rate) if "auto" == "time" else int(0.1), 1) )
        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_char*1, (5760,5760,5760,5760,5760,5760))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(100)
        self.analog_agc_xx_0 = analog.agc_cc((1e-4), 1.0, 1.0, 65536)
        self._UDP_SO_tool_bar = Qt.QToolBar(self)
        self._UDP_SO_tool_bar.addWidget(Qt.QLabel("UDP Sync Port" + ": "))
        self._UDP_SO_line_edit = Qt.QLineEdit(str(self.UDP_SO))
        self._UDP_SO_tool_bar.addWidget(self._UDP_SO_line_edit)
        self._UDP_SO_line_edit.editingFinished.connect(
            lambda: self.set_UDP_SO(int(str(self._UDP_SO_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_SO_tool_bar, 1, 3, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.D192_Carrier_RX_0 = D192_Carrier_RX()
        self.Audio_RX_Set_0 = Audio_RX_Set()


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self.variable_control_2, 'value'), (self.D192_Carrier_RX_0, 'Din'))
        self.connect((self.Audio_RX_Set_0, 0), (self.network_udp_sink_0_0, 0))
        self.connect((self.D192_Carrier_RX_0, 7), (self.Audio_RX_Set_0, 1))
        self.connect((self.D192_Carrier_RX_0, 6), (self.Audio_RX_Set_0, 0))
        self.connect((self.D192_Carrier_RX_0, 3), (self.blocks_stream_mux_0, 3))
        self.connect((self.D192_Carrier_RX_0, 1), (self.blocks_stream_mux_0, 1))
        self.connect((self.D192_Carrier_RX_0, 5), (self.blocks_stream_mux_0, 5))
        self.connect((self.D192_Carrier_RX_0, 0), (self.blocks_stream_mux_0, 0))
        self.connect((self.D192_Carrier_RX_0, 2), (self.blocks_stream_mux_0, 2))
        self.connect((self.D192_Carrier_RX_0, 4), (self.blocks_stream_mux_0, 4))
        self.connect((self.analog_agc_xx_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.analog_agc_xx_0, 0), (self.qtgui_sink_x_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D192_Carrier_RX_0, 0))
        self.connect((self.blocks_stream_mux_0, 0), (self.network_udp_sink_0, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.analog_agc_xx_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0, 0), (self.blocks_throttle2_0, 0))
        self.connect((self.soapy_hackrf_source_0, 0), (self.rational_resampler_xxx_0_2_0_0_0, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "HackRF_RX")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_variable_control_2(self):
        return self.variable_control_2

    def set_variable_control_2(self, variable_control_2):
        self.variable_control_2 = variable_control_2

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.blocks_throttle2_0.set_sample_rate(self.samp_rate)
        self.qtgui_sink_x_0.set_frequency_range(0, self.samp_rate)

    def get_VGA_Gain(self):
        return self.VGA_Gain

    def set_VGA_Gain(self, VGA_Gain):
        self.VGA_Gain = VGA_Gain
        self.soapy_hackrf_source_0.set_gain(0, 'VGA', min(max(self.VGA_Gain, 0.0), 62.0))

    def get_UDP_VO(self):
        return self.UDP_VO

    def set_UDP_VO(self, UDP_VO):
        self.UDP_VO = UDP_VO
        Qt.QMetaObject.invokeMethod(self._UDP_VO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_VO)))

    def get_UDP_SO(self):
        return self.UDP_SO

    def set_UDP_SO(self, UDP_SO):
        self.UDP_SO = UDP_SO
        Qt.QMetaObject.invokeMethod(self._UDP_SO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_SO)))

    def get_UDP_IP(self):
        return self.UDP_IP

    def set_UDP_IP(self, UDP_IP):
        self.UDP_IP = UDP_IP
        Qt.QMetaObject.invokeMethod(self._UDP_IP_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_IP)))

    def get_UDP_AO(self):
        return self.UDP_AO

    def set_UDP_AO(self, UDP_AO):
        self.UDP_AO = UDP_AO
        Qt.QMetaObject.invokeMethod(self._UDP_AO_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_AO)))

    def get_IF_Gain(self):
        return self.IF_Gain

    def set_IF_Gain(self, IF_Gain):
        self.IF_Gain = IF_Gain
        self.soapy_hackrf_source_0.set_gain(0, 'LNA', min(max(self.IF_Gain, 0.0), 40.0))

    def get_Center_Freq(self):
        return self.Center_Freq

    def set_Center_Freq(self, Center_Freq):
        self.Center_Freq = Center_Freq
        self.soapy_hackrf_source_0.set_frequency(0, (self.Center_Freq*1000))




def main(top_block_cls=HackRF_RX, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
