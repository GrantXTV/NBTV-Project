# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: 192 Carrier RX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from D24_Carrier_RX1 import D24_Carrier_RX1  # grc-generated hier_block
from D24_Carrier_RX2 import D24_Carrier_RX2  # grc-generated hier_block
from D24_Carrier_RX3 import D24_Carrier_RX3  # grc-generated hier_block
from D24_Carrier_RX4 import D24_Carrier_RX4  # grc-generated hier_block
from D24_Carrier_RX5 import D24_Carrier_RX5  # grc-generated hier_block
from D24_Carrier_RX6 import D24_Carrier_RX6  # grc-generated hier_block
from D24_Carrier_RX7 import D24_Carrier_RX7  # grc-generated hier_block
from D24_Carrier_RX8 import D24_Carrier_RX8  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
import threading







class D192_Carrier_RX(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "192 Carrier RX",
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
                gr.io_signature.makev(8, 8, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
        )
        self.message_port_register_hier_in("Din")

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 384000

        ##################################################
        # Blocks
        ##################################################

        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(2)
        self.D24_Carrier_RX8_0 = D24_Carrier_RX8()
        self.D24_Carrier_RX7_0 = D24_Carrier_RX7()
        self.D24_Carrier_RX6_0 = D24_Carrier_RX6()
        self.D24_Carrier_RX5_0 = D24_Carrier_RX5()
        self.D24_Carrier_RX4_0 = D24_Carrier_RX4()
        self.D24_Carrier_RX3_0 = D24_Carrier_RX3()
        self.D24_Carrier_RX2_1 = D24_Carrier_RX2()
        self.D24_Carrier_RX1_1 = D24_Carrier_RX1()


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX1_1, 'Din'))
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX2_1, 'Din'))
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX3_0, 'Din'))
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX4_0, 'Din'))
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX5_0, 'Din'))
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX6_0, 'Din'))
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX7_0, 'Din'))
        self.msg_connect((self, 'Din'), (self.D24_Carrier_RX8_0, 'Din'))
        self.connect((self.D24_Carrier_RX1_1, 0), (self, 0))
        self.connect((self.D24_Carrier_RX2_1, 0), (self, 1))
        self.connect((self.D24_Carrier_RX3_0, 0), (self, 2))
        self.connect((self.D24_Carrier_RX4_0, 0), (self, 3))
        self.connect((self.D24_Carrier_RX5_0, 0), (self, 4))
        self.connect((self.D24_Carrier_RX6_0, 0), (self, 5))
        self.connect((self.D24_Carrier_RX7_0, 0), (self, 6))
        self.connect((self.D24_Carrier_RX8_0, 0), (self, 7))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX1_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX2_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX3_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX4_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX5_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX6_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX7_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.D24_Carrier_RX8_0, 0))
        self.connect((self, 0), (self.blocks_multiply_const_vxx_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate

