#!/bin/bash
./OFDM_Loopback_v2/OFDM_Loopback_v2.py
