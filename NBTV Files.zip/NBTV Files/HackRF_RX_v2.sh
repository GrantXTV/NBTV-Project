#!/bin/bash
./HackRF_RX_v2/HackRF_RX_v2.py
