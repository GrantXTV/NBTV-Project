#!/bin/bash
./HackRF_RX/HackRF_RX.py
