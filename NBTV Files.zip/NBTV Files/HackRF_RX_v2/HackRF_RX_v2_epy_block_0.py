import numpy as np
from gnuradio import gr

class blk(gr.sync_block):
    def __init__(self):
        gr.sync_block.__init__(
            self,
            name="Zero Crossing Trigger",
            in_sig=[np.float32],
            out_sig=[np.uint8]
        )
        self.prev_sample = 0.0
        self.pulse_remaining = 0

    def work(self, input_items, output_items):
        n_samples = len(output_items[0])
        in_data = input_items[0]
        out_data = output_items[0]
        out_data[:] = np.uint8(255)

        for i in range(n_samples):
            curr = in_data[i]

            if self.pulse_remaining > 0:
                out_data[i] = np.uint8(0)
                self.pulse_remaining -= 1
            elif self.prev_sample < 0 and curr >= 0:
                out_data[i] = np.uint8(0)
                self.pulse_remaining = 1  # 10-sample pulse total

            self.prev_sample = curr

        return n_samples
