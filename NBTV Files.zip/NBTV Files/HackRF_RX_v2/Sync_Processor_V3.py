# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Sync Processor V3
# GNU Radio version: 3.10.12.0

from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import sys
import signal
import Sync_Processor_V3_epy_block_0 as epy_block_0  # embedded python block
import threading







class Sync_Processor_V3(gr.hier_block2):
    def __init__(self, samp_rate=0):
        gr.hier_block2.__init__(
            self, "Sync Processor V3",
                gr.io_signature.makev(2, 2, [gr.sizeof_char*1, gr.sizeof_char*1]),
                gr.io_signature.makev(5, 5, [gr.sizeof_char*1, gr.sizeof_float*1, gr.sizeof_float*1, gr.sizeof_float*1, gr.sizeof_char*1]),
        )

        ##################################################
        # Parameters
        ##################################################
        self.samp_rate = samp_rate

        ##################################################
        # Blocks
        ##################################################

        self.epy_block_0 = epy_block_0.blk()
        self.blocks_uchar_to_float_0_1_0_0_1 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1_0_0_0 = blocks.uchar_to_float()
        self.blocks_stream_mux_1 = blocks.stream_mux(gr.sizeof_float*1, (720,720))
        self.blocks_multiply_xx_0 = blocks.multiply_vff(1)
        self.blocks_multiply_const_vxx_0_1_0_1 = blocks.multiply_const_ff(1)
        self.blocks_multiply_const_vxx_0_1_0_0_0 = blocks.multiply_const_ff(1)
        self.blocks_multiply_const_vxx_0_1_0_0 = blocks.multiply_const_ff(64)
        self.blocks_multiply_const_vxx_0_1_0 = blocks.multiply_const_ff(64)
        self.blocks_float_to_uchar_0_1_0_1_0_0 = blocks.float_to_uchar(1, 1.5, 0)
        self.blocks_float_to_complex_1_0 = blocks.float_to_complex(1)
        self.blocks_float_to_complex_0_0 = blocks.float_to_complex(1)
        self.blocks_delay_0_1 = blocks.delay(gr.sizeof_float*1, 216)
        self.blocks_delay_0_0_0 = blocks.delay(gr.sizeof_float*1, 144)
        self.blocks_complex_to_float_1_0 = blocks.complex_to_float(1)
        self.blocks_complex_to_float_0_0 = blocks.complex_to_float(1)
        self.blocks_add_const_vxx_0_2 = blocks.add_const_ff((-128))
        self.blocks_add_const_vxx_0_1_1 = blocks.add_const_ff((-128))
        self.blocks_add_const_vxx_0_1_0 = blocks.add_const_ff(96)
        self.band_pass_filter_0_1_1 = filter.fir_filter_fff(
            1,
            firdes.band_pass(
                1,
                500,
                4.125,
                8.3,
                1,
                window.WIN_KAISER,
                8.32))
        self.band_pass_filter_0_1_0 = filter.fir_filter_fff(
            1,
            firdes.band_pass(
                2,
                samp_rate,
                1.5,
                2.6,
                1,
                window.WIN_KAISER,
                8.32))
        self.band_pass_filter_0_1 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                10,
                samp_rate,
                4.125,
                8.3,
                1,
                window.WIN_KAISER,
                8.32))
        self.band_pass_filter_0_0_0_0 = filter.fir_filter_fff(
            1,
            firdes.band_pass(
                1,
                500,
                3.125,
                5.25,
                1,
                window.WIN_KAISER,
                8.32))
        self.band_pass_filter_0_0_0 = filter.fir_filter_ccf(
            1,
            firdes.band_pass(
                10,
                samp_rate,
                3.125,
                5.25,
                1,
                window.WIN_KAISER,
                8.32))
        self.analog_pll_refout_cc_1_0 = analog.pll_refout_cc(0.0262, 0.092, 0.066)
        self.analog_pll_refout_cc_0_0 = analog.pll_refout_cc(0.0262, 0.067, 0.033)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_pll_refout_cc_0_0, 0), (self.blocks_complex_to_float_1_0, 0))
        self.connect((self.analog_pll_refout_cc_1_0, 0), (self.blocks_complex_to_float_0_0, 0))
        self.connect((self.band_pass_filter_0_0_0, 0), (self.analog_pll_refout_cc_0_0, 0))
        self.connect((self.band_pass_filter_0_0_0_0, 0), (self.blocks_delay_0_1, 0))
        self.connect((self.band_pass_filter_0_0_0_0, 0), (self.blocks_float_to_complex_1_0, 0))
        self.connect((self.band_pass_filter_0_1, 0), (self.analog_pll_refout_cc_1_0, 0))
        self.connect((self.band_pass_filter_0_1_0, 0), (self.epy_block_0, 0))
        self.connect((self.band_pass_filter_0_1_0, 0), (self, 2))
        self.connect((self.band_pass_filter_0_1_1, 0), (self.blocks_delay_0_0_0, 0))
        self.connect((self.band_pass_filter_0_1_1, 0), (self.blocks_float_to_complex_0_0, 0))
        self.connect((self.blocks_add_const_vxx_0_1_0, 0), (self.blocks_float_to_uchar_0_1_0_1_0_0, 0))
        self.connect((self.blocks_add_const_vxx_0_1_1, 0), (self.band_pass_filter_0_1_1, 0))
        self.connect((self.blocks_add_const_vxx_0_2, 0), (self.band_pass_filter_0_0_0_0, 0))
        self.connect((self.blocks_complex_to_float_0_0, 0), (self.blocks_multiply_const_vxx_0_1_0, 0))
        self.connect((self.blocks_complex_to_float_0_0, 0), (self.blocks_multiply_xx_0, 0))
        self.connect((self.blocks_complex_to_float_0_0, 0), (self, 1))
        self.connect((self.blocks_complex_to_float_1_0, 0), (self.blocks_multiply_const_vxx_0_1_0_0, 0))
        self.connect((self.blocks_complex_to_float_1_0, 0), (self.blocks_multiply_xx_0, 1))
        self.connect((self.blocks_complex_to_float_1_0, 0), (self, 3))
        self.connect((self.blocks_delay_0_0_0, 0), (self.blocks_float_to_complex_0_0, 1))
        self.connect((self.blocks_delay_0_1, 0), (self.blocks_float_to_complex_1_0, 1))
        self.connect((self.blocks_float_to_complex_0_0, 0), (self.band_pass_filter_0_1, 0))
        self.connect((self.blocks_float_to_complex_1_0, 0), (self.band_pass_filter_0_0_0, 0))
        self.connect((self.blocks_float_to_uchar_0_1_0_1_0_0, 0), (self, 4))
        self.connect((self.blocks_multiply_const_vxx_0_1_0, 0), (self.blocks_stream_mux_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0_1_0_0, 0), (self.blocks_stream_mux_1, 1))
        self.connect((self.blocks_multiply_const_vxx_0_1_0_0_0, 0), (self.blocks_add_const_vxx_0_1_1, 0))
        self.connect((self.blocks_multiply_const_vxx_0_1_0_1, 0), (self.blocks_add_const_vxx_0_2, 0))
        self.connect((self.blocks_multiply_xx_0, 0), (self.band_pass_filter_0_1_0, 0))
        self.connect((self.blocks_stream_mux_1, 0), (self.blocks_add_const_vxx_0_1_0, 0))
        self.connect((self.blocks_uchar_to_float_0_1_0_0_0, 0), (self.blocks_multiply_const_vxx_0_1_0_0_0, 0))
        self.connect((self.blocks_uchar_to_float_0_1_0_0_1, 0), (self.blocks_multiply_const_vxx_0_1_0_1, 0))
        self.connect((self.epy_block_0, 0), (self, 0))
        self.connect((self, 0), (self.blocks_uchar_to_float_0_1_0_0_0, 0))
        self.connect((self, 1), (self.blocks_uchar_to_float_0_1_0_0_1, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.band_pass_filter_0_0_0.set_taps(firdes.band_pass(10, self.samp_rate, 3.125, 5.25, 1, window.WIN_KAISER, 8.32))
        self.band_pass_filter_0_1.set_taps(firdes.band_pass(10, self.samp_rate, 4.125, 8.3, 1, window.WIN_KAISER, 8.32))
        self.band_pass_filter_0_1_0.set_taps(firdes.band_pass(2, self.samp_rate, 1.5, 2.6, 1, window.WIN_KAISER, 8.32))

