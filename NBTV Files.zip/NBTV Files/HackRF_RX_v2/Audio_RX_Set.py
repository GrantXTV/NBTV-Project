# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Audio RX_Set
# GNU Radio version: 3.10.12.0

from gnuradio import analog
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class Audio_RX_Set(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Audio RX_Set",
                gr.io_signature.makev(2, 2, [gr.sizeof_char*1, gr.sizeof_char*1]),
                gr.io_signature(1, 1, gr.sizeof_char*1),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 24000

        ##################################################
        # Blocks
        ##################################################

        self.blocks_uchar_to_float_0_2_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1_0 = blocks.uchar_to_float()
        self.blocks_throttle2_0_0 = blocks.throttle( gr.sizeof_char*1, samp_rate, True, 0 if "auto" == "auto" else max( int(float(0.1) * samp_rate) if "auto" == "time" else int(0.1), 1) )
        self.blocks_throttle2_0 = blocks.throttle( gr.sizeof_char*1, samp_rate, True, 0 if "auto" == "auto" else max( int(float(0.1) * samp_rate) if "auto" == "time" else int(0.1), 1) )
        self.blocks_interleave_0 = blocks.interleave(gr.sizeof_char*1, 1)
        self.blocks_float_to_uchar_0_1 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_float_to_uchar_0_0_0 = blocks.float_to_uchar(1, 1, 0)
        self.analog_fm_deemph_0_0 = analog.fm_deemph(fs=samp_rate, tau=(45e-6))
        self.analog_fm_deemph_0 = analog.fm_deemph(fs=samp_rate, tau=(45e-6))


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_fm_deemph_0, 0), (self.blocks_float_to_uchar_0_1, 0))
        self.connect((self.analog_fm_deemph_0_0, 0), (self.blocks_float_to_uchar_0_0_0, 0))
        self.connect((self.blocks_float_to_uchar_0_0_0, 0), (self.blocks_interleave_0, 1))
        self.connect((self.blocks_float_to_uchar_0_1, 0), (self.blocks_interleave_0, 0))
        self.connect((self.blocks_interleave_0, 0), (self, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.blocks_uchar_to_float_0_1_0, 0))
        self.connect((self.blocks_throttle2_0_0, 0), (self.blocks_uchar_to_float_0_2_0, 0))
        self.connect((self.blocks_uchar_to_float_0_1_0, 0), (self.analog_fm_deemph_0, 0))
        self.connect((self.blocks_uchar_to_float_0_2_0, 0), (self.analog_fm_deemph_0_0, 0))
        self.connect((self, 0), (self.blocks_throttle2_0, 0))
        self.connect((self, 1), (self.blocks_throttle2_0_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.blocks_throttle2_0.set_sample_rate(self.samp_rate)
        self.blocks_throttle2_0_0.set_sample_rate(self.samp_rate)

