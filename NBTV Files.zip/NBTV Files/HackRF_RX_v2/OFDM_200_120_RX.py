# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: OFDM 200 120 RX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Audio_RX_Set import Audio_RX_Set  # grc-generated hier_block
from OFDM_200_RX_R import OFDM_200_RX_R  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
import threading







class OFDM_200_120_RX(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "OFDM 200 120 RX",
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
                gr.io_signature.makev(4, 4, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
        )
        self.message_port_register_hier_in("in")

        ##################################################
        # Variables
        ##################################################
        self.DB = DB = 5760

        ##################################################
        # Blocks
        ##################################################

        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_char*1, (DB,DB,DB,DB,DB,DB))
        self.OFDM_200_RX_R_0 = OFDM_200_RX_R()
        self.Audio_RX_Set_0 = Audio_RX_Set()


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self, 'in'), (self.OFDM_200_RX_R_0, 'in'))
        self.connect((self.Audio_RX_Set_0, 0), (self, 1))
        self.connect((self.OFDM_200_RX_R_0, 0), (self.Audio_RX_Set_0, 0))
        self.connect((self.OFDM_200_RX_R_0, 9), (self.Audio_RX_Set_0, 1))
        self.connect((self.OFDM_200_RX_R_0, 2), (self.blocks_stream_mux_0, 4))
        self.connect((self.OFDM_200_RX_R_0, 7), (self.blocks_stream_mux_0, 2))
        self.connect((self.OFDM_200_RX_R_0, 1), (self.blocks_stream_mux_0, 1))
        self.connect((self.OFDM_200_RX_R_0, 8), (self.blocks_stream_mux_0, 3))
        self.connect((self.OFDM_200_RX_R_0, 6), (self.blocks_stream_mux_0, 5))
        self.connect((self.OFDM_200_RX_R_0, 3), (self.blocks_stream_mux_0, 0))
        self.connect((self.OFDM_200_RX_R_0, 4), (self, 0))
        self.connect((self.OFDM_200_RX_R_0, 5), (self, 3))
        self.connect((self.blocks_stream_mux_0, 0), (self, 2))
        self.connect((self, 0), (self.OFDM_200_RX_R_0, 0))


    def get_DB(self):
        return self.DB

    def set_DB(self, DB):
        self.DB = DB

