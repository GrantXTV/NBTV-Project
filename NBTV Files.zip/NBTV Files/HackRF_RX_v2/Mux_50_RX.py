# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Mux 50 RX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from QAM_Demod import QAM_Demod  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
import threading







class Mux_50_RX(gr.hier_block2):
    def __init__(self, Delay=0):
        gr.hier_block2.__init__(
            self, "Mux 50 RX",
                gr.io_signature.makev(25, 25, [gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1]),
                gr.io_signature.makev(3, 3, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
        )
        self.message_port_register_hier_in("Din")

        ##################################################
        # Parameters
        ##################################################
        self.Delay = Delay

        ##################################################
        # Variables
        ##################################################
        self.DB = DB = 120

        ##################################################
        # Blocks
        ##################################################

        self.blocks_stream_mux_0 = blocks.stream_mux(gr.sizeof_char*1, (DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB))
        self.blocks_delay_0 = blocks.delay(gr.sizeof_gr_complex*1, Delay)
        self.QAM_Demod_0_6 = QAM_Demod()
        self.QAM_Demod_0_5 = QAM_Demod()
        self.QAM_Demod_0_4 = QAM_Demod()
        self.QAM_Demod_0_3 = QAM_Demod()
        self.QAM_Demod_0_2 = QAM_Demod()
        self.QAM_Demod_0_1_4 = QAM_Demod()
        self.QAM_Demod_0_1_3 = QAM_Demod()
        self.QAM_Demod_0_1_2 = QAM_Demod()
        self.QAM_Demod_0_1_1 = QAM_Demod()
        self.QAM_Demod_0_1_0 = QAM_Demod()
        self.QAM_Demod_0_1 = QAM_Demod()
        self.QAM_Demod_0_0_6 = QAM_Demod()
        self.QAM_Demod_0_0_5 = QAM_Demod()
        self.QAM_Demod_0_0_4 = QAM_Demod()
        self.QAM_Demod_0_0_3 = QAM_Demod()
        self.QAM_Demod_0_0_2 = QAM_Demod()
        self.QAM_Demod_0_0_1 = QAM_Demod()
        self.QAM_Demod_0_0_0_4_0 = QAM_Demod()
        self.QAM_Demod_0_0_0_4 = QAM_Demod()
        self.QAM_Demod_0_0_0_3 = QAM_Demod()
        self.QAM_Demod_0_0_0_2 = QAM_Demod()
        self.QAM_Demod_0_0_0_1 = QAM_Demod()
        self.QAM_Demod_0_0_0_0 = QAM_Demod()
        self.QAM_Demod_0_0_0 = QAM_Demod()
        self.QAM_Demod_0_0 = QAM_Demod()


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self, 'Din'), (self.blocks_delay_0, 'dly'))
        self.connect((self.QAM_Demod_0_0, 0), (self.blocks_stream_mux_0, 2))
        self.connect((self.QAM_Demod_0_0, 1), (self.blocks_stream_mux_0, 3))
        self.connect((self.QAM_Demod_0_0_0, 0), (self.blocks_stream_mux_0, 6))
        self.connect((self.QAM_Demod_0_0_0, 1), (self.blocks_stream_mux_0, 7))
        self.connect((self.QAM_Demod_0_0_0_0, 0), (self.blocks_stream_mux_0, 14))
        self.connect((self.QAM_Demod_0_0_0_0, 1), (self.blocks_stream_mux_0, 15))
        self.connect((self.QAM_Demod_0_0_0_1, 0), (self.blocks_stream_mux_0, 22))
        self.connect((self.QAM_Demod_0_0_0_1, 1), (self.blocks_stream_mux_0, 23))
        self.connect((self.QAM_Demod_0_0_0_2, 0), (self.blocks_stream_mux_0, 30))
        self.connect((self.QAM_Demod_0_0_0_2, 1), (self.blocks_stream_mux_0, 31))
        self.connect((self.QAM_Demod_0_0_0_3, 0), (self.blocks_stream_mux_0, 38))
        self.connect((self.QAM_Demod_0_0_0_3, 1), (self.blocks_stream_mux_0, 39))
        self.connect((self.QAM_Demod_0_0_0_4, 1), (self.blocks_stream_mux_0, 47))
        self.connect((self.QAM_Demod_0_0_0_4, 0), (self.blocks_stream_mux_0, 46))
        self.connect((self.QAM_Demod_0_0_0_4_0, 0), (self, 1))
        self.connect((self.QAM_Demod_0_0_0_4_0, 1), (self, 2))
        self.connect((self.QAM_Demod_0_0_1, 0), (self.blocks_stream_mux_0, 10))
        self.connect((self.QAM_Demod_0_0_1, 1), (self.blocks_stream_mux_0, 11))
        self.connect((self.QAM_Demod_0_0_2, 0), (self.blocks_stream_mux_0, 18))
        self.connect((self.QAM_Demod_0_0_2, 1), (self.blocks_stream_mux_0, 19))
        self.connect((self.QAM_Demod_0_0_3, 0), (self.blocks_stream_mux_0, 26))
        self.connect((self.QAM_Demod_0_0_3, 1), (self.blocks_stream_mux_0, 27))
        self.connect((self.QAM_Demod_0_0_4, 0), (self.blocks_stream_mux_0, 34))
        self.connect((self.QAM_Demod_0_0_4, 1), (self.blocks_stream_mux_0, 35))
        self.connect((self.QAM_Demod_0_0_5, 0), (self.blocks_stream_mux_0, 42))
        self.connect((self.QAM_Demod_0_0_5, 1), (self.blocks_stream_mux_0, 43))
        self.connect((self.QAM_Demod_0_0_6, 0), (self.blocks_stream_mux_0, 1))
        self.connect((self.QAM_Demod_0_0_6, 1), (self.blocks_stream_mux_0, 0))
        self.connect((self.QAM_Demod_0_1, 1), (self.blocks_stream_mux_0, 4))
        self.connect((self.QAM_Demod_0_1, 0), (self.blocks_stream_mux_0, 5))
        self.connect((self.QAM_Demod_0_1_0, 1), (self.blocks_stream_mux_0, 12))
        self.connect((self.QAM_Demod_0_1_0, 0), (self.blocks_stream_mux_0, 13))
        self.connect((self.QAM_Demod_0_1_1, 0), (self.blocks_stream_mux_0, 21))
        self.connect((self.QAM_Demod_0_1_1, 1), (self.blocks_stream_mux_0, 20))
        self.connect((self.QAM_Demod_0_1_2, 1), (self.blocks_stream_mux_0, 28))
        self.connect((self.QAM_Demod_0_1_2, 0), (self.blocks_stream_mux_0, 29))
        self.connect((self.QAM_Demod_0_1_3, 0), (self.blocks_stream_mux_0, 37))
        self.connect((self.QAM_Demod_0_1_3, 1), (self.blocks_stream_mux_0, 36))
        self.connect((self.QAM_Demod_0_1_4, 1), (self.blocks_stream_mux_0, 44))
        self.connect((self.QAM_Demod_0_1_4, 0), (self.blocks_stream_mux_0, 45))
        self.connect((self.QAM_Demod_0_2, 1), (self.blocks_stream_mux_0, 8))
        self.connect((self.QAM_Demod_0_2, 0), (self.blocks_stream_mux_0, 9))
        self.connect((self.QAM_Demod_0_3, 0), (self.blocks_stream_mux_0, 17))
        self.connect((self.QAM_Demod_0_3, 1), (self.blocks_stream_mux_0, 16))
        self.connect((self.QAM_Demod_0_4, 0), (self.blocks_stream_mux_0, 25))
        self.connect((self.QAM_Demod_0_4, 1), (self.blocks_stream_mux_0, 24))
        self.connect((self.QAM_Demod_0_5, 1), (self.blocks_stream_mux_0, 32))
        self.connect((self.QAM_Demod_0_5, 0), (self.blocks_stream_mux_0, 33))
        self.connect((self.QAM_Demod_0_6, 1), (self.blocks_stream_mux_0, 40))
        self.connect((self.QAM_Demod_0_6, 0), (self.blocks_stream_mux_0, 41))
        self.connect((self.blocks_delay_0, 1), (self.QAM_Demod_0_0, 0))
        self.connect((self.blocks_delay_0, 3), (self.QAM_Demod_0_0_0, 0))
        self.connect((self.blocks_delay_0, 7), (self.QAM_Demod_0_0_0_0, 0))
        self.connect((self.blocks_delay_0, 11), (self.QAM_Demod_0_0_0_1, 0))
        self.connect((self.blocks_delay_0, 15), (self.QAM_Demod_0_0_0_2, 0))
        self.connect((self.blocks_delay_0, 19), (self.QAM_Demod_0_0_0_3, 0))
        self.connect((self.blocks_delay_0, 23), (self.QAM_Demod_0_0_0_4, 0))
        self.connect((self.blocks_delay_0, 5), (self.QAM_Demod_0_0_1, 0))
        self.connect((self.blocks_delay_0, 9), (self.QAM_Demod_0_0_2, 0))
        self.connect((self.blocks_delay_0, 13), (self.QAM_Demod_0_0_3, 0))
        self.connect((self.blocks_delay_0, 17), (self.QAM_Demod_0_0_4, 0))
        self.connect((self.blocks_delay_0, 21), (self.QAM_Demod_0_0_5, 0))
        self.connect((self.blocks_delay_0, 0), (self.QAM_Demod_0_0_6, 0))
        self.connect((self.blocks_delay_0, 2), (self.QAM_Demod_0_1, 0))
        self.connect((self.blocks_delay_0, 6), (self.QAM_Demod_0_1_0, 0))
        self.connect((self.blocks_delay_0, 10), (self.QAM_Demod_0_1_1, 0))
        self.connect((self.blocks_delay_0, 14), (self.QAM_Demod_0_1_2, 0))
        self.connect((self.blocks_delay_0, 18), (self.QAM_Demod_0_1_3, 0))
        self.connect((self.blocks_delay_0, 22), (self.QAM_Demod_0_1_4, 0))
        self.connect((self.blocks_delay_0, 4), (self.QAM_Demod_0_2, 0))
        self.connect((self.blocks_delay_0, 8), (self.QAM_Demod_0_3, 0))
        self.connect((self.blocks_delay_0, 12), (self.QAM_Demod_0_4, 0))
        self.connect((self.blocks_delay_0, 16), (self.QAM_Demod_0_5, 0))
        self.connect((self.blocks_delay_0, 20), (self.QAM_Demod_0_6, 0))
        self.connect((self.blocks_stream_mux_0, 0), (self, 0))
        self.connect((self, 0), (self.blocks_delay_0, 16))
        self.connect((self, 1), (self.blocks_delay_0, 18))
        self.connect((self, 2), (self.blocks_delay_0, 20))
        self.connect((self, 3), (self.blocks_delay_0, 12))
        self.connect((self, 4), (self.blocks_delay_0, 11))
        self.connect((self, 5), (self.blocks_delay_0, 19))
        self.connect((self, 6), (self.blocks_delay_0, 5))
        self.connect((self, 7), (self.blocks_delay_0, 10))
        self.connect((self, 8), (self.blocks_delay_0, 3))
        self.connect((self, 9), (self.blocks_delay_0, 13))
        self.connect((self, 10), (self.blocks_delay_0, 21))
        self.connect((self, 11), (self.blocks_delay_0, 17))
        self.connect((self, 12), (self.blocks_delay_0, 15))
        self.connect((self, 13), (self.blocks_delay_0, 14))
        self.connect((self, 14), (self.blocks_delay_0, 0))
        self.connect((self, 15), (self.blocks_delay_0, 22))
        self.connect((self, 16), (self.blocks_delay_0, 6))
        self.connect((self, 17), (self.blocks_delay_0, 4))
        self.connect((self, 18), (self.blocks_delay_0, 1))
        self.connect((self, 19), (self.blocks_delay_0, 7))
        self.connect((self, 20), (self.blocks_delay_0, 23))
        self.connect((self, 21), (self.QAM_Demod_0_0_0_4_0, 0))
        self.connect((self, 22), (self.blocks_delay_0, 2))
        self.connect((self, 23), (self.blocks_delay_0, 9))
        self.connect((self, 24), (self.blocks_delay_0, 8))


    def get_Delay(self):
        return self.Delay

    def set_Delay(self, Delay):
        self.Delay = Delay
        self.blocks_delay_0.set_dly(int(self.Delay))

    def get_DB(self):
        return self.DB

    def set_DB(self, DB):
        self.DB = DB

