# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: OFDM 200 RX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Mux_50_RX import Mux_50_RX  # grc-generated hier_block
from Mux_50_RX_A import Mux_50_RX_A  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import fft
from gnuradio.fft import window
from gnuradio import gr
from gnuradio.filter import firdes
import signal
import threading







class OFDM_200_RX(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "OFDM 200 RX",
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
                gr.io_signature.makev(10, 10, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
        )
        self.message_port_register_hier_in("in")

        ##################################################
        # Blocks
        ##################################################

        self.fft_vxx_0 = fft.fft_vcc(200, True, window.rectangular(200), True, 1)
        self.blocks_vector_to_streams_0 = blocks.vector_to_streams(gr.sizeof_gr_complex*1, 200)
        self.blocks_uchar_to_float_0_3 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_2_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_2 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1_1 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1_0_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0_2 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0_1_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0_1 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0_0_1 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0_0_0_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0_0_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0 = blocks.uchar_to_float()
        self.blocks_stream_to_vector_0 = blocks.stream_to_vector(gr.sizeof_gr_complex*1, 200)
        self.blocks_multiply_const_vxx_1 = blocks.multiply_const_ff((1/8))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_ff((1/8))
        self.blocks_float_to_uchar_1 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_float_to_uchar_0 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_add_xx_0_0 = blocks.add_vff(1)
        self.blocks_add_xx_0 = blocks.add_vff(1)
        self.Mux_50_RX_A_1 = Mux_50_RX_A(
            Delay=0,
        )
        self.Mux_50_RX_A_0 = Mux_50_RX_A(
            Delay=0,
        )
        self.Mux_50_RX_0_4 = Mux_50_RX(
            Delay=0,
        )
        self.Mux_50_RX_0_3 = Mux_50_RX(
            Delay=0,
        )
        self.Mux_50_RX_0_2 = Mux_50_RX(
            Delay=0,
        )
        self.Mux_50_RX_0_1 = Mux_50_RX(
            Delay=0,
        )
        self.Mux_50_RX_0_0 = Mux_50_RX(
            Delay=0,
        )
        self.Mux_50_RX_0 = Mux_50_RX(
            Delay=0,
        )


        ##################################################
        # Connections
        ##################################################
        self.msg_connect((self, 'in'), (self.Mux_50_RX_0, 'Din'))
        self.msg_connect((self, 'in'), (self.Mux_50_RX_0_0, 'Din'))
        self.msg_connect((self, 'in'), (self.Mux_50_RX_0_1, 'Din'))
        self.msg_connect((self, 'in'), (self.Mux_50_RX_0_2, 'Din'))
        self.msg_connect((self, 'in'), (self.Mux_50_RX_0_3, 'Din'))
        self.msg_connect((self, 'in'), (self.Mux_50_RX_0_4, 'Din'))
        self.msg_connect((self, 'in'), (self.Mux_50_RX_A_0, 'Din'))
        self.msg_connect((self, 'in'), (self.Mux_50_RX_A_1, 'Din'))
        self.connect((self.Mux_50_RX_0, 1), (self.blocks_uchar_to_float_0_1_0, 0))
        self.connect((self.Mux_50_RX_0, 2), (self.blocks_uchar_to_float_0_1_0_0, 0))
        self.connect((self.Mux_50_RX_0, 0), (self, 0))
        self.connect((self.Mux_50_RX_0_0, 2), (self.blocks_uchar_to_float_0_0_0_0, 0))
        self.connect((self.Mux_50_RX_0_0, 1), (self.blocks_uchar_to_float_0_0_0_0_0, 0))
        self.connect((self.Mux_50_RX_0_0, 0), (self, 1))
        self.connect((self.Mux_50_RX_0_1, 1), (self.blocks_uchar_to_float_0_2, 0))
        self.connect((self.Mux_50_RX_0_1, 2), (self.blocks_uchar_to_float_0_2_0, 0))
        self.connect((self.Mux_50_RX_0_1, 0), (self, 2))
        self.connect((self.Mux_50_RX_0_2, 2), (self.blocks_uchar_to_float_0_0_1, 0))
        self.connect((self.Mux_50_RX_0_2, 1), (self.blocks_uchar_to_float_0_0_1_0, 0))
        self.connect((self.Mux_50_RX_0_2, 0), (self, 3))
        self.connect((self.Mux_50_RX_0_3, 1), (self.blocks_uchar_to_float_0_1, 0))
        self.connect((self.Mux_50_RX_0_3, 2), (self.blocks_uchar_to_float_0_1_1, 0))
        self.connect((self.Mux_50_RX_0_3, 0), (self, 6))
        self.connect((self.Mux_50_RX_0_4, 1), (self.blocks_uchar_to_float_0_0_0, 0))
        self.connect((self.Mux_50_RX_0_4, 2), (self.blocks_uchar_to_float_0_0_0_1, 0))
        self.connect((self.Mux_50_RX_0_4, 0), (self, 7))
        self.connect((self.Mux_50_RX_A_0, 1), (self.blocks_uchar_to_float_0, 0))
        self.connect((self.Mux_50_RX_A_0, 2), (self.blocks_uchar_to_float_0_3, 0))
        self.connect((self.Mux_50_RX_A_0, 0), (self, 8))
        self.connect((self.Mux_50_RX_A_1, 2), (self.blocks_uchar_to_float_0_0, 0))
        self.connect((self.Mux_50_RX_A_1, 1), (self.blocks_uchar_to_float_0_0_2, 0))
        self.connect((self.Mux_50_RX_A_1, 0), (self, 9))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.blocks_add_xx_0_0, 0), (self.blocks_multiply_const_vxx_1, 0))
        self.connect((self.blocks_float_to_uchar_0, 0), (self, 4))
        self.connect((self.blocks_float_to_uchar_1, 0), (self, 5))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.blocks_float_to_uchar_0, 0))
        self.connect((self.blocks_multiply_const_vxx_1, 0), (self.blocks_float_to_uchar_1, 0))
        self.connect((self.blocks_stream_to_vector_0, 0), (self.fft_vxx_0, 0))
        self.connect((self.blocks_uchar_to_float_0, 0), (self.blocks_add_xx_0, 6))
        self.connect((self.blocks_uchar_to_float_0_0, 0), (self.blocks_add_xx_0, 7))
        self.connect((self.blocks_uchar_to_float_0_0_0, 0), (self.blocks_add_xx_0, 5))
        self.connect((self.blocks_uchar_to_float_0_0_0_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.blocks_uchar_to_float_0_0_0_0_0, 0), (self.blocks_add_xx_0_0, 1))
        self.connect((self.blocks_uchar_to_float_0_0_0_1, 0), (self.blocks_add_xx_0_0, 5))
        self.connect((self.blocks_uchar_to_float_0_0_1, 0), (self.blocks_add_xx_0, 3))
        self.connect((self.blocks_uchar_to_float_0_0_1_0, 0), (self.blocks_add_xx_0_0, 3))
        self.connect((self.blocks_uchar_to_float_0_0_2, 0), (self.blocks_add_xx_0_0, 7))
        self.connect((self.blocks_uchar_to_float_0_1, 0), (self.blocks_add_xx_0, 4))
        self.connect((self.blocks_uchar_to_float_0_1_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.blocks_uchar_to_float_0_1_0_0, 0), (self.blocks_add_xx_0_0, 0))
        self.connect((self.blocks_uchar_to_float_0_1_1, 0), (self.blocks_add_xx_0_0, 4))
        self.connect((self.blocks_uchar_to_float_0_2, 0), (self.blocks_add_xx_0, 2))
        self.connect((self.blocks_uchar_to_float_0_2_0, 0), (self.blocks_add_xx_0_0, 2))
        self.connect((self.blocks_uchar_to_float_0_3, 0), (self.blocks_add_xx_0_0, 6))
        self.connect((self.blocks_vector_to_streams_0, 19), (self.Mux_50_RX_0, 5))
        self.connect((self.blocks_vector_to_streams_0, 1), (self.Mux_50_RX_0, 18))
        self.connect((self.blocks_vector_to_streams_0, 16), (self.Mux_50_RX_0, 0))
        self.connect((self.blocks_vector_to_streams_0, 20), (self.Mux_50_RX_0, 2))
        self.connect((self.blocks_vector_to_streams_0, 2), (self.Mux_50_RX_0, 22))
        self.connect((self.blocks_vector_to_streams_0, 4), (self.Mux_50_RX_0, 17))
        self.connect((self.blocks_vector_to_streams_0, 23), (self.Mux_50_RX_0, 20))
        self.connect((self.blocks_vector_to_streams_0, 13), (self.Mux_50_RX_0, 9))
        self.connect((self.blocks_vector_to_streams_0, 11), (self.Mux_50_RX_0, 4))
        self.connect((self.blocks_vector_to_streams_0, 0), (self.Mux_50_RX_0, 14))
        self.connect((self.blocks_vector_to_streams_0, 12), (self.Mux_50_RX_0, 3))
        self.connect((self.blocks_vector_to_streams_0, 5), (self.Mux_50_RX_0, 6))
        self.connect((self.blocks_vector_to_streams_0, 17), (self.Mux_50_RX_0, 11))
        self.connect((self.blocks_vector_to_streams_0, 24), (self.Mux_50_RX_0, 21))
        self.connect((self.blocks_vector_to_streams_0, 9), (self.Mux_50_RX_0, 23))
        self.connect((self.blocks_vector_to_streams_0, 6), (self.Mux_50_RX_0, 16))
        self.connect((self.blocks_vector_to_streams_0, 15), (self.Mux_50_RX_0, 12))
        self.connect((self.blocks_vector_to_streams_0, 18), (self.Mux_50_RX_0, 1))
        self.connect((self.blocks_vector_to_streams_0, 14), (self.Mux_50_RX_0, 13))
        self.connect((self.blocks_vector_to_streams_0, 10), (self.Mux_50_RX_0, 7))
        self.connect((self.blocks_vector_to_streams_0, 21), (self.Mux_50_RX_0, 10))
        self.connect((self.blocks_vector_to_streams_0, 3), (self.Mux_50_RX_0, 8))
        self.connect((self.blocks_vector_to_streams_0, 22), (self.Mux_50_RX_0, 15))
        self.connect((self.blocks_vector_to_streams_0, 8), (self.Mux_50_RX_0, 24))
        self.connect((self.blocks_vector_to_streams_0, 7), (self.Mux_50_RX_0, 19))
        self.connect((self.blocks_vector_to_streams_0, 33), (self.Mux_50_RX_0_0, 24))
        self.connect((self.blocks_vector_to_streams_0, 29), (self.Mux_50_RX_0_0, 17))
        self.connect((self.blocks_vector_to_streams_0, 38), (self.Mux_50_RX_0_0, 9))
        self.connect((self.blocks_vector_to_streams_0, 42), (self.Mux_50_RX_0_0, 11))
        self.connect((self.blocks_vector_to_streams_0, 48), (self.Mux_50_RX_0_0, 20))
        self.connect((self.blocks_vector_to_streams_0, 28), (self.Mux_50_RX_0_0, 8))
        self.connect((self.blocks_vector_to_streams_0, 30), (self.Mux_50_RX_0_0, 6))
        self.connect((self.blocks_vector_to_streams_0, 39), (self.Mux_50_RX_0_0, 13))
        self.connect((self.blocks_vector_to_streams_0, 40), (self.Mux_50_RX_0_0, 12))
        self.connect((self.blocks_vector_to_streams_0, 46), (self.Mux_50_RX_0_0, 10))
        self.connect((self.blocks_vector_to_streams_0, 34), (self.Mux_50_RX_0_0, 23))
        self.connect((self.blocks_vector_to_streams_0, 49), (self.Mux_50_RX_0_0, 21))
        self.connect((self.blocks_vector_to_streams_0, 32), (self.Mux_50_RX_0_0, 19))
        self.connect((self.blocks_vector_to_streams_0, 47), (self.Mux_50_RX_0_0, 15))
        self.connect((self.blocks_vector_to_streams_0, 37), (self.Mux_50_RX_0_0, 3))
        self.connect((self.blocks_vector_to_streams_0, 35), (self.Mux_50_RX_0_0, 7))
        self.connect((self.blocks_vector_to_streams_0, 44), (self.Mux_50_RX_0_0, 5))
        self.connect((self.blocks_vector_to_streams_0, 41), (self.Mux_50_RX_0_0, 0))
        self.connect((self.blocks_vector_to_streams_0, 45), (self.Mux_50_RX_0_0, 2))
        self.connect((self.blocks_vector_to_streams_0, 25), (self.Mux_50_RX_0_0, 14))
        self.connect((self.blocks_vector_to_streams_0, 36), (self.Mux_50_RX_0_0, 4))
        self.connect((self.blocks_vector_to_streams_0, 43), (self.Mux_50_RX_0_0, 1))
        self.connect((self.blocks_vector_to_streams_0, 26), (self.Mux_50_RX_0_0, 18))
        self.connect((self.blocks_vector_to_streams_0, 27), (self.Mux_50_RX_0_0, 22))
        self.connect((self.blocks_vector_to_streams_0, 31), (self.Mux_50_RX_0_0, 16))
        self.connect((self.blocks_vector_to_streams_0, 55), (self.Mux_50_RX_0_1, 6))
        self.connect((self.blocks_vector_to_streams_0, 61), (self.Mux_50_RX_0_1, 4))
        self.connect((self.blocks_vector_to_streams_0, 72), (self.Mux_50_RX_0_1, 15))
        self.connect((self.blocks_vector_to_streams_0, 54), (self.Mux_50_RX_0_1, 17))
        self.connect((self.blocks_vector_to_streams_0, 68), (self.Mux_50_RX_0_1, 1))
        self.connect((self.blocks_vector_to_streams_0, 60), (self.Mux_50_RX_0_1, 7))
        self.connect((self.blocks_vector_to_streams_0, 59), (self.Mux_50_RX_0_1, 23))
        self.connect((self.blocks_vector_to_streams_0, 67), (self.Mux_50_RX_0_1, 11))
        self.connect((self.blocks_vector_to_streams_0, 62), (self.Mux_50_RX_0_1, 3))
        self.connect((self.blocks_vector_to_streams_0, 70), (self.Mux_50_RX_0_1, 2))
        self.connect((self.blocks_vector_to_streams_0, 51), (self.Mux_50_RX_0_1, 18))
        self.connect((self.blocks_vector_to_streams_0, 71), (self.Mux_50_RX_0_1, 10))
        self.connect((self.blocks_vector_to_streams_0, 74), (self.Mux_50_RX_0_1, 21))
        self.connect((self.blocks_vector_to_streams_0, 50), (self.Mux_50_RX_0_1, 14))
        self.connect((self.blocks_vector_to_streams_0, 64), (self.Mux_50_RX_0_1, 13))
        self.connect((self.blocks_vector_to_streams_0, 56), (self.Mux_50_RX_0_1, 16))
        self.connect((self.blocks_vector_to_streams_0, 58), (self.Mux_50_RX_0_1, 24))
        self.connect((self.blocks_vector_to_streams_0, 53), (self.Mux_50_RX_0_1, 8))
        self.connect((self.blocks_vector_to_streams_0, 65), (self.Mux_50_RX_0_1, 12))
        self.connect((self.blocks_vector_to_streams_0, 73), (self.Mux_50_RX_0_1, 20))
        self.connect((self.blocks_vector_to_streams_0, 69), (self.Mux_50_RX_0_1, 5))
        self.connect((self.blocks_vector_to_streams_0, 57), (self.Mux_50_RX_0_1, 19))
        self.connect((self.blocks_vector_to_streams_0, 63), (self.Mux_50_RX_0_1, 9))
        self.connect((self.blocks_vector_to_streams_0, 52), (self.Mux_50_RX_0_1, 22))
        self.connect((self.blocks_vector_to_streams_0, 66), (self.Mux_50_RX_0_1, 0))
        self.connect((self.blocks_vector_to_streams_0, 99), (self.Mux_50_RX_0_2, 21))
        self.connect((self.blocks_vector_to_streams_0, 97), (self.Mux_50_RX_0_2, 15))
        self.connect((self.blocks_vector_to_streams_0, 77), (self.Mux_50_RX_0_2, 22))
        self.connect((self.blocks_vector_to_streams_0, 86), (self.Mux_50_RX_0_2, 4))
        self.connect((self.blocks_vector_to_streams_0, 79), (self.Mux_50_RX_0_2, 17))
        self.connect((self.blocks_vector_to_streams_0, 80), (self.Mux_50_RX_0_2, 6))
        self.connect((self.blocks_vector_to_streams_0, 88), (self.Mux_50_RX_0_2, 9))
        self.connect((self.blocks_vector_to_streams_0, 83), (self.Mux_50_RX_0_2, 24))
        self.connect((self.blocks_vector_to_streams_0, 96), (self.Mux_50_RX_0_2, 10))
        self.connect((self.blocks_vector_to_streams_0, 75), (self.Mux_50_RX_0_2, 14))
        self.connect((self.blocks_vector_to_streams_0, 87), (self.Mux_50_RX_0_2, 3))
        self.connect((self.blocks_vector_to_streams_0, 76), (self.Mux_50_RX_0_2, 18))
        self.connect((self.blocks_vector_to_streams_0, 93), (self.Mux_50_RX_0_2, 1))
        self.connect((self.blocks_vector_to_streams_0, 85), (self.Mux_50_RX_0_2, 7))
        self.connect((self.blocks_vector_to_streams_0, 81), (self.Mux_50_RX_0_2, 16))
        self.connect((self.blocks_vector_to_streams_0, 90), (self.Mux_50_RX_0_2, 12))
        self.connect((self.blocks_vector_to_streams_0, 78), (self.Mux_50_RX_0_2, 8))
        self.connect((self.blocks_vector_to_streams_0, 91), (self.Mux_50_RX_0_2, 0))
        self.connect((self.blocks_vector_to_streams_0, 84), (self.Mux_50_RX_0_2, 23))
        self.connect((self.blocks_vector_to_streams_0, 92), (self.Mux_50_RX_0_2, 11))
        self.connect((self.blocks_vector_to_streams_0, 94), (self.Mux_50_RX_0_2, 5))
        self.connect((self.blocks_vector_to_streams_0, 82), (self.Mux_50_RX_0_2, 19))
        self.connect((self.blocks_vector_to_streams_0, 89), (self.Mux_50_RX_0_2, 13))
        self.connect((self.blocks_vector_to_streams_0, 95), (self.Mux_50_RX_0_2, 2))
        self.connect((self.blocks_vector_to_streams_0, 98), (self.Mux_50_RX_0_2, 20))
        self.connect((self.blocks_vector_to_streams_0, 118), (self.Mux_50_RX_0_3, 1))
        self.connect((self.blocks_vector_to_streams_0, 117), (self.Mux_50_RX_0_3, 11))
        self.connect((self.blocks_vector_to_streams_0, 105), (self.Mux_50_RX_0_3, 6))
        self.connect((self.blocks_vector_to_streams_0, 102), (self.Mux_50_RX_0_3, 22))
        self.connect((self.blocks_vector_to_streams_0, 111), (self.Mux_50_RX_0_3, 4))
        self.connect((self.blocks_vector_to_streams_0, 106), (self.Mux_50_RX_0_3, 16))
        self.connect((self.blocks_vector_to_streams_0, 116), (self.Mux_50_RX_0_3, 0))
        self.connect((self.blocks_vector_to_streams_0, 115), (self.Mux_50_RX_0_3, 12))
        self.connect((self.blocks_vector_to_streams_0, 114), (self.Mux_50_RX_0_3, 13))
        self.connect((self.blocks_vector_to_streams_0, 110), (self.Mux_50_RX_0_3, 7))
        self.connect((self.blocks_vector_to_streams_0, 124), (self.Mux_50_RX_0_3, 21))
        self.connect((self.blocks_vector_to_streams_0, 120), (self.Mux_50_RX_0_3, 2))
        self.connect((self.blocks_vector_to_streams_0, 121), (self.Mux_50_RX_0_3, 10))
        self.connect((self.blocks_vector_to_streams_0, 104), (self.Mux_50_RX_0_3, 17))
        self.connect((self.blocks_vector_to_streams_0, 113), (self.Mux_50_RX_0_3, 9))
        self.connect((self.blocks_vector_to_streams_0, 103), (self.Mux_50_RX_0_3, 8))
        self.connect((self.blocks_vector_to_streams_0, 122), (self.Mux_50_RX_0_3, 15))
        self.connect((self.blocks_vector_to_streams_0, 109), (self.Mux_50_RX_0_3, 23))
        self.connect((self.blocks_vector_to_streams_0, 108), (self.Mux_50_RX_0_3, 24))
        self.connect((self.blocks_vector_to_streams_0, 107), (self.Mux_50_RX_0_3, 19))
        self.connect((self.blocks_vector_to_streams_0, 119), (self.Mux_50_RX_0_3, 5))
        self.connect((self.blocks_vector_to_streams_0, 101), (self.Mux_50_RX_0_3, 18))
        self.connect((self.blocks_vector_to_streams_0, 112), (self.Mux_50_RX_0_3, 3))
        self.connect((self.blocks_vector_to_streams_0, 123), (self.Mux_50_RX_0_3, 20))
        self.connect((self.blocks_vector_to_streams_0, 100), (self.Mux_50_RX_0_3, 14))
        self.connect((self.blocks_vector_to_streams_0, 143), (self.Mux_50_RX_0_4, 1))
        self.connect((self.blocks_vector_to_streams_0, 139), (self.Mux_50_RX_0_4, 13))
        self.connect((self.blocks_vector_to_streams_0, 131), (self.Mux_50_RX_0_4, 16))
        self.connect((self.blocks_vector_to_streams_0, 130), (self.Mux_50_RX_0_4, 6))
        self.connect((self.blocks_vector_to_streams_0, 135), (self.Mux_50_RX_0_4, 7))
        self.connect((self.blocks_vector_to_streams_0, 148), (self.Mux_50_RX_0_4, 20))
        self.connect((self.blocks_vector_to_streams_0, 134), (self.Mux_50_RX_0_4, 23))
        self.connect((self.blocks_vector_to_streams_0, 138), (self.Mux_50_RX_0_4, 9))
        self.connect((self.blocks_vector_to_streams_0, 133), (self.Mux_50_RX_0_4, 24))
        self.connect((self.blocks_vector_to_streams_0, 129), (self.Mux_50_RX_0_4, 17))
        self.connect((self.blocks_vector_to_streams_0, 144), (self.Mux_50_RX_0_4, 5))
        self.connect((self.blocks_vector_to_streams_0, 146), (self.Mux_50_RX_0_4, 10))
        self.connect((self.blocks_vector_to_streams_0, 137), (self.Mux_50_RX_0_4, 3))
        self.connect((self.blocks_vector_to_streams_0, 136), (self.Mux_50_RX_0_4, 4))
        self.connect((self.blocks_vector_to_streams_0, 145), (self.Mux_50_RX_0_4, 2))
        self.connect((self.blocks_vector_to_streams_0, 147), (self.Mux_50_RX_0_4, 15))
        self.connect((self.blocks_vector_to_streams_0, 125), (self.Mux_50_RX_0_4, 14))
        self.connect((self.blocks_vector_to_streams_0, 140), (self.Mux_50_RX_0_4, 12))
        self.connect((self.blocks_vector_to_streams_0, 142), (self.Mux_50_RX_0_4, 11))
        self.connect((self.blocks_vector_to_streams_0, 132), (self.Mux_50_RX_0_4, 19))
        self.connect((self.blocks_vector_to_streams_0, 126), (self.Mux_50_RX_0_4, 18))
        self.connect((self.blocks_vector_to_streams_0, 127), (self.Mux_50_RX_0_4, 22))
        self.connect((self.blocks_vector_to_streams_0, 141), (self.Mux_50_RX_0_4, 0))
        self.connect((self.blocks_vector_to_streams_0, 149), (self.Mux_50_RX_0_4, 21))
        self.connect((self.blocks_vector_to_streams_0, 128), (self.Mux_50_RX_0_4, 8))
        self.connect((self.blocks_vector_to_streams_0, 154), (self.Mux_50_RX_A_0, 17))
        self.connect((self.blocks_vector_to_streams_0, 166), (self.Mux_50_RX_A_0, 0))
        self.connect((self.blocks_vector_to_streams_0, 171), (self.Mux_50_RX_A_0, 10))
        self.connect((self.blocks_vector_to_streams_0, 165), (self.Mux_50_RX_A_0, 12))
        self.connect((self.blocks_vector_to_streams_0, 158), (self.Mux_50_RX_A_0, 24))
        self.connect((self.blocks_vector_to_streams_0, 156), (self.Mux_50_RX_A_0, 16))
        self.connect((self.blocks_vector_to_streams_0, 160), (self.Mux_50_RX_A_0, 7))
        self.connect((self.blocks_vector_to_streams_0, 162), (self.Mux_50_RX_A_0, 3))
        self.connect((self.blocks_vector_to_streams_0, 173), (self.Mux_50_RX_A_0, 20))
        self.connect((self.blocks_vector_to_streams_0, 174), (self.Mux_50_RX_A_0, 21))
        self.connect((self.blocks_vector_to_streams_0, 150), (self.Mux_50_RX_A_0, 14))
        self.connect((self.blocks_vector_to_streams_0, 163), (self.Mux_50_RX_A_0, 9))
        self.connect((self.blocks_vector_to_streams_0, 151), (self.Mux_50_RX_A_0, 18))
        self.connect((self.blocks_vector_to_streams_0, 169), (self.Mux_50_RX_A_0, 5))
        self.connect((self.blocks_vector_to_streams_0, 170), (self.Mux_50_RX_A_0, 2))
        self.connect((self.blocks_vector_to_streams_0, 164), (self.Mux_50_RX_A_0, 13))
        self.connect((self.blocks_vector_to_streams_0, 168), (self.Mux_50_RX_A_0, 1))
        self.connect((self.blocks_vector_to_streams_0, 167), (self.Mux_50_RX_A_0, 11))
        self.connect((self.blocks_vector_to_streams_0, 157), (self.Mux_50_RX_A_0, 19))
        self.connect((self.blocks_vector_to_streams_0, 161), (self.Mux_50_RX_A_0, 4))
        self.connect((self.blocks_vector_to_streams_0, 155), (self.Mux_50_RX_A_0, 6))
        self.connect((self.blocks_vector_to_streams_0, 152), (self.Mux_50_RX_A_0, 22))
        self.connect((self.blocks_vector_to_streams_0, 159), (self.Mux_50_RX_A_0, 23))
        self.connect((self.blocks_vector_to_streams_0, 172), (self.Mux_50_RX_A_0, 15))
        self.connect((self.blocks_vector_to_streams_0, 153), (self.Mux_50_RX_A_0, 8))
        self.connect((self.blocks_vector_to_streams_0, 188), (self.Mux_50_RX_A_1, 9))
        self.connect((self.blocks_vector_to_streams_0, 189), (self.Mux_50_RX_A_1, 13))
        self.connect((self.blocks_vector_to_streams_0, 182), (self.Mux_50_RX_A_1, 19))
        self.connect((self.blocks_vector_to_streams_0, 183), (self.Mux_50_RX_A_1, 24))
        self.connect((self.blocks_vector_to_streams_0, 181), (self.Mux_50_RX_A_1, 16))
        self.connect((self.blocks_vector_to_streams_0, 187), (self.Mux_50_RX_A_1, 3))
        self.connect((self.blocks_vector_to_streams_0, 192), (self.Mux_50_RX_A_1, 11))
        self.connect((self.blocks_vector_to_streams_0, 186), (self.Mux_50_RX_A_1, 4))
        self.connect((self.blocks_vector_to_streams_0, 179), (self.Mux_50_RX_A_1, 17))
        self.connect((self.blocks_vector_to_streams_0, 175), (self.Mux_50_RX_A_1, 14))
        self.connect((self.blocks_vector_to_streams_0, 178), (self.Mux_50_RX_A_1, 8))
        self.connect((self.blocks_vector_to_streams_0, 191), (self.Mux_50_RX_A_1, 0))
        self.connect((self.blocks_vector_to_streams_0, 198), (self.Mux_50_RX_A_1, 20))
        self.connect((self.blocks_vector_to_streams_0, 176), (self.Mux_50_RX_A_1, 18))
        self.connect((self.blocks_vector_to_streams_0, 195), (self.Mux_50_RX_A_1, 2))
        self.connect((self.blocks_vector_to_streams_0, 196), (self.Mux_50_RX_A_1, 10))
        self.connect((self.blocks_vector_to_streams_0, 177), (self.Mux_50_RX_A_1, 22))
        self.connect((self.blocks_vector_to_streams_0, 184), (self.Mux_50_RX_A_1, 23))
        self.connect((self.blocks_vector_to_streams_0, 194), (self.Mux_50_RX_A_1, 5))
        self.connect((self.blocks_vector_to_streams_0, 193), (self.Mux_50_RX_A_1, 1))
        self.connect((self.blocks_vector_to_streams_0, 180), (self.Mux_50_RX_A_1, 6))
        self.connect((self.blocks_vector_to_streams_0, 197), (self.Mux_50_RX_A_1, 15))
        self.connect((self.blocks_vector_to_streams_0, 190), (self.Mux_50_RX_A_1, 12))
        self.connect((self.blocks_vector_to_streams_0, 185), (self.Mux_50_RX_A_1, 7))
        self.connect((self.blocks_vector_to_streams_0, 199), (self.Mux_50_RX_A_1, 21))
        self.connect((self.fft_vxx_0, 0), (self.blocks_vector_to_streams_0, 0))
        self.connect((self, 0), (self.blocks_stream_to_vector_0, 0))


