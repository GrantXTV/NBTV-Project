import numpy as np
from gnuradio import gr
import pmt
from collections import deque


class blk(gr.sync_block):
    def __init__(self, period=120, ma_length=10):
        gr.sync_block.__init__(self, name='Sync Delay Calc',
                               in_sig=[np.uint8, np.uint8],
                               out_sig=[np.uint8])
        self.period = period
        self.ma_length = ma_length
        self.delay_window = deque(maxlen=ma_length)
        self.hold = False
        self.last_ref_pos = None
        self.last_unk_pos = None
        self.ref_was_high = False
        self.unk_was_high = False
        self.first_pair_done = False
        self.message_port_register_out(pmt.intern('delay'))
        self.message_port_register_out(pmt.intern('delay_ma'))
        self.message_port_register_in(pmt.intern('toggle'))
        self.set_msg_handler(pmt.intern('toggle'), self.handle_toggle)

    def handle_toggle(self, msg):
        if pmt.is_pair(msg):
            val = pmt.to_long(pmt.cdr(msg))
        else:
            val = pmt.to_long(msg)
        self.hold = (val == 0)
        #print(f"toggle: val={val} hold={self.hold}", flush=True)

    def work(self, input_items, output_items):
        ref = input_items[0]
        unk = input_items[1]
        out = output_items[0]
        n = len(ref)
        for i in range(n):
            if ref[i] == 255 and not self.ref_was_high:
                self.last_ref_pos = self.nitems_read(0) + i
            self.ref_was_high = (ref[i] == 255)
            if unk[i] == 255 and not self.unk_was_high:
                self.last_unk_pos = self.nitems_read(1) + i
            self.unk_was_high = (unk[i] == 255)
            if self.last_ref_pos is not None and self.last_unk_pos is not None:
                delay_samples = self.last_unk_pos - self.last_ref_pos
                if not self.first_pair_done:
                    self.first_pair_done = True
                    self.last_ref_pos = None
                    self.last_unk_pos = None
                else:
                    result = self.period - delay_samples
                    self.delay_window.append(result)
                    ma_result = sum(self.delay_window) / len(self.delay_window)
                    if not self.hold:
                        self.message_port_pub(pmt.intern('delay'), pmt.from_long(result))
                        self.message_port_pub(pmt.intern('delay_ma'), pmt.from_long(round(ma_result)))
                    self.last_ref_pos = None
                    self.last_unk_pos = None
        out[:n] = ref[:n]
        return n
