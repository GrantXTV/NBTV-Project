# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Rate Downconverter 10
# GNU Radio version: 3.10.12.0

from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class Rate_Downconverter_10(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Rate Downconverter 10",
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
        )

        ##################################################
        # Blocks
        ##################################################

        self.blocks_multiply_const_vxx_0_2_0 = blocks.multiply_const_cc(1/10)
        self.blocks_deinterleave_0_0 = blocks.deinterleave(gr.sizeof_gr_complex*1, 1)
        self.blocks_deinterleave_0 = blocks.deinterleave(gr.sizeof_gr_complex*1, 1)
        self.blocks_add_xx_0_0 = blocks.add_vcc(1)
        self.blocks_add_xx_0 = blocks.add_vcc(1)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_deinterleave_0_0, 0))
        self.connect((self.blocks_add_xx_0_0, 0), (self.blocks_multiply_const_vxx_0_2_0, 0))
        self.connect((self.blocks_deinterleave_0, 4), (self.blocks_add_xx_0, 4))
        self.connect((self.blocks_deinterleave_0, 3), (self.blocks_add_xx_0, 3))
        self.connect((self.blocks_deinterleave_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.blocks_deinterleave_0, 2), (self.blocks_add_xx_0, 2))
        self.connect((self.blocks_deinterleave_0, 1), (self.blocks_add_xx_0, 1))
        self.connect((self.blocks_deinterleave_0_0, 0), (self.blocks_add_xx_0_0, 0))
        self.connect((self.blocks_deinterleave_0_0, 1), (self.blocks_add_xx_0_0, 1))
        self.connect((self.blocks_multiply_const_vxx_0_2_0, 0), (self, 0))
        self.connect((self, 0), (self.blocks_deinterleave_0, 0))


