#!/bin/bash
./OFDM_Loopback_v2_120/OFDM_Loopback_v2_120.py
