# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Mux 74 TX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from QAM_Mod import QAM_Mod  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
import threading







class Mux_74_TX(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Mux 74 TX",
                gr.io_signature.makev(3, 3, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
                gr.io_signature.makev(37, 37, [gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1]),
        )

        ##################################################
        # Variables
        ##################################################
        self.DB = DB = 180

        ##################################################
        # Blocks
        ##################################################

        self.blocks_stream_demux_1 = blocks.stream_demux(gr.sizeof_char*1, (DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB))
        self.QAM_Mod_0_4_6_0_0_0 = QAM_Mod()
        self.QAM_Mod_0_4_6_0_0 = QAM_Mod()
        self.QAM_Mod_0_4_6_0 = QAM_Mod()
        self.QAM_Mod_0_4_6 = QAM_Mod()
        self.QAM_Mod_0_4_5 = QAM_Mod()
        self.QAM_Mod_0_4_4 = QAM_Mod()
        self.QAM_Mod_0_4_3 = QAM_Mod()
        self.QAM_Mod_0_4_2 = QAM_Mod()
        self.QAM_Mod_0_4_1 = QAM_Mod()
        self.QAM_Mod_0_4_0 = QAM_Mod()
        self.QAM_Mod_0_4 = QAM_Mod()
        self.QAM_Mod_0_3 = QAM_Mod()
        self.QAM_Mod_0_2 = QAM_Mod()
        self.QAM_Mod_0_1 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_1_0_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_1_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_1 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_0_0_0_0_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_0_0_0_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_0_0_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_0_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_6_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_6 = QAM_Mod()
        self.QAM_Mod_0_0_3_5_0_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_5_0 = QAM_Mod()
        self.QAM_Mod_0_0_3_5 = QAM_Mod()
        self.QAM_Mod_0_0_3_4 = QAM_Mod()
        self.QAM_Mod_0_0_3_3 = QAM_Mod()
        self.QAM_Mod_0_0_3_2 = QAM_Mod()
        self.QAM_Mod_0_0_3_1 = QAM_Mod()
        self.QAM_Mod_0_0_3_0 = QAM_Mod()
        self.QAM_Mod_0_0_3 = QAM_Mod()
        self.QAM_Mod_0_0_2 = QAM_Mod()
        self.QAM_Mod_0_0_1 = QAM_Mod()
        self.QAM_Mod_0_0_0 = QAM_Mod()
        self.QAM_Mod_0_0 = QAM_Mod()
        self.QAM_Mod_0 = QAM_Mod()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.QAM_Mod_0, 0), (self, 20))
        self.connect((self.QAM_Mod_0_0, 0), (self, 12))
        self.connect((self.QAM_Mod_0_0_0, 0), (self, 0))
        self.connect((self.QAM_Mod_0_0_1, 0), (self, 30))
        self.connect((self.QAM_Mod_0_0_2, 0), (self, 1))
        self.connect((self.QAM_Mod_0_0_3, 0), (self, 21))
        self.connect((self.QAM_Mod_0_0_3_0, 0), (self, 22))
        self.connect((self.QAM_Mod_0_0_3_1, 0), (self, 26))
        self.connect((self.QAM_Mod_0_0_3_2, 0), (self, 36))
        self.connect((self.QAM_Mod_0_0_3_3, 0), (self, 35))
        self.connect((self.QAM_Mod_0_0_3_4, 0), (self, 34))
        self.connect((self.QAM_Mod_0_0_3_5, 0), (self, 31))
        self.connect((self.QAM_Mod_0_0_3_5_0, 0), (self, 32))
        self.connect((self.QAM_Mod_0_0_3_5_0_0, 0), (self, 33))
        self.connect((self.QAM_Mod_0_0_3_6, 0), (self, 3))
        self.connect((self.QAM_Mod_0_0_3_6_0, 0), (self, 4))
        self.connect((self.QAM_Mod_0_0_3_6_0_0, 0), (self, 5))
        self.connect((self.QAM_Mod_0_0_3_6_0_0_0, 0), (self, 6))
        self.connect((self.QAM_Mod_0_0_3_6_0_0_0_0, 0), (self, 7))
        self.connect((self.QAM_Mod_0_0_3_6_0_0_0_0_0, 0), (self, 8))
        self.connect((self.QAM_Mod_0_0_3_6_1, 0), (self, 9))
        self.connect((self.QAM_Mod_0_0_3_6_1_0, 0), (self, 10))
        self.connect((self.QAM_Mod_0_0_3_6_1_0_0, 0), (self, 11))
        self.connect((self.QAM_Mod_0_1, 0), (self, 28))
        self.connect((self.QAM_Mod_0_2, 0), (self, 23))
        self.connect((self.QAM_Mod_0_3, 0), (self, 14))
        self.connect((self.QAM_Mod_0_4, 0), (self, 27))
        self.connect((self.QAM_Mod_0_4_0, 0), (self, 2))
        self.connect((self.QAM_Mod_0_4_1, 0), (self, 19))
        self.connect((self.QAM_Mod_0_4_2, 0), (self, 24))
        self.connect((self.QAM_Mod_0_4_3, 0), (self, 25))
        self.connect((self.QAM_Mod_0_4_4, 0), (self, 29))
        self.connect((self.QAM_Mod_0_4_5, 0), (self, 13))
        self.connect((self.QAM_Mod_0_4_6, 0), (self, 15))
        self.connect((self.QAM_Mod_0_4_6_0, 0), (self, 16))
        self.connect((self.QAM_Mod_0_4_6_0_0, 0), (self, 17))
        self.connect((self.QAM_Mod_0_4_6_0_0_0, 0), (self, 18))
        self.connect((self.blocks_stream_demux_1, 0), (self.QAM_Mod_0, 0))
        self.connect((self.blocks_stream_demux_1, 1), (self.QAM_Mod_0, 1))
        self.connect((self.blocks_stream_demux_1, 2), (self.QAM_Mod_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 3), (self.QAM_Mod_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 7), (self.QAM_Mod_0_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 6), (self.QAM_Mod_0_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 10), (self.QAM_Mod_0_0_1, 1))
        self.connect((self.blocks_stream_demux_1, 11), (self.QAM_Mod_0_0_1, 0))
        self.connect((self.blocks_stream_demux_1, 15), (self.QAM_Mod_0_0_2, 0))
        self.connect((self.blocks_stream_demux_1, 14), (self.QAM_Mod_0_0_2, 1))
        self.connect((self.blocks_stream_demux_1, 19), (self.QAM_Mod_0_0_3, 0))
        self.connect((self.blocks_stream_demux_1, 18), (self.QAM_Mod_0_0_3, 1))
        self.connect((self.blocks_stream_demux_1, 22), (self.QAM_Mod_0_0_3_0, 1))
        self.connect((self.blocks_stream_demux_1, 23), (self.QAM_Mod_0_0_3_0, 0))
        self.connect((self.blocks_stream_demux_1, 27), (self.QAM_Mod_0_0_3_1, 0))
        self.connect((self.blocks_stream_demux_1, 26), (self.QAM_Mod_0_0_3_1, 1))
        self.connect((self.blocks_stream_demux_1, 30), (self.QAM_Mod_0_0_3_2, 1))
        self.connect((self.blocks_stream_demux_1, 31), (self.QAM_Mod_0_0_3_2, 0))
        self.connect((self.blocks_stream_demux_1, 34), (self.QAM_Mod_0_0_3_3, 1))
        self.connect((self.blocks_stream_demux_1, 35), (self.QAM_Mod_0_0_3_3, 0))
        self.connect((self.blocks_stream_demux_1, 38), (self.QAM_Mod_0_0_3_4, 1))
        self.connect((self.blocks_stream_demux_1, 39), (self.QAM_Mod_0_0_3_4, 0))
        self.connect((self.blocks_stream_demux_1, 43), (self.QAM_Mod_0_0_3_5, 0))
        self.connect((self.blocks_stream_demux_1, 42), (self.QAM_Mod_0_0_3_5, 1))
        self.connect((self.blocks_stream_demux_1, 51), (self.QAM_Mod_0_0_3_5_0, 0))
        self.connect((self.blocks_stream_demux_1, 50), (self.QAM_Mod_0_0_3_5_0, 1))
        self.connect((self.blocks_stream_demux_1, 58), (self.QAM_Mod_0_0_3_5_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 59), (self.QAM_Mod_0_0_3_5_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 47), (self.QAM_Mod_0_0_3_6, 0))
        self.connect((self.blocks_stream_demux_1, 46), (self.QAM_Mod_0_0_3_6, 1))
        self.connect((self.blocks_stream_demux_1, 48), (self.QAM_Mod_0_0_3_6_0, 0))
        self.connect((self.blocks_stream_demux_1, 49), (self.QAM_Mod_0_0_3_6_0, 1))
        self.connect((self.blocks_stream_demux_1, 57), (self.QAM_Mod_0_0_3_6_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 56), (self.QAM_Mod_0_0_3_6_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 64), (self.QAM_Mod_0_0_3_6_0_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 65), (self.QAM_Mod_0_0_3_6_0_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 70), (self.QAM_Mod_0_0_3_6_0_0_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 71), (self.QAM_Mod_0_0_3_6_0_0_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 54), (self.QAM_Mod_0_0_3_6_1, 1))
        self.connect((self.blocks_stream_demux_1, 55), (self.QAM_Mod_0_0_3_6_1, 0))
        self.connect((self.blocks_stream_demux_1, 62), (self.QAM_Mod_0_0_3_6_1_0, 1))
        self.connect((self.blocks_stream_demux_1, 63), (self.QAM_Mod_0_0_3_6_1_0, 0))
        self.connect((self.blocks_stream_demux_1, 69), (self.QAM_Mod_0_0_3_6_1_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 68), (self.QAM_Mod_0_0_3_6_1_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 4), (self.QAM_Mod_0_1, 0))
        self.connect((self.blocks_stream_demux_1, 5), (self.QAM_Mod_0_1, 1))
        self.connect((self.blocks_stream_demux_1, 8), (self.QAM_Mod_0_2, 0))
        self.connect((self.blocks_stream_demux_1, 9), (self.QAM_Mod_0_2, 1))
        self.connect((self.blocks_stream_demux_1, 13), (self.QAM_Mod_0_3, 1))
        self.connect((self.blocks_stream_demux_1, 12), (self.QAM_Mod_0_3, 0))
        self.connect((self.blocks_stream_demux_1, 17), (self.QAM_Mod_0_4, 1))
        self.connect((self.blocks_stream_demux_1, 16), (self.QAM_Mod_0_4, 0))
        self.connect((self.blocks_stream_demux_1, 21), (self.QAM_Mod_0_4_0, 1))
        self.connect((self.blocks_stream_demux_1, 20), (self.QAM_Mod_0_4_0, 0))
        self.connect((self.blocks_stream_demux_1, 25), (self.QAM_Mod_0_4_1, 1))
        self.connect((self.blocks_stream_demux_1, 24), (self.QAM_Mod_0_4_1, 0))
        self.connect((self.blocks_stream_demux_1, 29), (self.QAM_Mod_0_4_2, 1))
        self.connect((self.blocks_stream_demux_1, 28), (self.QAM_Mod_0_4_2, 0))
        self.connect((self.blocks_stream_demux_1, 33), (self.QAM_Mod_0_4_3, 1))
        self.connect((self.blocks_stream_demux_1, 32), (self.QAM_Mod_0_4_3, 0))
        self.connect((self.blocks_stream_demux_1, 37), (self.QAM_Mod_0_4_4, 1))
        self.connect((self.blocks_stream_demux_1, 36), (self.QAM_Mod_0_4_4, 0))
        self.connect((self.blocks_stream_demux_1, 41), (self.QAM_Mod_0_4_5, 1))
        self.connect((self.blocks_stream_demux_1, 40), (self.QAM_Mod_0_4_5, 0))
        self.connect((self.blocks_stream_demux_1, 45), (self.QAM_Mod_0_4_6, 1))
        self.connect((self.blocks_stream_demux_1, 44), (self.QAM_Mod_0_4_6, 0))
        self.connect((self.blocks_stream_demux_1, 52), (self.QAM_Mod_0_4_6_0, 0))
        self.connect((self.blocks_stream_demux_1, 53), (self.QAM_Mod_0_4_6_0, 1))
        self.connect((self.blocks_stream_demux_1, 61), (self.QAM_Mod_0_4_6_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 60), (self.QAM_Mod_0_4_6_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 66), (self.QAM_Mod_0_4_6_0_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 67), (self.QAM_Mod_0_4_6_0_0_0, 0))
        self.connect((self, 0), (self.blocks_stream_demux_1, 0))
        self.connect((self, 1), (self.QAM_Mod_0_0_3_6_0_0_0_0_0, 1))
        self.connect((self, 2), (self.QAM_Mod_0_0_3_6_0_0_0_0_0, 0))


    def get_DB(self):
        return self.DB

    def set_DB(self, DB):
        self.DB = DB

