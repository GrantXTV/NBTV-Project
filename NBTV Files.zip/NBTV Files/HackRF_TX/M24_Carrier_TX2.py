# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: M24 Carrier TX2
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from QAM_Mod import QAM_Mod  # grc-generated hier_block
from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import signal
import threading







class M24_Carrier_TX2(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "M24 Carrier TX2",
                gr.io_signature(1, 1, gr.sizeof_char*1),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 200000
        self.T_set_0 = T_set_0 = 1
        self.T_set = T_set = 4
        self.Scale = Scale = 400
        self.Ran_value = Ran_value = 479
        self.Level = Level = 1
        self.H_rate = H_rate = 48000
        self.Freq = Freq = 500
        self.Filter = Filter = 250
        self.DB = DB = 48
        self.Cut_off = Cut_off = 250
        self.Beta = Beta = 7.84

        ##################################################
        # Blocks
        ##################################################

        self.rational_resampler_xxx_0_2_0_0_4_2_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_4_2 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_4_1 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_4_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_4 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_3 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_2_0_2 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_2_0_1 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_2_0_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_2_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_2 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_1_0_2 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_1_0_1 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_1_0_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_1_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_1 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_1_2_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_1_2 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_1_1 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_1_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_1 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.rational_resampler_xxx_0_2_0_0 = filter.rational_resampler_ccc(
                interpolation=Scale,
                decimation=1,
                taps=[T_set],
                fractional_bw=0)
        self.filter_fft_low_pass_filter_0_7 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_6 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_5 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_4 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_3 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_2_4 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_2_3 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_2_2 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_2_1 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_2_0 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_2 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_1_4 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_1_3 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_1_2 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_1_1 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_1_0 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_1 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_0_4 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_0_3 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_0_2 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_0_1 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_0_0 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0_0 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.filter_fft_low_pass_filter_0 = filter.fft_filter_ccc(1, firdes.low_pass(Level, samp_rate, Filter, Cut_off, window.WIN_HANN, 6.76), 1)
        self.blocks_stream_demux_1 = blocks.stream_demux(gr.sizeof_char*1, (DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB,DB))
        self.blocks_multiply_xx_0_1_0_1_5 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_4 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_3 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_2 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_1 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_0_3 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_0_2 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_0_1 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_0_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_1 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_5 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_4 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_3 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_2 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_1 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_0_3 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_0_2 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_0_1 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_0_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_xx_0_1_0 = blocks.multiply_vcc(1)
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(.03125*8)
        self.blocks_add_xx_0 = blocks.add_vcc(1)
        self.analog_sig_source_x_0_0_0_0_1_5 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*47), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_4 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*43), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*39), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*35), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*31), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*45), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*41), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*37), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*33), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*29), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*27), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_5 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*48), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_4 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*44), 1, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*40), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*36), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*32), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_3 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*46), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_2 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*42), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_1 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*38), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*34), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*30), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*28), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*26), T_set_0, 0, 0)
        self.analog_sig_source_x_0_0_0_0 = analog.sig_source_c(samp_rate, analog.GR_SIN_WAVE, (Freq*25), T_set_0, 0, 0)
        self.QAM_Mod_0_4_6 = QAM_Mod()
        self.QAM_Mod_0_4_5 = QAM_Mod()
        self.QAM_Mod_0_4_4 = QAM_Mod()
        self.QAM_Mod_0_4_3 = QAM_Mod()
        self.QAM_Mod_0_4_2 = QAM_Mod()
        self.QAM_Mod_0_4_1 = QAM_Mod()
        self.QAM_Mod_0_4_0 = QAM_Mod()
        self.QAM_Mod_0_4 = QAM_Mod()
        self.QAM_Mod_0_3 = QAM_Mod()
        self.QAM_Mod_0_2 = QAM_Mod()
        self.QAM_Mod_0_1 = QAM_Mod()
        self.QAM_Mod_0_0_3_6 = QAM_Mod()
        self.QAM_Mod_0_0_3_5 = QAM_Mod()
        self.QAM_Mod_0_0_3_4 = QAM_Mod()
        self.QAM_Mod_0_0_3_3 = QAM_Mod()
        self.QAM_Mod_0_0_3_2 = QAM_Mod()
        self.QAM_Mod_0_0_3_1 = QAM_Mod()
        self.QAM_Mod_0_0_3_0 = QAM_Mod()
        self.QAM_Mod_0_0_3 = QAM_Mod()
        self.QAM_Mod_0_0_2 = QAM_Mod()
        self.QAM_Mod_0_0_1 = QAM_Mod()
        self.QAM_Mod_0_0_0 = QAM_Mod()
        self.QAM_Mod_0_0 = QAM_Mod()
        self.QAM_Mod_0 = QAM_Mod()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.QAM_Mod_0, 0), (self.rational_resampler_xxx_0_2_0_0, 0))
        self.connect((self.QAM_Mod_0_0, 0), (self.rational_resampler_xxx_0_2_0_0_0, 0))
        self.connect((self.QAM_Mod_0_0_0, 0), (self.rational_resampler_xxx_0_2_0_0_2, 0))
        self.connect((self.QAM_Mod_0_0_1, 0), (self.rational_resampler_xxx_0_2_0_0_0_0, 0))
        self.connect((self.QAM_Mod_0_0_2, 0), (self.rational_resampler_xxx_0_2_0_0_2_0, 0))
        self.connect((self.QAM_Mod_0_0_3, 0), (self.rational_resampler_xxx_0_2_0_0_0_1, 0))
        self.connect((self.QAM_Mod_0_0_3_0, 0), (self.rational_resampler_xxx_0_2_0_0_2_0_0, 0))
        self.connect((self.QAM_Mod_0_0_3_1, 0), (self.rational_resampler_xxx_0_2_0_0_0_1_0, 0))
        self.connect((self.QAM_Mod_0_0_3_2, 0), (self.rational_resampler_xxx_0_2_0_0_2_0_1, 0))
        self.connect((self.QAM_Mod_0_0_3_3, 0), (self.rational_resampler_xxx_0_2_0_0_0_1_1, 0))
        self.connect((self.QAM_Mod_0_0_3_4, 0), (self.rational_resampler_xxx_0_2_0_0_2_0_2, 0))
        self.connect((self.QAM_Mod_0_0_3_5, 0), (self.rational_resampler_xxx_0_2_0_0_0_1_2, 0))
        self.connect((self.QAM_Mod_0_0_3_6, 0), (self.rational_resampler_xxx_0_2_0_0_0_1_2_0, 0))
        self.connect((self.QAM_Mod_0_1, 0), (self.rational_resampler_xxx_0_2_0_0_1, 0))
        self.connect((self.QAM_Mod_0_2, 0), (self.rational_resampler_xxx_0_2_0_0_3, 0))
        self.connect((self.QAM_Mod_0_3, 0), (self.rational_resampler_xxx_0_2_0_0_1_0, 0))
        self.connect((self.QAM_Mod_0_4, 0), (self.rational_resampler_xxx_0_2_0_0_4, 0))
        self.connect((self.QAM_Mod_0_4_0, 0), (self.rational_resampler_xxx_0_2_0_0_1_0_0, 0))
        self.connect((self.QAM_Mod_0_4_1, 0), (self.rational_resampler_xxx_0_2_0_0_4_0, 0))
        self.connect((self.QAM_Mod_0_4_2, 0), (self.rational_resampler_xxx_0_2_0_0_1_0_1, 0))
        self.connect((self.QAM_Mod_0_4_3, 0), (self.rational_resampler_xxx_0_2_0_0_4_1, 0))
        self.connect((self.QAM_Mod_0_4_4, 0), (self.rational_resampler_xxx_0_2_0_0_1_0_2, 0))
        self.connect((self.QAM_Mod_0_4_5, 0), (self.rational_resampler_xxx_0_2_0_0_4_2, 0))
        self.connect((self.QAM_Mod_0_4_6, 0), (self.rational_resampler_xxx_0_2_0_0_4_2_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0, 0), (self.blocks_multiply_xx_0_1_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_1_0_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_1_0_0_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_1_0_0_0_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_0, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_1, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_1, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_2, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_2, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_0_3, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_3, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_1, 0), (self.blocks_multiply_xx_0_1_0_0_0_1, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_2, 0), (self.blocks_multiply_xx_0_1_0_0_0_2, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_3, 0), (self.blocks_multiply_xx_0_1_0_0_0_3, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_4, 0), (self.blocks_multiply_xx_0_1_0_0_0_4, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_0_0_5, 0), (self.blocks_multiply_xx_0_1_0_0_0_5, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1, 0), (self.blocks_multiply_xx_0_1_0_1, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0, 0), (self.blocks_multiply_xx_0_1_0_1_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_0, 0), (self.blocks_multiply_xx_0_1_0_1_0_0, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_1, 0), (self.blocks_multiply_xx_0_1_0_1_0_1, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_2, 0), (self.blocks_multiply_xx_0_1_0_1_0_2, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_0_3, 0), (self.blocks_multiply_xx_0_1_0_1_0_3, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_1, 0), (self.blocks_multiply_xx_0_1_0_1_1, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_2, 0), (self.blocks_multiply_xx_0_1_0_1_2, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_3, 0), (self.blocks_multiply_xx_0_1_0_1_3, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_4, 0), (self.blocks_multiply_xx_0_1_0_1_4, 0))
        self.connect((self.analog_sig_source_x_0_0_0_0_1_5, 0), (self.blocks_multiply_xx_0_1_0_1_5, 0))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self, 0))
        self.connect((self.blocks_multiply_xx_0_1_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.blocks_multiply_xx_0_1_0_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0, 0), (self.blocks_add_xx_0, 3))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_0, 0), (self.blocks_add_xx_0, 5))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_0_0, 0), (self.blocks_add_xx_0, 9))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_0_1, 0), (self.blocks_add_xx_0, 13))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_0_2, 0), (self.blocks_add_xx_0, 17))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_0_3, 0), (self.blocks_add_xx_0, 21))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_1, 0), (self.blocks_add_xx_0, 7))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_2, 0), (self.blocks_add_xx_0, 11))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_3, 0), (self.blocks_add_xx_0, 15))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_4, 0), (self.blocks_add_xx_0, 19))
        self.connect((self.blocks_multiply_xx_0_1_0_0_0_5, 0), (self.blocks_add_xx_0, 23))
        self.connect((self.blocks_multiply_xx_0_1_0_1, 0), (self.blocks_add_xx_0, 2))
        self.connect((self.blocks_multiply_xx_0_1_0_1_0, 0), (self.blocks_add_xx_0, 4))
        self.connect((self.blocks_multiply_xx_0_1_0_1_0_0, 0), (self.blocks_add_xx_0, 8))
        self.connect((self.blocks_multiply_xx_0_1_0_1_0_1, 0), (self.blocks_add_xx_0, 12))
        self.connect((self.blocks_multiply_xx_0_1_0_1_0_2, 0), (self.blocks_add_xx_0, 16))
        self.connect((self.blocks_multiply_xx_0_1_0_1_0_3, 0), (self.blocks_add_xx_0, 20))
        self.connect((self.blocks_multiply_xx_0_1_0_1_1, 0), (self.blocks_add_xx_0, 6))
        self.connect((self.blocks_multiply_xx_0_1_0_1_2, 0), (self.blocks_add_xx_0, 10))
        self.connect((self.blocks_multiply_xx_0_1_0_1_3, 0), (self.blocks_add_xx_0, 14))
        self.connect((self.blocks_multiply_xx_0_1_0_1_4, 0), (self.blocks_add_xx_0, 18))
        self.connect((self.blocks_multiply_xx_0_1_0_1_5, 0), (self.blocks_add_xx_0, 22))
        self.connect((self.blocks_stream_demux_1, 1), (self.QAM_Mod_0, 1))
        self.connect((self.blocks_stream_demux_1, 0), (self.QAM_Mod_0, 0))
        self.connect((self.blocks_stream_demux_1, 3), (self.QAM_Mod_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 2), (self.QAM_Mod_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 6), (self.QAM_Mod_0_0_0, 1))
        self.connect((self.blocks_stream_demux_1, 7), (self.QAM_Mod_0_0_0, 0))
        self.connect((self.blocks_stream_demux_1, 11), (self.QAM_Mod_0_0_1, 0))
        self.connect((self.blocks_stream_demux_1, 10), (self.QAM_Mod_0_0_1, 1))
        self.connect((self.blocks_stream_demux_1, 14), (self.QAM_Mod_0_0_2, 1))
        self.connect((self.blocks_stream_demux_1, 15), (self.QAM_Mod_0_0_2, 0))
        self.connect((self.blocks_stream_demux_1, 19), (self.QAM_Mod_0_0_3, 0))
        self.connect((self.blocks_stream_demux_1, 18), (self.QAM_Mod_0_0_3, 1))
        self.connect((self.blocks_stream_demux_1, 23), (self.QAM_Mod_0_0_3_0, 0))
        self.connect((self.blocks_stream_demux_1, 22), (self.QAM_Mod_0_0_3_0, 1))
        self.connect((self.blocks_stream_demux_1, 26), (self.QAM_Mod_0_0_3_1, 1))
        self.connect((self.blocks_stream_demux_1, 27), (self.QAM_Mod_0_0_3_1, 0))
        self.connect((self.blocks_stream_demux_1, 30), (self.QAM_Mod_0_0_3_2, 1))
        self.connect((self.blocks_stream_demux_1, 31), (self.QAM_Mod_0_0_3_2, 0))
        self.connect((self.blocks_stream_demux_1, 34), (self.QAM_Mod_0_0_3_3, 1))
        self.connect((self.blocks_stream_demux_1, 35), (self.QAM_Mod_0_0_3_3, 0))
        self.connect((self.blocks_stream_demux_1, 39), (self.QAM_Mod_0_0_3_4, 0))
        self.connect((self.blocks_stream_demux_1, 38), (self.QAM_Mod_0_0_3_4, 1))
        self.connect((self.blocks_stream_demux_1, 43), (self.QAM_Mod_0_0_3_5, 0))
        self.connect((self.blocks_stream_demux_1, 42), (self.QAM_Mod_0_0_3_5, 1))
        self.connect((self.blocks_stream_demux_1, 46), (self.QAM_Mod_0_0_3_6, 1))
        self.connect((self.blocks_stream_demux_1, 47), (self.QAM_Mod_0_0_3_6, 0))
        self.connect((self.blocks_stream_demux_1, 5), (self.QAM_Mod_0_1, 1))
        self.connect((self.blocks_stream_demux_1, 4), (self.QAM_Mod_0_1, 0))
        self.connect((self.blocks_stream_demux_1, 9), (self.QAM_Mod_0_2, 1))
        self.connect((self.blocks_stream_demux_1, 8), (self.QAM_Mod_0_2, 0))
        self.connect((self.blocks_stream_demux_1, 13), (self.QAM_Mod_0_3, 1))
        self.connect((self.blocks_stream_demux_1, 12), (self.QAM_Mod_0_3, 0))
        self.connect((self.blocks_stream_demux_1, 16), (self.QAM_Mod_0_4, 0))
        self.connect((self.blocks_stream_demux_1, 17), (self.QAM_Mod_0_4, 1))
        self.connect((self.blocks_stream_demux_1, 20), (self.QAM_Mod_0_4_0, 0))
        self.connect((self.blocks_stream_demux_1, 21), (self.QAM_Mod_0_4_0, 1))
        self.connect((self.blocks_stream_demux_1, 25), (self.QAM_Mod_0_4_1, 1))
        self.connect((self.blocks_stream_demux_1, 24), (self.QAM_Mod_0_4_1, 0))
        self.connect((self.blocks_stream_demux_1, 29), (self.QAM_Mod_0_4_2, 1))
        self.connect((self.blocks_stream_demux_1, 28), (self.QAM_Mod_0_4_2, 0))
        self.connect((self.blocks_stream_demux_1, 33), (self.QAM_Mod_0_4_3, 1))
        self.connect((self.blocks_stream_demux_1, 32), (self.QAM_Mod_0_4_3, 0))
        self.connect((self.blocks_stream_demux_1, 37), (self.QAM_Mod_0_4_4, 1))
        self.connect((self.blocks_stream_demux_1, 36), (self.QAM_Mod_0_4_4, 0))
        self.connect((self.blocks_stream_demux_1, 41), (self.QAM_Mod_0_4_5, 1))
        self.connect((self.blocks_stream_demux_1, 40), (self.QAM_Mod_0_4_5, 0))
        self.connect((self.blocks_stream_demux_1, 44), (self.QAM_Mod_0_4_6, 0))
        self.connect((self.blocks_stream_demux_1, 45), (self.QAM_Mod_0_4_6, 1))
        self.connect((self.filter_fft_low_pass_filter_0, 0), (self.blocks_multiply_xx_0_1_0, 1))
        self.connect((self.filter_fft_low_pass_filter_0_0, 0), (self.blocks_multiply_xx_0_1_0_0, 1))
        self.connect((self.filter_fft_low_pass_filter_0_0_0, 0), (self.blocks_multiply_xx_0_1_0_0_0_0, 1))
        self.connect((self.filter_fft_low_pass_filter_0_0_1, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_0, 1))
        self.connect((self.filter_fft_low_pass_filter_0_0_2, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_1, 1))
        self.connect((self.filter_fft_low_pass_filter_0_0_3, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_2, 1))
        self.connect((self.filter_fft_low_pass_filter_0_0_4, 0), (self.blocks_multiply_xx_0_1_0_0_0_0_3, 1))
        self.connect((self.filter_fft_low_pass_filter_0_1, 0), (self.blocks_multiply_xx_0_1_0_1, 1))
        self.connect((self.filter_fft_low_pass_filter_0_1_0, 0), (self.blocks_multiply_xx_0_1_0_1_1, 1))
        self.connect((self.filter_fft_low_pass_filter_0_1_1, 0), (self.blocks_multiply_xx_0_1_0_1_2, 1))
        self.connect((self.filter_fft_low_pass_filter_0_1_2, 0), (self.blocks_multiply_xx_0_1_0_1_3, 1))
        self.connect((self.filter_fft_low_pass_filter_0_1_3, 0), (self.blocks_multiply_xx_0_1_0_1_4, 1))
        self.connect((self.filter_fft_low_pass_filter_0_1_4, 0), (self.blocks_multiply_xx_0_1_0_1_5, 1))
        self.connect((self.filter_fft_low_pass_filter_0_2, 0), (self.blocks_multiply_xx_0_1_0_0_0, 1))
        self.connect((self.filter_fft_low_pass_filter_0_2_0, 0), (self.blocks_multiply_xx_0_1_0_0_0_1, 1))
        self.connect((self.filter_fft_low_pass_filter_0_2_1, 0), (self.blocks_multiply_xx_0_1_0_0_0_2, 1))
        self.connect((self.filter_fft_low_pass_filter_0_2_2, 0), (self.blocks_multiply_xx_0_1_0_0_0_3, 1))
        self.connect((self.filter_fft_low_pass_filter_0_2_3, 0), (self.blocks_multiply_xx_0_1_0_0_0_4, 1))
        self.connect((self.filter_fft_low_pass_filter_0_2_4, 0), (self.blocks_multiply_xx_0_1_0_0_0_5, 1))
        self.connect((self.filter_fft_low_pass_filter_0_3, 0), (self.blocks_multiply_xx_0_1_0_1_0, 1))
        self.connect((self.filter_fft_low_pass_filter_0_4, 0), (self.blocks_multiply_xx_0_1_0_1_0_0, 1))
        self.connect((self.filter_fft_low_pass_filter_0_5, 0), (self.blocks_multiply_xx_0_1_0_1_0_1, 1))
        self.connect((self.filter_fft_low_pass_filter_0_6, 0), (self.blocks_multiply_xx_0_1_0_1_0_2, 1))
        self.connect((self.filter_fft_low_pass_filter_0_7, 0), (self.blocks_multiply_xx_0_1_0_1_0_3, 1))
        self.connect((self, 0), (self.blocks_stream_demux_1, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0, 0), (self.filter_fft_low_pass_filter_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0, 0), (self.filter_fft_low_pass_filter_0_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_0, 0), (self.filter_fft_low_pass_filter_0_0_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_1, 0), (self.filter_fft_low_pass_filter_0_0_1, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_1_0, 0), (self.filter_fft_low_pass_filter_0_0_2, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_1_1, 0), (self.filter_fft_low_pass_filter_0_0_3, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_1_2, 0), (self.filter_fft_low_pass_filter_0_0_4, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0_1_2_0, 0), (self.filter_fft_low_pass_filter_0_2_4, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_1, 0), (self.filter_fft_low_pass_filter_0_1, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_1_0, 0), (self.filter_fft_low_pass_filter_0_1_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_1_0_0, 0), (self.filter_fft_low_pass_filter_0_1_1, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_1_0_1, 0), (self.filter_fft_low_pass_filter_0_1_2, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_1_0_2, 0), (self.filter_fft_low_pass_filter_0_1_3, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_2, 0), (self.filter_fft_low_pass_filter_0_2, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_2_0, 0), (self.filter_fft_low_pass_filter_0_2_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_2_0_0, 0), (self.filter_fft_low_pass_filter_0_2_1, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_2_0_1, 0), (self.filter_fft_low_pass_filter_0_2_2, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_2_0_2, 0), (self.filter_fft_low_pass_filter_0_2_3, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_3, 0), (self.filter_fft_low_pass_filter_0_3, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_4, 0), (self.filter_fft_low_pass_filter_0_4, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_4_0, 0), (self.filter_fft_low_pass_filter_0_5, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_4_1, 0), (self.filter_fft_low_pass_filter_0_6, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_4_2, 0), (self.filter_fft_low_pass_filter_0_7, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_4_2_0, 0), (self.filter_fft_low_pass_filter_0_1_4, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.analog_sig_source_x_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_0_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_4.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_0_0_5.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_0.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_0_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_1.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_2.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_3.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_4.set_sampling_freq(self.samp_rate)
        self.analog_sig_source_x_0_0_0_0_1_5.set_sampling_freq(self.samp_rate)
        self.filter_fft_low_pass_filter_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))

    def get_T_set_0(self):
        return self.T_set_0

    def set_T_set_0(self, T_set_0):
        self.T_set_0 = T_set_0
        self.analog_sig_source_x_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_0_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_0_0_5.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_0.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_0_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_1.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_2.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_3.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_4.set_amplitude(self.T_set_0)
        self.analog_sig_source_x_0_0_0_0_1_5.set_amplitude(self.T_set_0)

    def get_T_set(self):
        return self.T_set

    def set_T_set(self, T_set):
        self.T_set = T_set
        self.rational_resampler_xxx_0_2_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_1_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_1_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_1_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_0_1_2_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_1_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_1_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_1_0_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_1_0_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_2_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_2_0_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_2_0_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_2_0_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_3.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_4.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_4_0.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_4_1.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_4_2.set_taps([self.T_set])
        self.rational_resampler_xxx_0_2_0_0_4_2_0.set_taps([self.T_set])

    def get_Scale(self):
        return self.Scale

    def set_Scale(self, Scale):
        self.Scale = Scale

    def get_Ran_value(self):
        return self.Ran_value

    def set_Ran_value(self, Ran_value):
        self.Ran_value = Ran_value

    def get_Level(self):
        return self.Level

    def set_Level(self, Level):
        self.Level = Level
        self.filter_fft_low_pass_filter_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))

    def get_H_rate(self):
        return self.H_rate

    def set_H_rate(self, H_rate):
        self.H_rate = H_rate

    def get_Freq(self):
        return self.Freq

    def set_Freq(self, Freq):
        self.Freq = Freq
        self.analog_sig_source_x_0_0_0_0.set_frequency((self.Freq*25))
        self.analog_sig_source_x_0_0_0_0_0.set_frequency((self.Freq*26))
        self.analog_sig_source_x_0_0_0_0_0_0.set_frequency((self.Freq*28))
        self.analog_sig_source_x_0_0_0_0_0_0_0.set_frequency((self.Freq*30))
        self.analog_sig_source_x_0_0_0_0_0_0_0_0.set_frequency((self.Freq*34))
        self.analog_sig_source_x_0_0_0_0_0_0_0_1.set_frequency((self.Freq*38))
        self.analog_sig_source_x_0_0_0_0_0_0_0_2.set_frequency((self.Freq*42))
        self.analog_sig_source_x_0_0_0_0_0_0_0_3.set_frequency((self.Freq*46))
        self.analog_sig_source_x_0_0_0_0_0_0_1.set_frequency((self.Freq*32))
        self.analog_sig_source_x_0_0_0_0_0_0_2.set_frequency((self.Freq*36))
        self.analog_sig_source_x_0_0_0_0_0_0_3.set_frequency((self.Freq*40))
        self.analog_sig_source_x_0_0_0_0_0_0_4.set_frequency((self.Freq*44))
        self.analog_sig_source_x_0_0_0_0_0_0_5.set_frequency((self.Freq*48))
        self.analog_sig_source_x_0_0_0_0_1.set_frequency((self.Freq*27))
        self.analog_sig_source_x_0_0_0_0_1_0.set_frequency((self.Freq*29))
        self.analog_sig_source_x_0_0_0_0_1_0_0.set_frequency((self.Freq*33))
        self.analog_sig_source_x_0_0_0_0_1_0_1.set_frequency((self.Freq*37))
        self.analog_sig_source_x_0_0_0_0_1_0_2.set_frequency((self.Freq*41))
        self.analog_sig_source_x_0_0_0_0_1_0_3.set_frequency((self.Freq*45))
        self.analog_sig_source_x_0_0_0_0_1_1.set_frequency((self.Freq*31))
        self.analog_sig_source_x_0_0_0_0_1_2.set_frequency((self.Freq*35))
        self.analog_sig_source_x_0_0_0_0_1_3.set_frequency((self.Freq*39))
        self.analog_sig_source_x_0_0_0_0_1_4.set_frequency((self.Freq*43))
        self.analog_sig_source_x_0_0_0_0_1_5.set_frequency((self.Freq*47))

    def get_Filter(self):
        return self.Filter

    def set_Filter(self, Filter):
        self.Filter = Filter
        self.filter_fft_low_pass_filter_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))

    def get_DB(self):
        return self.DB

    def set_DB(self, DB):
        self.DB = DB

    def get_Cut_off(self):
        return self.Cut_off

    def set_Cut_off(self, Cut_off):
        self.Cut_off = Cut_off
        self.filter_fft_low_pass_filter_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_1_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_0.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_1.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_2.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_2_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_3.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_4.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_5.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_6.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))
        self.filter_fft_low_pass_filter_0_7.set_taps(firdes.low_pass(self.Level, self.samp_rate, self.Filter, self.Cut_off, window.WIN_HANN, 6.76))

    def get_Beta(self):
        return self.Beta

    def set_Beta(self, Beta):
        self.Beta = Beta

