# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: 192 Carrier TX
# GNU Radio version: 3.10.12.0

import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from M24_Carrier_TX1 import M24_Carrier_TX1  # grc-generated hier_block
from M24_Carrier_TX2 import M24_Carrier_TX2  # grc-generated hier_block
from M24_Carrier_TX3 import M24_Carrier_TX3  # grc-generated hier_block
from M24_Carrier_TX4 import M24_Carrier_TX4  # grc-generated hier_block
from M24_Carrier_TX5 import M24_Carrier_TX5  # grc-generated hier_block
from M24_Carrier_TX6 import M24_Carrier_TX6  # grc-generated hier_block
from M24_Carrier_TX7 import M24_Carrier_TX7  # grc-generated hier_block
from M24_Carrier_TX8 import M24_Carrier_TX8  # grc-generated hier_block
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import signal
import threading







class M192_Carrier_TX(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "192 Carrier TX",
                gr.io_signature.makev(8, 8, [gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1, gr.sizeof_char*1]),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 384000

        ##################################################
        # Blocks
        ##################################################

        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(0.5)
        self.blocks_add_xx_0 = blocks.add_vcc(1)
        self.M24_Carrier_TX8_0 = M24_Carrier_TX8()
        self.M24_Carrier_TX7_0 = M24_Carrier_TX7()
        self.M24_Carrier_TX6_0 = M24_Carrier_TX6()
        self.M24_Carrier_TX5_0 = M24_Carrier_TX5()
        self.M24_Carrier_TX4_0 = M24_Carrier_TX4()
        self.M24_Carrier_TX3_0 = M24_Carrier_TX3()
        self.M24_Carrier_TX2_0 = M24_Carrier_TX2()
        self.M24_Carrier_TX1_0 = M24_Carrier_TX1()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.M24_Carrier_TX1_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.M24_Carrier_TX2_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.M24_Carrier_TX3_0, 0), (self.blocks_add_xx_0, 2))
        self.connect((self.M24_Carrier_TX4_0, 0), (self.blocks_add_xx_0, 3))
        self.connect((self.M24_Carrier_TX5_0, 0), (self.blocks_add_xx_0, 4))
        self.connect((self.M24_Carrier_TX6_0, 0), (self.blocks_add_xx_0, 5))
        self.connect((self.M24_Carrier_TX7_0, 0), (self.blocks_add_xx_0, 6))
        self.connect((self.M24_Carrier_TX8_0, 0), (self.blocks_add_xx_0, 7))
        self.connect((self.blocks_add_xx_0, 0), (self.blocks_multiply_const_vxx_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self, 0))
        self.connect((self, 0), (self.M24_Carrier_TX1_0, 0))
        self.connect((self, 1), (self.M24_Carrier_TX2_0, 0))
        self.connect((self, 2), (self.M24_Carrier_TX3_0, 0))
        self.connect((self, 3), (self.M24_Carrier_TX4_0, 0))
        self.connect((self, 4), (self.M24_Carrier_TX5_0, 0))
        self.connect((self, 5), (self.M24_Carrier_TX6_0, 0))
        self.connect((self, 6), (self.M24_Carrier_TX7_0, 0))
        self.connect((self, 7), (self.M24_Carrier_TX8_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate

