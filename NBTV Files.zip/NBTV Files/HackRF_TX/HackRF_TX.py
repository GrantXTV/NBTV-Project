#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: OFDM NBTV TX
# Author: VE3XTV
# GNU Radio version: 3.10.12.0

from PyQt5 import Qt
from gnuradio import qtgui
import os
import sys
import logging as log

def get_state_directory() -> str:
    oldpath = os.path.expanduser("~/.grc_gnuradio")
    try:
        from gnuradio.gr import paths
        newpath = paths.persistent()
        if os.path.exists(newpath):
            return newpath
        if os.path.exists(oldpath):
            log.warning(f"Found persistent state path '{newpath}', but file does not exist. " +
                     f"Old default persistent state path '{oldpath}' exists; using that. " +
                     "Please consider moving state to new location.")
            return oldpath
        # Default to the correct path if both are configured.
        # neither old, nor new path exist: create new path, return that
        os.makedirs(newpath, exist_ok=True)
        return newpath
    except (ImportError, NameError):
        log.warning("Could not retrieve GNU Radio persistent state directory from GNU Radio. " +
                 "Trying defaults.")
        xdgstate = os.getenv("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
        xdgcand = os.path.join(xdgstate, "gnuradio")
        if os.path.exists(xdgcand):
            return xdgcand
        if os.path.exists(oldpath):
            log.warning(f"Using legacy state path '{oldpath}'. Please consider moving state " +
                     f"files to '{xdgcand}'.")
            return oldpath
        # neither old, nor new path exist: create new path, return that
        os.makedirs(xdgcand, exist_ok=True)
        return xdgcand

sys.path.append(os.environ.get('GRC_HIER_PATH', get_state_directory()))

from Audio_TX_Set import Audio_TX_Set  # grc-generated hier_block
from M192_Carrier_TX import M192_Carrier_TX  # grc-generated hier_block
from PyQt5 import QtCore
from gnuradio import blocks
from gnuradio import eng_notation
from gnuradio import filter
from gnuradio.filter import firdes
from gnuradio import gr
from gnuradio.fft import window
import signal
from PyQt5 import Qt
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import network
from gnuradio import soapy
import sip
import threading



class HackRF_TX(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "OFDM NBTV TX", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("OFDM NBTV TX")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except BaseException as exc:
            print(f"Qt GUI: Could not set Icon: {str(exc)}", file=sys.stderr)
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("gnuradio/flowgraphs", "HackRF_TX")

        try:
            geometry = self.settings.value("geometry")
            if geometry:
                self.restoreGeometry(geometry)
        except BaseException as exc:
            print(f"Qt GUI: Could not restore geometry: {str(exc)}", file=sys.stderr)
        self.flowgraph_started = threading.Event()

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 200000
        self.UDP_VI = UDP_VI = 1244
        self.UDP_SI = UDP_SI = 1243
        self.UDP_AI = UDP_AI = 1245
        self.Center_Freq = Center_Freq = 29250

        ##################################################
        # Blocks
        ##################################################

        self._UDP_VI_tool_bar = Qt.QToolBar(self)
        self._UDP_VI_tool_bar.addWidget(Qt.QLabel("UDP Video Port " + ": "))
        self._UDP_VI_line_edit = Qt.QLineEdit(str(self.UDP_VI))
        self._UDP_VI_tool_bar.addWidget(self._UDP_VI_line_edit)
        self._UDP_VI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_VI(int(str(self._UDP_VI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_VI_tool_bar, 1, 1, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 2):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._UDP_AI_tool_bar = Qt.QToolBar(self)
        self._UDP_AI_tool_bar.addWidget(Qt.QLabel("UDP Audio Port " + ": "))
        self._UDP_AI_line_edit = Qt.QLineEdit(str(self.UDP_AI))
        self._UDP_AI_tool_bar.addWidget(self._UDP_AI_line_edit)
        self._UDP_AI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_AI(int(str(self._UDP_AI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_AI_tool_bar, 1, 2, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(2, 3):
            self.top_grid_layout.setColumnStretch(c, 1)
        self._Center_Freq_range = qtgui.Range(29000, 29700, 10, 29250, (29700-29000))
        self._Center_Freq_win = qtgui.RangeWidget(self._Center_Freq_range, self.set_Center_Freq, "Center Frequency in kHz", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_grid_layout.addWidget(self._Center_Freq_win, 2, 1, 1, 4)
        for r in range(2, 3):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.soapy_hackrf_sink_0 = None
        dev = 'driver=hackrf'
        stream_args = ''
        tune_args = ['']
        settings = ['']

        self.soapy_hackrf_sink_0 = soapy.sink(dev, "fc32", 1, '',
                                  stream_args, tune_args, settings)
        self.soapy_hackrf_sink_0.set_sample_rate(0, 2000000)
        self.soapy_hackrf_sink_0.set_bandwidth(0, 0)
        self.soapy_hackrf_sink_0.set_frequency(0, (Center_Freq*1000))
        self.soapy_hackrf_sink_0.set_gain(0, 'AMP', True )
        self.soapy_hackrf_sink_0.set_gain(0, 'VGA', min(max(12, 0.0), 47.0))
        self.rational_resampler_xxx_0_2_0_0_0 = filter.rational_resampler_ccc(
                interpolation=2000000,
                decimation=samp_rate,
                taps=[],
                fractional_bw=0)
        self.qtgui_sink_x_0 = qtgui.sink_c(
            1024, #fftsize
            window.WIN_BLACKMAN_hARRIS, #wintype
            0, #fc
            samp_rate, #bw
            "", #name
            True, #plotfreq
            True, #plotwaterfall
            True, #plottime
            True, #plotconst
            None # parent
        )
        self.qtgui_sink_x_0.set_update_time(1.0/10)
        self._qtgui_sink_x_0_win = sip.wrapinstance(self.qtgui_sink_x_0.qwidget(), Qt.QWidget)

        self.qtgui_sink_x_0.enable_rf_freq(False)

        self.top_grid_layout.addWidget(self._qtgui_sink_x_0_win, 3, 1, 1, 4)
        for r in range(3, 4):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(1, 5):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.network_udp_source_0_1 = network.udp_source(gr.sizeof_char, 1, UDP_VI, 0, 34560, False, False, False)
        self.network_udp_source_0_0_0 = network.udp_source(gr.sizeof_char, 1, UDP_AI, 0, 500, False, False, False)
        self.blocks_throttle2_0 = blocks.throttle( gr.sizeof_gr_complex*1, samp_rate, True, 0 if "auto" == "auto" else max( int(float(0.1) * samp_rate) if "auto" == "time" else int(0.1), 1) )
        self.blocks_stream_demux_0 = blocks.stream_demux(gr.sizeof_char*1, (5760,5760,5760,5760,5760,5760))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(1/100)
        self._UDP_SI_tool_bar = Qt.QToolBar(self)
        self._UDP_SI_tool_bar.addWidget(Qt.QLabel("UDP Sync Port" + ": "))
        self._UDP_SI_line_edit = Qt.QLineEdit(str(self.UDP_SI))
        self._UDP_SI_tool_bar.addWidget(self._UDP_SI_line_edit)
        self._UDP_SI_line_edit.editingFinished.connect(
            lambda: self.set_UDP_SI(int(str(self._UDP_SI_line_edit.text()))))
        self.top_grid_layout.addWidget(self._UDP_SI_tool_bar, 1, 3, 1, 1)
        for r in range(1, 2):
            self.top_grid_layout.setRowStretch(r, 1)
        for c in range(3, 4):
            self.top_grid_layout.setColumnStretch(c, 1)
        self.M192_Carrier_TX_0 = M192_Carrier_TX()
        self.Audio_TX_Set_0 = Audio_TX_Set()


        ##################################################
        # Connections
        ##################################################
        self.connect((self.Audio_TX_Set_0, 1), (self.M192_Carrier_TX_0, 7))
        self.connect((self.Audio_TX_Set_0, 0), (self.M192_Carrier_TX_0, 6))
        self.connect((self.M192_Carrier_TX_0, 0), (self.blocks_throttle2_0, 0))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.soapy_hackrf_sink_0, 0))
        self.connect((self.blocks_stream_demux_0, 5), (self.M192_Carrier_TX_0, 5))
        self.connect((self.blocks_stream_demux_0, 4), (self.M192_Carrier_TX_0, 4))
        self.connect((self.blocks_stream_demux_0, 1), (self.M192_Carrier_TX_0, 1))
        self.connect((self.blocks_stream_demux_0, 3), (self.M192_Carrier_TX_0, 3))
        self.connect((self.blocks_stream_demux_0, 2), (self.M192_Carrier_TX_0, 2))
        self.connect((self.blocks_stream_demux_0, 0), (self.M192_Carrier_TX_0, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.qtgui_sink_x_0, 0))
        self.connect((self.blocks_throttle2_0, 0), (self.rational_resampler_xxx_0_2_0_0_0, 0))
        self.connect((self.network_udp_source_0_0_0, 0), (self.Audio_TX_Set_0, 0))
        self.connect((self.network_udp_source_0_1, 0), (self.blocks_stream_demux_0, 0))
        self.connect((self.rational_resampler_xxx_0_2_0_0_0, 0), (self.blocks_multiply_const_vxx_0, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("gnuradio/flowgraphs", "HackRF_TX")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.blocks_throttle2_0.set_sample_rate(self.samp_rate)
        self.qtgui_sink_x_0.set_frequency_range(0, self.samp_rate)

    def get_UDP_VI(self):
        return self.UDP_VI

    def set_UDP_VI(self, UDP_VI):
        self.UDP_VI = UDP_VI
        Qt.QMetaObject.invokeMethod(self._UDP_VI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_VI)))

    def get_UDP_SI(self):
        return self.UDP_SI

    def set_UDP_SI(self, UDP_SI):
        self.UDP_SI = UDP_SI
        Qt.QMetaObject.invokeMethod(self._UDP_SI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_SI)))

    def get_UDP_AI(self):
        return self.UDP_AI

    def set_UDP_AI(self, UDP_AI):
        self.UDP_AI = UDP_AI
        Qt.QMetaObject.invokeMethod(self._UDP_AI_line_edit, "setText", Qt.Q_ARG("QString", str(self.UDP_AI)))

    def get_Center_Freq(self):
        return self.Center_Freq

    def set_Center_Freq(self, Center_Freq):
        self.Center_Freq = Center_Freq
        self.soapy_hackrf_sink_0.set_frequency(0, (self.Center_Freq*1000))




def main(top_block_cls=HackRF_TX, options=None):

    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()
    tb.flowgraph_started.set()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
