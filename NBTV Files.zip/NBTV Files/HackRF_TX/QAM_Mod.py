# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: QAM Mod
# GNU Radio version: 3.10.12.0

from gnuradio import analog
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class QAM_Mod(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "QAM Mod",
                gr.io_signature.makev(2, 2, [gr.sizeof_char*1, gr.sizeof_char*1]),
                gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 500

        ##################################################
        # Blocks
        ##################################################

        self.blocks_uchar_to_float_0_0 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0 = blocks.uchar_to_float()
        self.blocks_sub_xx_0 = blocks.sub_ff(1)
        self.blocks_float_to_complex_0 = blocks.float_to_complex(1)
        self.blocks_add_xx_1 = blocks.add_vff(1)
        self.analog_fm_preemph_0_0_0 = analog.fm_preemph(fs=samp_rate, tau=(68e-5), fh=0)
        self.analog_fm_preemph_0_0 = analog.fm_preemph(fs=samp_rate, tau=(68e-5), fh=0)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_fm_preemph_0_0, 0), (self.blocks_float_to_complex_0, 1))
        self.connect((self.analog_fm_preemph_0_0_0, 0), (self.blocks_float_to_complex_0, 0))
        self.connect((self.blocks_add_xx_1, 0), (self.analog_fm_preemph_0_0_0, 0))
        self.connect((self.blocks_float_to_complex_0, 0), (self, 0))
        self.connect((self.blocks_sub_xx_0, 0), (self.analog_fm_preemph_0_0, 0))
        self.connect((self.blocks_uchar_to_float_0, 0), (self.blocks_add_xx_1, 1))
        self.connect((self.blocks_uchar_to_float_0, 0), (self.blocks_sub_xx_0, 1))
        self.connect((self.blocks_uchar_to_float_0_0, 0), (self.blocks_add_xx_1, 0))
        self.connect((self.blocks_uchar_to_float_0_0, 0), (self.blocks_sub_xx_0, 0))
        self.connect((self, 0), (self.blocks_uchar_to_float_0_0, 0))
        self.connect((self, 1), (self.blocks_uchar_to_float_0, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate

