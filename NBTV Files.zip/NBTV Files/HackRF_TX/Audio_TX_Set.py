# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: Audio TX_Set
# GNU Radio version: 3.10.12.0

from gnuradio import analog
from gnuradio import blocks
from gnuradio import gr
from gnuradio.filter import firdes
from gnuradio.fft import window
import sys
import signal
import threading







class Audio_TX_Set(gr.hier_block2):
    def __init__(self):
        gr.hier_block2.__init__(
            self, "Audio TX_Set",
                gr.io_signature(1, 1, gr.sizeof_char*1),
                gr.io_signature.makev(2, 2, [gr.sizeof_char*1, gr.sizeof_char*1]),
        )

        ##################################################
        # Variables
        ##################################################
        self.samp_rate = samp_rate = 32000

        ##################################################
        # Blocks
        ##################################################

        self.blocks_uchar_to_float_0_2 = blocks.uchar_to_float()
        self.blocks_uchar_to_float_0_1 = blocks.uchar_to_float()
        self.blocks_stream_demux_1 = blocks.stream_demux(gr.sizeof_char*1, (1,1))
        self.blocks_float_to_uchar_0_0 = blocks.float_to_uchar(1, 1, 0)
        self.blocks_float_to_uchar_0 = blocks.float_to_uchar(1, 1, 0)
        self.analog_fm_preemph_0_0 = analog.fm_preemph(fs=24000, tau=(50e-6), fh=12000)
        self.analog_fm_preemph_0 = analog.fm_preemph(fs=24000, tau=(50e-6), fh=12000)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.analog_fm_preemph_0, 0), (self.blocks_float_to_uchar_0, 0))
        self.connect((self.analog_fm_preemph_0_0, 0), (self.blocks_float_to_uchar_0_0, 0))
        self.connect((self.blocks_float_to_uchar_0, 0), (self, 0))
        self.connect((self.blocks_float_to_uchar_0_0, 0), (self, 1))
        self.connect((self.blocks_stream_demux_1, 0), (self.blocks_uchar_to_float_0_1, 0))
        self.connect((self.blocks_stream_demux_1, 1), (self.blocks_uchar_to_float_0_2, 0))
        self.connect((self.blocks_uchar_to_float_0_1, 0), (self.analog_fm_preemph_0, 0))
        self.connect((self.blocks_uchar_to_float_0_2, 0), (self.analog_fm_preemph_0_0, 0))
        self.connect((self, 0), (self.blocks_stream_demux_1, 0))


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate

