# NBTV SDR 1.37 — VE3XTV

NBTV SDR puts VE3XTV's NBTV system on the air. Encode and transmit, receive and decode, all in one window.

It is made from NBTV OFDM Lab 5.31 and uses the same codec and modem (`nbtv_core.py`), so its signal is the lab's signal. The lab's test parts have been taken out:

- the simulated channel (Noise / SNR dB and its sliders)
- the data frame monitor
- the RF out display
- Real world, Clean channel, the SNR sweep and the Sync test
- the Fast speed (NBTV SDR always runs in real time)

## New in 1.37 — UDP streams (udp://@:1234)

- **Stream URL: udp://@:1234** now works on its own. A big receive buffer that a burst can't overrun
  (fifo_size=1000000, overrun_nonfatal=1) is added by itself; options you type are kept.
- **Live network streams** (udp, rtp, srt, tcp) are no longer paced with -re. They come at their own rate, and
  pacing them let the receive buffer overrun.
- **Windows: the stream's sound comes on the same connection.** ffmpeg sends it back over a local TCP link,
  instead of the stream being opened a second time. A UDP port can't be listened to twice, so before this the
  pictures or the sound went missing on Windows. This also suits IPTV servers that allow only one connection.
- **No second listener:** for UDP / RTP the "no sound yet - open it on its own connection" fallback is no longer
  tried, since it would take the stream's packets.
- **Tested** with ffmpeg sending a test picture and a 1 kHz tone as MPEG-TS to UDP port 1234. The pictures came
  through and the sound was continuous, on both the Linux path and the Windows path.

## New in 1.36 — the sender under the picture

- The **sender's details** now sit right under the received picture, on two centred lines, so they're always on
  screen. The first line has the callsign, locator, latitude and longitude, and distance and bearing from your
  Locator. The second has the title and time (UTC). At the bottom (1.34, 1.35) they were cut off on most screens,
  because the RX panel is taller than the window.
- The receiver's information is one full-width block at the bottom again.

## New in 1.35 — Sender and Receiver side by side

- At the bottom of Decoder and RX, the **Sender** block (left) and the receiver's information (**Receiver**, right)
  now sit side by side, so the sender's details no longer run off the bottom of the window.
- **The Sender block** is in short lines: callsign; locator; latitude and longitude; distance and bearing from
  your own Locator; time (UTC); title.

## New in 1.34 — the mode word always sent; Sender block on the RX side

- **Send mode word (TX)** is gone: the mode word is always sent. It carries the settings, plus the callsign,
  time, locator and title.
- **Sender (from the mode word)**, at the bottom of Decoder and RX, shows the station being received:
  - **Callsign.**
  - **Location:** its locator, as latitude and longitude. With your own Locator set, it also gives how far
    away the sender is and its bearing from you, e.g. "FN06ab (46.06°N 79.96°W) 5495 km, bearing 053°".
  - **Time:** when the sender has ticked Time stamp.
  - **Title.**
  It replaces the "Station:" line in the receiver's information. Frames out of turn still show there.

## New in 1.33 — Lip sync slider removed

- The Lip sync slider is gone from the Decoder and RX side: picture and sound stay in step on their own.
  Lip sync is fixed at 0, so a value saved by an older version no longer shifts the sound.

## New in 1.32 — LO spike removal

- **Remove the LO spike** (Radio / I/Q setup, under the tabs; on by default): the HackRF's, RTL-SDR's and
  SoapySDR radios' LO leakage is taken out of their samples on receive. It is a steady tone at the LO, the
  LO offset below the channel. A slow running average of the raw samples (over 0.5 s) is that tone alone,
  since the scrambled OFDM carriers average to nothing, and it is subtracted before the channel is tuned.
  That is a notch well under 1 Hz wide. The Airspy (tuned straight on the channel) and the ExSDR radio are
  not touched.
- **Why it's needed:** the spike's level is fixed while a received signal can be weak. When the receiver
  corrects a frequency offset the spike no longer sits on a carrier position, so a strong one spills into
  the carriers near the channel's edge. Measured with a 37 Hz offset, at 25 dB C/N (data PSNR): a spike level
  with the signal costs 0.7 dB, +10 dB above it 4.4 dB, +20 dB 12 dB and +30 dB 23 dB. With the removal, every
  case comes back to exactly the no-spike figure, in 120x96 and 180x96.
- The hardware line shows the spike's level ("LO spike -42 dBFS, removed").

## New in 1.31 — LO offset down to 50 kHz

- The LO offset (HackRF, RTL-SDR, SDRplay / SoapySDR) can now go down to 50 kHz (it was 60): the
  SDR's DC spike then sits at the channel's edge, just outside the OFDM signal. (The note in 1.31 that it
  lands on a video carrier in 120x96 was wrong: the lowest carriers are 1 to 2.5 kHz inside the edge in
  every layout, so the edge itself carries nothing.)

## New in 1.30 — hardware settings fix (LO offset)

- **Fix: the HackRF's LO offset wouldn't update.** The same LO offset box is on the HackRF, RTL-SDR and
  SDRplay / SoapySDR tabs, and each copy kept its own value. A change on one tab left the others showing the
  old one, and when one of those lost focus it wrote the old value back. All the copies now share one value.
- **Decimals** are taken in the LO offset (e.g. 250.5 kHz). Boxes that need a whole number (RTL-SDR device
  index, ppm) say so rather than silently ignoring the entry.
- **Out of range or not a number:** the log now says so (the LO offset is 50 to 900 kHz from 1.31), and the box goes back to the value in use. Before, the entry was silently ignored and the
  box kept showing it.
- A new LO offset now retunes the SDR at once.

## New in 1.29 — languages

- **Language** choice in the top bar, next to Help: English (the default), Deutsch, Nederlands, Français,
  Italiano, Español. It changes the labels, buttons, tick boxes and window titles in every window at once,
  including Radio / I/Q setup, Sound devices, the large view, the Help window's title and the test card
  editor. The receiver's status lines are translated as they update. It is kept with your settings.
- **Not translated:** the log, the Help text, radio and product names, units, the mode descriptions and the
  receiver's detailed sound and clean-up figures. Settings keep their English values inside, so saved
  settings and the settings word are the same in every language.
- **New file:** nbtv_lang.py, with the translations. A text with no translation shows in English.

## New in 1.28 — Auto I/Q swap on the RX side

- Auto I/Q swap only acts on receive, so it has moved from Encode and TX to Decoder and RX, under the
  RX input line, with its "I/Q as sent / swapped" label beside it.

## New in 1.27 — sources under the playback controls

- The picture source row (Test card ... Stream URL, Test card editor...), the Sound in row, the Screen X / Y
  sliders (with Screen), the Sound in dB slider and the source information line now sit under Load / Play /
  Pause / 4:3 / 16:9, below the TX viewer. The "Sending" caption sits right under the viewer.

## New in 1.26 — playback controls under the viewer

- Load..., Play / Pause and 4:3 / 16:9 now sit just under the playback slider, below the TX viewer.

## New in 1.25 — Radio / I/Q setup button moved

- The Radio / I/Q setup... button now sits below the TX viewer, to the right of the RX on hardware choice.

## New in 1.24 — TX viewer at the top

- The TX viewer (with its position bar) now sits at the top of the Encode and TX panel, just under the TX
  button; all the settings follow below it, in the same order as before.

## New in 1.23 — RX estimate tick box

- **RX estimate** now has a tick box beside Track colour, as in the lab (on by default, kept with your
  settings), so you can compare the picture with and without it.

## New in 1.22 — RX estimate, Spread Hadamard (from NBTV OFDM Lab 5.42)

- **RX estimate**, always on in every mode (no switch): the receiver takes the key picture's luma and colour
  each as its local average plus as much of its own detail as stands above the noise it measures (a local
  LLSE estimate, 5x5). Receiver only, so it works on any NBTV signal. Measured in the lab, plain noise: it
  saves 1 to 3.7 dB of C/N for the same picture at -3 to 10 dB (120x96 mode 1 most, 2.8-3.7 dB on the test
  card); on HF fading it adds up to 2 dB to the picture; it makes no difference above 20 dB.
- **Spread: Hadamard**, a fourth choice beside Off / Groups / Whole band: each picture value on 16 carriers
  taken right across the band (Walsh-Hadamard codes, I and Q kept apart). The best of the spreads on a
  fading path; like them, no help for an echo longer than the guard. It travels in the mode word, so a
  receiver follows it (the lab 5.42 and NBTV SDR 1.22 and later).

## New in 1.21 — mode descriptions tidied

- The mode text for 120x96 modes 3 (KMM) and 4 (KK) and 180x96 mode 1 (KMD) no longer refers to CPU6,
  CPU1 and CPU7 - those were the old software's names.

## New in 1.20 — Auto I/Q swap keeps the centre frequency

- **Auto I/Q swap** no longer steps through settings that move the signal (that made the RX display jump).
  The signal stays where it is on the channel; the receiver works out which way round the OFDM signal is
  and flips it about the centre if it is mirrored.  While searching it tries the same samples both ways
  and keeps the way that locks (on 180x96, where a mirrored signal can partly lock, the better sync fit,
  then the mode word).  Found in about 2 s either way, the same as a normal lock.
- From RX takes the flip into account.
- Tested: 120x96 and 180x96, 200 and 400 carriers, all three syncs, 0 to 20 dB C/N, both ways round - always
  the right way with the mode word (NBTV SDR always sends it); through a sound card loop with the inputs
  exchanged: flipped and locked in 2 s, back in 2 s when the swap was taken away; trims and drag unchanged.

## New in 1.19 — Auto I/Q swap; mode 3 is KMM

- **Auto I/Q swap (RX)**, on by default: if the receiver can't lock it tries, a few seconds each, the I/Q
  as sent, the RX's swapped, the TX's swapped (mirrored on its image twice its channel offset away, moved
  back home), both, and another station's swapped TX with no offset - and keeps the one that locks.  The
  label beside it says what it found; for your own swapped TX the log says to tick Swap I/Q for the card.
- Worked out for the ExSDR card to itself, the card to a HackRF and a HackRF to a HackRF, every way round
  (each case put right exactly by one of them).  Tested through a sound card loop with the card's two
  inputs exchanged: found in 12 s, locked; back to as sent 15 s after the swap was taken away.
- 120x96 **mode 3 is now named KMM** (was L KMM).

## New in 1.18 — drag the spectrum to centre the signal

- On the 200 kHz spectrum and waterfall, **click and drag** the received signal to the centre line, as in
  ExSDR: the drag sets **RX trim** live (shown while you drag); the channel stays put.  **Shift** while
  dragging moves a tenth as much (about 33 Hz a pixel), for the last few hundred Hz; From RX then finishes.
  A plain click still tunes.
- Works on receive and on your own signal with RX during TX.
- Tested through a sound card loop: TX 1500 Hz off -> no signal; dragged 4.5 pixels -> RX trim +1500 Hz,
  locked, 0 Hz; a plain click still moved the channel and left the trim alone.

## New in 1.17 — TX and RX frequency trims

- **TX trim Hz** and **RX trim Hz** under TX on / RX on, for any hardware (sound card or SDR), live: TX trim
  moves what is sent up by that many Hz, RX trim moves what comes in down.  For two pieces of hardware a
  little apart in frequency (1.5 kHz, say): the receiver locks only within about +-250 Hz (+-125 Hz on 400
  carriers), so set RX trim near by hand first.
- **From RX**: once locked, adds the frequency error the receiver still measures to RX trim, so the signal
  sits exactly on the channel.
- Tested through a sound card loop: TX trim +1500 Hz -> no signal; RX trim +1450 Hz -> locked, +50.0 Hz
  measured; From RX -> RX trim +1500 Hz, 0.0 Hz.
- RX trim was the HackRF tab's (SDR only); it is now in the main window for all hardware (a saved value
  is kept).

## New in 1.16 — TX and RX on different hardware

- **TX on** and **RX on** replace the one Hardware choice: for example TX on the ExSDR radio and RX on a
  HackRF.  The same one for both works as before.  An older setting starts with its Hardware on both
  sides (receive-only SDRs on RX only).
- The channel is the same for both; the tuning range is what both can reach.  The ExSDR radio's LO and
  card offset are set when it is in use on either side, an SDR's frequency likewise.  The radio is sent
  TX / RX only when it is the transmitter.
- **RX during TX** (off by default): with two different pieces of hardware the receiver keeps running while
  you transmit, so you see and decode your own signal.  Mind the receiver's input (dummy load, attenuator).
- Swap I/Q is now the sound card's only, as the I/Q trim already was: it never touches an SDR's I/Q
  (with the card on one side and an SDR on the other, a card swap would have mirrored the SDR).

## New in 1.15 — stereo sound at 0-10 dB C/N; balance control (from NBTV OFDM Lab 5.41)

- **Sound fix:** at 0-10 dB C/N the quieter side of the stereo could fade out.  The sound NR was told
  the noise was 14-38% higher than it is, its frame-to-frame smoothing held quiet sound at the floor,
  and Strong took the programme down with the hiss below 2 dB.  All three fixed: the quieter side keeps
  8-14 dB more at 0-10 dB C/N (about 3 dB more hiss left on the louder side).  Below 10 dB the stereo
  still blends towards mono, by design.
- **Balance L/R** slider under Volume.
- The codec is the lab's 5.41 core (modes 5 and 6 still not offered here).

## New in 1.14 — fewer choices

- The 120x96 encoder modes are 1 KWMD, 2 KWMM, 3 L KMM and 4 KK again: the lab's experimental modes
  5 (KWMD-MC) and 6 (L KMM-MS) are not offered (a saved mode 5 starts as mode 1, mode 6 as mode 3).
  A signal sent in them by the lab is still decoded.
- Video emphasis is always on: the Video emph tick box is gone.  (The lab's Video emph must be on to
  work with NBTV SDR.)

## New in 1.13 — video emphasis in every mode (from NBTV OFDM Lab 5.38)

- **Video emph** (next to I/Q flip), on by default: the transmitter lifts the fine detail of each
  picture's brightness (soft knee, the colour untouched), the receiver takes it back down with the
  channel's fine-grain noise.  About +0.5 to +1.5 dB at 0-10 dB C/N in every mode, little or nothing
  above 20 dB.  Not sent in the mode word: both stations must have it set the same.
- The codec is the lab's 5.38, so the 120x96 encoder modes now include 5 KWMD-MC (mode 1's signal,
  the 240x192 detail carried along the motion at the receiver) and 6 L KMM-MS (mode 3 with a 192 line
  key as line sums and differences).
- The Auto line names the mode by the format the sync found (the mode word's codes now mean different
  modes in 120x96 and 180x96).

## New in 1.12

- **The lines under the frequency readout now wrap at the readout's width.** These are the LO / radio line and the lock / C/N line, and each now runs to two short lines. Before, they could widen the frequency block and push the 10 m and 6 m channel buttons past the right edge of the centre panel.

## New in 1.11 — ExSDR pre-amp and attenuator, 6 m channels

- **Pre-amp and Attenuator for the ExSDR radio.** These are in Radio / I/Q setup, on the ExSDR radio tab.
  - Ticking one sends `P1` / `P0` or `A1` / `A0`, then reads the setting back with `?P` / `?A`.
  - The tick boxes follow what the radio reports. On connecting, the window takes the radio's own settings.
  - **Read back** asks the radio again.
  - The radio line under the frequency shows "pre-amp on/off, attenuator on/off".
- **6 m channels.** Ten channels of 100 kHz fill 51.0 to 52.0 MHz. Their centres run from 51.050 to 51.950 MHz. They sit to the right of the 10 m channels, in two columns of five.
  - A button jumps to that channel's centre.
  - The lit button is the channel you are on. A dimmer one means you are inside it but off its centre.

## New in 1.10 — the "cuda" fix carried to CuPy's own probe

**What went wrong in 1.9.** "Canary probe child process exited with code 1": CuPy 14 checks its libraries by starting a small Python process of its own, the "canary" probe. 1.9's fix only applied inside NBTV SDR itself. The probe process still found the GNU Radio `cuda` package first and failed in the same way.

**The fix.** NBTV SDR now puts a small `cuda` package of its own first on the path, in `~/.cache/nbtv_cuda_shim`. That package points `cuda` at NVIDIA's folders. It does this for NBTV SDR and, through PYTHONPATH, for every process NBTV SDR starts, so CuPy's probe gets it too. Nothing of yours is moved or changed.

**Checking it.** `--gpu-check` now also shows where a child process finds `cuda`. It should be the NVIDIA folder, not the GNU Radio one.

## New in 1.9 — the GPU and a GNU Radio package called "cuda"

**What `--gpu-check` showed.** CuPy (cupy-cuda12x 14.2) is fine. CuPy 14 imports NVIDIA's `cuda` package (`cuda.pathfinder`), but there is another package called `cuda` in `/usr/local/lib/python3.12/dist-packages/cuda`. It is a GNU Radio block (`gpu_kernel`), and Python picks it over NVIDIA's wherever it sits.

That block imports GNU Radio, which Ubuntu builds for NumPy 1.x. NumPy 2.5.4 in `~/.local` then stops GNU Radio from loading, so CuPy failed with "initialization failed".

**The fix.** Before NBTV SDR loads CuPy, it now makes `cuda` mean NVIDIA's package, for this program only. The other package is left where it is, and it is only set aside inside NBTV SDR. `--gpu-check` says when it has done this.

If CuPy still stops, the GPU line and `--gpu-check` give the next reason. Now that the error names the GNU Radio package, the message says that rather than suggesting a CuPy update.

## New in 1.8 — finding out why the GPU won't load

- **A clearer reason when CuPy won't load.** The GPU line used to show only CuPy's last words (for example just "initialization failed"). Now it gives:
  - the line that actually says why
  - the CuPy, NumPy and Python versions in use
  - the likely fix

  The usual cause of "initialization failed" is a CuPy built for NumPy 1.x running under NumPy 2.x. The fix for that is to update CuPy for that same Python: `/usr/bin/python3 -m pip install -U cupy-cuda12x`, or `cupy-cuda11x` to match your CUDA.
- **`python3 nbtv_sdr.py --gpu-check`** prints everything in one go:
  - Python and where it is
  - the NumPy version
  - the CuPy package and version
  - the card and driver, and the CUDA version from `nvidia-smi`
  - a test on the card, or CuPy's full error

## New in 1.7 — no more bursts of noise on the RX spectrum

**The cause.** After TX or a loop back test, with nothing coming in, the receiver could fall behind what the card or HackRF was delivering, and stay behind.

- While behind, it was working from samples already read in. In those frames no new hardware input reached the spectrum, so the spectrum and waterfall drew the received channel *after its AGC* instead.
- The AGC lifts bare noise up to the transmitter's level, so those frames showed as bursts of noise about 60–77 dB over the noise floor.

It was reproduced here, with a stand-in sound card looped back: 10–13 bursts in the 15 s after TX or after the loop back test, and none before.

**The fixes:**

- The 200 kHz spectrum and waterfall now draw only what comes in from the hardware, never the AGC'd channel.
- On receive, the hardware's input now sets the pace, as it already did for TX. A receiver that falls behind catches up at once instead of staying behind.
- Frames still in the pipeline from before a TX / RX / loop back switch are not drawn after it. TX rows are marked by their own frame, so they are never drawn as RX.

Same test after the fixes: no bursts after TX or after the loop back test.

## New in 1.6 — Windows version

NBTV SDR is now one program for Linux and Windows. **NBTV_SDR_Windows.zip** has the same files, plus `run_nbtv_sdr.bat`, `build_windows.bat` (makes `NBTV_SDR.exe` with the NBTV logo as its icon), `requirements.txt` and `README_Windows.txt`.

- **Windows sound devices.** Every card shows up once for each Windows sound system, so the I/Q devices are now listed with theirs, e.g. "Line (Realtek) [Windows WASAPI]". WASAPI is listed first; it opens in exclusive mode where the card allows, which gives the card's own 192 kHz. An older setting with a bare name picks whichever of its entries runs at 192 kHz.
- **Tools next to the program are found.** ffmpeg, hackrf_transfer, rtl_sdr and airspyhf_rx can sit in the program's folder, on Linux too.
- **`--list-devices`** prints the sound devices (and which can run at 192 kHz), the SDRs and the serial ports.
- **Windows fonts and display.** It uses Segoe UI and Consolas, and stays sharp on high-DPI screens.
- **The Windows version has not been tried on a real Windows PC yet.** The way the sound devices are named and picked was tested here, against stand-in Windows sound devices.

## New in 1.5

- **Software loop back:** a new tick box to the right of the cable Loop back test (Encode and TX).
  - The transmitter goes straight into the receiver inside the program. No sound card, SDR or radio is used, and the radio stays on RX.
  - Use it to check the codec and modem on their own, with any Hardware setting.
  - The status reads SOFTWARE LOOP, and the RX input line says "software loop back".
  - TX is locked out while it is on. Only one loop runs at a time, so ticking either loop box clears the other.

## New in 1.4

- **More SDR hardware for HF.** The Hardware list is now a drop-down with seven choices:

  | Hardware | TX | Tunes | Through |
  |---|---|---|---|
  | None | – | – | – |
  | ExSDR radio | yes | 0.36 – 65 MHz | serial port + 192 kHz sound card |
  | HackRF | yes | 1 MHz – 6 GHz | hackrf_transfer, 2 Msps |
  | RTL-SDR (V3 / V4) | receive only | 0.5 MHz – 1.7 GHz | rtl_sdr, 2 Msps (V4 built-in HF, V3 direct sampling, or a 125 MHz upconverter) |
  | Airspy HF+ / Discovery | receive only | 0.5 – 260 MHz | airspyhf_rx, 192 kHz |
  | SDRplay RSP | receive only | 1 MHz – 2 GHz | SoapySDR (SoapySDRPlay3), 2 Msps |
  | SoapySDR (other, e.g. LimeSDR) | yes, where the radio can | 1 MHz – 6 GHz | SoapySDR, 2 Msps |

  - Radio / I/Q setup now has one tab for each kind of hardware, with its own settings. The 2 Msps SDRs are set the LO offset below the channel, so their DC spike stays out of it.
  - With a receive-only SDR, the TX button says so and stays on receive.
  - Tested here: the RTL-SDR and Airspy HF+ input paths, against stand-in tools giving a known tone; it came out at the right frequency and level. The SoapySDR path could not be tested here (no SoapySDR module).
- **TX drop-outs in the hardware loop back test.** Three changes:
  - While it is going out of real hardware (TX, or the loop back test), the program now works at the hardware's pace instead of the computer clock's. A frame that is late is made up at once, instead of the card running dry.
  - If the picture source isn't ready for a frame (a video file or stream falling behind), the last pictures go out again rather than leaving a gap.
  - If the output buffer does run dry, it starts again half full, not after a whole buffer of silence. The buffer is now 500 ms to start with.
  - Tested with a stand-in sound card looped back for 60 s: locked all the way, 50 dB C/N, no underruns.
- **RX information** under the audio meters now has one item per line (C/N and pilots, sound, clean-up, A/V, station) and room for eight lines, so it no longer gets cut off.
- **A rare upscaler error fixed:** on a completely flat picture (blank or black), the Super-res motion step could fail with "Singular matrix".
- **120x96 mode 2** is now named **240x192x12.5 KWMM** (it was "KWMM L"). The NBTV OFDM Lab gets the same name.

## New in 1.3

- **10 m channels:** buttons for Ch 1 to Ch 5 sit to the right of the frequency readout, as ExSDR has its band buttons. Each channel is 100 kHz wide, and together they fill 29.0 to 29.5 MHz:

  | Channel | Centre | Covers |
  |---|---|---|
  | Ch 1 | 29.050 MHz | 29.0 – 29.1 MHz |
  | Ch 2 | 29.150 MHz | 29.1 – 29.2 MHz |
  | Ch 3 | 29.250 MHz | 29.2 – 29.3 MHz |
  | Ch 4 | 29.350 MHz | 29.3 – 29.4 MHz |
  | Ch 5 | 29.450 MHz | 29.4 – 29.5 MHz |

  - A button jumps to that channel's centre and updates the frequency display. The ExSDR radio's LO is set there too.
  - The button for the channel you are on is lit. A dimmer light means you are inside that channel but off its centre.
- **Top bar and window title** show just the name and version.

## New in 1.2

- **Spectrum and waterfall in real time.** They used to jump once a data frame (about 4 times a second, 3 lines at a time). Now there is a spectrum line for every 50 ms of signal, and the window plays them out over the frame's own time: about 20 lines a second, the same in Loop back, receive and transmit.
- **Receiver's information line moved.** The RX information (C/N, pilots, sound, clean-up, callsign) is now under the Audio out (L / R) meters, at the bottom of Decoder and RX.
- **Frequency readout and signal meter line up on the left** with the Modem (TX and RX) settings.
- **NBTV logo** as the window's icon and in the top bar (`nbtv_logo.png`).
- **Help:** the Help button (top right) opens `NBTV_SDR_Help.txt`, a guide to every part of the window, the hardware setup, and what to check when something is wrong.

## New in 1.1

- **Centre layout:** the frequency readout and signal meter now sit centred under the spectrum, with the **Modem** settings full width below them, so they're no longer pushed off to the right.
- **Loop back test** (Encode and TX, under the TX button): checks the ExSDR radio's 192 kHz sound card with a cable from line out to line in.
  - The transmitter goes out of the card and back in, and the receiver decodes what comes back, as in the lab's Loop.
  - The radio is left on RX (no TX command), and TX is locked out while the test runs.
  - The HackRF can't do it, because it is half duplex.
- **Serial port:** Radio / I/Q setup has a drop-down of the serial ports it finds (`/dev/ttyUSB*`, `ttyACM*`, `/dev/serial/by-id/*`, `ttyS*`). **Refresh** looks again, and choosing one connects.
- **Setup button:** "Setup..." is now **Radio / I/Q setup...**.
  - The Sound devices window says these are the programme sound only, not the radio's I/Q, and has a button to Radio / I/Q setup.
  - **Loopback** under Sound in records the computer's own sound output as the programme sound. It is not the I/Q loop test.
- **GPU** has moved to the top bar, to the right of Multi-core.

## Running it

    python3 nbtv_sdr.py

Keep `nbtv_core.py`, `nbtv_radio.py`, `testcard_editor.py`, `testcards/`, `nbtv_logo.png` and `NBTV_SDR_Help.txt` in the same folder. It needs the same packages as the lab: python3, numpy and tkinter, and ideally Pillow and ffmpeg. For the sound card it needs sounddevice or ALSA `hw:` devices; for the HackRF it needs `hackrf_transfer` (`sudo apt install hackrf`).

Settings are kept in `~/.config/nbtv_sdr.json`, separate from the lab's own.

## The window

- **Encode and TX** (left)
  - **TX** goes on the air. Press it again to come back to receive. NBTV SDR is half duplex and always starts on receive.
  - **Hardware**: None, ExSDR radio or HackRF. **Setup...** opens the hardware window.
  - **TX level dBFS** sets the output level.
  - Below that are the picture source, sound and encoder mode, as in the lab.
- **On the air** (centre), the settings shared by TX and RX:
  - **Spectrum and waterfall, 200 kHz** across the top, laid out like ExSDR's.
    - On receive it shows what comes in from the hardware: the sound card's ±96 kHz, or 200 kHz out of the HackRF's 2 Msps.
    - On transmit it shows what goes out, in orange.
    - The channel's 100 kHz is shaded, and the yellow line marks its centre.
    - The kHz scale is the real frequency.
    - Click the spectrum to tune there. The mouse wheel over it tunes 1 kHz a click.
  - **Frequency** is the channel's centre, in Hz, like ExSDR's readout.
    - Use the wheel on a digit, or click its top half to go up and its bottom half to go down.
    - You can also type kHz into the box, or use the −1k / +1k buttons.
    - Right-click the readout to change its colour.
    - The line under it shows the radio's LO and where the channel sits.
  - **Signal meter** sits under the frequency.
    - It reads the channel's level coming in, in S units. S9 is set in Setup (−60 dBFS to start with).
    - Under it you get the lock state, C/N and the frequency error.
    - On transmit it shows TX and the output level.
  - **Modem**: guard, equaliser, long symbols, 16 pilots, frame rate, TX peaks, spread, Fold peaks, I/Q flip, Auto mode, mode word, callsign, sync, Resync and RX mute, all as in the lab.
  - The hardware status line, the vector scopes, the carriers and the sync display are also here.
- **Decoder and RX** (right) works as in the lab. Sound out is on to start with.
  - On transmit, the receiver monitors your own signal and is labelled MONITOR.

## Hardware

**ExSDR radio** is the homebrew HF SDR, the same one ExSDR uses.

- **Control** goes over its serial port, written the same way as ExSDR's:
  - 9600 baud 8N1, no terminator.
  - `F` (kHz), `TX` and `RX`, with the same gaps between commands (600 ms around a frequency command).
  - The window follows the radio's replies.
- **I/Q** goes through its 192 kHz sound card. Set Card output and Card input in Setup; ALSA `hw:C,D` goes past the mixers.
- **Tuning**: the radio's LO is in kHz.
  - The channel sits **Channel in card kHz** from it (0 to start with).
  - Tuning within ±20 kHz of that is done in the card's I/Q, so no command goes to the radio.
  - Past that, the LO is moved with one `F` command.
- **TX** sends `TX` to the radio, then the I/Q. Coming back, the I/Q stops first, then `RX` is sent.
- Card check, Release card and I/Q trim are as in the lab.

**HackRF** runs through `hackrf_transfer` at 2 Msps.

- It tunes 1 MHz to 6 GHz, with a 10-digit readout.
- The LO sits *LO offset* (250 kHz) below the frequency, so its DC spike stays out of the channel.
- Each new frequency restarts `hackrf_transfer`. That happens once you stop tuning for 0.4 s, not on every wheel click.
- TX and RX take turns, and each turn restarts it too.
- Gains and amps are set in Setup.

**None** gives no I/Q at all. The receiver hears nothing. On TX the signal is drawn and monitored here only.

## Not tested on real hardware yet

All of this was tested here with no sound card, HackRF or radio attached:

- **Radio control**: against a stand-in radio on a pseudo serial port. It got `?F ?P ?A`, `F29250`, `F29290`, `TX` and `RX` and its replies came back correctly.
- **Card input path**: a modem signal 12 kHz off centre was fed into the receive path at 192 kHz. It locked at 32 dB C/N, and the 200 kHz spectrum showed the channel centred.

First tries on the air should start with a low TX level.
